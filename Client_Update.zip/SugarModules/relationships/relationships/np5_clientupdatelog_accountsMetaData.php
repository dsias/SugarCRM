<?php
// created: 2013-07-02 00:24:20
$dictionary["np5_clientupdatelog_accounts"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'np5_clientupdatelog_accounts' => 
    array (
      'lhs_module' => 'Accounts',
      'lhs_table' => 'accounts',
      'lhs_key' => 'id',
      'rhs_module' => 'np5_ClientUpdateLog',
      'rhs_table' => 'np5_clientupdatelog',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'np5_clientulog_accounts_c',
      'join_key_lhs' => 'np5_clientb5e1ccounts_ida',
      'join_key_rhs' => 'np5_client5ca7datelog_idb',
    ),
  ),
  'table' => 'np5_clientulog_accounts_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'np5_clientb5e1ccounts_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'np5_client5ca7datelog_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'np5_clientutelog_accountsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'np5_clientutelog_accounts_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'np5_clientb5e1ccounts_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'np5_clientutelog_accounts_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'np5_client5ca7datelog_idb',
      ),
    ),
  ),
);
?>
