<?php
// created: 2013-07-02 00:24:20
$dictionary["np5_ClientUpdateLog"]["fields"]["np5_clientupdatelog_accounts"] = array (
  'name' => 'np5_clientupdatelog_accounts',
  'type' => 'link',
  'relationship' => 'np5_clientupdatelog_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
$dictionary["np5_ClientUpdateLog"]["fields"]["np5_clientupdatelog_accounts_name"] = array (
  'name' => 'np5_clientupdatelog_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'np5_clientb5e1ccounts_ida',
  'link' => 'np5_clientupdatelog_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["np5_ClientUpdateLog"]["fields"]["np5_clientb5e1ccounts_ida"] = array (
  'name' => 'np5_clientb5e1ccounts_ida',
  'type' => 'link',
  'relationship' => 'np5_clientupdatelog_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
);
