<?php
// created: 2013-07-02 00:24:20
$dictionary["Account"]["fields"]["np5_clientupdatelog_accounts"] = array (
  'name' => 'np5_clientupdatelog_accounts',
  'type' => 'link',
  'relationship' => 'np5_clientupdatelog_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
);
