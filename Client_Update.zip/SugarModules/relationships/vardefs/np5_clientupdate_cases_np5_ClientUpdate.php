<?php
// created: 2013-07-02 00:24:20
$dictionary["np5_ClientUpdate"]["fields"]["np5_clientupdate_cases"] = array (
  'name' => 'np5_clientupdate_cases',
  'type' => 'link',
  'relationship' => 'np5_clientupdate_cases',
  'source' => 'non-db',
  'vname' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_CASES_TITLE',
);
$dictionary["np5_ClientUpdate"]["fields"]["np5_clientupdate_cases_name"] = array (
  'name' => 'np5_clientupdate_cases_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_CASES_TITLE',
  'save' => true,
  'id_name' => 'np5_clientb371escases_ida',
  'link' => 'np5_clientupdate_cases',
  'table' => 'cases',
  'module' => 'Cases',
  'rname' => 'name',
);
$dictionary["np5_ClientUpdate"]["fields"]["np5_clientb371escases_ida"] = array (
  'name' => 'np5_clientb371escases_ida',
  'type' => 'link',
  'relationship' => 'np5_clientupdate_cases',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
);
