<?php
// created: 2013-06-30 23:56:41
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-01 00:00:04
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-01 02:25:51
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-01 02:36:45
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-01 05:20:04
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-01 05:22:42
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-02 00:23:47
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
<?php
// created: 2013-07-02 00:24:20
$layout_defs["Cases"]["subpanel_setup"]["np5_clientupdate_cases"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdate',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATE_CASES_FROM_NP5_CLIENTUPDATE_TITLE',
  'get_subpanel_data' => 'np5_clientupdate_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);
?>
