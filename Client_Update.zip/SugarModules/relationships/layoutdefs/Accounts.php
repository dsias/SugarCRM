<?php
// created: 2013-07-01 02:25:51
$layout_defs["Accounts"]["subpanel_setup"]["np5_clientupdatelog_accounts"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdateLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
  'get_subpanel_data' => 'np5_clientupdatelog_accounts',
  'top_buttons' => 
  array (
  ),
);
?>
<?php
// created: 2013-07-01 02:36:45
$layout_defs["Accounts"]["subpanel_setup"]["np5_clientupdatelog_accounts"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdateLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
  'get_subpanel_data' => 'np5_clientupdatelog_accounts',
  'top_buttons' => 
  array (
  ),
);
?>
<?php
// created: 2013-07-01 05:20:05
$layout_defs["Accounts"]["subpanel_setup"]["np5_clientupdatelog_accounts"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdateLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
  'get_subpanel_data' => 'np5_clientupdatelog_accounts',
  'top_buttons' => 
  array (
  ),
);
?>
<?php
// created: 2013-07-01 05:22:42
$layout_defs["Accounts"]["subpanel_setup"]["np5_clientupdatelog_accounts"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdateLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
  'get_subpanel_data' => 'np5_clientupdatelog_accounts',
  'top_buttons' => 
  array (
  ),
);
?>
<?php
// created: 2013-07-02 00:23:47
$layout_defs["Accounts"]["subpanel_setup"]["np5_clientupdatelog_accounts"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdateLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
  'get_subpanel_data' => 'np5_clientupdatelog_accounts',
  'top_buttons' => 
  array (
  ),
);
?>
<?php
// created: 2013-07-02 00:24:20
$layout_defs["Accounts"]["subpanel_setup"]["np5_clientupdatelog_accounts"] = array (
  'order' => 100,
  'module' => 'np5_ClientUpdateLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_NP5_CLIENTUPDATELOG_TITLE',
  'get_subpanel_data' => 'np5_clientupdatelog_accounts',
  'top_buttons' => 
  array (
  ),
);
?>
