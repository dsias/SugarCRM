<?php
$module_name = 'np5_ClientUpdateLog';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
          1 => 
          array (
            'name' => 'status',
            'studio' => 'visible',
            'label' => 'LBL_STATUS',
          ),
        ),
        1 => 
        array (
          0 => '',
          1 => 
          array (
            'name' => 'status_description',
            'studio' => 'visible',
            'label' => 'LBL_STATUS_DESCRIPTION',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'np5_clientupdatelog_accounts_name',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'from_name',
            'label' => 'LBL_FROM_NAME',
          ),
          1 => 
          array (
            'name' => 'to_name',
            'label' => 'LBL_TO_NAME',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'from_email',
            'label' => 'LBL_FROM_EMAIL',
          ),
          1 => 
          array (
            'name' => 'to_email',
            'label' => 'LBL_TO_EMAIL',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'subject',
            'label' => 'LBL_SUBJECT',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'body',
            'studio' => 'visible',
            'label' => 'LBL_BODY',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
      ),
    ),
  ),
);
?>
