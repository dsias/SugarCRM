<?php
$module_name='np5_ClientUpdateLog';
$subpanel_layout = array (
  'top_buttons' => 
  array (
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '10%',
      'default' => true,
    ),
    'status' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_STATUS',
      'sortable' => false,
      'width' => '10%',
    ),
    'status_description' => 
    array (
      'type' => 'text',
      'studio' => 'visible',
      'vname' => 'LBL_STATUS_DESCRIPTION',
      'sortable' => false,
      'width' => '10%',
      'default' => true,
    ),
    'to_email' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_TO_EMAIL',
      'width' => '20%',
      'default' => true,
    ),
    'subject' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_SUBJECT',
      'width' => '40%',
      'default' => true,
    ),
    'date_entered' => 
    array (
      'type' => 'datetime',
      'vname' => 'LBL_DATE_ENTERED',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'widget_class' => 'SubPanelEditButton',
      'module' => 'np5_ClientUpdateLog',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'np5_ClientUpdateLog',
      'width' => '5%',
      'default' => true,
    ),
  ),
);