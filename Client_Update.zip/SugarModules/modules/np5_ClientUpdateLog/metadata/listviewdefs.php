<?php
$module_name = 'np5_ClientUpdateLog';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'sortable' => false,
    'width' => '10%',
  ),
  'STATUS_DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_STATUS_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'FROM_EMAIL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FROM_EMAIL',
    'width' => '10%',
    'default' => true,
  ),
  'TO_EMAIL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TO_EMAIL',
    'width' => '10%',
    'default' => true,
  ),
  'SUBJECT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SUBJECT',
    'width' => '10%',
    'default' => true,
  ),
  'NP5_CLIENTUPDATELOG_ACCOUNTS_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'np5_clientupdatelog_accounts',
    'label' => 'LBL_NP5_CLIENTUPDATELOG_ACCOUNTS_FROM_ACCOUNTS_TITLE',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'TO_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TO_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'BODY' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_BODY',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'FROM_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FROM_NAME',
    'width' => '10%',
    'default' => false,
  ),
);
?>
