<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

$app_list_strings['moduleList']['np5_ClientUpdate'] = 'ClientUpdate';
$app_list_strings['moduleList']['np5_ClientUpdateLog'] = 'ClientUpdateLog';
$app_list_strings['moduleList']['np5_ClientUpdateSetting'] = 'ClientUpdateSetting';
$app_list_strings['send_day_list']['01'] = '01';
$app_list_strings['send_day_list']['02'] = '02';
$app_list_strings['send_day_list']['03'] = '03';
$app_list_strings['send_day_list']['04'] = '04';
$app_list_strings['send_day_list']['05'] = '05';
$app_list_strings['send_day_list']['06'] = '06';
$app_list_strings['send_day_list']['07'] = '07';
$app_list_strings['send_day_list']['08'] = '08';
$app_list_strings['send_day_list']['09'] = '09';
$app_list_strings['send_day_list']['10'] = '10';
$app_list_strings['send_day_list']['11'] = '11';
$app_list_strings['send_day_list']['12'] = '12';
$app_list_strings['send_day_list']['13'] = '13';
$app_list_strings['send_day_list']['14'] = '14';
$app_list_strings['send_day_list']['15'] = '15';
$app_list_strings['send_day_list']['16'] = '16';
$app_list_strings['send_day_list']['17'] = '17';
$app_list_strings['send_day_list']['18'] = '18';
$app_list_strings['send_day_list']['19'] = '19';
$app_list_strings['send_day_list']['20'] = '20';
$app_list_strings['send_day_list']['21'] = '21';
$app_list_strings['send_day_list']['22'] = '22';
$app_list_strings['send_day_list']['23'] = '23';
$app_list_strings['send_day_list']['24'] = '24';
$app_list_strings['send_day_list']['25'] = '25';
$app_list_strings['send_day_list']['26'] = '26';
$app_list_strings['send_day_list']['27'] = '27';
$app_list_strings['send_day_list']['28'] = '28';
$app_list_strings['send_day_list']['29'] = '29';
$app_list_strings['send_day_list']['30'] = '30';
$app_list_strings['send_day_list']['31'] = '31';
$app_list_strings['status_3']['Active'] = 'Active';
$app_list_strings['status_3']['Inactive'] = 'Inactive';
$app_list_strings['status_4']['Send'] = 'Send';
$app_list_strings['status_4']['Error'] = 'Error';
