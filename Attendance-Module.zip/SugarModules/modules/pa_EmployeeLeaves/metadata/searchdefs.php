<?php
$module_name = 'pa_EmployeeLeaves';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      0 => 'name',
      1 => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'leave_year' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_LEAVE_YEAR',
        'width' => '10%',
        'default' => true,
        'name' => 'leave_year',
      ),
      'no_of_leaves' => 
      array (
        'type' => 'decimal',
        'label' => 'LBL_NO_OF_LEAVES',
        'width' => '10%',
        'default' => true,
        'name' => 'no_of_leaves',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
