<?php
$module_name='pa_EmployeeLeaves';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'pa_EmployeeLeaves',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'leave_year' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_LEAVE_YEAR',
      'width' => '10%',
      'default' => true,
    ),
    'no_of_leaves' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_NO_OF_LEAVES',
      'width' => '10%',
      'default' => true,
    ),
    'date_modified' => 
    array (
      'vname' => 'LBL_DATE_MODIFIED',
      'width' => '45%',
      'default' => true,
    ),
  ),
);