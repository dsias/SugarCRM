<?php
$module_name = 'pa_EmployeeLeaves';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '15%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'LEAVE_YEAR' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_LEAVE_YEAR',
    'width' => '10%',
    'default' => true,
  ),
  'NO_OF_LEAVES' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_NO_OF_LEAVES',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
