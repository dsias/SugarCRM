<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class pa_EmployeeDetailViewDetail extends ViewDetail {
	var $currSymbol;
	function pa_EmployeeDetailViewDetail(){
 		parent::ViewDetail();
 	}
	
	function display(){
		$html = "";
		if($this->bean->employee_picture != "")
		{
			$html = "<img src='employee_pic/".$this->bean->user_id_c."/".$this->bean->employee_picture."' height='90' width='80' />";
		}

		$this->ss->assign('EMPLOYEE_PIC',$html);

		parent::display();
	}
}
?>
