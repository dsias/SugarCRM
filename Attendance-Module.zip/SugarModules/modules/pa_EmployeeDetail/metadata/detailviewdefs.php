<?php
$module_name = 'pa_EmployeeDetail';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_ADDRESS_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_contact_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'employee_id',
            'label' => 'LBL_EMPLOYEE_ID',
          ),
          1 => 
          array (
            'name' => 'employee_picture',
            'label' => 'LBL_EMPLOYEE_PICTURE',
            'customCode' => '{$EMPLOYEE_PIC}',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'employee_status',
            'studio' => 'visible',
            'label' => 'LBL_EMPLOYEE_STATUS',
          ),
          1 => 
          array (
            'name' => 'immediate_supervisor',
            'studio' => 'visible',
            'label' => 'LBL_IMMEDIATE_SUPERVISOR',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_of_joining',
            'label' => 'LBL_DATE_OF_JOINING',
          ),
          1 => 
          array (
            'name' => 'last_date_of_office',
            'label' => 'LBL_LAST_DATE_OF_OFFICE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'employee_title',
            'studio' => 'visible',
            'label' => 'LBL_EMPLOYEE_TITLE',
          ),
          1 => 
          array (
            'name' => 'employee_department',
            'studio' => 'visible',
            'label' => 'LBL_EMPLOYEE_DEPARTMENT',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'leave_administrator',
            'label' => 'LBL_LEAVE_ADMINISTRATOR',
          ),
          1 => 
          array (
            'name' => 'offline_administrator',
            'label' => 'LBL_OFFLINE_ADMINISTRATOR',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'crm_user',
            'studio' => 'visible',
            'label' => 'LBL_CRM_USER',
          ),
          1 => 'assigned_user_name',
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'comment' => 'Date record last modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        7 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'comment' => 'First name of the contact',
            'label' => 'LBL_FIRST_NAME',
          ),
          1 => 
          array (
            'name' => 'last_name',
            'comment' => 'Last name of the contact',
            'label' => 'LBL_LAST_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'date_of_birth',
            'label' => 'LBL_DATE_OF_BIRTH',
          ),
          1 => 
          array (
            'name' => 'gender',
            'studio' => 'visible',
            'label' => 'LBL_GENDER',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'cnic_no',
            'label' => 'LBL_CNIC_NO',
          ),
          1 => 
          array (
            'name' => 'passport_number',
            'label' => 'LBL_PASSPORT_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'labour_card_no',
            'label' => 'LBL_LABOUR_CARD_NO',
          ),
          1 => 'phone_home',
        ),
        4 => 
        array (
          0 => 'phone_mobile',
          1 => 'phone_other',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'skype_name',
            'label' => 'LBL_SKYPE_NAME',
          ),
          1 => 'phone_fax',
        ),
        6 => 
        array (
          0 => 'email1',
        ),
      ),
      'lbl_address_information' => 
      array (
        0 => 
        array (
          0 => 'primary_address_street',
          1 => 'alt_address_street',
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'emergency_contact_name',
            'label' => 'LBL_EMERGENCY_CONTACT_NAME',
          ),
          1 => 
          array (
            'name' => 'emergency_contact_no',
            'label' => 'LBL_EMERGENCY_CONTACT_NO ',
          ),
        ),
      ),
    ),
  ),
);
?>
