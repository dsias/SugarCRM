<?php
$module_name = 'pa_EmployeeDetail';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'employee_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_EMPLOYEE_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'employee_id',
      ),
      'search_name' => 
      array (
        'name' => 'search_name',
        'label' => 'LBL_NAME',
        'type' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'date_of_joining' => 
      array (
        'type' => 'date',
        'label' => 'LBL_DATE_OF_JOINING',
        'width' => '10%',
        'default' => true,
        'name' => 'date_of_joining',
      ),
    ),
    'advanced_search' => 
    array (
      'employee_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_EMPLOYEE_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'employee_id',
      ),
      'first_name' => 
      array (
        'name' => 'first_name',
        'default' => true,
        'width' => '10%',
      ),
      'crm_user' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_CRM_USER',
        'id' => 'USER_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'crm_user',
      ),
      'last_name' => 
      array (
        'name' => 'last_name',
        'default' => true,
        'width' => '10%',
      ),
      'passport_number' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PASSPORT_NUMBER',
        'width' => '10%',
        'default' => true,
        'name' => 'passport_number',
      ),
      'address_city' => 
      array (
        'name' => 'address_city',
        'default' => true,
        'width' => '10%',
      ),
      'cnic_no' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CNIC_NO',
        'width' => '10%',
        'default' => true,
        'name' => 'cnic_no',
      ),
      'created_by_name' => 
      array (
        'name' => 'created_by_name',
        'default' => true,
        'width' => '10%',
      ),
      'gender' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_GENDER',
        'width' => '10%',
        'name' => 'gender',
      ),
      'date_of_joining' => 
      array (
        'type' => 'date',
        'label' => 'LBL_DATE_OF_JOINING',
        'width' => '10%',
        'default' => true,
        'name' => 'date_of_joining',
      ),
      'employee_title' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_EMPLOYEE_TITLE',
        'width' => '10%',
        'name' => 'employee_title',
      ),
      'employee_status' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_EMPLOYEE_STATUS',
        'width' => '10%',
        'name' => 'employee_status',
      ),
      'employee_department' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_EMPLOYEE_DEPARTMENT',
        'width' => '10%',
        'name' => 'employee_department',
      ),
      'email' => 
      array (
        'name' => 'email',
        'default' => true,
        'width' => '10%',
      ),
      'date_of_birth' => 
      array (
        'type' => 'date',
        'label' => 'LBL_DATE_OF_BIRTH',
        'width' => '10%',
        'default' => true,
        'name' => 'date_of_birth',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
