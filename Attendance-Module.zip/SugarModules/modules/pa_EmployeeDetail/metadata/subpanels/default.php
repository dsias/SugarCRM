<?php
$module_name='pa_EmployeeDetail';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'People',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'employee_id' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_EMPLOYEE_ID',
      'width' => '10%',
      'default' => true,
    ),
    'name' => 
    array (
      'name' => 'name',
      'vname' => 'LBL_LIST_NAME',
      'sort_by' => 'last_name',
      'sort_order' => 'asc',
      'widget_class' => 'SubPanelDetailViewLink',
      'module' => 'Contacts',
      'width' => '40%',
      'default' => true,
    ),
    'date_of_joining' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_DATE_OF_JOINING',
      'width' => '10%',
      'default' => true,
    ),
    'employee_title' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_EMPLOYEE_TITLE',
      'width' => '10%',
    ),
    'employee_department' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_EMPLOYEE_DEPARTMENT',
      'width' => '10%',
    ),
    'employee_status' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_EMPLOYEE_STATUS',
      'width' => '10%',
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'Contacts',
      'width' => '5%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'Contacts',
      'width' => '5%',
      'default' => true,
    ),
    'first_name' => 
    array (
      'name' => 'first_name',
      'usage' => 'query_only',
    ),
    'last_name' => 
    array (
      'name' => 'last_name',
      'usage' => 'query_only',
    ),
    'salutation' => 
    array (
      'name' => 'salutation',
      'usage' => 'query_only',
    ),
  ),
);