<?php
$popupMeta = array (
    'moduleMain' => 'pa_EmployeeDetail',
    'varName' => 'pa_EmployeeDetail',
    'orderBy' => 'pa_employeedetail.first_name, pa_employeedetail.last_name',
    'whereClauses' => array (
  'employee_id' => 'pa_employeedetail.employee_id',
  'name' => 'pa_employeedetail.name',
  'employee_status' => 'pa_employeedetail.employee_status',
),
    'searchInputs' => array (
  2 => 'employee_id',
  3 => 'name',
  4 => 'employee_status',
),
    'searchdefs' => array (
  'employee_id' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_ID',
    'width' => '10%',
    'name' => 'employee_id',
  ),
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'employee_status' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_STATUS',
    'width' => '10%',
    'name' => 'employee_status',
  ),
),
    'listviewdefs' => array (
  'EMPLOYEE_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_ID',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_OF_JOINING' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_OF_JOINING',
    'width' => '10%',
    'default' => true,
  ),
  'EMPLOYEE_STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_STATUS',
    'width' => '10%',
  ),
),
);
