<?php
$module_name = 'pa_EmployeeDetail';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'enctype' => 'multipart/form-data',
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_ADDRESS_INFORMATION' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_contact_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'employee_id',
            'label' => 'LBL_EMPLOYEE_ID',
          ),
          1 => 
          array (
            'name' => 'employee_picture',
            'label' => 'LBL_EMPLOYEE_PICTURE',
            'customCode' => '<input type="file" id="employee_picture" name="employee_picture" />',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'employee_status',
            'studio' => 'visible',
            'label' => 'LBL_EMPLOYEE_STATUS',
          ),
          1 => 
          array (
            'name' => 'immediate_supervisor',
            'studio' => 'visible',
            'label' => 'LBL_IMMEDIATE_SUPERVISOR',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_of_joining',
            'label' => 'LBL_DATE_OF_JOINING',
          ),
          1 => 
          array (
            'name' => 'last_date_of_office',
            'label' => 'LBL_LAST_DATE_OF_OFFICE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'employee_title',
            'studio' => 'visible',
            'label' => 'LBL_EMPLOYEE_TITLE',
          ),
          1 => 
          array (
            'name' => 'employee_department',
            'studio' => 'visible',
            'label' => 'LBL_EMPLOYEE_DEPARTMENT',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'leave_administrator',
            'label' => 'LBL_LEAVE_ADMINISTRATOR',
          ),
          1 => 
          array (
            'name' => 'offline_administrator',
            'label' => 'LBL_OFFLINE_ADMINISTRATOR',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'crm_user',
            'studio' => 'visible',
            'label' => 'LBL_CRM_USER',
          ),
          1 => 'assigned_user_name',
        ),
        6 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'customCode' => '{html_options name="salutation" id="salutation" options=$fields.salutation.options selected=$fields.salutation.value}&nbsp;<input name="first_name"  id="first_name" size="25" maxlength="25" type="text" value="{$fields.first_name.value}">',
          ),
          1 => 'last_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'date_of_birth',
            'label' => 'LBL_DATE_OF_BIRTH',
          ),
          1 => 
          array (
            'name' => 'gender',
            'studio' => 'visible',
            'label' => 'LBL_GENDER',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'cnic_no',
            'label' => 'LBL_CNIC_NO',
          ),
          1 => 
          array (
            'name' => 'passport_number',
            'label' => 'LBL_PASSPORT_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'labour_card_no',
            'label' => 'LBL_LABOUR_CARD_NO',
          ),
          1 => 'phone_home',
        ),
        4 => 
        array (
          0 => 'phone_mobile',
          1 => 'phone_other',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'skype_name',
            'label' => 'LBL_SKYPE_NAME',
          ),
          1 => 'phone_fax',
        ),
        6 => 
        array (
          0 => 'email1',
        ),
      ),
      'lbl_address_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'primary_address_street',
            'hideLabel' => true,
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'primary',
              'rows' => 2,
              'cols' => 30,
              'maxlength' => 150,
            ),
          ),
          1 => 
          array (
            'name' => 'alt_address_street',
            'hideLabel' => true,
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'alt',
              'copy' => 'primary',
              'rows' => 2,
              'cols' => 30,
              'maxlength' => 150,
            ),
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'emergency_contact_name',
            'label' => 'LBL_EMERGENCY_CONTACT_NAME',
          ),
          1 => 
          array (
            'name' => 'emergency_contact_no',
            'label' => 'LBL_EMERGENCY_CONTACT_NO ',
          ),
        ),
      ),
    ),
  ),
);
?>
