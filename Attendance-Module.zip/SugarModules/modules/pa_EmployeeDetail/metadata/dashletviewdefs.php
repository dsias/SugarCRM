<?php
$dashletData['pa_EmployeeDetailDashlet']['searchFields'] = array (
  'employee_id' => 
  array (
    'default' => '',
  ),
  'employee_status' => 
  array (
    'default' => '',
  ),
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
);
$dashletData['pa_EmployeeDetailDashlet']['columns'] = array (
  'employee_id' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_ID',
    'width' => '10%',
    'default' => true,
    'name' => 'employee_id',
  ),
  'name' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'date_of_joining' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_OF_JOINING',
    'width' => '10%',
    'default' => true,
    'name' => 'date_of_joining',
  ),
  'employee_status' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_STATUS',
    'width' => '10%',
    'name' => 'employee_status',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'phone_home' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_HOME_PHONE',
    'width' => '10%',
    'default' => false,
    'name' => 'phone_home',
  ),
  'phone_mobile' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_MOBILE_PHONE',
    'width' => '10%',
    'default' => false,
    'name' => 'phone_mobile',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'employee_department' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_DEPARTMENT',
    'width' => '10%',
    'name' => 'employee_department',
  ),
  'employee_title' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_TITLE',
    'width' => '10%',
    'name' => 'employee_title',
  ),
  'date_of_birth' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_OF_BIRTH',
    'width' => '10%',
    'default' => false,
    'name' => 'date_of_birth',
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
);
