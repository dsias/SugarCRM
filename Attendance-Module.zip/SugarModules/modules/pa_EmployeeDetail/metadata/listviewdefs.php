<?php
$module_name = 'pa_EmployeeDetail';
$listViewDefs [$module_name] = 
array (
  'FULL_NAME' => 
  array (
    'type' => 'fullname',
    'studio' => 
    array (
      'listview' => false,
    ),
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'EMPLOYEE_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_ID',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'link' => true,
    'orderBy' => 'last_name',
    'default' => true,
    'related_fields' => 
    array (
      0 => 'first_name',
      1 => 'last_name',
      2 => 'salutation',
    ),
  ),
  'EMPLOYEE_STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_STATUS',
    'width' => '10%',
  ),
  'PHONE_MOBILE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_MOBILE_PHONE',
    'default' => true,
  ),
  'PHONE_HOME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_HOME_PHONE',
    'default' => true,
  ),
  'DATE_OF_JOINING' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_OF_JOINING',
    'width' => '10%',
    'default' => true,
  ),
  'EMAIL1' => 
  array (
    'width' => '15%',
    'label' => 'LBL_EMAIL_ADDRESS',
    'sortable' => false,
    'link' => true,
    'customCode' => '{$EMAIL1_LINK}{$EMAIL1}</a>',
    'default' => true,
  ),
  'PHONE_WORK' => 
  array (
    'width' => '15%',
    'label' => 'LBL_OFFICE_PHONE',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'ALT_ADDRESS_COUNTRY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_COUNTRY',
    'width' => '10%',
    'default' => false,
  ),
  'LABOUR_CARD_NO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LABOUR_CARD_NO',
    'width' => '10%',
    'default' => false,
  ),
  'OFFLINE_ADMINISTRATOR' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_OFFLINE_ADMINISTRATOR',
    'width' => '10%',
  ),
  'IMMEDIATE_SUPERVISOR' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_IMMEDIATE_SUPERVISOR',
    'id' => 'PA_EMPLOYEEDETAIL_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'LEAVE_ADMINISTRATOR' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_LEAVE_ADMINISTRATOR',
    'width' => '10%',
  ),
  'DATE_OF_BIRTH' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_OF_BIRTH',
    'width' => '10%',
    'default' => false,
  ),
  'GENDER' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_GENDER',
    'width' => '10%',
  ),
  'EMERGENCY_CONTACT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMERGENCY_CONTACT_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'EMERGENCY_CONTACT_NO' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_EMERGENCY_CONTACT_NO ',
    'width' => '10%',
    'default' => false,
  ),
  'SKYPE_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SKYPE_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'CNIC_NO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CNIC_NO',
    'width' => '10%',
    'default' => false,
  ),
  'CRM_USER' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_CRM_USER',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
  'PASSPORT_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PASSPORT_NUMBER',
    'width' => '10%',
    'default' => false,
  ),
  'LAST_DATE_OF_OFFICE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_LAST_DATE_OF_OFFICE',
    'width' => '10%',
    'default' => false,
  ),
  'EMPLOYEE_DEPARTMENT' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_DEPARTMENT',
    'width' => '10%',
  ),
  'EMPLOYEE_TITLE' => 
  array (
    'type' => 'enum',
    'default' => false,
    'studio' => 'visible',
    'label' => 'LBL_EMPLOYEE_TITLE',
    'width' => '10%',
  ),
  'ALT_ADDRESS_POSTALCODE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_POSTALCODE',
    'width' => '10%',
    'default' => false,
  ),
  'ALT_ADDRESS_STATE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_STATE',
    'width' => '10%',
    'default' => false,
  ),
  'ALT_ADDRESS_CITY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_CITY',
    'width' => '10%',
    'default' => false,
  ),
  'ALT_ADDRESS_STREET_3' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_STREET_3',
    'width' => '10%',
    'default' => false,
  ),
  'ALT_ADDRESS_STREET_2' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_STREET_2',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_COUNTRY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_COUNTRY',
    'width' => '10%',
    'default' => false,
  ),
  'ALT_ADDRESS_STREET' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALT_ADDRESS_STREET',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_STATE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_STATE',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_POSTALCODE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_POSTALCODE',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_CITY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_CITY',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_STREET_3' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_STREET_3',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_STREET_2' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_STREET_2',
    'width' => '10%',
    'default' => false,
  ),
  'PRIMARY_ADDRESS_STREET' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRIMARY_ADDRESS_STREET',
    'width' => '10%',
    'default' => false,
  ),
  'LAST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAST_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'FIRST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIRST_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'SALUTATION' => 
  array (
    'type' => 'enum',
    'label' => 'LBL_SALUTATION',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'PHONE_OTHER' => 
  array (
    'width' => '10%',
    'label' => 'LBL_WORK_PHONE',
    'default' => false,
  ),
  'PHONE_FAX' => 
  array (
    'width' => '10%',
    'label' => 'LBL_FAX_PHONE',
    'default' => false,
  ),
  'ADDRESS_STREET' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PRIMARY_ADDRESS_STREET',
    'default' => false,
  ),
  'ADDRESS_CITY' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PRIMARY_ADDRESS_CITY',
    'default' => false,
  ),
  'ADDRESS_STATE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PRIMARY_ADDRESS_STATE',
    'default' => false,
  ),
  'ADDRESS_POSTALCODE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PRIMARY_ADDRESS_POSTALCODE',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_CREATED',
    'default' => false,
  ),
);
?>
