<?php
$module_name = 'pa_Qualification';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'COUNTRY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COUNTRY',
    'width' => '10%',
    'default' => true,
  ),
  'PA_QUALIFICATION_PA_EMPLOYEEDETAIL_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_PA_QUALIFICATION_PA_EMPLOYEEDETAIL_FROM_PA_EMPLOYEEDETAIL_TITLE',
    'id' => 'PA_QUALIFICATION_PA_EMPLOYEEDETAILPA_EMPLOYEEDETAIL_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'DEGREE' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_DEGREE',
    'width' => '10%',
    'default' => true,
  ),
  'MAJOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MAJOR',
    'width' => '10%',
    'default' => true,
  ),
  'GPA_PERCENTAGE_GRADE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_GPA_PERCENTAGE_GRADE',
    'width' => '10%',
    'default' => true,
  ),
  'COMPLETION_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_COMPLETION_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
  'CITY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CITY',
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
