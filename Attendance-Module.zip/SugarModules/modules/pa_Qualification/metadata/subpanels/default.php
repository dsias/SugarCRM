<?php
$module_name='pa_Qualification';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'pa_Qualification',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '10%',
      'default' => true,
    ),
    'degree' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_DEGREE',
      'width' => '10%',
      'default' => true,
    ),
    'major' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_MAJOR',
      'width' => '10%',
      'default' => true,
    ),
    'country' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_COUNTRY',
      'width' => '10%',
      'default' => true,
    ),
    'gpa_percentage_grade' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_GPA_PERCENTAGE_GRADE',
      'width' => '10%',
      'default' => true,
    ),
    'completion_date' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_COMPLETION_DATE',
      'width' => '10%',
      'default' => true,
    ),
    'date_modified' => 
    array (
      'vname' => 'LBL_DATE_MODIFIED',
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'pa_Qualification',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'pa_Qualification',
      'width' => '5%',
      'default' => true,
    ),
  ),
);