<?php
$module_name = 'pa_Qualification';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'country' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_COUNTRY',
        'width' => '10%',
        'default' => true,
        'name' => 'country',
      ),
    ),
    'advanced_search' => 
    array (
      'country' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_COUNTRY',
        'width' => '10%',
        'default' => true,
        'name' => 'country',
      ),
      'degree' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_DEGREE',
        'width' => '10%',
        'default' => true,
        'name' => 'degree',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'major' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_MAJOR',
        'width' => '10%',
        'default' => true,
        'name' => 'major',
      ),
      'gpa_percentage_grade' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_GPA_PERCENTAGE_GRADE',
        'width' => '10%',
        'default' => true,
        'name' => 'gpa_percentage_grade',
      ),
      'completion_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_COMPLETION_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'completion_date',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
