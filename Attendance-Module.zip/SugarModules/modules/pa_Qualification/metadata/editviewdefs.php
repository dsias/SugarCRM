<?php
$module_name = 'pa_Qualification';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'pa_qualification_pa_employeedetail_name',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'country',
            'label' => 'LBL_COUNTRY',
          ),
          1 => 
          array (
            'name' => 'city',
            'label' => 'LBL_CITY',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'degree',
            'studio' => 'visible',
            'label' => 'LBL_DEGREE',
          ),
          1 => 
          array (
            'name' => 'major',
            'label' => 'LBL_MAJOR',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'gpa_percentage_grade',
            'label' => 'LBL_GPA_PERCENTAGE_GRADE',
          ),
          1 => 
          array (
            'name' => 'completion_date',
            'label' => 'LBL_COMPLETION_DATE',
          ),
        ),
        4 => 
        array (
          0 => 'description',
          1 => 'assigned_user_name',
        ),
      ),
    ),
  ),
);
?>
