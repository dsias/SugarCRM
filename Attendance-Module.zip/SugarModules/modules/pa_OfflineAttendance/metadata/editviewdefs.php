<?php
$module_name = 'pa_OfflineAttendance';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'attendance_date',
            'label' => 'LBL_ATTENDANCE_DATE',
          ),
          1 => 
          array (
            'name' => 'status',
            'studio' => 'visible',
            'label' => 'LBL_STATUS',
			'customCode' => '{$STATUS}',			
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
			'customCode' => '<input type="text" title="" value="{$fields.name.value}" maxlength="255" size="85" id="name" name="name" >',
          ),

          1 => 'assigned_user_name',
        ),
        2 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'authority_remarks',
            'studio' => 'visible',
            'label' => 'LBL_AUTHORITY_REMARKS',
			'customCode'=> '{$AUTH_REMARKS}',			
          ),
        ),
      ),
    ),
  ),
);
?>
