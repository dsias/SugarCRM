<?php
$module_name = 'pa_Holidays';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'attendance_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_ATTENDANCE_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'attendance_date',
      ),
    ),
    'advanced_search' => 
    array (
      'attendance_date' => 
      array (
        'type' => 'date',
        'label' => 'LBL_ATTENDANCE_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'attendance_date',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'status' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_STATUS',
        'width' => '10%',
        'default' => true,
        'name' => 'status',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
