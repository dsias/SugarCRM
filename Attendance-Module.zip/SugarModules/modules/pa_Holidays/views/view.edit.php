<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.edit.php');

class pa_OfflineAttendanceViewEdit extends ViewEdit {
	
	
	function pa_OfflineAttendanceViewEdit(){
 		parent::ViewEdit();
 	}
	
	function display(){
		global $db, $current_user;

		$emp_id = $current_user->id;

		$main_sql = "
			SELECT * 
			FROM pa_employeedetail e
			WHERE
				e.deleted=0 and e.user_id_c='$emp_id' AND employee_status='Active'
		";	
		$main_result = $this->bean->db->query($main_sql);
		$authorize = 0;
		$offline_admin = 0;
		while ($main_row = $this->bean->db->fetchByAssoc($main_result)) 
		{
			$authorize++;
			$offline_admin = $main_row['offline_administrator'];
			
		}
		if($authorize == 0)
		{
			die("Un Authorized Access");
		}

		if($this->bean->id == "" && $this->bean->status == "")
		{
			$this->ss->assign('STATUS',"New <input type='hidden' id='status' name='status' value='Waiting_for_Approval' />");					
			$this->ss->assign('AUTH_REMARKS',"");											

		}
		else if($this->bean->id != "" && $this->bean->status == "Waiting_for_Approval" && $offline_admin==0)
		{
			$this->ss->assign('AUTH_REMARKS',"");														
			$ls="";
			$m = array (
								'Waiting_for_Approval' => 'Waiting for Approval',						
								'Cancelled' => 'Cancelled',
							);
							$ls .= '<select name="status" id="status">';
							foreach ($m as $key => $val)
							{
								if ($this->bean->status == $key)
									$ls .= "<option value='".$key."' selected>".$val."</option>";				
								else
									$ls .= "<option value='".$key."'>".$val."</option>";				
							}
							$ls .='</select>';
							
			$this->ss->assign('STATUS',$ls);								
		}

		else if($this->bean->id != "" && $offline_admin==1)
		{
			$this->ss->assign('AUTH_REMARKS','<textarea tabindex="0" title="" cols="80" rows="6" name="authority_remarks" id="authority_remarks">'.$this->bean->authority_remarks.'</textarea>');														
			$ls="";
			$m = array (
								'Waiting_for_Approval' => 'Waiting for Approval',						
								'Approved' => 'Approved',
								'Un_Approved' => 'Un-Approved',
								'Cancelled' => 'Cancelled',
							);
							$ls .= '<select name="status" id="status">';
							foreach ($m as $key => $val)
							{
								if ($this->bean->status == $key)
									$ls .= "<option value='".$key."' selected>".$val."</option>";				
								else
									$ls .= "<option value='".$key."'>".$val."</option>";				
							}
							$ls .='</select>';
							
			$this->ss->assign('STATUS',$ls);								
		}
		else
		{
			die("It can't be editable");			
		}
			
		parent::display();
	}
}
?>
