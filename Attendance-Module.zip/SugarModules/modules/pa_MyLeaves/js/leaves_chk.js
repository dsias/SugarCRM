function leave_type_change(str)
{

	if (str.length==0)
	   { 
	  document.getElementById("available_leave").value="0";
	   return;
	   }
	 if (window.XMLHttpRequest)
	   {// code for IE7+, Firefox, Chrome, Opera, Safari
	   xmlhttp=new XMLHttpRequest();
	   }
	 else
	   {// code for IE6, IE5
	   xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	   }
	 xmlhttp.onreadystatechange=function()
	   {
		 document.getElementById("available_leave").value=xmlhttp.responseText;
		 document.getElementById("number_of_days_applied_for").value = "";
	   }
	 xmlhttp.open("GET","index.php?module=pa_MyLeaves&action=getLeaves&sugar_body_only=1&inline=1&q="+str,true);
	 xmlhttp.send();

}
function no_of_days_change()
{
	days = parseFloat(document.getElementById("number_of_days_applied_for").value);
	if(isNaN(days))
		days = 0;
	available = parseFloat(document.getElementById("available_leave").value);
	if(isNaN(available))
		available = 0;

	
	if(days > available)
	{
		document.getElementById("number_of_days_applied_for").value = "";
		alert("No of Days Applied can not be greater than Available Leave");
	}

	if(days == 0)
	{
		document.getElementById("number_of_days_applied_for").value = "";
		alert("No of Days Applied can not be Zero");
	}
	
}