<?php
$module_name = 'pa_MyLeaves';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
	 'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/pa_MyLeaves/js/leaves_chk.js',
        ),
      ),
	  
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pa_myleaves_pa_employeeleaves_name',
			'customLabel' => 'Type of Leave:',
			'customCode' => '{$TYPE_OF_LEAVE}',						
          ),
          1 => 
          array (
            'name' => 'leave_status',
            'studio' => 'visible',
            'label' => 'LBL_LEAVE_STATUS',
			'customCode' => '{$LEAVE_STATUS}',
			
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'apply_leave_for',
            'studio' => 'visible',
            'label' => 'LBL_APPLY_LEAVE_FOR',
          ),
          1 => 
          array (
            'name' => 'available_leave',
            'label' => 'LBL_AVAILABLE_LEAVE',
			'customCode' => '<input type="text" id="available_leave" name="available_leave" value="{$fields.available_leave.value}" size="15" style="text-align:right" readonly="readonly" />',
			
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_from',
            'label' => 'LBL_DATE_FROM',
          ),
          1 => 
          array (
            'name' => 'date_to',
            'label' => 'LBL_DATE_TO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'number_of_days_applied_for',
            'label' => 'LBL_NUMBER_OF_DAYS_APPLIED_FOR',
			'customCode' => '<input type="text" id="number_of_days_applied_for" name="number_of_days_applied_for" value="{$fields.number_of_days_applied_for.value}" size="15" style="text-align:right" onchange="no_of_days_change()" />',
			
          ),
          1 => 'assigned_user_name',
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
			'customCode' => '<input type="text" title="" value="{$fields.name.value}" maxlength="255" size="85" id="name" name="name" >',
          ),

		  
        ),
        5 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'authority_remarks',
            'studio' => 'visible',
            'label' => 'LBL_AUTHORITY_REMARKS',
			'customCode'=> '{$AUTH_REMARKS}',
          ),
        ),
      ),
    ),
  ),
);
?>
