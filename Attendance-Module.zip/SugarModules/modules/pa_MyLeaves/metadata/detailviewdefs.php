<?php
$module_name = 'pa_MyLeaves';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pa_myleaves_pa_employeeleaves_name',
			'customLabel' => 'Type of Leave:',

          ),
          1 => 
          array (
            'name' => 'leave_status',
            'studio' => 'visible',
            'label' => 'LBL_LEAVE_STATUS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'apply_leave_for',
            'studio' => 'visible',
            'label' => 'LBL_APPLY_LEAVE_FOR',
          ),
          1 => 
          array (
            'name' => 'available_leave',
            'label' => 'LBL_AVAILABLE_LEAVE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_from',
            'label' => 'LBL_DATE_FROM',
          ),
          1 => 
          array (
            'name' => 'date_to',
            'label' => 'LBL_DATE_TO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'number_of_days_applied_for',
            'label' => 'LBL_NUMBER_OF_DAYS_APPLIED_FOR',
          ),
          1 => 'assigned_user_name',
        ),
        4 => 
        array (
          0 => 'date_entered',
          1 => 'date_modified',
        ),
        5 => 
        array (
          0 => 'name',
        ),
        6 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'authority_remarks',
            'studio' => 'visible',
            'label' => 'LBL_AUTHORITY_REMARKS',
          ),
        ),
      ),
    ),
  ),
);
?>
