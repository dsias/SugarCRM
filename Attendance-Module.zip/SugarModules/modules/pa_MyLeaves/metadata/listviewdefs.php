<?php
$module_name = 'pa_MyLeaves';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '15%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'DATE_FROM' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_FROM',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_TO' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_TO',
    'width' => '10%',
    'default' => true,
  ),
  'APPLY_LEAVE_FOR' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_APPLY_LEAVE_FOR',
    'width' => '10%',
    'default' => true,
  ),
  'NUMBER_OF_DAYS_APPLIED_FOR' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_NUMBER_OF_DAYS_APPLIED_FOR',
    'width' => '10%',
    'default' => true,
  ),
  'PA_MYLEAVES_PA_EMPLOYEELEAVES_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_PA_MYLEAVES_PA_EMPLOYEELEAVES_FROM_PA_EMPLOYEELEAVES_TITLE',
    'id' => 'PA_MYLEAVES_PA_EMPLOYEELEAVESPA_EMPLOYEELEAVES_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'LEAVE_STATUS' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_LEAVE_STATUS',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'AVAILABLE_LEAVE' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_AVAILABLE_LEAVE',
    'width' => '10%',
    'default' => false,
  ),
  'AUTHORITY_REMARKS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_AUTHORITY_REMARKS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_MODIFIED_NAME',
    'id' => 'MODIFIED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
