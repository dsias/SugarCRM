<?php
$module_name='pa_MyLeaves';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'pa_MyLeaves',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'apply_leave_for' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_APPLY_LEAVE_FOR',
      'width' => '10%',
      'default' => true,
    ),
    'leave_status' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_LEAVE_STATUS',
      'width' => '10%',
      'default' => true,
    ),
    'number_of_days_applied_for' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_NUMBER_OF_DAYS_APPLIED_FOR',
      'width' => '10%',
      'default' => true,
    ),
    'date_modified' => 
    array (
      'vname' => 'LBL_DATE_MODIFIED',
      'width' => '45%',
      'default' => true,
    ),
    'edit_button' => 
    array (
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'pa_MyLeaves',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'pa_MyLeaves',
      'width' => '5%',
      'default' => true,
    ),
  ),
);