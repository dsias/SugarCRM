<?php

$db = DBManagerFactory::getInstance();

$q = $_GET['q'];

$sql = "SELECT no_of_leaves FROM pa_employeeleaves WHERE deleted=0 and id='$q'";
$results = $db->query($sql);
$row = $db->fetchByAssoc($results);

$sql1 = "SELECT sum(number_of_days_applied_for ) as earn FROM pa_myleaves l, pa_myleaves_pa_employeeleaves_c le 

WHERE le.pa_myleaves_pa_employeeleavespa_myleaves_idb = l.id AND l.leave_status!='Un_Approved' AND l.leave_status != 'Cancelled' AND l.deleted=0 AND le.pa_myleaves_pa_employeeleavespa_employeeleaves_ida = '$q' and le.deleted=0";
$results1 = $db->query($sql1);
$row1 = $db->fetchByAssoc($results1);



echo $row['no_of_leaves']- $row1['earn'];

?>