<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.edit.php');

class pa_MyLeavesViewEdit extends ViewEdit {
	
	
	function pa_MyLeavesViewEdit(){
 		parent::ViewEdit();
 	}
	
	function display(){
		global $db, $current_user;

		$emp_id = $current_user->id;

		$main_sql = "
			SELECT * 
			FROM pa_employeedetail e
			WHERE
				e.deleted=0 and e.user_id_c='$emp_id' AND employee_status='Active'
		";	
		$main_result = $this->bean->db->query($main_sql);
		$authorize = 0;
		$leave_admin = 0;
		while ($main_row = $this->bean->db->fetchByAssoc($main_result)) 
		{
			$authorize++;
			$leave_admin = $main_row['leave_administrator'];
			
		}
		if($authorize == 0)
		{
			die("Un Authorized Access");
		}

		$leave_type	= "";
		if($this->bean->id == "" && $this->bean->leave_status == "")
		{
			$this->ss->assign('LEAVE_STATUS',"New <input type='hidden' id='leave_status' name='leave_status' value='Waiting_for_Approval' />");					
			$this->ss->assign('AUTH_REMARKS',"");											

			$current_year = date('Y');
			
			$sql = "
				SELECT l.id, l.name 
				FROM pa_employeedetail e
				LEFT JOIN pa_employeeleaves_pa_employeedetail_c el ON (el.pa_employeeleaves_pa_employeedetailpa_employeedetail_idb = e.id AND el.deleted=0)
				LEFT JOIN pa_employeeleaves l ON (l.id = el.pa_employeeleaves_pa_employeedetailpa_employeeleaves_ida AND l.deleted=0)
				WHERE
					e.deleted=0 and e.user_id_c='$emp_id' and l.leave_year='$current_year' and employee_status='Active'
			
			";	
	
	
	
			$result = $this->bean->db->query($sql);
			$leave_type="<SELECT id='pa_myleaves_pa_employeeleavespa_employeeleaves_ida' name='pa_myleaves_pa_employeeleavespa_employeeleaves_ida' onchange='leave_type_change(this.value)'>";
			$k=0;
			while ($row = $this->bean->db->fetchByAssoc($result)) 
			{
				$k++;
				if($k==1)
					$leave_type.="<OPTION value=''></OPTION>";
				$leave_type .= "<OPTION value='".$row['id']."'>".$row['name']."</OPTION>";					
			}
			if($k==0)
			{
				$leave_type .= "<OPTION value=''>No Leave Assign to you ask your administrator</OPTION>";									
			}
			$leave_type.="</SELECT>";




		}
		else if($this->bean->id != "" && $this->bean->leave_status == "Waiting_for_Approval" && $leave_admin==0)
		{
			$leave_type	= $this->bean->pa_myleaves_pa_employeeleaves_name;
			$this->ss->assign('AUTH_REMARKS',"");														
			$ls="";
			$m = array (
								'Waiting_for_Approval' => 'Waiting for Approval',						
								'Cancelled' => 'Cancelled',
							);
							$ls .= '<select name="leave_status" id="leave_status">';
							foreach ($m as $key => $val)
							{
								if ($this->bean->leave_status == $key)
									$ls .= "<option value='".$key."' selected>".$val."</option>";				
								else
									$ls .= "<option value='".$key."'>".$val."</option>";				
							}
							$ls .='</select>';
							
			$this->ss->assign('LEAVE_STATUS',$ls);								
		}

		else if($this->bean->id != "" && $leave_admin==1)
		{
			$leave_type	= $this->bean->pa_myleaves_pa_employeeleaves_name;
			$this->ss->assign('AUTH_REMARKS','<textarea tabindex="0" title="" cols="80" rows="6" name="authority_remarks" id="authority_remarks">'.$this->bean->authority_remarks.'</textarea>');														
			$ls="";
			$m = array (
								'Waiting_for_Approval' => 'Waiting for Approval',						
								'Approved' => 'Approved',
								'Un_Approved' => 'Un-Approved',
								'Cancelled' => 'Cancelled',
							);
							$ls .= '<select name="leave_status" id="leave_status">';
							foreach ($m as $key => $val)
							{
								if ($this->bean->leave_status == $key)
									$ls .= "<option value='".$key."' selected>".$val."</option>";				
								else
									$ls .= "<option value='".$key."'>".$val."</option>";				
							}
							$ls .='</select>';
							
			$this->ss->assign('LEAVE_STATUS',$ls);								
		}
		else
		{
			die("It can't be editable");			
		}
			
		$this->ss->assign('TYPE_OF_LEAVE',$leave_type);		
		parent::display();
	}
}
?>
