<?php

global $current_user, $timedate;
static $user_today_timestamp = null;

if(!isset($user_today_timestamp)) {
	$gmt_today = $timedate->get_gmt_db_datetime();
	$user_today = $timedate->handle_offset($gmt_today, $GLOBALS['timedate']->get_db_date_time_format());
	preg_match_all('/\d*/', $user_today, $matches);
	$matches = $matches[0];
	$user_today_timestamp = mktime($matches[6], $matches[8], '0', $matches[2], $matches[4], $matches[0]);
}

$db = DBManagerFactory::getInstance();

// Report Parameters
$p_user=$_GET['p_user'];
$p_subject=$_GET['p_subject'];
$p_date_from=date('d/m/Y',strtotime(date($GLOBALS['timedate']->get_db_date_time_format(), $user_today_timestamp)));
$p_date_to=date('d/m/Y',strtotime(date($GLOBALS['timedate']->get_db_date_time_format(), $user_today_timestamp)));


$p_status_punch_in=$_GET['p_status_punch_in'];
$p_status_punch_out = $_GET['p_status_punch_out'];
$p_lunch_punch_in = $_GET['p_lunch_in'];
$p_lunch_punch_out = $_GET['p_lunch_out'];

$p1 = "";
$p2 = "";
$p3 = "";
$p4 = "";
$p5 = "";

if($p_user!="")
{
	$p1 = " AND a.assigned_user_id = '".$p_user."'";
}
if($p_subject!="")
{
	$p2 = " AND a.name like '%".$p_subject."%'";
}
if($p_date_from!="")
{
	$a = explode('/',$p_date_from);
	$d_from = $a[2]."-".$a[1]."-".$a[0];
	$a = explode('/',$p_date_to);
	$d_to = $a[2]."-".$a[1]."-".$a[0];

	$p3 = " AND a.attendance_date_time BETWEEN '".$d_from." 00:00:00' AND '".$d_to." 23:59:59'";
}
if($p_status_punch_in!="")
{
	$p4 = " AND a.status_punch_in like '%".$p_status_punch_in."%'";
}

if($p_status_punch_out!="")
{
	$p5 = " AND a.status_punch_out like '%".$p_status_punch_out."%'";
}


$sql_set = "
SELECT * 
FROM attendance_setting
WHERE id=1
";
//echo $sql;
$results_set = $db->query($sql_set);
$row_set = $db->fetchByAssoc($results_set);

$sql1 = "
SELECT concat(ifNULL(e.first_name,''),' ',e.last_name) as full_name, e.employee_picture, u.user_name, u.id as user_id,  e.employee_id, e.employee_title, e.employee_department, DATE_FORMAT(e.date_of_joining,'%d %M, %Y') as dj
FROM pa_employeedetail e
LEFT JOIN users u ON (u.id = e.user_id_c)
ORDER BY full_name
";

$results1 = $db->query($sql1);
//$row1 = $db->fetchByAssoc($results1);



require('mypdf/mc_table_2.php');

$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage('P');
$pdf->SetSubject("sarfaraz",true);
$pdf->SetAuthor("sarfaraz",true);
$pdf->SetTitle("MEC-MIS Reports",true);
$pdf->SetCreator("sarfaraz",true);
$pdf->SetKeywords("sarfaraz",true);
//if(file_exists('employee_pic/'.$p_user.'/'.$row1['employee_picture']))
//{
//	$pdf->Image('employee_pic/'.$p_user.'/'.$row1['employee_picture'],8,9,26,30);
//}
//else
//{
//	$pdf->Image('modules/pa_Attendance/default.png',8,9,26,30);	
//}

$pdf->SetFont('Arial','B',16);
$pdf->SetTextColor(195,195,195);
$pdf->SetRightMargin(4);
$pdf->Cell(0,0,"Today's Attendance Report",0,0,'R');
$pdf->Ln(2);
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);




if($p_subject!="")
{
$pdf->Cell(0,0,'Subject: '.$p_subject,0,0,'L');
$pdf->Ln(4);
}

//if($p_date_from!="")
//{
//$pdf->Cell(0,0,'Date From: '.$p_date_from.' To: '.$p_date_to,0,0,'L');
//$pdf->Ln(4);
//}

if($p_status_punch_in!="")
{
$pdf->Cell(0,0,'Status Punch In: '.str_replace('_',' ',$p_status_punch_in),0,0,'L');
$pdf->Ln(4);
}

if($p_status_punch_out!="")
{
$pdf->Cell(0,0,'Status Punch Out: '.str_replace('_',' ',$p_status_punch_out),0,0,'L');$pdf->Ln(4);
}

if($p_lunch_punch_in!="")
{
$pdf->Cell(0,0,'Lunch In: '.$p_lunch_punch_in,0,0,'L');
$pdf->Ln(4);
}
if($p_lunch_punch_out!="")
{
$pdf->Cell(0,0,'Lunch Out: '.$p_lunch_punch_out,0,0,'L');
$pdf->Ln(4);
}
$pdf->SetLeftMargin(8);

$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);
$header = array('Pic','Employee Name','User Name','Punch In','Punch Out','Lunch In', 'Lunch Out','Last Status');



$pdf->Ln(5);
$head=0;
$sno=0;

$days = (strtotime($d_to.' 00:00:00') - strtotime($d_from. ' 00:00:00'))/86400;
$i = 0;
$start_date = date('d M Y',strtotime($d_from));

$total_present = 0;
$total_leave = 0;
$total_offline = 0;
$total_holiday = 0;
$total_off = 0;
$total_absent = 0;


while($row1 = $db->fetchByAssoc($results1))
{
	if($i==0)
		$i = $i + 23;
	else
		$i = $i + 10;
	
	if ($head==0)
	{
		$head++;
		$pdf->SetFont('Arial','B',10);		
		$w = array(11,54,25,19,21,20,20,28);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}
	$p_user = $row1['user_id'];
	if($row1['employee_picture']=="")
	{
		$row1['employee_picture']="../../modules/pa_Attendance/default.png";
	}

	
	$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	
	$database_date = date('Y-m-d',strtotime($start_date));
	$sun = date('D',strtotime($start_date));

	$main_id = "";
	$print_status = "";
	$print_punch_in = "";
	$print_punch_out = "";	
	$print_lunch_in = "";	
	$print_lunch_out = "";
	$print_last_status = "";
	$print_style=0;	

			// Searching for Leaave
			$sql_leave = "
				SELECT * 
				FROM pa_myleaves l
				WHERE l.deleted=0 and date_from <= '$database_date' and date_to >= '$database_date' AND created_by = '$p_user' limit 1
			";
			$results_leave = $db->query($sql_leave);
			$leave_name = "";
			$leave_type = "";
			while($row_leave = $db->fetchByAssoc($results_leave)) 
			{
				$leave_name = $row_leave['name'];
				$leave_type = str_replace("_"," ",$row_leave['apply_leave_for']);
			}
			if($leave_name != "")
			{
				$print_status=$leave_type."-Leave (".$leave_name.")";
				$print_style=1;
				$total_leave++;
			}
			else
			{
						
				// Start finding Offline Attedance
				$sql_offline = "
					SELECT * 
					FROM pa_offlineattendance o
					WHERE o.deleted=0 and o.attendance_date = '$database_date' AND o.created_by = '$p_user' limit 1
				";
				$results_offline = $db->query($sql_offline);
				$offline_name = "";
				while($row_offline = $db->fetchByAssoc($results_offline)) 
				{
					$offline_name = $row_offline['name'];
				}
				if($offline_name != "")
				{
					$print_status="Offline Attendance (".$offline_name.")";
					$print_style=1;
					$total_offline++;
				}
				else
				{
				
		
					// Start finding Present
					$sql = "
						SELECT * 
						FROM pa_attendance a
						WHERE a.deleted=0 and attendance_date_time like '$database_date%' and created_by = '$p_user'
					";
					$results = $db->query($sql);
					while($row = $db->fetchByAssoc($results)) 
					{
						$main_id = $row['id'];
					}
					if($main_id != "")
					{
						require_once('modules/pa_Attendance/pa_Attendance.php');
						$att = new pa_Attendance();
						$att->retrieve($main_id);
		
						$k = explode("<",$att->attendance_date_time);
						$att->attendance_date_time = $k[0];
						$k = explode(" ",$att->attendance_date_time);
						$att->attendance_date_time = $k[1];
		
					
						$k = explode("<",$att->punch_out_date_time);
						$att->punch_out_date_time = $k[0];
						$k = explode(" ",$att->punch_out_date_time);
						$att->punch_out_date_time = $k[1];
		
					
						$k = explode("<",$att->lunch_in_date_time);
						$att->lunch_in_date_time = $k[0];
						$k = explode(" ",$att->lunch_in_date_time);
						$att->lunch_in_date_time = $k[1];
		
					
						$k = explode("<",$att->lunch_out_date_time);
						$att->lunch_out_date_time = $k[0];
						$k = explode(" ",$att->lunch_out_date_time);
						$att->lunch_out_date_time = $k[1];
		
		
						
						$print_status = "Present";
						$total_present++;
		
		
						$print_punch_in = $att->attendance_date_time.'   '.str_replace('_',' ',$att->status_punch_in);
						$print_punch_out = $att->punch_out_date_time.'   '.str_replace('_',' ',$att->status_punch_out);	
						$print_lunch_in = $att->lunch_in_date_time.'   '.str_replace('_',' ',$att->status_lunch_in);	
						$print_lunch_out = $att->lunch_out_date_time.'   '.str_replace('_',' ',$att->status_lunch_out);
						$print_last_status = $att->name;
						
					}
					// End of Present finding
					else // Absent
					{
						$print_status = "Absent";
						$print_style = 2;
						$total_absent++;
					}
				}
				// End Finding Offline Attendance
	
			} 
			// End of Leave Searching

	if($print_style==0)
	{
		$pdf->SetWidths($w);
		$pdf->Row(array($pdf->Image('employee_pic/'.$row1['user_id'].'/'.$row1['employee_picture'],9.5,$i,8,8),$row1['full_name'],$row1['user_name'],$print_punch_in,$print_punch_out,$print_lunch_in,$print_lunch_out,$print_last_status));
	}
	else if($print_style==1)
	{
		$k = array(11,54,25,108);
		$pdf->SetWidths($k);
		$pdf->Row_Style_1(array($pdf->Image('employee_pic/'.$row1['user_id'].'/'.$row1['employee_picture'],9.5,$i,8,8),$row1['full_name'],$row1['user_name'],$print_status));
	}
	else if($print_style==2)
	{
		$k = array(11,54,25,108);
		$pdf->SetWidths($k);
		$pdf->Row_Style_2(array($pdf->Image('employee_pic/'.$row1['user_id'].'/'.$row1['employee_picture'],9.5,$i,8,8),$row1['full_name'],$row1['user_name'],$print_status));
	}


	

	
//	$start_date = date("d M Y",strtotime('+1 day', strtotime($start_date)));
//	$i++;
}

$pdf->Output();


?>