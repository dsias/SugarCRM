<?php
?>
<table style="width:100%">
	<tbody>
    	<tr>
        	<td>
            	<div class="moduleTitle">
					<h2> Punch Offline Attendance </h2>
                </div>


<div class="clear"></div>

<form id="EditView" name="EditView" method="POST" action="index.php">
	<table width="100%" cellspacing="0" cellpadding="0" border="0" class="dcQuickEdit">
	<tbody>
    	<tr>
			<td class="buttons">
				<input type="hidden" value="pa_Attendance" name="module">
				<input type="hidden" value="" name="record">
				<input type="hidden" value="false" name="isDuplicate">
                <input type="hidden" name="action" value="save_attendance">
                <input type="hidden" value="pa_Attendance" name="return_module">
                <input type="hidden" value="index" name="return_action">
                <input type="hidden" value="" name="return_id">
                <input type="hidden" name="module_tab"> 
                <input type="hidden" value="pa_Attendance" name="relate_to">
                <input type="hidden" value="" name="relate_id">
                <input type="hidden" value="1" name="offset">
                <input type="hidden" value="<?php echo $rec_id ?>" name="rec_id" />
				<!-- to be used for id for buttons with custom code in def files-->
			</td>
			<td align="right">
			</td>
		</tr>
	</tbody>
</table>
<span id="tabcounterJS"><script>SUGAR.TabFields=new Array();//this will be used to track tabindexes for references</script></span>
<div id="EditView_tabs">
	<div>
		<div id="detailpanel_1">
			<table width="100%" cellspacing="1" cellpadding="0" border="0" class="yui3-skin-sam edit view panelContainer" id="Default_pa_Attendance_Subpanel">
				<tbody>
                	<tr>
						<td width="10%" valign="top" scope="col" id="name_label">
						Subject:
						<span class="required">*</span>
						</td>
						<td width="37.5%" valign="top" colspan="3">
							<?php echo "Offline Attendance" ?>
						</td>

						<td width="5%" valign="top" scope="col" id="name_label">
						Status:
						<span class="required">*</span>
						</td>
						<td width="43%" valign="top" colspan="3">
							<?php echo "New" ?>
						</td>

                   	</tr>
					<tr>
						<td width="10%" valign="top" scope="col" id="attendance_date_time_label">

						</td>
						<td width="37.5%" valign="top">
							<table cellspacing="0" cellpadding="0" border="0" class="dateTime">
							<tbody>
                            	<tr valign="middle">
									<td nowrap="">
										<label style="font-size:14px; font-weight:bold;"></label>
									</td>
								</tr>
							</tbody>
                            </table>
						</td>
					<tr>
<tr>
<td width="6%" valign="top" scope="col" id="description_label">
Remarks:						<span class="required">*</span>

</td>
<td width="37.5%" valign="top" colspan="3">
<textarea tabindex="0" title="" cols="80" rows="6" name="description" id="description"></textarea>
</td></tr>
<tr>
<td>
</td>
<td>
<input type="submit" id="SAVE_FOOTER" value="Punch Offline Attendance" name="button" onclick="" class="button primary" accesskey="a" title="Save">  
</td>
</tr>
</tbody></table>
</div>
</div></div>
</form>
        </td></tr></tbody></table>