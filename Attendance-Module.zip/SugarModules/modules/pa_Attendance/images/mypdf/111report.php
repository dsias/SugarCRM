<?php

	require_once '../config.php';
//	$report_id = $_GET['report_id'];
//	$report_name = $_GET['rpt_name'];

//	if (!$report_id)
//	{
//		die("Invalid Access");
//	}
	$conn2=mysql_connect($sugar_config['dbconfig']['db_host_name'],$sugar_config['dbconfig']['db_user_name'],$sugar_config['dbconfig']['db_password']);
	if (!$conn2)
	{
		die('Could not connect to database');
		
	}
	$db1 = mysql_select_db($sugar_config['dbconfig']['db_name'],$conn2);
	
//	$user_id=$_GET['user_id']; 
//	$from_date=explode("/",$_GET['from_date']);
//	$to_date=explode("/",$_GET['to_date']);
//	$uname = $_GET['uname'];
//	$lead_reference = $_GET['lead_reference'];	
//	$status = $_GET['status'];	

//	$sql = "SELECT * FROM accounts a, accounts_cstm ac WHERE a.id = ac.id_c AND leadreference_c like '%$lead_reference%' AND status_c like '$status%'  AND created_by like '%$user_id%' AND date_entered between '$from_date[2]-$from_date[0]-$from_date[1]' AND '$to_date[2]-$to_date[0]-$to_date[1]'";
	
	$sql = "SELECT a.name as company_name, a.id as company_id, pb.url as url, pb.name as silo_name, pb.dadded as date_added, pb.cmonpay as cmonpay, p.active as active, p.tax_class  as base_line, p.pause_date as pause_date, p.rpt_update as rpt_update, lx_update as lx_update, lb_update as ww_update, bb_update as bb_update, which_bb as which_bb
FROM accounts a,
products p,
product_bundles pb,
product_bundle_product pbp

WHERE a.deleted = '0' and a.id = p.quote_id and p.deleted='0' and pb.deleted='0' and pbp.deleted='0' and pbp.product_id = p.id and pbp.bundle_id = pb.id
ORDER BY a.date_modified desc  ";
	$result = mysql_query($sql);



require('mc_table.php');

$pdf=new PDF_MC_Table();
$pdf->AddPage('L');
$pdf->SetSubject("sarfaraz",true);
$pdf->SetAuthor("sarfaraz",true);
$pdf->SetTitle("sarfaraz",true);
$pdf->SetCreator("sarfaraz",true);
$pdf->SetKeywords("sarfaraz",true);
$pdf->SetFont('Arial','B',22);
$pdf->SetTextColor(23,14,204);
$pdf->Image('../custom/themes/default/images/company_logo.png',10,02,-1300);
$pdf->Cell(0,0,'Company Silo Report',0,0,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','B',10);

$header = array('Company Name','Website URL', 'Date Added', 'Current Monthly', 'Active', 'Baseline Added', 'Pause Date', 'Reporting Updated', 'LX Last Updated', 'WW Last Updated', 'BB Last Updated', 'Whic BB Account' );

$pdf->Ln(4);
// Column widths
$head=0;

while($row = mysql_fetch_array($result))
{


	if ($head==0)
	{
		$head++;
		$pdf->SetWidths(array(50,40,18,18,15,18,19,20,20,20,20,23));
		$pdf->Head_Row(array('Company Name','[Silo Name]-URL', 'Date Added', 'Current Monthly', 'Active', 'Baseline Added', 'Pause Date', 'Reporting Updated', 'LX Last Updated', 'WW Last Updated', 'BB Last Updated', 'Whic BB Account' ));

	}

//	echo(strlen($row['name'])."<br>");
	
	$pdf->SetTextColor(0,0,0);
//     $x=$pdf->GetX();
//     $y=$pdf->GetY();

	$pdf->SetFont('Arial','',9);
		$pdf->SetWidths(array(50,40,18,18,15,18,19,20,20,20,20,23));
	
	if ($row['date_added']=='mm/dd/yyyy')
		$row['date_added'] = '';
	if ($row['pause_date']=='mm/dd/yyyy')
		$row['pause_date'] = '';
	if ($row['rpt_update']=='mm/dd/yyyy')
		$row['rpt_update'] = '';
	if ($row['lx_update']=='mm/dd/yyyy')
		$row['lx_update'] = '';
	if ($row['ww_update']=='mm/dd/yyyy')
		$row['ww_update'] = '';
	if ($row['bb_update']=='mm/dd/yyyy')
		$row['bb_update'] = '';
			
	$pdf->Row(array($row['company_name'].'^'.$row['company_id'],'['.$row['silo_name'].'] - '.$row['url'],$row['date_added'],$row['cmonpay'],$row['active'],$row['base_line'],$row['pause_date'],$row['rpt_update'],$row['lx_update'],$row['ww_update'],$row['bb_update'],$row['which_bb']));

}
	//		$pdf->SetFillColor(127, 127, 127); 
	//		$pdf->SetTextColor(255,255,255);

//	$pdf->MultiCell(55,5,"pakistan",0,1,'L',true);
//		$pdf->Cell($w[$i],7,$header[$i],1,0,'C',true);

/*
require('mc_table.php');

$pdf1=new PDF_MC_Table();
$pdf1->AddPage();

$pdf1->SetWidths(array(30,50,30,40));
while($row = mysql_fetch_array($result))
{
	 $pdf1->Row($row['name'],row['name'],row['contactperson_c'],row['status']);
}
*/

$pdf->Ln(2);
$pdf->SetFont('Arial','I',8);
$pdf->Write(4,'This is a computer generated report from rankpop-CRM @ '.date('m/d/Y h:i a'));

$pdf->Output();
?>