<?php

require('fpdf.php');

require_once '../config.php';
	$ac_id = $_GET['main_id'];
	if (!$ac_id)
	{
		die("Invalid Access");
	}
	$conn2=mysql_connect($sugar_config['dbconfig']['db_host_name'],$sugar_config['dbconfig']['db_user_name'],$sugar_config['dbconfig']['db_password']);
	if (!$conn2)
	{
		die('Could not connect to database');
		
	}
	$db1 = mysql_select_db($sugar_config['dbconfig']['db_name'],$conn2);
	$sql = "SELECT * FROM np_accounteachcases WHERE deleted='0' and account_id_c='$ac_id'";
	$result = mysql_query($sql);

	$sql1 = "SELECT * FROM np_accountannualcontracts WHERE deleted='0' and account_id_c='$ac_id'";
	$result1 = mysql_query($sql1);

	$sql2 = "SELECT * FROM accounts a, accounts_cstm ac WHERE a.deleted='0' and a.id = ac.id_c and a.id='$ac_id'";
	$result2 = mysql_query($sql2);
	$row2 = mysql_fetch_array($result2);
	if (!$row2['id'])
	{
		die('Invalid Access');
	}	

	if ($row2['np_templates_id_c']=='')
	{
		die('Please Select Template');
	}	

	
	$template_id = $row2['np_templates_id_c'];
	$currency = $row2['currency_id'];
	$sql3 = "SELECT * FROM np_templates WHERE deleted='0' and id='$template_id'";
	$result3 = mysql_query($sql3);
	$row3= mysql_fetch_array($result3);

	$sql4 = "SELECT * FROM currencies WHERE deleted='0' and id='c2393f10-74a1-14a9-3471-4cd12304b4f4'";
	$result4 = mysql_query($sql4);
	$row4 = mysql_fetch_array($result4);
	
	if ($currency=='-99')
	{
		$mycurrency='USD';
	}
	else
	{
		$mycurrency=$row4['iso4217'];	
	}
	


$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,51,102);
$pdf->Cell(0,0,'AL BAHAR & ASSOCIATES',0,0,'C');
$pdf->Ln(04);
$pdf->Cell(0,0,'ADVOCATES & LEGAL CONSULTANTS',0,0,'C');
$pdf->Ln(12);
$pdf->SetFont('Arial','',10);
$pdf->Write(0,'Ref: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,'ALB/DCD/'.$row2['leadreference_c']);
$pdf->Ln(10);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'M/s. ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$row2['name']);
$pdf->Ln(4);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'P.O.Box: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$row2['pobox_c']);
$pdf->Ln(4);

if ($row2['telephone1_c']!="")
{
	$pdf->SetTextColor(0,51,102);
	$pdf->Write(0,'Tel: ');
	$pdf->SetTextColor(0,0,0);
	$pdf->Write(0,$row2['telephone1_c']);
	$pdf->Ln(4);
}
else
{
	$pdf->SetTextColor(0,51,102);
	$pdf->Write(0,'Mob: ');
	$pdf->SetTextColor(0,0,0);
	$pdf->Write(0,$row2['mobile1_c']);
	$pdf->Ln(4);
}
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Fax: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$row2['faxnumber_c']);

$pdf->Ln(4);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Email: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$row2['email_c']);

$pdf->Ln(12);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Attention: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$row2['contactperson_c']);

$pdf->Ln(12);
$pdf->SetTextColor(0,51,102);
$pdf->SetFont('Arial','BIU',10);
$pdf->Write(0,'Subject: '.$row3['template_title']);


$pdf->Ln(8);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',10);
$pdf->Write(4,$row3['body_1']);

$pdf->Ln(12);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Debt Collection Agreement: ');
$pdf->Ln(6);
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$mycurrency.' '.$row3['debt_collection_agreement']);

$pdf->Ln(10);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Collection Charges: ');

$pdf->Ln(4);
$pdf->SetTextColor(0,0,0);
$header = array('Options', 'Processing Charges (each case)', 'Commission' );
// Column widths
$head=0;
while($row = mysql_fetch_array($result))
{
	if ($head==0)
	{
		$head++;
		$w = array(40, 90, 60);
		for($i=0;$i<count($header);$i++)
		{
			$pdf->SetTextColor(0,51,102);
			$pdf->Cell($w[$i],7,$header[$i],1,0,'C');
		}
		$pdf->Ln();

	}
	$pdf->SetTextColor(0,0,0);
	$pdf->Cell(40,6,$row['e_options'],1,0,'C');
    $pdf->Cell(90,6,$row['e_process_charges'],1,0,'C');			
    $pdf->Cell(60,6,$row['e_commission'],1,0,'C');						
	$pdf->Ln();
}
if ($head!=0)
{

	$kead=0;
	while($row1 = mysql_fetch_array($result1))
	{
		if ($kead==0)
		{
			$kead++;
			$pdf->SetTextColor(0,51,102);
			$pdf->Cell(190,7,"Retainership (Annual Contract)",1,0,'C');
			$pdf->Ln();
	
		}
		$pdf->SetTextColor(0,0,0);
		$pdf->Cell(40,6,$row1['a_options'],1,0,'C');
		$pdf->Cell(90,6,$row1['a_process_charges'],1,0,'C');			
		$pdf->Cell(60,6,$row1['a_commission'],1,0,'C');						
		$pdf->Ln();
	}


}
else
{
	$header1 = array('Options', 'Retainership (Annual Contract)', 'Commission' );
	$kead=0;
	while($row1 = mysql_fetch_array($result1))
	{
		if ($kead==0)
		{
			$kead++;
			$w = array(40, 90, 60);
			for($i=0;$i<count($header1);$i++)
			{
				$pdf->SetTextColor(0,51,102);
				$pdf->Cell($w[$i],7,$header1[$i],1,0,'C');
			}
			$pdf->Ln();
	
		}
		$pdf->SetTextColor(0,0,0);
		$pdf->Cell(40,6,$row1['a_options'],1,0,'C');
		$pdf->Cell(90,6,$row1['a_process_charges'],1,0,'C');			
		$pdf->Cell(60,6,$row1['a_commission'],1,0,'C');						
		$pdf->Ln();
	}
}

$pdf->Ln(6);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',10);
$pdf->Write(4,$row3['body_2']);

$pdf->Ln(6);
$pdf->SetFont('Arial','B',10);
$pdf->Write(4,'Note:- ');
$pdf->SetFont('Arial','',10);
$pdf->Write(4,$row3['note']);

$pdf->Ln(10);
$pdf->SetFont('Arial','',10);
$pdf->Write(4,'Thank You,');

$pdf->Ln(10);
$pdf->SetFont('Arial','',10);
$pdf->Write(4,'Sincerely,');

$pdf->Ln(10);
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,51,102);
$pdf->Write(4,'Al Bahar & Associates');
$pdf->Ln(4);
$pdf->Write(4,'04-3244455');

$pdf->Output();
?>