<?php

	require_once '../config.php';
	$report_id = $_GET['report_id'];
	$report_name = $_GET['rpt_name'];

	if (!$report_id)
	{
		die("Invalid Access");
	}
	$conn2=mysql_connect($sugar_config['dbconfig']['db_host_name'],$sugar_config['dbconfig']['db_user_name'],$sugar_config['dbconfig']['db_password']);
	if (!$conn2)
	{
		die('Could not connect to database');
		
	}
	$db1 = mysql_select_db($sugar_config['dbconfig']['db_name'],$conn2);
	
	$user_id=$_GET['user_id']; 
	$from_date=explode("/",$_GET['from_date']);
	$to_date=explode("/",$_GET['to_date']);
	$uname = $_GET['uname'];
	$lead_reference = $_GET['lead_reference'];	
	$status = $_GET['status'];	

	$sql = "SELECT * FROM accounts a, accounts_cstm ac WHERE a.id = ac.id_c AND leadreference_c like '%$lead_reference%' AND status_c like '$status%'  AND created_by like '%$user_id%' AND date_entered between '$from_date[2]-$from_date[0]-$from_date[1]' AND '$to_date[2]-$to_date[0]-$to_date[1]'";
	$result = mysql_query($sql);

require('mc_table.php');

$pdf=new PDF_MC_Table();
$pdf->AddPage();

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,51,102);
$pdf->Cell(0,0,'AL BAHAR & ASSOCIATES',0,0,'C');
$pdf->Ln(04);
$pdf->Cell(0,0,'ADVOCATES & LEGAL CONSULTANTS',0,0,'C');
$pdf->Ln(12);
$pdf->SetFont('Arial','',10);
$pdf->Write(0,'Report Name : ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$report_name);
$pdf->Ln(10);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'User Name : ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$uname);
$pdf->Ln(4);
$pdf->SetTextColor(0,51,102);
if ($report_id == 1)
{
	$pdf->Write(0,'Lead Reference: ');
	$pdf->SetTextColor(0,0,0);
	if ($lead_reference)
		$pdf->Write(0,$lead_reference);
	else
		$pdf->Write(0,"ALL");	
	$pdf->Ln(4);
}
if ($report_id == 2)
{
	$pdf->Write(0,'Status: ');
	$pdf->SetTextColor(0,0,0);
	if ($lead_reference)
		$pdf->Write(0,$status);
	else
		$pdf->Write(0,"ALL");	
	$pdf->Ln(4);
}
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Date From: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$from_date[1]."-".$from_date[0]."-".$from_date[2]);
$pdf->Ln(4);
$pdf->SetTextColor(0,51,102);
$pdf->Write(0,'Date To: ');
$pdf->SetTextColor(0,0,0);
$pdf->Write(0,$to_date[1]."-".$to_date[0]."-".$to_date[2]);


$pdf->Ln(4);
$pdf->SetTextColor(0,0,0);
$header = array('Client Name', 'Contact Person', 'Telephone', 'File Code', 'Proposal Date', 'Status' );

$pdf->Ln(4);
// Column widths
$head=0;


while($row = mysql_fetch_array($result))
{
	if ($head==0)
	{
		$head++;
		$w = array(40, 40, 30,20,30,20);
		for($i=0;$i<count($header);$i++)
		{
			$pdf->SetFillColor(127, 127, 127); 
			$pdf->SetTextColor(255,255,255);
			$pdf->Cell($w[$i],7,$header[$i],1,0,'C',true);
			$pdf->SetFillColor(255, 255, 255); 			
		}
		$pdf->Ln();

	}
//	echo(strlen($row['name'])."<br>");
	
	$pdf->SetTextColor(0,0,0);
//     $x=$pdf->GetX();
//     $y=$pdf->GetY();

	$pdf->SetFont('Arial','',9);
	$pdf->SetWidths(array(40,40,30,20,30,20));
	
	$k = explode(" ",$row['proposaldate_c']);
	$dat = explode("-",$k[0]);
	
	if($k[0]!="")
	{
		$final_date = $dat[2]."/".$dat[1]."/".$dat[0];
	}
	else
	{
		$final_date = "";
	}
	
	$pdf->Row(array($row['name'],$row['contactperson_c'],$row['telephone1_c'],$row['filecode_c'],$final_date,$row['status_c']));
//	$pdf->MultiCell(20,4,$row['name'],1,'L',0);
//	$pdf->SetXY($x+20,$y);
 //   $pdf->MultiCell(20,4,$row['contactperson_c'],1,'L',4);			

 //   $pdf->MultiCell(60,6,$row['status_c'],1,0,'L');						
//	$pdf->Ln(8);
}

/*
require('mc_table.php');

$pdf1=new PDF_MC_Table();
$pdf1->AddPage();

$pdf1->SetWidths(array(30,50,30,40));
while($row = mysql_fetch_array($result))
{
	 $pdf1->Row($row['name'],row['name'],row['contactperson_c'],row['status']);
}
*/

$pdf->Ln(2);
$pdf->SetFont('Arial','I',8);
$pdf->Write(4,'This is a computer generated report');

$pdf->Output();
?>