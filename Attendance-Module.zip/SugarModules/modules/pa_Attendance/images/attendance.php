<?php

global $current_user, $timedate;
static $user_today_timestamp = null;

if(!isset($user_today_timestamp)) {
	$gmt_today = $timedate->get_gmt_db_datetime();
	$user_today = $timedate->handle_offset($gmt_today, $GLOBALS['timedate']->get_db_date_time_format());
	preg_match_all('/\d*/', $user_today, $matches);
	$matches = $matches[0];
	$user_today_timestamp = mktime($matches[6], $matches[8], '0', $matches[2], $matches[4], $matches[0]);
}

$db = DBManagerFactory::getInstance();

$disable_punch_in = 0;
$disable_punch_out = 0;
$disable_lunch_in = 0;
$disable_lunch_out = 0;

$sql_setting = "SHOW TABLES LIKE 'attendance_setting'";
$result_setting = $db->query($sql_setting);
$setting_exists = $db->getRowCount($result_setting);	
$status_value = "";
if($setting_exists==0)
{
	echo "<label style='font-size:14px; font-weight:bold; color:#F00'>Attendance Setting Missing, Please contact your administrator</label>";
	die();
}


?>
<script>
/*function check_status(a)
{
	if (a=="Lunch In")
	{
//		lunch_in_time = Date.pa('2013-06-17 09:00:00');
	    lunch_in_time = new Date((document.getElementById('lunch_in_time').value).replace(/-/g,"/"));		
		lunch_out_time = new Date((document.getElementById('lunch_out_time').value).replace(/-/g,"/"));		
		lunch_current_time = new Date((document.getElementById('lunch_current_time').value).replace(/-/g,"/"));		

		if((lunch_current_time.getTime() >= lunch_current_time.getTime()) && (lunch_in_time.getTime() < lunch_current_time.getTime()))
			alert(lunch_in_time+"---"+lunch_out_time);
	}
}*/
function sub(a)
{
	if(a==1)
	{
		document.getElementById('subject').value="Punch In";
	}
	else if(a==2)
	{
		document.getElementById('subject').value="Punch Out";
	}
	else if(a==3)
	{
		document.getElementById('subject').value="Lunch In";
	}
	else if(a==4)
	{
		document.getElementById('subject').value="Lunch Out";
	}

	
	if(document.getElementById('description').value == "")
		alert("Please Enter Remarks")
	else
	{
		document.getElementById('EditView').submit();
	}
}
</script>
<?php


$curr_user_id = $current_user->id;
$database_datetime = date($timedate->get_db_date_time_format());
$crm_datetime = date($GLOBALS['timedate']->get_db_date_time_format(), $user_today_timestamp);
$format_datetime =  date($timedate->get_date_format(), strtotime($crm_datetime))." ".date($timedate->get_time_format(), strtotime($crm_datetime));
//$p = "2013-08-15 08:54:00";
//$k = $timedate->swap_formats($p, $GLOBALS['timedate']->dbDayFormat, $timedate->get_time_format() );
$a = explode(' ',$database_datetime);
$curr_date = $a[0];
$punch_date_time = $format_datetime;

//$subject_line = "<SELECT id='name' name='name' onChange='check_status(this.value)'>";
$main_label = "Date & Time:";
$rec_id = "";
$sql_setting = "SELECT * FROM attendance_setting WHERE name='Attendance Setting'";
$result_setting = $db->query($sql_setting);
$row_setting = $db->fetchByAssoc($result_setting);


$sql = "SELECT * FROM pa_attendance WHERE deleted=0 AND assigned_user_id='$curr_user_id' AND attendance_date_time like '$curr_date%'";
//echo $sql;
$results = $db->query($sql);
$i=0;
while($row = $db->fetchByAssoc($results)) 
{
	$rec_id = $row['id'];

	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	$att->retrieve($rec_id);


	$i++;
	if($row['punch_out_date_time']=="" && $row['name']=="Punch In"  && $row['lunch_in_date_time']=="")
	{
		$subject_line .="<OPTION value='Punch Out'>Punch Out</OPTION>";
		$subject_line .="<OPTION value='Lunch In'>Lunch In</OPTION>";	
		
		$disable_punch_in=1;
		$disable_lunch_out=1;
		

		$date1 = $crm_datetime;		

		$date2 = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['office_out_time']));

		$lunch_in_time = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['lunch_in_time']));		

		$lunch_out_time = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['lunch_out_time']));

		?>
        <input type='hidden' id='lunch_in_time' value='<?php echo $lunch_in_time ?>' />
        <input type='hidden' id='lunch_out_time' value='<?php echo $lunch_out_time ?>' />        
        <input type='hidden' id='lunch_current_time' value='<?php echo $date1 ?>' />        
		<?php

		if (strtotime($date2) > strtotime($date1))
		{
			$status_value = "<div id='status_label' style='font-size:14px; font-weight:bold; color:#F00'>Early Out</div><input type='hidden' id='status' name='status' value='Early_Out'/>";
		}
		else
		{
			$status_value = "<div id='status_label' style='font-size:14px; font-weight:bold; color:#093'>Punch Out On Time</div><input type='hidden' id='status' name='status' value='On_Time'/>";			
		}

	}

	else if($row['punch_out_date_time']=="" && $row['name']=="Punch In" )
	{

		$subject_line .="<OPTION value='Punch Out'>Punch Out</OPTION>";

		$disable_punch_in=1;
		$disable_lunch_out=1;
		$disable_lunch_in=1;

		$rec_id = $row['id'];
		$date1 = $crm_datetime;		

		$date2 = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['office_out_time']));

		if (strtotime($date2) > strtotime($date1))
		{
			$status_value = "<label style='font-size:14px; font-weight:bold; color:#F00'>Early Out</label><input type='hidden' id='status' name='status' value='Early_Out'/>";
		}
		else
		{
			$status_value = "<label style='font-size:14px; font-weight:bold; color:#093'>Punch Out On Time</label><input type='hidden' id='status' name='status' value='On_Time'/>";			
		}

	}

	else if($row['lunch_in_date_time']!="" && $row['name']=="Lunch In")
	{
		$disable_punch_in=1;
		$disable_punch_out=1;
		$disable_lunch_in=1;
				
		$subject_line .="<OPTION value='Lunch Out'>Lunch Out</OPTION>";	
		$rec_id = $row['id'];
		$status_value = "<label style='font-size:14px; font-weight:bold; color:#093'>Resume to Work</label>";			
	}

	else
	{
		$disable_punch_in=1;
		$disable_punch_out=1;
		$disable_lunch_in=1;
		$disable_lunch_out=1;

		$subject_line .="<OPTION value='Access Denied'>Access Denied</OPTION>";	
		$status_value = "<label style='font-size:14px; font-weight:bold; color:#F00'>Wrong Punching</label>";			
		$i++;
	}
}
if ($i == 0)
{
	$subject_line .="<OPTION value='Punch In'>Punch In</OPTION>";
	$disable_punch_out=1;
	$disable_lunch_in=1;
	$disable_lunch_out=1;
	
	$date1 = $crm_datetime;		

	$date2 = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['office_in_time']));

	if (strtotime($date2) > strtotime($date1))
	{
		$status_value = "<label style='font-size:14px; font-weight:bold; color:#093'>Punch In on Time</label><input type='hidden' id='status' name='status' value='On_Time'/>";
	}
	else
	{
		$status_value = "<label style='font-size:14px; font-weight:bold; color:#F00'>Late In</label><input type='hidden' id='status' name='status' value='Late_In'/>";			
	}
		
}

$subject_line .= "</SELECT>";

?>
<table style="width:100%">
	<tbody>
    	<tr>
        	<td>
            	<div class="moduleTitle">
					<h2> Punch Attendance </h2>
                </div>


<div class="clear"></div>

<form id="EditView" name="EditView" method="POST" action="index.php">
	<table width="100%" cellspacing="0" cellpadding="0" border="0" class="dcQuickEdit">
	<tbody>
    	<tr>
			<td class="buttons">
				<input type="hidden" value="pa_Attendance" name="module">
				<input type="hidden" value="" name="record">
				<input type="hidden" value="false" name="isDuplicate">
                <input type="hidden" name="action" value="save_attendance">
                <input type="hidden" value="pa_Attendance" name="return_module">
                <input type="hidden" value="index" name="return_action">
                <input type="hidden" value="" name="return_id">
                <input type="hidden" name="module_tab"> 
                <input type="hidden" value="pa_Attendance" name="relate_to">
                <input type="hidden" value="" name="relate_id">
                <input type="hidden" value="1" name="offset">
                <input type="hidden" value="<?php echo $rec_id ?>" name="rec_id" />
                <input type="hidden" value="" id="subject" name="subject"/>
				<!-- to be used for id for buttons with custom code in def files-->
			</td>
			<td align="right">
			</td>
		</tr>
	</tbody>
</table>
<span id="tabcounterJS"><script>SUGAR.TabFields=new Array();//this will be used to track tabindexes for references</script></span>
<div id="EditView_tabs">
	<div>
		<div id="detailpanel_1">
        <table width="100%">
        	<tr>
            <td valign="top">
            <table width="100%" cellspacing="1" cellpadding="0" border="0" class="yui3-skin-sam edit view panelContainer">
            	<tr>
                	<td>
                    	<?php 
						if ($disable_punch_in==0)
						{
						?>
                    	<a href="#"><img src="modules/pa_Attendance/images/punch_in.png" onmouseover=src="modules/pa_Attendance/images/punch_in_over.png" onmouseout=src="modules/pa_Attendance/images/punch_in.png" height="122" width="122" border="1" onclick="sub(1)"/></a>
                        <?php
						}
						else
						{
						?>
                    	<img src="modules/pa_Attendance/images/punch_in_disable.png" height="122" width="122" border="1"/></a>
						<?php
						}
						?>
                    </td>
                    <td >
                    	<?php 
						if ($disable_punch_out==0)
						{
						?>
	                    <a href="#"><img src="modules/pa_Attendance/images/punch_out.png" onmouseover=src="modules/pa_Attendance/images/punch_out_over.png" onmouseout=src="modules/pa_Attendance/images/punch_out.png" height="122" width="122" border="1" onclick="sub(2)"/></a>
                        <?php
						}
						else
						{
						?>
                    	<img src="modules/pa_Attendance/images/punch_out_disable.png" height="122" width="122" border="1"/></a>                        
                        <?php
						}
						?>
                    </td>
                </tr>
                <tr>
                	<td>&nbsp;<b><?php echo $att->attendance_date_time ?></b>
                    	
                    </td>
                    <td>&nbsp;<b><?php echo $att->punch_out_date_time ?></b>
                    
                    </td>
                </tr>

                	<td>
                    	<?php 
						if ($disable_lunch_in==0)
						{
						?>
                    	<a href="#"><img src="modules/pa_Attendance/images/lunch_in.png" onmouseover=src="modules/pa_Attendance/images/lunch_in_over.png" onmouseout=src="modules/pa_Attendance/images/lunch_in.png" height="120" width="120" border="1" onclick="sub(3)"/></a>
						<?php
						}
						else
						{
						?>
                    	<img src="modules/pa_Attendance/images/lunch_in_disable.png" height="120" width="120" border="1"/></a>
						<?php
						}
						?>
                    </td>
                    <td >
                    	<?php 
						if ($disable_lunch_out==0)
						{
						?>

	                    <a href="#"><img src="modules/pa_Attendance/images/lunch_out.png" onmouseover=src="modules/pa_Attendance/images/lunch_out_over.png" onmouseout=src="modules/pa_Attendance/images/lunch_out.png" height="120" width="120" border="1" onclick="sub(4)"/></a>
						<?php
						}
						else
						{
						?>
                    	<img src="modules/pa_Attendance/images/lunch_out_disable.png" height="120" width="120" border="1"/></a>
						<?php
						}
						?>

                    </td>
                </tr>
                <tr>
                	<td>&nbsp;<b><?php echo $att->lunch_in_date_time ?></b>
                    	
                    </td>
                    <td>&nbsp;<b><?php echo $att->lunch_out_date_time ?></b>
                    	
                    </td>
                </tr>
                
            </table>
            </td>
            <td>    
			<table width="100%" cellspacing="1" cellpadding="0" border="0" class="yui3-skin-sam edit view panelContainer" id="Default_pa_Attendance_Subpanel">
				<tbody>
                	<tr>

						<td width="5%" valign="top" scope="col" id="name_label">
						Status:
						<span class="required">*</span>
						</td>
						<td width="43%" valign="top" colspan="3">
							<?php echo $status_value ?>
						</td>

                   	</tr>
                    <tr>
                    	<td>&nbsp;</td>
                    </tr>
					<tr>
						<td width="10%" valign="top" scope="col" id="attendance_date_time_label">
							<?php echo $main_label ?>
						</td>
						<td width="37.5%" valign="top">
							<table cellspacing="0" cellpadding="0" border="0" class="dateTime">
							<tbody>
                            	<tr valign="middle">
									<td nowrap="">
										<label style="font-size:14px; font-weight:bold;"><?php echo $punch_date_time ?></label>
									</td>
								</tr>
							</tbody>
                            </table>
						</td>
                    <tr>
                    	<td>&nbsp;</td>
                    </tr>

					<tr>
<tr>
<td width="6%" valign="top" scope="col" id="description_label">
Remarks:
<span class="required">*</span>
</td>
<td width="37.5%" valign="top" colspan="3">
<textarea tabindex="0" title="" cols="80" rows="12" name="description" id="description"></textarea>
</td></tr>
<tr>
<td>
</td>
<td>
<?php 
if ($i==2)
{
	echo "<label style='font-size:14px; font-weight:bold; color:#F00'>Today's Attendance is already punched, If something wrong contact your administrator</label>";
}
else
{
?>

<?php
}
?>
</td>
</tr>
</tbody></table>
</td>
</tr>
</table>
</div>
</div></div>
</form>
        </td></tr></tbody></table>