<?php
global $current_user, $timedate;

static $user_today_timestamp = null;

if(!isset($user_today_timestamp)) {
	$gmt_today = $timedate->get_gmt_db_datetime();
	$user_today = $timedate->handle_offset($gmt_today, $GLOBALS['timedate']->get_db_date_time_format());
	preg_match_all('/\d*/', $user_today, $matches);
	$matches = $matches[0];
	$user_today_timestamp = mktime($matches[6], $matches[8], '0', $matches[2], $matches[4], $matches[0]);
}

$db = DBManagerFactory::getInstance();

$sql_setting = "SELECT * FROM attendance_setting WHERE name='Attendance Setting'";
$result_setting = $db->query($sql_setting);
$row_setting = $db->fetchByAssoc($result_setting);


$subject = $_POST['subject'];
$date_entered = date('Y-m-d G:i:s');
$date_modified = date('Y-m-d G:i:s');
$modified_user_id = $current_user->id;	
$create_by = $current_user->id;	
$description = $_POST['description'];
$assigned_user_id = $current_user->id;	
$database_datetime = date($timedate->get_db_date_time_format());
$crm_datetime = date($GLOBALS['timedate']->get_db_date_time_format(), $user_today_timestamp);
$format_datetime =  date($timedate->get_date_format(), strtotime($crm_datetime))." ".date($timedate->get_time_format(), strtotime($crm_datetime));

$punch_time = $format_datetime;

$rec_id = $_POST['rec_id'];
$status = $_POST['status'];
if ($subject == "Punch In")
{
	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	
	$att->name = $subject;
	$att->date_entered = $date_entered;
	$att->date_modified = $date_modified;
	$att->description = $description;
	$att->status_punch_in = $status;
	$att->assigned_user_id = $assigned_user_id;
	$att->attendance_date_time = $punch_time;

	if($att->name !="")
		$att->save();
}

if ($subject == "Punch Out")
{
	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	
	$att->id = $rec_id;
	$att->name = $subject;
	$att->date_modified = $date_modified;
	$att->punch_out_remarks = $description;
	$att->status_punch_out = $status;
	$att->punch_out_date_time = $punch_time;

	if($att->id !="")
		$att->save();
}

if ($subject == "Lunch In")
{
	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	
	$att->id = $rec_id;
	$att->name = $subject;
	$att->date_modified = $date_modified;
	$att->lunch_in_remarks = $description;
	$att->lunch_in_date_time = $punch_time;

	$current_time = $crm_datetime;		

	$lunch_in_time = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['lunch_in_time']));		

	$lunch_out_time = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['lunch_out_time']));

	if(strtotime($current_time) > strtotime($lunch_out_time))
		$status = "Late_In";
	else if(strtotime($current_time) < strtotime($lunch_in_time))
		$status = "Early_In";
	else 
		$status = "On_Time";

	$att->status_lunch_in = $status;

	if($att->id !="")
		$att->save();
}

if ($subject == "Lunch Out")
{
	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	
	$att->id = $rec_id;
	$att->name = "Punch In";
	$att->date_modified = $date_modified;
	$att->lunch_out_remarks = $description;
	$att->lunch_out_date_time = $punch_time;

	$current_time = $crm_datetime;		

	$lunch_in_time = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['lunch_in_time']));		

	$lunch_out_time = date('Y-m-d',strtotime(str_replace('/','-',$crm_datetime))).'  '.date('G:i:s',strtotime($row_setting['lunch_out_time']));


	if(strtotime($current_time) > strtotime($lunch_out_time))
		$status = "Late_Out";
	else if(strtotime($current_time) < strtotime($lunch_out_time) && strtotime($current_time) < strtotime($lunch_in_time))
		$status = "Early_Out";
	else 
		$status = "On_Time";

	$att->status_lunch_out = $status;

	if($att->id !="")
		$att->save();
}

header("Location: index.php?module=pa_Attendance&action=index");
?>