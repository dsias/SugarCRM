<?php

global $current_user, $timedate;

$db = DBManagerFactory::getInstance();

if($current_user->id != 1)
{
	die("Restricted Area, Only Administrator have access");
}
else
{
?>
<div class="moduleTitle">
<h2><a href="index.php?module=Reports&amp;action=index"><img align="absmiddle" title="Reports" alt="Reports" src="themes/Sugar5/images/icon_Reports_32.gif?s=cb21d6754d45b057dac04cbcac463168&amp;c=1"></a><span class="pointer"></span>Attendance Reports</h2>
<span class="utils">&nbsp;
</div>
<script>
function sam()
{
	document.f1.action = "index.php?module=pa_Attendance&action=reports&ch="+document.f1.select_report.value;
	document.f1.submit();
}
function run_report(mov)
{
	if (mov == 1)
	{

		var b = document.getElementById("select_report"); 
		var strRpt = b.options[b.selectedIndex].text;
	
		window.open('index.php?module=pa_Attendance&action=report_by_month&inline=1&sugar_body_only=1&p_user='+document.getElementById('p_user').value+'&p_subject='+document.getElementById('p_subject').value+'&p_date_from='+document.getElementById('date_from').value+'&p_date_to='+document.getElementById('date_to').value+'&p_status_punch_in='+document.getElementById('p_status_punch_in').value+'&p_status_punch_out='+document.getElementById('p_status_punch_out').value+'&p_lunch_in='+document.getElementById('p_status_lunch_in').value+'&p_lunch_out='+document.getElementById('p_status_lunch_out').value);
	}
}
</script>
<form action="" method="POST" name="f1">

<div class="edit view search basic" style="" id="">
    <br />
<table width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody>
    	
        <tr>
        	<td width="10%">Select Report: </td>
            <td>
            <?php 
	            $html = "<SELECT id='select_report' name='select_report' onchange='sam();' >";
    	        $html .= "<OPTION value=''></OPTION>";
			
				$rep = array (
					'1' => 'Attendance Employee Report by Month',
				);
				if (isset($_GET['ch']))
				{
					$cm = $_GET['ch'];
				}
				else
				{
					$cm = '';
				}
				foreach ($rep as $key => $val)
				{
					if ($cm == $key)
						$html .= "<OPTION value='".$key."' selected>".$val."</option>";				
					else
						$html .= "<OPTION value='".$key."'>".$val."</OPTION>";
				}		

    	        $html .= "</SELECT>";
				echo($html);
			?>
			</td>
        </tr>

    </tbody>
</table>

</div>
</form>

<?php
if ($cm == "1") 
{
?> 

    <div class="edit view search basic" style="" id="">
        <br />
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
        <tbody>


            <tr>
                <td width="10%">User: </td>
                <td>
<?php

		$sql = "
			SELECT e.*,u.user_name, u.id
			FROM pa_employeedetail e
			LEFT JOIN users u ON (u.id = e.user_id_c)
			WHERE
				e.deleted=0 AND e.employee_status='Active'
		";	
		$result = $db->query($sql);
		echo ("<SELECT  id='p_user' name='p_user' >");
		while ($row = $db->fetchByAssoc($result)) 
		{
			if($row['first_name']!="")
				echo ("<OPTION value='".$row['id']."'>".$row['first_name']." ".$row['last_name']." - ".$row['user_name']."</OPTION>");
			else
				echo ("<OPTION value='".$row['id']."'>".$row['last_name']." - ".$row['user_name']."</OPTION>");			
		}
		echo ("</SELECT>");
?>
                </td>
            </tr>

            <tr>
                <td width="10%">Subject: </td>
                <td>
			<input type='text' id='p_subject' name='p_subject' value=''>
                </td>
            </tr>

            <tr>
                <td width="10%">Date From: </td>
                
                <td  valign="top">
                <span class="dateTime">
                <input type="text" maxlength="10" size="11" tabindex="104" title="" value="" id="date_from" name="date_from" autocomplete="off" class="date_input">
                <img border="0" align="absmiddle" id="date_from_trigger" alt="Enter Date" src="themes/Sugar5/images/jscalendar.gif">
                </span>
                <script type="text/javascript">
                Calendar.setup ({
                inputField : "date_from",
                ifFormat : "%d/%m/%Y %H:%M",
                daFormat : "%d/%m/%Y %H:%M",
                button : "date_from_trigger",
                singleClick : true,
                dateStr : "",
                step : 1,
                weekNumbers:false
                }
                );
                </script>
                </td>
		
                <td width="6%">Date To: </td>
                
                <td  width="50%">
                <span class="dateTime">
                <input type="text" maxlength="10" size="11" tabindex="104" title="" value="" id="date_to" name="date_to" autocomplete="off" class="date_input">
                <img border="0" align="absmiddle" id="date_to_trigger" alt="Enter Date" src="themes/Sugar5/images/jscalendar.gif">
                </span>
                <script type="text/javascript">
                Calendar.setup ({
                inputField : "date_to",
                ifFormat : "%d/%m/%Y %H:%M",
                daFormat : "%d/%m/%Y %H:%M",
                button : "date_to_trigger",
                singleClick : true,
                dateStr : "",
                step : 1,
                weekNumbers:false
                }
                );
                </script>
                </td>

            </tr>
            
            <tr>
                <td width="10%">Punch In Status: </td>
                <td>
                <?php
					$l = array (
							'Late_In' => 'Late In',
							'Early_Out' => 'Early Out',
							'Punch_In_on_Time'=> 'Punch In on Time',
							'Punch_Out_on_Time'=> 'Punch Out on Time',							
					);
			
					$html = "<SELECT id='p_status_punch_in' name='p_status_punch_in' >";
					$html .= "<OPTION value=''>All</OPTION>";
					foreach ($l as $key => $val)
					{
						$html .= "<OPTION value='".$key."'>".$val."</OPTION>";
						}		
					$html .= "</SELECT>";
					echo($html);
				?>
                </td>
            </tr>

            <tr>
                <td width="10%">Punch Out Status: </td>
                <td>
                <?php
					$l = array (
							'Late_In' => 'Late In',
							'Early_Out' => 'Early Out',
							'Punch_In_on_Time'=> 'Punch In on Time',
							'Punch_Out_on_Time'=> 'Punch Out on Time',							
					);
			
					$html = "<SELECT id='p_status_punch_out' name='p_status_punch_out' >";
					$html .= "<OPTION value=''>All</OPTION>";
					foreach ($l as $key => $val)
					{
						$html .= "<OPTION value='".$key."'>".$val."</OPTION>";
						}		
					$html .= "</SELECT>";
					echo($html);
				?>
                </td>
            </tr>

            <tr>
                <td width="10%">Lunch In Status: </td>
                <td>
                <?php
					$l = array (
							'Late_In' => 'Late In',
							'Early_Out' => 'Early Out',
							'Punch_In_on_Time'=> 'Punch In on Time',
							'Punch_Out_on_Time'=> 'Punch Out on Time',							
					);
			
					$html = "<SELECT id='p_status_lunch_in' name='p_status_lunch_in' >";
					$html .= "<OPTION value=''>All</OPTION>";
					foreach ($l as $key => $val)
					{
						$html .= "<OPTION value='".$key."'>".$val."</OPTION>";
						}		
					$html .= "</SELECT>";
					echo($html);
				?>
                </td>
            </tr>

            <tr>
                <td width="10%">Lunch Out Status: </td>
                <td>
                <?php
					$l = array (
							'Late_In' => 'Late In',
							'Early_Out' => 'Early Out',
							'Punch_In_on_Time'=> 'Punch In on Time',
							'Punch_Out_on_Time'=> 'Punch Out on Time',							
					);
			
					$html = "<SELECT id='p_status_lunch_out' name='p_status_lunch_out' >";
					$html .= "<OPTION value=''>All</OPTION>";
					foreach ($l as $key => $val)
					{
						$html .= "<OPTION value='".$key."'>".$val."</OPTION>";
						}		
					$html .= "</SELECT>";
					echo($html);
				?>
                </td>
            </tr>


			<tr>
            	<td><br /></td>
                <td></td>
            </tr>
    		<tr>
            	<td></td>
                <td><input type="button" id="run_report" value="Run Report" name="run_report" onclick="run_report('1');"></td>
            </tr>    
        </tbody>
    </table>
    
    </div>
<?php
}
?>
<?php
if ($cm == "2") 
{
?> 

    <div class="edit view search basic" style="" id="">
        <br />
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
        <tbody>
            
            <tr>
                <td width="10%">Created by User: </td>
                <td>
                <?php
					global $locale, $app_list_strings, $app_strings, $mod_strings;
					$sql = "SELECT * FROM users WHERE status='Active'";
				  	$result = $this->bean->db->query($sql);
					$html = "<SELECT id='users' name='users' >";
					$html .= "<OPTION value=''>ALL</OPTION>";
					
					while ($row = $this->bean->db->fetchByAssoc($result))
					{
						if ($row['first_name'] == "")
							$html .= "<OPTION value='".$row['id']."'>".$row['last_name']."</OPTION>";
						else
							$html .= "<OPTION value='".$row['id']."'>".$row['first_name']." ".$row['last_name']."</OPTION>";
					}
						
					$html .= "</SELECT>";
					echo($html);
				?>
                </td>
            </tr>

			<tr>
            	<td><br /></td>
                <td></td>
            </tr>
    		<tr>
            	<td></td>
                <td><input type="button" id="run_report" value="Run Report" name="run_report" onclick="run_report(2);"></td>
            </tr>    
        </tbody>
    </table>
    
    </div>
<?php
}
?>




<?php
	
}
?>