<?php

$db = DBManagerFactory::getInstance();

// Report Parameters
$p_user=$_GET['p_user'];
$p_subject=$_GET['p_subject'];
$p_date_from=$_GET['p_date_from'];
$p_date_to=$_GET['p_date_to'];

$p_status_punch_in=$_GET['p_status_punch_in'];
$p_status_punch_out = $_GET['p_status_punch_out'];
$p_lunch_punch_in = $_GET['p_lunch_in'];
$p_lunch_punch_out = $_GET['p_lunch_out'];

$p1 = "";
$p2 = "";
$p3 = "";
$p4 = "";
$p5 = "";

if($p_user!="")
{
	$p1 = " AND a.assigned_user_id = '".$p_user."'";
}
if($p_subject!="")
{
	$p2 = " AND a.name like '%".$p_subject."%'";
}
if($p_date_from!="")
{
	$a = explode('/',$p_date_from);
	$d_from = $a[2]."-".$a[1]."-".$a[0];
	$a = explode('/',$p_date_to);
	$d_to = $a[2]."-".$a[1]."-".$a[0];

	$p3 = " AND a.attendance_date_time BETWEEN '".$d_from." 00:00:00' AND '".$d_to." 23:59:59'";
}
if($p_status_punch_in!="")
{
	$p4 = " AND a.status_punch_in like '%".$p_status_punch_in."%'";
}

if($p_status_punch_out!="")
{
	$p5 = " AND a.status_punch_out like '%".$p_status_punch_out."%'";
}


$sql = "
SELECT * 
FROM pa_attendance a
WHERE a.deleted=0 $p1 $p2 $p3 $p4 $p5
ORDER BY attendance_date_time
";
//echo $sql;
$results = $db->query($sql);


$sql1 = "
SELECT concat(ifNULL(first_name,''),' ',last_name) as full_name
FROM users
WHERE id = ".$p_user."
";

$results1 = $db->query($sql1);
$row1 = $db->fetchByAssoc($results1);



require('mypdf/mc_table_1.php');

$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage('L');
$pdf->SetSubject("sarfaraz",true);
$pdf->SetAuthor("sarfaraz",true);
$pdf->SetTitle("MEC-MIS Reports",true);
$pdf->SetCreator("sarfaraz",true);
$pdf->SetKeywords("sarfaraz",true);
//$pdf->Image('img/header.png',10,10,-240);
//$pdf->Image('img/globe-sindh.png',10,3,0);
//$pdf->Image('img/mec_logo.png',268,6,-220);
$pdf->Ln(6);
$pdf->SetFont('Arial','B',18);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(50);
$pdf->Cell(0,0,'Employee Attendance Report',0,0,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);



if($p_user!="")
{
$pdf->Cell(0,0,'User Name: '.$row1['full_name'],0,0,'L');
$pdf->Ln(4);
}

if($p_subject!="")
{
$pdf->Cell(0,0,'Subject: '.$p_subject,0,0,'L');
$pdf->Ln(4);
}

if($p_date_from!="")
{
$pdf->Cell(0,0,'Date From: '.$p_date_from.' To: '.$p_date_to,0,0,'L');
$pdf->Ln(4);
}

if($p_status_punch_in!="")
{
$pdf->Cell(0,0,'Status Punch In: '.str_replace('_',' ',$p_status_punch_in),0,0,'L');
$pdf->Ln(4);
}

if($p_status_punch_out!="")
{
$pdf->Cell(0,0,'Status Punch Out: '.str_replace('_',' ',$p_status_punch_out),0,0,'L');$pdf->Ln(4);
}

if($p_lunch_punch_in!="")
{
$pdf->Cell(0,0,'Lunch In: '.$p_lunch_punch_in,0,0,'L');
$pdf->Ln(4);
}
if($p_lunch_punch_out!="")
{
$pdf->Cell(0,0,'Lunch Out: '.$p_lunch_punch_out,0,0,'L');
$pdf->Ln(4);
}

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('S.   #','Employee Name','Punch In','Punch Out','Lunch In', 'Lunch Out','Subject');



$pdf->Ln(2);
$head=0;
$sno=0;

while($row = $db->fetchByAssoc($results)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

	$main_id = $row['id'];
	
	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	$att->retrieve($main_id);

	$k = explode("<",$att->attendance_date_time);
	$att->attendance_date_time = $k[0];

	$k = explode("<",$att->punch_out_date_time);
	$att->punch_out_date_time = $k[0];

	$k = explode("<",$att->lunch_in_date_time);
	$att->lunch_in_date_time = $k[0];

	$k = explode("<",$att->lunch_out_date_time);
	$att->lunch_out_date_time = $k[0];

	
	$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$att->assigned_user_name, $att->attendance_date_time.'    '.str_replace('_',' ',$att->status_punch_in),$att->punch_out_date_time.'    '.str_replace('_',' ',$att->status_punch_out),$att->lunch_in_date_time.'    '.str_replace('_',' ',$att->status_lunch_in),$att->lunch_out_date_time.'    '.str_replace('_',' ',$att->status_lunch_out),$att->name));


//	$pdf->Row(array($sno.".",$row['ref_no'], $row['scheme_name'], $row['department_name'], $row['location'], number_format($row['adp_cost'], 3, '.', ','),number_format($row['rev'], 3, '.', ','), number_format($row['cost'], 3, '.', ','),number_format($row['cost']+$row['rev'], 3, '.', ','), number_format($row['exp'], 3, '.', ',').'   ('.number_format($row['per'], 2, '.', ',').'%)'));




}
/*$pdf->SetFont('Arial','B',10);
$header_total = array('','','','','TOTAL:  ', number_format($total_total, 3, '.', ','), number_format($total_rev, 3, '.', ','), number_format($total_cap, 3, '.', ','),number_format($total_cap+$total_rev, 3, '.', ','), number_format($total_exp, 3, '.', ',')." (".(number_format(($total_exp/$total_total)*100, 2, '.', ','))."%)");
	$w = array(173,22,22,22,22,22);
//	for($i=0;$i<count($header_total);$i++)
//	{
		$pdf->SetTextColor(0,0,0);
		$pdf->SetFillColor(255, 255, 255); 			
//		$pdf->Cell($w[$i],7,$header_total[$i],1,0,'R',true);		
		$pdf->Row($header_total);
		
		$pdf->SetFillColor(255, 255, 255); 			
	//}
	$pdf->Ln();
*/
$pdf->Output();


?>