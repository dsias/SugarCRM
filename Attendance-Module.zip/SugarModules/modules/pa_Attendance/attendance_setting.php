<?php
global $current_user, $timedate;

$db = DBManagerFactory::getInstance();

if($current_user->id != 1)
{
	die("Restricted Area, Only Administrator have access");
}
else
{
	$sql_setting = "SHOW TABLES LIKE 'attendance_setting'";
	$result_setting = $db->query($sql_setting);
	$setting_exists = $db->getRowCount($result_setting);	

	if($setting_exists==0)
	{
		$sql_setting_create = "CREATE TABLE attendance_setting(
								id INT NOT NULL AUTO_INCREMENT,
								name VARCHAR(100) NOT NULL,
								date_entered DATETIME,
								date_modified DATETIME,								
								office_in_time TIME,
								office_out_time TIME,
								lunch_in_time TIME,
								lunch_out_time TIME,
								office_off_day VARCHAR(100) NOT NULL,								
								PRIMARY KEY ( id )		
								);";
		$result_setting_create = $db->query($sql_setting_create);
		$sql_insert = "INSERT INTO attendance_setting VALUES(NULL, 'Attendance Setting', '".date('Y-m-d G:i:s')."','".date('Y-m-d G:i:s')."', '09:00:00','17:00:00','13:00:00','14:00:00','Sun');";
		$result_insert = $db->query($sql_insert);
	}	
	$sql = "SELECT HOUR(`office_in_time`) AS hour_in, HOUR(`lunch_in_time`) AS lunch_hour_in, Minute(`office_in_time`) AS minute_in, Minute(`lunch_in_time`) AS lunch_minute_in, HOUR(`office_out_time`) AS hour_out, HOUR(`lunch_out_time`) AS lunch_hour_out, Minute(`office_out_time`) AS minute_out, Minute(`lunch_out_time`) AS lunch_minute_out, office_off_day FROM attendance_setting WHERE name='Attendance Setting'";
	$results = $db->query($sql);
	while($row = $db->fetchByAssoc($results)) 
	{

?>
<table style="width:100%">
	<tbody>
    	<tr>
        	<td>
            	<div class="moduleTitle">
					<h2> Attendance Setting </h2>
                </div>


<div class="clear"></div>

<form id="EditView" name="EditView" method="POST" action="index.php">
	<table width="100%" cellspacing="0" cellpadding="0" border="0" class="dcQuickEdit">
	<tbody>
    	<tr>
			<td class="buttons">
				<input type="hidden" value="pa_Attendance" name="module">
				<input type="hidden" value="" name="record">
				<input type="hidden" value="false" name="isDuplicate">
                <input type="hidden" name="action" value="save_attendance_setting">
                <input type="hidden" value="pa_Attendance" name="return_module">
                <input type="hidden" value="index" name="return_action">
                <input type="hidden" value="" name="return_id">
                <input type="hidden" name="module_tab"> 
                <input type="hidden" value="pa_Attendance" name="relate_to">
                <input type="hidden" value="" name="relate_id">
                <input type="hidden" value="1" name="offset">
				<!-- to be used for id for buttons with custom code in def files-->
			</td>
			<td align="right">
			</td>
		</tr>
	</tbody>
</table>
<div id="EditView_tabs">
	<div>
		<div id="detailpanel_1">
			<table width="100%" cellspacing="1" cellpadding="0" border="0" class="yui3-skin-sam edit view panelContainer" id="Default_pa_Attendance_Subpanel">
				<tbody>
                	<tr>
						<td width="8%" valign="top" scope="col" id="name_label">
						Office Time In:
						<span class="required">*</span>
						</td>
						<td width="37.5%" valign="top" colspan="3">
						<?php

						$m = array (
								'00' => '00',						
								'01' => '01',
								'02' => '02',
								'03' => '03',
								'04' => '04',
								'05' => '05',
								'06' => '06',
								'07' => '07',
								'08' => '08',
								'09' => '09',
								'10' => '10',
								'11' => '11',
								'12' => '12',
								'13' => '13',
								'14' => '14',																
								'15' => '15',
								'16' => '16',
								'17' => '17',
								'18' => '18',
								'19' => '19',
								'20' => '20',
								'21' => '21',	
								'22' => '22',
								'23' => '23'																																																																							
							);
							echo('<select name="office_in_hours" id="office_in_hours">');
							foreach ($m as $key => $val)
							{
								if ($row['hour_in'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> :');

						$m = array (
								'00' => '00',						
								'15' => '15',
								'30' => '30',
								'45' => '45',
							);
							echo(' <select name="office_in_minute" id="office_in_minute">');
							foreach ($m as $key => $val)
							{
								if ($row['minute_in'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> &nbsp;<label style="font-size: 10px">(Hours : Minutes)</label>');

						
						?>						
						</td>
						<td width="8%" valign="top" scope="col" id="name_label">
						Office Time Out:
						<span class="required">*</span>
						</td>
						<td width="37.5%" valign="top" colspan="3">
						<?php

						$m = array (
								'00' => '00',						
								'01' => '01',
								'02' => '02',
								'03' => '03',
								'04' => '04',
								'05' => '05',
								'06' => '06',
								'07' => '07',
								'08' => '08',
								'09' => '09',
								'10' => '10',
								'11' => '11',
								'12' => '12',
								'13' => '13',
								'14' => '14',																
								'15' => '15',
								'16' => '16',
								'17' => '17',
								'18' => '18',
								'19' => '19',
								'20' => '20',
								'21' => '21',	
								'22' => '22',
								'23' => '23'																																																																							
							);
							echo('<select name="office_out_hours" id="office_out_hours">');
							foreach ($m as $key => $val)
							{
								if ($row['hour_out'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> :');

						$m = array (
								'00' => '00',						
								'15' => '15',
								'30' => '30',
								'45' => '45',
							);
							echo(' <select name="office_out_minute" id="office_out_minute">');
							foreach ($m as $key => $val)
							{
								if ($row['minute_out'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> &nbsp;<label style="font-size: 10px">(Hours : Minutes)</label>');

						
						?>						

						</td>

                   	</tr>

                	<tr>
						<td width="8%" valign="top" scope="col" id="name_label">
						Lunch Time In:
						<span class="required">*</span>
						</td>
						<td width="37.5%" valign="top" colspan="3">
						<?php

						$m = array (
								'00' => '00',						
								'01' => '01',
								'02' => '02',
								'03' => '03',
								'04' => '04',
								'05' => '05',
								'06' => '06',
								'07' => '07',
								'08' => '08',
								'09' => '09',
								'10' => '10',
								'11' => '11',
								'12' => '12',
								'13' => '13',
								'14' => '14',																
								'15' => '15',
								'16' => '16',
								'17' => '17',
								'18' => '18',
								'19' => '19',
								'20' => '20',
								'21' => '21',	
								'22' => '22',
								'23' => '23'																																																																							
							);
							echo('<select name="lunch_in_hours" id="office_in_hours">');
							foreach ($m as $key => $val)
							{
								if ($row['lunch_hour_in'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> :');

						$m = array (
								'00' => '00',						
								'15' => '15',
								'30' => '30',
								'45' => '45',
							);
							echo(' <select name="lunch_in_minute" id="office_in_minute">');
							foreach ($m as $key => $val)
							{
								if ($row['lunch_minute_in'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> &nbsp;<label style="font-size: 10px">(Hours : Minutes)</label>');

						
						?>						
						</td>
						<td width="8%" valign="top" scope="col" id="name_label">
						Lunch Time Out:
						<span class="required">*</span>
						</td>
						<td width="37.5%" valign="top" colspan="3">
						<?php

						$m = array (
								'00' => '00',						
								'01' => '01',
								'02' => '02',
								'03' => '03',
								'04' => '04',
								'05' => '05',
								'06' => '06',
								'07' => '07',
								'08' => '08',
								'09' => '09',
								'10' => '10',
								'11' => '11',
								'12' => '12',
								'13' => '13',
								'14' => '14',																
								'15' => '15',
								'16' => '16',
								'17' => '17',
								'18' => '18',
								'19' => '19',
								'20' => '20',
								'21' => '21',	
								'22' => '22',
								'23' => '23'																																																																							
							);
							echo('<select name="lunch_out_hours" id="office_out_hours">');
							foreach ($m as $key => $val)
							{
								if ($row['lunch_hour_out'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> :');

						$m = array (
								'00' => '00',						
								'15' => '15',
								'30' => '30',
								'45' => '45',
							);
							echo(' <select name="lunch_out_minute" id="office_out_minute">');
							foreach ($m as $key => $val)
							{
								if ($row['lunch_minute_out'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select> &nbsp;<label style="font-size: 10px">(Hours : Minutes)</label>');

						
						?>						

						</td>

                   	</tr>

                	<tr>
						<td width="8%" valign="top" scope="col" id="name_label">
						Office Off Day:
						<span class="required">*</span>
						</td>
						<td width="37.5%" valign="top" colspan="3">
						<?php

						$m = array (
								'Sun' => 'Sun',						
								'Mon' => 'Mon',
								'Tue' => 'Tue',
								'Wed' => 'Wed',
								'Thu' => 'Thu',
								'Fri' => 'Fri',
								'Sat' => 'Sat',
							);
							echo('<select name="office_off_day" id="office_off_day">');
							foreach ($m as $key => $val)
							{
								if ($row['office_off_day'] == $key)
									echo("<option value='".$key."' selected>".$val."</option>");				
								else
									echo("<option value='".$key."'>".$val."</option>");				
							}
							echo('</select>');
						?>						
						</td>

                   	</tr>





</tbody></table>
</div>
</div></div>
<input type="submit" id="SAVE_FOOTER" value="Save" name="button" onclick="" class="button primary" accesskey="a" title="Save">  

</form>
        </td></tr></tbody></table>
<?php
	}
}
