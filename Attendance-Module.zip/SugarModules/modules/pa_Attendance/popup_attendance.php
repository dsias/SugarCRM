<html>
<body onload="window.open('index.php?module=pa_Attendance&action=today_attendance&inline=1&sugar_body_only=1&p_user=1&p_subject=&p_date_from=&p_date_to=&p_status_punch_in=&p_status_punch_out=&p_lunch_in=&p_lunch_out=')">

<meta http-equiv="refresh" content="0; url=index.php?module=pa_Attendance&action=index"> 
</body>
</html>