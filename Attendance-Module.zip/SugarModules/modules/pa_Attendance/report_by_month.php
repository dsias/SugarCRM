<?php

$db = DBManagerFactory::getInstance();

// Report Parameters
$p_user=$_GET['p_user'];
$p_subject=$_GET['p_subject'];
$p_date_from=$_GET['p_date_from'];
$p_date_to=$_GET['p_date_to'];

$p_status_punch_in=$_GET['p_status_punch_in'];
$p_status_punch_out = $_GET['p_status_punch_out'];
$p_lunch_punch_in = $_GET['p_lunch_in'];
$p_lunch_punch_out = $_GET['p_lunch_out'];

$p1 = "";
$p2 = "";
$p3 = "";
$p4 = "";
$p5 = "";

if($p_user!="")
{
	$p1 = " AND a.assigned_user_id = '".$p_user."'";
}
if($p_subject!="")
{
	$p2 = " AND a.name like '%".$p_subject."%'";
}
if($p_date_from!="")
{
	$a = explode('/',$p_date_from);
	$d_from = $a[2]."-".$a[1]."-".$a[0];
	$a = explode('/',$p_date_to);
	$d_to = $a[2]."-".$a[1]."-".$a[0];

	$p3 = " AND a.attendance_date_time BETWEEN '".$d_from." 00:00:00' AND '".$d_to." 23:59:59'";
}
if($p_status_punch_in!="")
{
	$p4 = " AND a.status_punch_in like '%".$p_status_punch_in."%'";
}

if($p_status_punch_out!="")
{
	$p5 = " AND a.status_punch_out like '%".$p_status_punch_out."%'";
}


$sql_set = "
SELECT * 
FROM attendance_setting
WHERE id=1
";
//echo $sql;
$results_set = $db->query($sql_set);
$row_set = $db->fetchByAssoc($results_set);

$sql1 = "
SELECT concat(ifNULL(e.first_name,''),' ',e.last_name) as full_name, e.employee_picture, u.user_name, e.employee_id, e.employee_title, e.employee_department, DATE_FORMAT(e.date_of_joining,'%d %M, %Y') as dj
FROM pa_employeedetail e
LEFT JOIN users u ON (u.id = e.user_id_c)
WHERE e.user_id_c = '".$p_user."'
";

$results1 = $db->query($sql1);
$row1 = $db->fetchByAssoc($results1);



require('mypdf/mc_table_1.php');

$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage('P');
$pdf->SetSubject("sarfaraz",true);
$pdf->SetAuthor("sarfaraz",true);
$pdf->SetTitle("MEC-MIS Reports",true);
$pdf->SetCreator("sarfaraz",true);
$pdf->SetKeywords("sarfaraz",true);
if(file_exists('employee_pic/'.$p_user.'/'.$row1['employee_picture']))
{
	$pdf->Image('employee_pic/'.$p_user.'/'.$row1['employee_picture'],8,9,26,30);
}
else
{
	$pdf->Image('modules/pa_Attendance/default.png',8,9,26,30);	
}
//$pdf->Image('img/header.png',10,10,-240);
//$pdf->Image('img/globe-sindh.png',10,3,0);
//$pdf->Image('img/mec_logo.png',268,6,-220);
$pdf->SetFont('Arial','B',16);
$pdf->SetTextColor(195,195,195);
$pdf->SetRightMargin(4);
$pdf->Cell(0,0,'Employee Attendance Report',0,0,'R');
$pdf->Ln(2);
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);



//if($p_user!="")
//{
$pdf->Cell(25);
$pdf->Cell(0,0,'Employee ID: '.$row1['employee_id'],0,0,'L');
$pdf->Ln(4);
$pdf->Cell(25);
$pdf->Cell(0,0,'CRM User Name: '.$row1['user_name'],0,0,'L');
$pdf->Ln(4);
$pdf->Cell(25);
$pdf->Cell(0,0,'Full Name: '.$row1['full_name'],0,0,'L');
$pdf->Ln(4);
$pdf->Cell(25);
$pdf->Cell(0,0,'Designation: '.$row1['employee_title'],0,0,'L');
$pdf->Ln(4);
$pdf->Cell(25);
$pdf->Cell(0,0,'Department: '.$row1['employee_department'],0,0,'L');
$pdf->Ln(4);
$pdf->Cell(25);
$pdf->Cell(0,0,'Date of Joining: '.$row1['dj'],0,0,'L');
$pdf->Ln(4);
$pdf->Cell(25);
$pdf->Cell(0,0,'Attendance From: '.$p_date_from.' To: '.$p_date_to,0,0,'L');
$pdf->Ln(4);

//}

if($p_subject!="")
{
$pdf->Cell(0,0,'Subject: '.$p_subject,0,0,'L');
$pdf->Ln(4);
}

//if($p_date_from!="")
//{
//$pdf->Cell(0,0,'Date From: '.$p_date_from.' To: '.$p_date_to,0,0,'L');
//$pdf->Ln(4);
//}

if($p_status_punch_in!="")
{
$pdf->Cell(0,0,'Status Punch In: '.str_replace('_',' ',$p_status_punch_in),0,0,'L');
$pdf->Ln(4);
}

if($p_status_punch_out!="")
{
$pdf->Cell(0,0,'Status Punch Out: '.str_replace('_',' ',$p_status_punch_out),0,0,'L');$pdf->Ln(4);
}

if($p_lunch_punch_in!="")
{
$pdf->Cell(0,0,'Lunch In: '.$p_lunch_punch_in,0,0,'L');
$pdf->Ln(4);
}
if($p_lunch_punch_out!="")
{
$pdf->Cell(0,0,'Lunch Out: '.$p_lunch_punch_out,0,0,'L');
$pdf->Ln(4);
}
$pdf->SetLeftMargin(8);

$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);
$header = array('Date','Status','Punch In','Punch Out','Lunch In', 'Lunch Out','Last Status');



$pdf->Ln(2);
$head=0;
$sno=0;

$days = (strtotime($d_to.' 00:00:00') - strtotime($d_from. ' 00:00:00'))/86400;
$i = 0;
$start_date = date('d M Y',strtotime($d_from));

$total_present = 0;
$total_leave = 0;
$total_offline = 0;
$total_holiday = 0;
$total_off = 0;
$total_absent = 0;



while($i <= $days)
{
	if ($head==0)
	{
		$head++;
		$pdf->SetFont('Arial','B',10);		
		$w = array(24,18,32,32,32,32,28);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}
	$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	
	$database_date = date('Y-m-d',strtotime($start_date));
	$sun = date('D',strtotime($start_date));

	$main_id = "";
	$print_status = "";
	$print_punch_in = "";
	$print_punch_out = "";	
	$print_lunch_in = "";	
	$print_lunch_out = "";
	$print_last_status = "";
	$print_style=0;	

	if($sun == $row_set['office_off_day'])
	{
		if($sun=="Fri")
			$sun = "Friday";
		if($sun=="Sun")
			$sun = "Sunday";
		$print_status=$sun;
		$print_style=1;
		$total_off++;
	}
	else
	{
		// Searching Holiday Start
		
		$sql_holiday = "
			SELECT * 
			FROM pa_holidays h
			WHERE h.deleted=0 and attendance_date = '$database_date' limit 1
		";
		$results_holiday = $db->query($sql_holiday);
		$holiday_name = "";
		while($row_holiday = $db->fetchByAssoc($results_holiday)) 
		{
			$holiday_name = $row_holiday['name'];
		}
		if($holiday_name != "")
		{
			$print_status="Holiday (".$holiday_name.")";
			$print_style=1;
			$total_holiday++;
		}
		else
		{
	
			// Searching for Leaave
			$sql_leave = "
				SELECT * 
				FROM pa_myleaves l
				WHERE l.deleted=0 and date_from <= '$database_date' and date_to >= '$database_date' AND created_by = '$p_user' limit 1
			";
			$results_leave = $db->query($sql_leave);
			$leave_name = "";
			$leave_type = "";
			while($row_leave = $db->fetchByAssoc($results_leave)) 
			{
				$leave_name = $row_leave['name'];
				$leave_type = str_replace("_"," ",$row_leave['apply_leave_for']);
			}
			if($leave_name != "")
			{
				$print_status=$leave_type."-Leave (".$leave_name.")";
				$print_style=1;
				$total_leave++;
			}
			else
			{
						
				// Start finding Offline Attedance
				$sql_offline = "
					SELECT * 
					FROM pa_offlineattendance o
					WHERE o.deleted=0 and o.attendance_date = '$database_date' AND o.created_by = '$p_user' limit 1
				";
				$results_offline = $db->query($sql_offline);
				$offline_name = "";
				while($row_offline = $db->fetchByAssoc($results_offline)) 
				{
					$offline_name = $row_offline['name'];
				}
				if($offline_name != "")
				{
					$print_status="Offline Attendance (".$offline_name.")";
					$print_style=1;
					$total_offline++;
				}
				else
				{
				
		
					// Start finding Present
					$sql = "
						SELECT * 
						FROM pa_attendance a
						WHERE a.deleted=0 and attendance_date_time like '$database_date%' and created_by = '$p_user'
					";
					$results = $db->query($sql);
					while($row = $db->fetchByAssoc($results)) 
					{
						$main_id = $row['id'];
					}
					if($main_id != "")
					{
						require_once('modules/pa_Attendance/pa_Attendance.php');
						$att = new pa_Attendance();
						$att->retrieve($main_id);
		
						$k = explode("<",$att->attendance_date_time);
						$att->attendance_date_time = $k[0];
						$k = explode(" ",$att->attendance_date_time);
						$att->attendance_date_time = $k[1];
		
					
						$k = explode("<",$att->punch_out_date_time);
						$att->punch_out_date_time = $k[0];
						$k = explode(" ",$att->punch_out_date_time);
						$att->punch_out_date_time = $k[1];
		
					
						$k = explode("<",$att->lunch_in_date_time);
						$att->lunch_in_date_time = $k[0];
						$k = explode(" ",$att->lunch_in_date_time);
						$att->lunch_in_date_time = $k[1];
		
					
						$k = explode("<",$att->lunch_out_date_time);
						$att->lunch_out_date_time = $k[0];
						$k = explode(" ",$att->lunch_out_date_time);
						$att->lunch_out_date_time = $k[1];
		
		
						
						$print_status = "Present";
						$total_present++;
		
		
						$print_punch_in = $att->attendance_date_time.' '.str_replace('_',' ',$att->status_punch_in);
						$print_punch_out = $att->punch_out_date_time.' '.str_replace('_',' ',$att->status_punch_out);	
						$print_lunch_in = $att->lunch_in_date_time.' '.str_replace('_',' ',$att->status_lunch_in);	
						$print_lunch_out = $att->lunch_out_date_time.' '.str_replace('_',' ',$att->status_lunch_out);
						$print_last_status = $att->name;
						
					}
					// End of Present finding
					else // Absent
					{
						$print_status = "Absent";
						$print_style = 2;
						$total_absent++;
					}
				}
				// End Finding Offline Attendance
	
			} 
			// End of Leave Searching
		}
		// Search Holiday End
	}

	if($print_style==0)
	{
		$pdf->SetWidths($w);
		$pdf->Row(array($start_date,$print_status,$print_punch_in,$print_punch_out,$print_lunch_in,$print_lunch_out,$print_last_status));
	}
	else if($print_style==1)
	{
		$k = array(24,174);
		$pdf->SetWidths($k);
		$pdf->Row_Style_1(array($start_date,$print_status));
	}
	else if($print_style==2)
	{
		$k = array(24,174);
		$pdf->SetWidths($k);
		$pdf->Row_Style_2(array($start_date,$print_status));
	}


	

	
	$start_date = date("d M Y",strtotime('+1 day', strtotime($start_date)));
	$i++;
}
$pdf->Ln(6);
$pdf->SetFont('Arial','B',16);
$pdf->SetTextColor(195,195,195);
$pdf->SetRightMargin(4);
$pdf->Cell(0,0,'Summary',0,0,'L');
$pdf->Ln(6);
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Total Present Day(s): '.$total_present,0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Total Leave Day(s): '.$total_leave,0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Total Offline Attendance Day(s): '.$total_offline,0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Total Holiday(s): '.$total_holiday,0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Total Off Day(s): '.$total_off,0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Total Absent(s): '.$total_absent,0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Total Day(s): '.$i,0,0);


//while($row = $db->fetchByAssoc($results)) 
//{
	
/*	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

	$main_id = $row['id'];
	
	require_once('modules/pa_Attendance/pa_Attendance.php');
	$att = new pa_Attendance();
	$att->retrieve($main_id);

	$k = explode("<",$att->attendance_date_time);
	$att->attendance_date_time = $k[0];

	$k = explode("<",$att->punch_out_date_time);
	$att->punch_out_date_time = $k[0];

	$k = explode("<",$att->lunch_in_date_time);
	$att->lunch_in_date_time = $k[0];

	$k = explode("<",$att->lunch_out_date_time);
	$att->lunch_out_date_time = $k[0];

	
	$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$att->assigned_user_name, $att->attendance_date_time.'    '.str_replace('_',' ',$att->status_punch_in),$att->punch_out_date_time.'    '.str_replace('_',' ',$att->status_punch_out),$att->lunch_in_date_time.'    '.str_replace('_',' ',$att->status_lunch_in),$att->lunch_out_date_time.'    '.str_replace('_',' ',$att->status_lunch_out),$att->name));

*/
//	$pdf->Row(array($sno.".",$row['ref_no'], $row['scheme_name'], $row['department_name'], $row['location'], number_format($row['adp_cost'], 3, '.', ','),number_format($row['rev'], 3, '.', ','), number_format($row['cost'], 3, '.', ','),number_format($row['cost']+$row['rev'], 3, '.', ','), number_format($row['exp'], 3, '.', ',').'   ('.number_format($row['per'], 2, '.', ',').'%)'));




//}
/*$pdf->SetFont('Arial','B',10);
$header_total = array('','','','','TOTAL:  ', number_format($total_total, 3, '.', ','), number_format($total_rev, 3, '.', ','), number_format($total_cap, 3, '.', ','),number_format($total_cap+$total_rev, 3, '.', ','), number_format($total_exp, 3, '.', ',')." (".(number_format(($total_exp/$total_total)*100, 2, '.', ','))."%)");
	$w = array(173,22,22,22,22,22);
//	for($i=0;$i<count($header_total);$i++)
//	{
		$pdf->SetTextColor(0,0,0);
		$pdf->SetFillColor(255, 255, 255); 			
//		$pdf->Cell($w[$i],7,$header_total[$i],1,0,'R',true);		
		$pdf->Row($header_total);
		
		$pdf->SetFillColor(255, 255, 255); 			
	//}
	$pdf->Ln();
*/
$pdf->Output();


?>