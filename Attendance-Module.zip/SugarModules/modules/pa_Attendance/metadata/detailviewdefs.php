<?php
$module_name = 'pa_Attendance';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'attendance_date_time',
            'label' => 'LBL_ATTENDANCE_DATE_TIME',
          ),
          1 => 
          array (
            'name' => 'punch_out_date_time',
            'label' => 'LBL_PUNCH_OUT_DATE_TIME',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'lunch_in_date_time',
            'label' => 'LBL_LUNCH_IN_DATE_TIME',
          ),
          1 => 
          array (
            'name' => 'lunch_out_date_time',
            'label' => 'LBL_LUNCH_OUT_DATE_TIME',
          ),
        ),
        3 => 
        array (
          0 => 'date_entered',
          1 => 'date_modified',
        ),
        4 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'punch_out_remarks',
            'studio' => 'visible',
            'label' => 'LBL_PUNCH_OUT_REMARKS',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'lunch_in_remarks',
            'studio' => 'visible',
            'label' => 'LBL_LUNCH_IN_REMARKS',
          ),
          1 => 
          array (
            'name' => 'lunch_out_remarks',
            'studio' => 'visible',
            'label' => 'LBL_LUNCH_OUT_REMARKS',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'admin_remarks',
            'studio' => 'visible',
            'label' => 'LBL_ADMIN_REMARKS',
          ),
        ),
      ),
    ),
  ),
);
?>
