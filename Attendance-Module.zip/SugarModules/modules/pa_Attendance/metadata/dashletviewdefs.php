<?php
$dashletData['pa_AttendanceDashlet']['searchFields'] = array (
  'attendance_date_time' => 
  array (
    'default' => '',
  ),
  'lunch_out_date_time' => 
  array (
    'default' => '',
  ),
  'assigned_user_id' => 
  array (
    'default' => '',
  ),
);
$dashletData['pa_AttendanceDashlet']['columns'] = array (
  'name' => 
  array (
    'width' => '15%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'attendance_date_time' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_ATTENDANCE_DATE_TIME',
    'width' => '10%',
    'default' => true,
    'name' => 'attendance_date_time',
  ),
  'punch_out_date_time' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_PUNCH_OUT_DATE_TIME',
    'width' => '10%',
    'default' => true,
    'name' => 'punch_out_date_time',
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'lunch_in_date_time' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_LUNCH_IN_DATE_TIME',
    'width' => '10%',
    'default' => false,
    'name' => 'lunch_in_date_time',
  ),
  'lunch_out_date_time' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_LUNCH_OUT_DATE_TIME',
    'width' => '10%',
    'default' => false,
    'name' => 'lunch_out_date_time',
  ),
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => false,
    'name' => 'date_entered',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
);
