<?php
$module_name = 'pa_Attendance';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'width' => '10%',
        'default' => true,
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'attendance_date_time' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_ATTENDANCE_DATE_TIME',
        'width' => '10%',
        'default' => true,
        'name' => 'attendance_date_time',
      ),
      'punch_out_date_time' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_PUNCH_OUT_DATE_TIME',
        'width' => '10%',
        'default' => true,
        'name' => 'punch_out_date_time',
      ),
      'lunch_in_date_time' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_LUNCH_IN_DATE_TIME',
        'width' => '10%',
        'default' => true,
        'name' => 'lunch_in_date_time',
      ),
      'lunch_out_date_time' => 
      array (
        'type' => 'datetimecombo',
        'label' => 'LBL_LUNCH_OUT_DATE_TIME',
        'width' => '10%',
        'default' => true,
        'name' => 'lunch_out_date_time',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
