<?php
$module_name = 'pa_Attendance';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '15%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ATTENDANCE_DATE_TIME' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_ATTENDANCE_DATE_TIME',
    'width' => '14%',
    'default' => true,
  ),
  'PUNCH_OUT_DATE_TIME' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_PUNCH_OUT_DATE_TIME',
    'width' => '14%',
    'default' => true,
  ),
  'LUNCH_IN_DATE_TIME' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_LUNCH_IN_DATE_TIME',
    'width' => '14%',
    'default' => true,
  ),
  'LUNCH_OUT_DATE_TIME' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_LUNCH_OUT_DATE_TIME',
    'width' => '14%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '14%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'PUNCH_OUT_REMARKS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_PUNCH_OUT_REMARKS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'LUNCH_OUT_REMARKS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_LUNCH_OUT_REMARKS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'ADMIN_REMARKS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_ADMIN_REMARKS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'STATUS_LUNCH_IN' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_STATUS_LUNCH_IN',
    'width' => '10%',
    'default' => false,
  ),
  'STATUS_LUNCH_OUT' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_STATUS_LUNCH_OUT',
    'width' => '10%',
    'default' => false,
  ),
  'STATUS_PUNCH_IN' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_STATUS_PUNCH_IN',
    'width' => '10%',
    'default' => false,
  ),
  'STATUS_PUNCH_OUT' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_STATUS_PUNCH_OUT',
    'width' => '10%',
    'default' => false,
  ),
  'LUNCH_IN_REMARKS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_LUNCH_IN_REMARKS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
);
?>
