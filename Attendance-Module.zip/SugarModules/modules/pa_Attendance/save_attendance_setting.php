<?php
global $current_user, $timedate;

$db = DBManagerFactory::getInstance();

$date_modified = date('Y-m-d G:i:s');
$office_in_hours = $_POST['office_in_hours'];
$office_in_minute = $_POST['office_in_minute'];

$office_out_hours = $_POST['office_out_hours'];
$office_out_minute = $_POST['office_out_minute'];

$lunch_in_hours = $_POST['lunch_in_hours'];
$lunch_in_minute = $_POST['lunch_in_minute'];

$lunch_out_hours = $_POST['lunch_out_hours'];
$lunch_out_minute = $_POST['lunch_out_minute'];
$office_off_day = $_POST['office_off_day'];


$sql = "UPDATE attendance_setting SET office_in_time='$office_in_hours:$office_in_minute:00', lunch_in_time='$lunch_in_hours:$lunch_in_minute:00', office_out_time='$office_out_hours:$office_out_minute:00',lunch_out_time='$lunch_out_hours:$lunch_out_minute:00', date_modified='$date_modified', office_off_day='$office_off_day' WHERE name='Attendance Setting'";
$result = $db->query($sql);

header("Location: index.php?module=pa_Attendance&action=index");
?>