<?php
 // created: 2013-07-31 06:36:54
$layout_defs["pa_EmployeeDocuments"]["subpanel_setup"]['pa_employe169fcuments_ida'] = array (
  'order' => 100,
  'module' => 'pa_EmployeeDocuments',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDOCUMENTS_FROM_PA_EMPLOYEEDOCUMENTS_R_TITLE',
  'get_subpanel_data' => 'pa_employe169fcuments_ida',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
