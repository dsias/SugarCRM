<?php
 // created: 2013-08-04 05:56:37
$layout_defs["pa_EmployeeDetail"]["subpanel_setup"]['pa_qualification_pa_employeedetail'] = array (
  'order' => 100,
  'module' => 'pa_Qualification',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PA_QUALIFICATION_PA_EMPLOYEEDETAIL_FROM_PA_QUALIFICATION_TITLE',
  'get_subpanel_data' => 'pa_qualification_pa_employeedetail',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
