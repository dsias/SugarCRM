<?php
 // created: 2013-08-04 05:56:36
$layout_defs["pa_EmployeeLeaves"]["subpanel_setup"]['pa_myleaves_pa_employeeleaves'] = array (
  'order' => 100,
  'module' => 'pa_MyLeaves',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PA_MYLEAVES_PA_EMPLOYEELEAVES_FROM_PA_MYLEAVES_TITLE',
  'get_subpanel_data' => 'pa_myleaves_pa_employeeleaves',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
