<?php
// created: 2013-08-04 05:56:35
$dictionary["pa_employeedocuments_pa_employeedetail"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'pa_employeedocuments_pa_employeedetail' => 
    array (
      'lhs_module' => 'pa_EmployeeDetail',
      'lhs_table' => 'pa_employeedetail',
      'lhs_key' => 'id',
      'rhs_module' => 'pa_EmployeeDocuments',
      'rhs_table' => 'pa_employeedocuments',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'pa_employeedocuments_pa_employeedetail_c',
      'join_key_lhs' => 'pa_employeedocuments_pa_employeedetailpa_employeedetail_ida',
      'join_key_rhs' => 'pa_employeedocuments_pa_employeedetailpa_employeedocuments_idb',
    ),
  ),
  'table' => 'pa_employeedocuments_pa_employeedetail_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'pa_employeedocuments_pa_employeedetailpa_employeedetail_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'pa_employeedocuments_pa_employeedetailpa_employeedocuments_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'pa_employeedocuments_pa_employeedetailspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'pa_employeedocuments_pa_employeedetail_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'pa_employeedocuments_pa_employeedetailpa_employeedetail_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'pa_employeedocuments_pa_employeedetail_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'pa_employeedocuments_pa_employeedetailpa_employeedocuments_idb',
      ),
    ),
  ),
);