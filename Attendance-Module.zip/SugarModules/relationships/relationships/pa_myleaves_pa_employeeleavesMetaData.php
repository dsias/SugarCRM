<?php
// created: 2013-08-04 05:56:36
$dictionary["pa_myleaves_pa_employeeleaves"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'pa_myleaves_pa_employeeleaves' => 
    array (
      'lhs_module' => 'pa_EmployeeLeaves',
      'lhs_table' => 'pa_employeeleaves',
      'lhs_key' => 'id',
      'rhs_module' => 'pa_MyLeaves',
      'rhs_table' => 'pa_myleaves',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'pa_myleaves_pa_employeeleaves_c',
      'join_key_lhs' => 'pa_myleaves_pa_employeeleavespa_employeeleaves_ida',
      'join_key_rhs' => 'pa_myleaves_pa_employeeleavespa_myleaves_idb',
    ),
  ),
  'table' => 'pa_myleaves_pa_employeeleaves_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'pa_myleaves_pa_employeeleavespa_employeeleaves_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'pa_myleaves_pa_employeeleavespa_myleaves_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'pa_myleaves_pa_employeeleavesspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'pa_myleaves_pa_employeeleaves_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'pa_myleaves_pa_employeeleavespa_employeeleaves_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'pa_myleaves_pa_employeeleaves_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'pa_myleaves_pa_employeeleavespa_myleaves_idb',
      ),
    ),
  ),
);