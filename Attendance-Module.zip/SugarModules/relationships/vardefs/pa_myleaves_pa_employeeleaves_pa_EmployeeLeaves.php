<?php
// created: 2013-08-04 05:56:36
$dictionary["pa_EmployeeLeaves"]["fields"]["pa_myleaves_pa_employeeleaves"] = array (
  'name' => 'pa_myleaves_pa_employeeleaves',
  'type' => 'link',
  'relationship' => 'pa_myleaves_pa_employeeleaves',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_PA_MYLEAVES_PA_EMPLOYEELEAVES_FROM_PA_MYLEAVES_TITLE',
);
