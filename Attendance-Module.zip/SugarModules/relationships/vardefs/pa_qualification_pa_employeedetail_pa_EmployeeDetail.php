<?php
// created: 2013-08-04 05:56:37
$dictionary["pa_EmployeeDetail"]["fields"]["pa_qualification_pa_employeedetail"] = array (
  'name' => 'pa_qualification_pa_employeedetail',
  'type' => 'link',
  'relationship' => 'pa_qualification_pa_employeedetail',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_PA_QUALIFICATION_PA_EMPLOYEEDETAIL_FROM_PA_QUALIFICATION_TITLE',
);
