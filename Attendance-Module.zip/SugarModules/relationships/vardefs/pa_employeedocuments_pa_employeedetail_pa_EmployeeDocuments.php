<?php
// created: 2013-08-04 05:56:36
$dictionary["pa_EmployeeDocuments"]["fields"]["pa_employeedocuments_pa_employeedetail"] = array (
  'name' => 'pa_employeedocuments_pa_employeedetail',
  'type' => 'link',
  'relationship' => 'pa_employeedocuments_pa_employeedetail',
  'source' => 'non-db',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDETAIL_FROM_PA_EMPLOYEEDETAIL_TITLE',
  'id_name' => 'pa_employeedocuments_pa_employeedetailpa_employeedetail_ida',
);
$dictionary["pa_EmployeeDocuments"]["fields"]["pa_employeedocuments_pa_employeedetail_name"] = array (
  'name' => 'pa_employeedocuments_pa_employeedetail_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDETAIL_FROM_PA_EMPLOYEEDETAIL_TITLE',
  'save' => true,
  'id_name' => 'pa_employeedocuments_pa_employeedetailpa_employeedetail_ida',
  'link' => 'pa_employeedocuments_pa_employeedetail',
  'table' => 'pa_employeedetail',
  'module' => 'pa_EmployeeDetail',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["pa_EmployeeDocuments"]["fields"]["pa_employeedocuments_pa_employeedetailpa_employeedetail_ida"] = array (
  'name' => 'pa_employeedocuments_pa_employeedetailpa_employeedetail_ida',
  'type' => 'link',
  'relationship' => 'pa_employeedocuments_pa_employeedetail',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDETAIL_FROM_PA_EMPLOYEEDOCUMENTS_TITLE',
);
