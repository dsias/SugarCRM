<?php
// created: 2013-08-04 05:56:36
$dictionary["pa_EmployeeDetail"]["fields"]["pa_employeedocuments_pa_employeedetail"] = array (
  'name' => 'pa_employeedocuments_pa_employeedetail',
  'type' => 'link',
  'relationship' => 'pa_employeedocuments_pa_employeedetail',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDETAIL_FROM_PA_EMPLOYEEDOCUMENTS_TITLE',
);
