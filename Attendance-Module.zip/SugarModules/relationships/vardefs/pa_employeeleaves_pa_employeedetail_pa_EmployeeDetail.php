<?php
// created: 2013-08-04 05:56:36
$dictionary["pa_EmployeeDetail"]["fields"]["pa_employeeleaves_pa_employeedetail"] = array (
  'name' => 'pa_employeeleaves_pa_employeedetail',
  'type' => 'link',
  'relationship' => 'pa_employeeleaves_pa_employeedetail',
  'source' => 'non-db',
  'vname' => 'LBL_PA_EMPLOYEELEAVES_PA_EMPLOYEEDETAIL_FROM_PA_EMPLOYEELEAVES_TITLE',
);
