<?php
// created: 2013-07-31 06:36:55
$dictionary["pa_EmployeeDocuments"]["fields"]["pa_employeedocuments_pa_employeedocuments"] = array (
  'name' => 'pa_employeedocuments_pa_employeedocuments',
  'type' => 'link',
  'relationship' => 'pa_employeedocuments_pa_employeedocuments',
  'source' => 'non-db',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDOCUMENTS_FROM_PA_EMPLOYEEDOCUMENTS_L_TITLE',
  'id_name' => 'pa_employe169fcuments_ida',
);
$dictionary["pa_EmployeeDocuments"]["fields"]["pa_employeedocuments_pa_employeedocuments_name"] = array (
  'name' => 'pa_employeedocuments_pa_employeedocuments_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDOCUMENTS_FROM_PA_EMPLOYEEDOCUMENTS_L_TITLE',
  'save' => true,
  'id_name' => 'pa_employe169fcuments_ida',
  'link' => 'pa_employeedocuments_pa_employeedocuments',
  'table' => 'pa_employeedocuments',
  'module' => 'pa_EmployeeDocuments',
  'rname' => 'document_name',
);
$dictionary["pa_EmployeeDocuments"]["fields"]["pa_employe169fcuments_ida"] = array (
  'name' => 'pa_employe169fcuments_ida',
  'type' => 'link',
  'relationship' => 'pa_employeedocuments_pa_employeedocuments',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_PA_EMPLOYEEDOCUMENTS_PA_EMPLOYEEDOCUMENTS_FROM_PA_EMPLOYEEDOCUMENTS_R_TITLE',
);
