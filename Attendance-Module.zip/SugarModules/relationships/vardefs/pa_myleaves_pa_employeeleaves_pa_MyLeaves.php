<?php
// created: 2013-08-04 05:56:36
$dictionary["pa_MyLeaves"]["fields"]["pa_myleaves_pa_employeeleaves"] = array (
  'name' => 'pa_myleaves_pa_employeeleaves',
  'type' => 'link',
  'relationship' => 'pa_myleaves_pa_employeeleaves',
  'source' => 'non-db',
  'vname' => 'LBL_PA_MYLEAVES_PA_EMPLOYEELEAVES_FROM_PA_EMPLOYEELEAVES_TITLE',
  'id_name' => 'pa_myleaves_pa_employeeleavespa_employeeleaves_ida',
);
$dictionary["pa_MyLeaves"]["fields"]["pa_myleaves_pa_employeeleaves_name"] = array (
  'name' => 'pa_myleaves_pa_employeeleaves_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_PA_MYLEAVES_PA_EMPLOYEELEAVES_FROM_PA_EMPLOYEELEAVES_TITLE',
  'save' => true,
  'id_name' => 'pa_myleaves_pa_employeeleavespa_employeeleaves_ida',
  'link' => 'pa_myleaves_pa_employeeleaves',
  'table' => 'pa_employeeleaves',
  'module' => 'pa_EmployeeLeaves',
  'rname' => 'name',
);
$dictionary["pa_MyLeaves"]["fields"]["pa_myleaves_pa_employeeleavespa_employeeleaves_ida"] = array (
  'name' => 'pa_myleaves_pa_employeeleavespa_employeeleaves_ida',
  'type' => 'link',
  'relationship' => 'pa_myleaves_pa_employeeleaves',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_PA_MYLEAVES_PA_EMPLOYEELEAVES_FROM_PA_MYLEAVES_TITLE',
);
