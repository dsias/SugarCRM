<?php

$admin_option_defs=array();
$admin_option_defs['Administration']['asol_config']= array($image_path . 'Administration','AlineaSol Config','AlineaSol Configuration Panel','./index.php?module=Administration&action=asolConfig');
$admin_option_defs['Administration']['asol_repair']= array($image_path . 'Administration','AlineaSol Repair','AlineaSol Modules Repair','./index.php?module=Administration&action=asolRepair');
$admin_group_header[]= array('AlineaSol Config','',false,$admin_option_defs, 'Configuration section for AlineaSol modules');

?>