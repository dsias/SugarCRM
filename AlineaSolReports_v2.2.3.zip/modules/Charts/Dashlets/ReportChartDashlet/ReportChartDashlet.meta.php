<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings, $current_language;

$dashletMeta['ReportChartDashlet'] = array('title'       => 'LBL_TITLE',  
                                             'description' => 'LBL_TITLE', 
                                             'icon'        => 'themes/default/images/icon_Reports_32.gif',
                                             'module'      => 'Reports', 
                                             'category'    => 'Charts');
?>
