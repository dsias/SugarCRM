<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

error_reporting(E_ALL & ~E_NOTICE);  

require_once('include/Dashlets/DashletGenericChart.php');

class ReportChartDashlet extends DashletGenericChart 
{
    public $rcd_ids = array();
    var $chartDefs;
    var $chartDefName;
    
    protected $_seedName = 'Reports';
    
    public function __construct($id, array $options = null) 
    {
        global $timedate, $db, $current_user;
            
        parent::__construct($id,$options);

		// Make a list of charts from the chartdef files
		require "modules/Charts/chartdefs.php";
		if (file_exists("custom/Charts/chartDefs.ext.php"))
			require("custom/Charts/chartDefs.ext.php");	
		$this->chartDefs = $chartDefs;
		
		
		
		$sqlReport = "SELECT id, name FROM reports WHERE deleted=0";
		$sqlReport .= (!empty($_REQUEST['sName'])) ? " AND name LIKE '%".$_REQUEST['sName']."%'" : "";
		$sqlReport .= (!empty($_REQUEST['sModule'])) ? " AND report_module LIKE '%".$_REQUEST['sModule']."%'" : "";
		$sqlReport .= (!empty($_REQUEST['sScope'])) ? " AND report_scope LIKE '%".$_REQUEST['sScope']."%'" : "";
		
		
	    if (!$current_user->is_admin) {
	
			$idsRoles = array();
			$queryUserRoles = $db->query("SELECT DISTINCT role_id FROM acl_roles_users WHERE user_id='".$current_user->id."' AND deleted=0");
			while($queryRow = $db->fetchByAssoc($queryUserRoles))
				$idsRoles[] = $queryRow['role_id'];
				
			$sqlReport .= " AND (report_scope = 'public' OR reports.assigned_user_id = '".$current_user->id."' OR reports.created_by = '".$current_user->id."'";
		
			$sqlWhereRoles = " OR (";
			foreach ($idsRoles as $idRole)
				$sqlWhereRoles .= " report_scope LIKE '%".$idRole."%' OR";
			$sqlWhereRoles = substr($sqlWhereRoles, 0, -2).")";
			
			if (empty($idsRoles))
				$sqlWhereRoles = "";
				
			$sqlReport .= $sqlWhereRoles." )";
			
		}
		
		
		//Is Domains Installed
		$DomainsQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name='AlineaSolDomains' AND status='installed'");
		$DomainsRow = $db->fetchByAssoc($DomainsQuery);
		
		if ($DomainsRow['count'] > 0) {
		
			if ((!$current_user->is_admin) || (($current_user->is_admin) && (!empty($current_user->asol_default_domain)))){
						
				require_once ('modules/asol_Domains/asol_Domains.php');
				$domainsBean = new asol_domains();
				$domainsBean->retrieve($current_user->asol_default_domain);
				
				if ($domainsBean->asol_domain_enabled) {
						
					$sqlReport .= " AND ( (reports.asol_domain_id='".$current_user->asol_default_domain."')";
					
					/*if ($current_user->asol_only_my_domain == 0) {
					
					
						//asol_domain_child_share_depth
						if (strtolower($e) != 'users') {
						
							$parentQuery = $db->query("SELECT DISTINCT asol_domains_id_c as parent_domain FROM asol_domains WHERE id = '".$current_user->asol_default_domain."'");
							$parentRow = $db->fetchByAssoc($parentQuery);
							$parentDomain = $parentRow['parent_domain'];
							$i=1;
							
							while (!empty($parentDomain)) {
							
								$sqlReport .= " OR ((reports.asol_domain_id = '".$parentRow['parent_domain']."') AND (reports.asol_domain_child_share_depth >= $i) AND (reports.asol_published_domain = 1)) ";
								
								$parentQuery = $db->query("SELECT DISTINCT asol_domains_id_c as parent_domain FROM asol_domains WHERE id = '".$parentDomain."'");
								$parentRow = $db->fetchByAssoc($parentQuery);
								$parentDomain = $parentRow['parent_domain'];
								
								$i++;
							
							} 
					
						}
						
						//asol_domain_child_share_depth condition
						
						//asol_multi_create_domain 
						if (strtolower($e) != 'users')
							$sqlReport .= " OR ((reports.asol_multi_create_domain LIKE '%;".$current_user->asol_default_domain.";%') AND (reports.asol_published_domain = 1)) ";
						//asol_multi_create_domain 
						
						
						//View hierarchy (any item above its hierarchy coul be seen)
						$childDomainsIds = $current_user->getChildDomains($current_user->asol_default_domain);
						$childDomainsStr = Array();
						foreach ($childDomainsIds as $key=>$domainId) {
							if (!$domainId['enabled'])
								array_splice($childDomainsIds, $key, 1);
							else
								$childDomainsStr[] = $domainId['id'];
						}
						$sqlReport .= (count($childDomainsIds) > 0) ? "OR (reports.asol_domain_id IN ('".implode("','", $childDomainsStr)."')) )" : ") " ;
		
					} else {*/
					
						$sqlReport .= ") ";
						
					//}
					
				} else {
				
					$sqlReport .= " AND (1!=1) ";
					
				}
							
			
			}
			
		}
		//Is Domains Installed
		
		
		$sqlReport .= " ORDER BY date_entered ASC";

		
		$reportsArray = array();
		
		$queryReport = $db->query($sqlReport);
		while($queryRow = $db->fetchByAssoc($queryReport))
			$reportsArray[] = $queryRow;
		
		foreach ($reportsArray as $value){
			$chart_list[$value['id']] = $value['name'];
			$rcd_ids[$value['id']] = $value['id'];
		}
		$this->_searchFields['which_chart']['options'] = $chart_list;
    }
    
    public function displayOptions()
    {
		global $app_list_strings, $current_user, $db;

		$this->chartDefName = $this->which_chart[0];

		if (!empty($this->chartDefs[$this->chartDefName]['searchFields']))
			foreach ($this->chartDefs[$this->chartDefName]['searchFields'] as $key => $value)
				$this->_searchFields[$key] = $value;

				
		global $dashletStrings;
		$this->_searchFields['which_chart']['vname'] = $dashletStrings['ReportChartDashlet']['LBL_WHICH_CHART'].":";

		$sModule = (isset($_REQUEST['sModule'])) ? $_REQUEST['sModule'] : "";
		$sScope = (isset($_REQUEST['sScope'])) ? $_REQUEST['sScope'] : "";
		$sName = (isset($_REQUEST['sName'])) ? $_REQUEST['sName'] : "";
		
		//asol
	    $acl_modules = ACLAction::getUserActions($current_user->id);

	    $modulesSelect = "<select id='sModule'>";
	    $modulesSelect .= (empty($sModule)) ? "<option value='' selected></option>" : "<option value=''></option>"; 
		foreach($acl_modules as $key=>$mod){
			if($mod['module']['access']['aclaccess'] >= 0)
				$modulesSelect .= ($sModule == $key) ? "<option value='".$key."' selected>".$app_list_strings['moduleList'][$key]."</option>" : "<option value='".$key."'>".$app_list_strings['moduleList'][$key]."</option>";
		}
		$modulesSelect .= "</select>";
		//asol
		$scopesSelect = "<select id='sScope'>";
		$scopesSelect .= (empty($sScope)) ? "<option value='' selected>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_ALL']."</option>" : "<option value=''>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_ALL']."</option>";
		$scopesSelect .= ($sScope == "public") ? "<option value='public' selected>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_PUBLIC']."</option>" : "<option value='public'>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_PUBLIC']."</option>";
		$scopesSelect .= ($sScope == "private") ? "<option value='private' selected>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_PRIVATE']."</option>" : "<option value='private'>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_PRIVATE']."</option>";
		$scopesSelect .= ($sScope == "role") ? "<option value='role' selected>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_ROLE']."</option>" : "<option value='role'>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE_ROLE']."</option>";
		$scopesSelect .= "</select>";
		//asol
		
		//Is Domains Installed
		$DomainsQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name='AlineaSolDomains' AND status='installed'");
		$DomainsRow = $db->fetchByAssoc($DomainsQuery);
	
		$asolAddon = ($DomainsRow['count'] <= 0) ? "<script type=\"text/javascript\" src=\"modules/Reports/templates/jquery.js\"></script>" : "";
		//Is Domains Installed
		
		$asolAddon .= "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" class=\"edit view\"><tbody>
			<tr>
				<td scope='row'>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_NAME'].":</td>
				<td><input type='text' id='sName' value='".$sName."'/></td>
			</tr>
			<tr>
				<td scope='row'>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_MODULE'].":</td>
				<td>".$modulesSelect."</td>
			</tr>
			<tr>
				<td scope='row'>".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SCOPE'].":</td>
				<td>".$scopesSelect."</td>
			</tr>
			<tr>
				<td align='right' colspan='2'><input type='button' onClick='var sModule = document.getElementById(\"sModule\").value; var sName = document.getElementById(\"sName\").value; var sScope = document.getElementById(\"sScope\").value; $(\"#dlg_mask\").remove(); SUGAR.mySugar.configureDashlet(\"".$this->id."&sModule=\"+sModule+\"&sName=\"+sName+\"&sScope=\"+sScope); return false;' value='".$dashletStrings['ReportChartDashlet']['LBL_REPORT_SEARCH']."'/></td>
			</tr>
		</tbody></table></div>
		";
		
		
        return $asolAddon.parent::displayOptions();
    }
    
    public function display() 
    {
    	global $dashletStrings, $current_user, $db;
    	
		$displayReportDashlet = true;
		
		//Check permissions to display the current Dashlet based on Domains
		//Is Domains Installed
		$DomainsQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name='AlineaSolDomains' AND status='installed'");
		$DomainsRow = $db->fetchByAssoc($DomainsQuery);
		
		if ($DomainsRow['count'] > 0) {
			$reportDomainQuery = $db->query("SELECT reports.asol_domain_id as domain_id, asol_domains.name as domain_name FROM reports LEFT JOIN asol_domains ON reports.asol_domain_id=asol_domains.id WHERE reports.id='".$this->which_chart[0]."'");
			$reportDomainRow = $db->fetchByAssoc($reportDomainQuery);
			
			if ((!empty($current_user->asol_default_domain)) && (!empty($this->which_chart[0])) && (($reportDomainRow['domain_id'] != $current_user->asol_default_domain)))
				$displayReportDashlet = false;
				
		}
		//Is Domains Installed
		
		if ($displayReportDashlet) {
			
			$chartId = (isset($this->which_chart[0])) ? $this->which_chart[0] : null;
			
			if (!empty($chartId)) {
			
				return '<div align="center">
					<img id="loadingGIF" src="themes/default/images/img_loading.gif"><span id="loadingTEXT">'.$dashletStrings['ReportChartDashlet']['LBL_LOADING_REPORT'].'</span>
					<iframe id="asolReportDashlet_'.$this->id.'" style="visibility:hidden" scrolling="auto" frameborder="no" width="100%" src="./index.php?module=Reports&action=DetailView&dashlet=true&record='.$chartId.'&dashletId='.$this->id.'&c='.time().'"></iframe>
					</div>
					';
				
			} else {
				
				return '<div align="center"></div>';
				
			}
			
		} else {
			return '<script>
					$(document).ready(function() {
						$("li[id=\'dashlet_'.$this->id.'\']").hide();
					});
				</script>';
		}
				
	}
	
}

?>
