<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

error_reporting(0);  

global $current_user, $timedate, $mod_strings, $app_strings, $theme, $db, $app_list_strings, $beanList, $beanFiles, $current_language, $sugar_config;

$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;
		


$isDashlet = (isset($_REQUEST['dashlet'])) ? true : false;
$dashletId = (isset($_REQUEST['dashletId'])) ? $_REQUEST['dashletId'] : "";


if (((!isset($sugar_config["asolReportsExtHttpUrl"])) || (!isset($sugar_config["asolReportsCurlRequestUrl"]))) || ($_REQUEST['entryPoint'] == 'viewReport')) {


	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL-----------------------------------------------Executing Report with Id [".$_REQUEST['record']."]");
	else
		$GLOBALS['log']->debug("ASOL-----------------------------------------------Executing Report with Id [".$_REQUEST['record']."]");
		
	
	//Get language from url request parameter
	if (isset($_REQUEST['language'])) {
		
		$current_language = $_REQUEST['language'];
		$mod_strings = return_module_language($current_language, "Reports");
	
	}
	
	//Check if current user is setted on request
	if (isset($_REQUEST['currentUserId'])) {
		
		$externalUser = new User();
		$current_user = $externalUser->retrieve($_REQUEST['currentUserId']);
	
	}
	
	if(!ACLController::checkAccess('Reports', 'view', true))
		die("<font color='red'>".$app_strings["LBL_EMAIL_DELETE_ERROR_DESC"]."</font>"); 
		
	
	//Generar a mayores report entero y almacenarlo en disco como "NOMBRE_REPORT_TIMESTAMP"
	$exportedReport = Array();
	
	require_once("include/SugarPHPMailer.php");
	require_once('modules/Reports/Report.php');
	require_once('modules/Reports/ReportExcel.php');
	require_once('modules/Reports/ReportPDF.php');
	require_once('modules/Reports/ReportChart.php');

	
	function sortAssocArray(&$assocArray, $key, $ascending = true, $isInteger = true) {
	
		if ($isInteger) {
	
			if ($ascending)
				usort($assocArray, create_function('$a, $b', "return (int)\$a['".$key."'] - (int)\$b['".$key."'];"));
			else
				usort($assocArray, create_function('$a, $b', "return (int)\$b['".$key."'] - (int)\$a['".$key."'];"));
		
		} else {
		
			if ($ascending)
				usort($assocArray, create_function('$a, $b', "return strcmp(\$a['".$key."'], \$b['".$key."']);"));
			else
				usort($assocArray, create_function('$a, $b', "return strcmp(\$a['".$key."'], \$b['".$key."'])*-1;"));
		
		}
	
	}
	
	
	
	//recogemos las variables del formulario de busqueda de Reports
	$return_action = (isset($_REQUEST['return_action'])) ? $_REQUEST['return_action'] : "";
	$record = (isset($_REQUEST['record'])) ? $_REQUEST['record'] : "";
	
	
	
	//recogemos el orden y el campo por el que se ordena el report actual
	$field_sort = (isset($_REQUEST['field_sort'])) ? $_REQUEST['field_sort'] : "";
	$sort_direction = (isset($_REQUEST['sort_direction'])) ? $_REQUEST['sort_direction'] : "";
	
	//Instanciamos nuestra clase Report que extiende de SugarBean
	$focus = new Report();
	
	
	$rs = $focus->getSelectionResults("SELECT * FROM reports WHERE id = '".$record."'", false);
	
	
	//Is Domains Installed
	$DomainsQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name='AlineaSolDomains' AND status='installed'");
	$DomainsRow = $db->fetchByAssoc($DomainsQuery);
	
	if ($DomainsRow['count'] > 0) {
	
		if (!$isDashlet) {
	
			$GLOBALS['log']->debug("*********************** ASOL: not default domain ".$_REQUEST['module'].": logic hook before_retrieve");
	
			$DomainNameQuery = $db->query("SELECT name FROM asol_domains WHERE id='".$rs[0]['asol_domain_id']."'");
			$DomainNameRow = $db->fetchByAssoc($DomainNameQuery);
	
			if ((($current_user->is_admin) && (!empty($current_user->asol_domain_id))) || (!$current_user->is_admin)) {
	
				if ((isset($_REQUEST['update_domain'])) && ($_REQUEST['update_domain'] != $rs[0]['asol_domain_id']))
				header("Location: index.php?module=".$_REQUEST['module']."&action=index&update_domain=".$current_user->asol_domain_id);
	
				if ($current_user->asol_default_domain != $rs[0]['asol_domain_id']) {
	
					if (!isset($_REQUEST['update_domain'])) {
	
						header("Location: index.php?module=Home&action=changeDomain&domain_id=".$rs[0]['asol_domain_id']."&domain_name=".$DomainNameRow['name']."&return_module=".$_REQUEST['module']."&return_action=".$_REQUEST['action']."&return_record=".$_REQUEST['record']);
	
					} else {
	
						if (!isset($_REQUEST['is_update'])) {
	
							header("Location: index.php?module=".$_REQUEST['module']."&action=index");
								
						}
	
					}
						
				}
	
			}
	
		}
	
	}
	//Is Domains Installed
	
	
	//Recuperamos todos los campos del report seleccionado
	
	$report_data['record'] = $rs[0]['id'];
	$report_data['report_name'] = $rs[0]['name'];
	$report_data['report_module'] = $rs[0]['report_module'];
	$report_data['description'] = $rs[0]['description'];
	$report_data['assigned_user_id'] = $rs[0]['assigned_user_id'];
	$report_data['created_by'] = $rs[0]['created_by'];
	$report_data['report_attachment_format'] = $rs[0]['report_attachment_format'];
	$report_data['report_charts'] = $rs[0]['report_charts'];
	$report_data['scheduled_images'] = $rs[0]['scheduled_images'];
	$report_data['row_index_display'] = $rs[0]['row_index_display'];
	$report_data['results_limit'] = $rs[0]['results_limit'];
	
	//Change user for external Calls
	
	$allowExportGeneratedFile = true;
	$externalCall = false;
	$userTZ = null;
	
	if (((isset($_REQUEST['sourceCall'])) && ($_REQUEST['sourceCall'] == "external")) || ((isset($_REQUEST['schedulerCall'])) && ($_REQUEST['schedulerCall'] == "true"))) {
		
		$externalCall = true;
		$theUser = new User();
		
		if ((isset($_REQUEST['schedulerCall'])) && ($_REQUEST['schedulerCall'] == "true")) {
			
			$theUser->retrieve($report_data['created_by']);
			$current_user = $theUser;
			$allowExportGeneratedFile = true;
			
		} else {
			
			$theUser->retrieve("1"); 
			$allowExportGeneratedFile = false;
			
		}
		
		$userPrefs = $theUser->user_preferences;
		$externalUserDateFormat = $userPrefs["global"]["datef"];
		$externalUserDateTimeFormat = $userPrefs["global"]["datef"]." ".$userPrefs["global"]["timef"];
		
	}
	
	
	
	//Global variables
	$userDateFormat = ($externalCall) ? $externalUserDateFormat : $timedate->get_date_format();
	$userDateTimeFormat = ($externalCall) ? $externalUserDateTimeFormat : $timedate->get_date_time_format();
	
	
	$gmtZone = ($externalCall) ? $theUser->getUserDateTimePreferences() : $current_user->getUserDateTimePreferences();
	$userTZlabel = ($externalCall) ? $theUser->getPreference("timezone")." ".$gmtZone["userGmt"] : $current_user->getPreference("timezone")." ".$gmtZone["userGmt"];
	
	$userTZ = ($externalCall) ? $theUser->getPreference("timezone") : $current_user->getPreference("timezone");
	$gmtOffsetArray = $timezones[$userTZ];
	//Set default timezone for php date/datetime functions
	date_default_timezone_set($userTZ);
	//Global variables

	
	
	//Check if searchCriteria was Called
	$searchCriteria = (!isset($_REQUEST['search_criteria'])) ? false : true;
	
	//obtenemos la configuracion de los reports paa el usuario activo
	$sqlCfg = "SELECT config FROM asol_config WHERE created_by = '".$current_user->id."'";
	$rsCfg = $focus->getSelectionResults($sqlCfg, false);
	$cfg = explode("|",$rsCfg[0]['config']);
	$quarter_month = $cfg[0];
	$entries_per_page = (!empty($cfg[1])) ? $cfg[1] : 15;
	
	$pdf_orientation = $cfg[2];
	$week_start = $cfg[3];
	$pdf_img_scaling_factor = $cfg[4];
	$scheduled_files_ttl = (empty($cfg[5])) ? "7" : $cfg[5];
	$host_name = $cfg[6];
	
	if (($externalCall) || ((isset($sugar_config["asolReportsAvoidReportsPagination"])) && ($sugar_config["asolReportsAvoidReportsPagination"] == true))) {
		$entries_per_page = 1000000;
	}
	
	
	$exportedReport['pdf_orientation'] = $pdf_orientation;
	$exportedReport['pdf_img_scaling_factor'] = $pdf_img_scaling_factor;
	
	//Buscar el nombre de usuario que tiene dicha Id
	$rs_user_name = $focus->getSelectionResults("SELECT user_name FROM users WHERE id = '".$rs[0]['assigned_user_id']."'", false);
	$report_data['assigned_user_name'] = $rs_user_name[0]['user_name'];
	
	
	$report_data['selected_fields'] = $rs[0]['report_fields'];
	$report_data['selected_filters'] = $rs[0]['report_filters'];
	$report_data['selected_tasks'] = $rs[0]['report_tasks'];
	$report_data['selected_charts'] = $rs[0]['report_charts_detail'];
	$report_data['report_type'] = $rs[0]['report_type'];
	$report_data['report_scope'] = $rs[0]['report_scope'];
	$tmpEmail = explode("\${pipe}", $rs[0]['email_list']);
	$report_data['email_list'] = $tmpEmail[0];
	$report_data['email_blind_copy'] = $tmpEmail[1];
	
	//recuperamos los campos a visualizar
	$report_name = $rs[0]['name'];
	$report_fields = $rs[0]['report_fields'];
	$report_filters = $rs[0]['report_filters'];
	$report_module = $rs[0]['report_module'];
	$report_charts = $report_data['report_charts'];
	
	
	$class_name = $beanList[$report_module];
	
	
	require_once($beanFiles[$class_name]);
	$bean = new $class_name();
	
	$report_table = $bean->table_name;
	
	if ($allowExportGeneratedFile) {
	
		$exportedReport['reportName'] = $report_name;
		$exportedReport['module'] = $app_list_strings["moduleList"][$report_module];
		$exportedReport['description'] = $report_data['description'];
		$exportedReport['report_charts'] = $report_data['report_charts'];
		$exportedReport['report_attachment_format'] = $report_data['report_attachment_format'];
		$exportedReport['row_index_display'] = $report_data['row_index_display'];
		$exportedReport['results_limit'] = $report_data['results_limit'];
		$exportedReport['email_list'] = $rs[0]['email_list'];
		$exportedReport['created_by'] = $rs[0]['created_by'];
	
	}
	
	$urlChart = Array();
	$chartInfo = Array();
	$chartSubGroupsValues = Array();
		
	$chart_info = explode("\${pipe}", substr($report_data['selected_charts'], 0, -9));
	foreach ($chart_info as $info)
		$chartInfo[] = explode("\${dp}", $info);
	
	//********************INICIO PASO COMUN 1********************
	
	$escapeTokensFiltersComma = "true";
	$escapeTokensFields = "true";
	$escapeTokensFilters = "true";
	$versionFields = "";
	$versionFilters = "";
	
	$posFields = strpos($report_fields, "\${v");
	$posFilters = strpos($report_filters, "\${v");
	
	if ($posFields === false){
	
		$versionFields = "\${v1.0.0}";
		$escapeTokensFields = "false";
	
	}else{ //Si field tiene version
	
		$versionFields = substr($report_fields, -9, 9);
	
		if ($versionFields < "\${v1.3.1}")
		$escapeTokensFields = "false";
		else
		$escapeTokensFields = "true";
	
		$report_fields = substr($report_fields, 0, -9);
	
	}
	
	if ($posFilters === false){
	
		$versionFilters = "\${v1.0.0}";
		$escapeTokensFiltersComma = "false";
		$escapeTokensFilters = "false";
	
	}else{ //Si filters tiene version
	
		$versionFilters = substr($report_filters, -9, 9);
	
		if ($versionFilters < "\${v1.3.0}"){
			$escapeTokensFiltersComma = "false";
			$escapeTokensFilters = "false";
		}else if ($versionFilters == "\${v1.3.0}"){
			$escapeTokensFiltersComma = "false";
			$escapeTokensFilters = "true";
		}else {
			$escapeTokensFiltersComma = "true";
			$escapeTokensFilters = "true";
		}
	
		$report_filters = substr($report_filters, 0, -9);
	
	}
	
	
	$fields = ($escapeTokensFields == "true") ? explode("\${pipe}",$report_fields) : explode("|",$report_fields);
	$field_values = Array();
	
	$i=0;
	foreach ($fields as $field_row){
	
		$values = ($escapeTokensFields == "true") ? explode("\${dp}", $field_row) : explode(":", $field_row);
		$j=0;
	
		foreach ($values as $val){
	
			$field_values[$i][$j] = $val;
			$j++;
		}
		$i++;
	}
	
	//recuperamos los filtros a aplicar (clausula WHERE)
	
	$filters = ($escapeTokensFilters == "true") ? explode("\${pipe}",$report_filters) : explode("|",$report_filters) ;
	
	$filter_values = Array();
	
	
	
	//Temporal fix
	//${nbsp} => " "
	$external_filters = str_replace("\${nbsp}", " ", $_REQUEST["external_filters"]);
	//Temporal fix
	
	//Get the external filter variables from request
	$extFilters = Array();
	$auxFilters = explode("\${pipe}", $external_filters);
	foreach ($auxFilters as $auxFilter) {
		
		
		$filterValues = explode("\${dp}", $auxFilter);
		
		
		//re-format dates to DB format
		if ( (!$timedate->check_matching_format($filterValues[2], $GLOBALS['timedate']->dbDayFormat)) && ($timedate->check_matching_format($filterValues[2], $userDateFormat)) && ($filterValues[2]!="") )
			$filterValues[2] = $timedate->swap_formats($filterValues[2], $userDateFormat, $GLOBALS['timedate']->dbDayFormat );
				
		if((!$timedate->check_matching_format($filterValues[3], $GLOBALS['timedate']->dbDayFormat)) && ($timedate->check_matching_format($filterValues[3], $userDateFormat)) && ($filterValues[3]!=""))
			$filterValues[3] = $timedate->swap_formats($filterValues[3], $userDateFormat, $GLOBALS['timedate']->dbDayFormat );
			
		
		$extFilters[$filterValues[0]] = Array(
											"opp" => $filterValues[1],
											"param1" => $filterValues[2],
											"param2" => $filterValues[3],
										);
	}
	
	
	//print_r($extFilters);
	
	
	//recuperamos los filtros a aplicar (clausula WHERE)
	$filters_panel = array();
	$filtersHiddenInputs = "";
	
	
	$x=0;
	foreach ($filters as $filter_row){
	
		$values = ($escapeTokensFilters == "true") ? explode("\${dp}", $filter_row) : explode(":", $filter_row) ;
		$j=0;
	
		//echo print_r($values, true)."<br>";
		
		$values[2] = stripslashes($values[2]);
		
	
		foreach ($values as $val){
			
			
			
			//Update filter values with external filters if exists
			if (($j == 9) && (!empty($extFilters[$val]))) {
				
				if (!empty($extFilters[$val]["opp"]))
					$filter_values[$x][1] = $extFilters[$val]["opp"];
				if (!empty($extFilters[$val]["param1"]))
					$filter_values[$x][2] = $extFilters[$val]["param1"];
				if (!empty($extFilters[$val]["param2"]))
					$filter_values[$x][3] = $extFilters[$val]["param2"];
	
			} 
			
			
			if (($j == 11) && ($val != "auto")) {
				
				$opp =  (!empty($extFilters[$values[9]]["opp"])) ? $extFilters[$values[9]]["opp"] : $values[1];
				
				if (!empty($extFilters[$values[9]]["param1"]))
					$values[2] = $extFilters[$values[9]]["param1"];
				
				if (!empty($extFilters[$values[9]]["param2"]))
					$values[3] = $extFilters[$values[9]]["param2"];
					
				if (($val == "user_input") || ($val == "visible")) {
					
					
					switch ($values[4]) {
						
						case "enum" :
							
							$selectedOpts = explode("\${dollar}", $values[2]);
							
							switch ($opp) {
								
								case "equals":
								case "not equals":
									if ($val == "user_input")
										$theInput1 = "<select id='".$values[9]."_1'>";
									break;
									
								case "one of":
								case "not one of":
									if ($val == "user_input")
										$theInput1 = "<select id='".$values[9]."_1' multiple size=3>";
									break;
								
							}
							
							if ($val == "user_input") {
							
								if (empty($values[12])) {
									$opts = explode("\${comma}", $values[8]);
									$optsLabels = explode("\${comma}", $values[7]);
								} else {
									$opts = explode(",", $values[12]);
									$optsLabels = explode(",", $values[12]);								
								}
							
								foreach ($opts as $key=>$opt) {
									$theInput1 .= (in_array($opt, $selectedOpts)) ? "<option value='".$opt."' selected>".$optsLabels[$key]."</option>" : "<option value='".$opt."'>".$optsLabels[$key]."</option>";
								}
								
								$theInput1 .= "</select>";
	
							} else if ($val == "visible") {
								
								$opts = explode("\${comma}", $values[7]);
								$optsLabels = explode("\${comma}", $values[8]);
								
								$theInput1 = '<span>';
								
								foreach ($opts as $key=>$opt) {
									if (in_array($opt, $selectedOpts))
										$theInput1 .= $optsLabels[array_search($opt, $opts)]."<br>";
								}
								
								$theInput1 = substr($theInput1, 0, -4);
								
								$theInput1 .= '</span>';
								
							}
							
							$theInput2 = null;
							break;
							
						case "datetime":
						case "date":
							
							switch ($opp) {
								
								case "equals":
								case "not equals":
								case "before date":
								case "after date":
									
									$date1 = $values[2];
										
									if((!$timedate->check_matching_format($date1, $userDateFormat)) && ($date1!=""))
										$date1 = $timedate->swap_formats($date1, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
	
									if ($val == "user_input") {
									
										$theInput1 = "<input type='text' id='".$values[9]."_1' style='width:80px' value='".$date1."' disabled='true'><img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='".$values[9]."_trigger1'>";												
										$theInput1 .= "<script>Calendar.setup ({ inputField : '".$values[9]."_1' , daFormat : '".$timedate->get_cal_date_format()."', button : '".$values[9]."_trigger1' , singleClick : true, dateStr : '', step : 1, weekNumbers:false });</script>";
									
									} else if ($val == "visible") {
										
										$theInput1 = "<span>".$date1."</span>";											
										
									}
									
									$theInput2 = null;
									
									break;
									
								case "between":
								case "not between":
									
									$date1 = $values[2];
									$date2 = $values[3];
									
									if((!$timedate->check_matching_format($date1, $userDateFormat)) && ($date1!=""))
										$date1 = $timedate->swap_formats($date1, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
										
									if((!$timedate->check_matching_format($date2, $userDateFormat)) && ($date2!=""))
										$date2 = $timedate->swap_formats($date2, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
									
									if ($val == "user_input") {
										
										$theInput1 = "<input type='text' id='".$values[9]."_1' style='width:80px' value='".$date1."' disabled='true'><img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='".$values[9]."_trigger1'>";												
										$theInput1 .= "<script>Calendar.setup ({ inputField : '".$values[9]."_1' , daFormat : '".$timedate->get_cal_date_format()."', button : '".$values[9]."_trigger1' , singleClick : true, dateStr : '', step : 1, weekNumbers:false });</script>";
										$theInput2 = "<input type='text' id='".$values[9]."_2' style='width:80px' value='".$date2."' disabled='true'><img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='".$values[9]."_trigger2'>";												
										$theInput2 .= "<script>Calendar.setup ({ inputField : '".$values[9]."_2' , daFormat : '".$timedate->get_cal_date_format()."', button : '".$values[9]."_trigger2' , singleClick : true, dateStr : '', step : 1, weekNumbers:false });</script>";
									
									} else if ($val == "visible") {
										
										$theInput1 = "<span>".$date1."</span>";													
										$theInput2 = "<span>".$date2."</span>";												
										
									}
									
									break;
									
								case "last":
								case "not last":
									
									if (empty($values[12])) {
										$fullOpts = Array( "day", "week", "month", "Nquarter", "Fquarter", "Nyear", "Fyear", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december");
										$fullOptsLabels = Array( $mod_strings["LBL_REPORT_DAY"], $mod_strings["LBL_REPORT_WEEK"], $mod_strings["LBL_REPORT_MONTH"], $mod_strings["LBL_REPORT_NQUARTER"], $mod_strings["LBL_REPORT_FQUARTER"], $mod_strings["LBL_REPORT_NYEAR"], $mod_strings["LBL_REPORT_FYEAR"], $mod_strings["LBL_REPORT_MONDAY"], $mod_strings["LBL_REPORT_TUESDAY"], $mod_strings["LBL_REPORT_WEDNESDAY"], $mod_strings["LBL_REPORT_THURSDAY"], $mod_strings["LBL_REPORT_FRIDAY"], $mod_strings["LBL_REPORT_SATURDAY"], $mod_strings["LBL_REPORT_SUNDAY"], $mod_strings["LBL_REPORT_JANUARY"], $mod_strings["LBL_REPORT_FEBRUARY"], $mod_strings["LBL_REPORT_MARCH"], $mod_strings["LBL_REPORT_APRIL"], $mod_strings["LBL_REPORT_MAY"], $mod_strings["LBL_REPORT_JUNE"], $mod_strings["LBL_REPORT_JULY"], $mod_strings["LBL_REPORT_AUGUST"], $mod_strings["LBL_REPORT_SEPTEMBER"], $mod_strings["LBL_REPORT_OCTOBER"], $mod_strings["LBL_REPORT_NOVEMBER"], $mod_strings["LBL_REPORT_DECEMBER"]);
									} else {
										$fullOpts = explode(",", $values[12]);
										$fullOptsLabels = explode(",", $values[12]);								
									}
																	
									
									if ($val == "user_input") {
									
										$theInput1 = "<select id='".$values[9]."_1' onChange='if (this.selectedIndex >= 7) { document.getElementById(\"".$values[9]."_2\").style.display=\"none\"; } else { document.getElementById(\"".$values[9]."_2\").style.display=\"inline\"; } '>";
										
										foreach ($fullOpts as $key=>$fullOpt) {
											
											$theInput1 .= ($fullOpt == $values[2]) ? "<option value='".$fullOpt."' selected>".$fullOptsLabels[$key]."</option>" : "<option value='".$fullOpt."'>".$fullOptsLabels[$key]."</option>";
											
										}
										
										$theInput1 .= "</select>";
										
									} else if ($val == "visible") {
	
										$theInput1 = (!empty($extFilters[$values[9]]["param1"])) ? '<span>'.$fullOptsLabels[array_search($extFilters[$values[9]]["param1"], $fullOpts)].'</span>' : '<span>'.$fullOptsLabels[array_search($values[2], $fullOpts)].'</span>';
										
									}
									
									switch ($values[2]) {
										
										case "day":
										case "week":
										case "month":
										case "Nquarter":
										case "Fquarter":
										case "Nyear":
										case "Fyear":
											
											if ($val == "user_input")
												$theInput2 = '<input id="'.$values[9].'_2" type="text" style="width:60px" value="'.$values[3].'">';
											else if ($val == "visible")
												$theInput2 = '<span>'.$values[3].'</span>';
											
											break;
											
										default:
											
											if ($val == "user_input")
												$theInput2 = '<input id="'.$values[9].'_2" style="display: none; width:60px" type="text" value="'.$values[3].'">';
											else if ($val == "visible")
												$theInput2 = '<span>'.$values[3].'</span>';
											
											break;
										
									}
									
									break;
									
								case "this":
								case "not this":
									
									if (empty($values[12])) {
										$opts = Array( "day", "week", "month", "Nquarter", "Fquarter", "Nyear", "Fyear");
										$optsLabels = Array( $mod_strings["LBL_REPORT_DAY"], $mod_strings["LBL_REPORT_WEEK"], $mod_strings["LBL_REPORT_MONTH"], $mod_strings["LBL_REPORT_NQUARTER"], $mod_strings["LBL_REPORT_FQUARTER"], $mod_strings["LBL_REPORT_NYEAR"], $mod_strings["LBL_REPORT_FYEAR"]);
									} else {
										$fullOpts = explode(",", $values[12]);
										$fullOptsLabels = explode(",", $values[12]);								
									}
									
									if ($val == "user_input") {
										
										$theInput1 = "<select id='".$values[9]."_1'>";
										
										foreach ($opts as $key=>$opt) {
											
											$theInput1 .= ($opt == $values[2]) ? "<option value='".$opt."' selected>".$optsLabels[$key]."</option>" : "<option value='".$opt."'>".$optsLabels[$key]."</option>";
											
										}
										
										$theInput1 .= "</select>";
									
									} else if ($val == "visible") {
										
										$theInput1 = '<span>'.$optsLabels[array_search($values[2], $opts)].'</span>';
										
									}
									
									$theInput2 = null;
									
									break;
									
								case "next":
								case "not next":
								case "theese":	
															
									if (empty($values[12])) {
										$opts = Array( "day", "week", "month", "Nquarter", "Fquarter", "Nyear", "Fyear");
										$optsLabels = Array( $mod_strings["LBL_REPORT_DAY"], $mod_strings["LBL_REPORT_WEEK"], $mod_strings["LBL_REPORT_MONTH"], $mod_strings["LBL_REPORT_NQUARTER"], $mod_strings["LBL_REPORT_FQUARTER"], $mod_strings["LBL_REPORT_NYEAR"], $mod_strings["LBL_REPORT_FYEAR"]);
									} else {
										$fullOpts = explode(",", $values[12]);
										$fullOptsLabels = explode(",", $values[12]);								
									}
									
									if ($val == "user_input") {
										
										$theInput1 = "<select id='".$values[9]."_1'>";
										
										foreach ($opts as $key=>$opt) {
											
											$theInput1 .= ($opt == $values[2]) ? "<option value='".$opt."' selected>".$optsLabels[$key]."</option>" : "<option value='".$opt."'>".$optsLabels[$key]."</option>";
											
										}
										
										$theInput1 .= "</select>";
										
									} else if ($val == "visible") {
										
										$theInput1 = '<span>'.$optsLabels[array_search($values[2], $opts)].'</span>';
										
									}
									
									if ($val == "user_input")
										$theInput2 = '<input id="'.$values[9].'_2" type="text" style="width:60px" value="'.$values[3].'">';
									else if ($val == "visible")
										$theInput2 = '<span>'.$values[3].'</span>';
									
									break;
								
							}
							
							break;
							
						case "bool":
						case "tinyint(1)":
							if (!empty($extFilters[$values[9]]["param1"]))
								$values[2] = $extFilters[$values[9]]["param1"];
							
							if ($val == "user_input")
								$theInput1 = ($values[2] == "true") ? "<select id='".$values[9]."_1' name='".$values[9]."_1' style='width:90px'><option value='true' selected>".$mod_strings["LBL_REPORT_TRUE"]."</option><option value='false'>".$mod_strings["LBL_REPORT_FALSE"]."</option></select>" : "<select id='".$values[9]."_1' style='width:90px'><option value='true'>".$mod_strings["LBL_REPORT_TRUE"]."</option><option value='false' selected>".$mod_strings["LBL_REPORT_FALSE"]."</option></select>";
							else if ($val == "visible")
								$theInput1 = "<span>".$values[2]."</span>";
							
							$theInput2 = null;
							break;
							
						default:
							
							if (!empty($values[12])) {
	
								$selectedOpts = Array( $extFilters[$values[9]]["param1"] );
								
								$opts = explode(",", $values[12]);
								$optsLabels = explode(",", $values[12]);								
							
								$theInput1 = "<select id='".$values[9]."_1' style='width:90px'>";
								foreach ($opts as $key=>$opt) {
									$theInput1 .= (in_array($opt, $selectedOpts)) ? "<option value='".$opt."' selected>".$optsLabels[$key]."</option>" : "<option value='".$opt."'>".$optsLabels[$key]."</option>";
								}
								
								$theInput1 .= "</select>";
							
							} else {
														
								if (!empty($extFilters[$values[9]]["param1"]))
									$values[2] = $extFilters[$values[9]]["param1"];
										
								if ($val == "user_input")	
									$theInput1 = '<input id="'.$values[9].'_1" type="text" style="width:140px" value="'.$values[2].'">';
								else if ($val == "visible")
									$theInput1 = '<span>'.$values[2].'</span>';
	
							}
	
							$theInput2 = null;
							break;
						
					}
					
					
					if ($val == "user_input") {
						
						$filtersHiddenInputs .= ($theInput2 == null) ? $values[9]."\${dp}".$opp."\${dp}1\${pipe}" : $values[9]."\${dp}".$opp."\${dp}2\${pipe}";
						
					}
					
					
				} else {
					
					$theInput1 = null;
					$theInput2 = null;
					
				}
				
				
				$filterLabel = "LBL_REPORT_".strtoupper(str_replace(" ", "_", $opp))."_".strtoupper(str_replace(" ", "_", $values[2]));
				$filterLabel .= (!empty($values[3])) ? "_".$values[3] : "";
				$filterLabelValue = $mod_strings[$filterLabel];
				
				
				$filters_panel[] = Array  ( 
										"type" => $val,
										"label" => $values[10],
										"reference" => $values[9],
										"opp" => $opp,
										"input1" => "<br>".$theInput1, 
										"input2" => "<br>".$theInput2,
										"genLabel" => (!empty($filterLabelValue)) ? $filterLabelValue: false,
								  );
				
			}
			
			$filter_values[$x][$j] = $val;
			$j++;
		}
		$x++;
	
	}
	
	$filtersHiddenInputs = substr($filtersHiddenInputs, 0, -7);
	
	$filtersHiddenInputs = (!empty($filtersHiddenInputs)) ? $filtersHiddenInputs : false;
	
	
	if (($filtersHiddenInputs == false) || ($searchCriteria == true)) {
		
		
		
		//OBTENEMOS LA CLAUSULA SQLJOIN
		$sqlFilterTableIndex = Array();
		$sqlJoin = "";
		
		$moduleCustomJoined = false;
		$leftJoineds = array();
		$keySearch = "";
		
		for ($i=0; $i<count($field_values); $i++){
		
			$aux = explode(".",$field_values[$i][0]);
			$aux2 = explode("_", $aux[0]);
			
			$numTokensAux2 = count($aux2);
			$auxTableName = (($aux2[$numTokensAux2-1]) == 'cstm') ? substr($aux[0], 0, -5) : $aux[0];
			$isCustomTable = (($aux2[$numTokensAux2-1]) == 'cstm') ? true : false;
			
			//echo "<br>".$field_values[$i][0];
			
			if ($field_values[$i][9] == "id"){
		
				//echo "Id Rel";
				
				if (count($aux) == 2) {
					
	
					$sql_relationships = "SELECT DISTINCT lhs_table, lhs_key, rhs_table, rhs_key, join_table, join_key_lhs, join_key_rhs FROM relationships WHERE rhs_table='".$report_table."' AND lhs_table='".strtolower($auxTableName)."' AND rhs_key='".$field_values[$i][9]."'";
					$rs = $focus->getSelectionResults($sql_relationships);
					
					$new_key_search = array_search($aux[0]."|".$field_values[$i][9], $leftJoineds);
					$keySearch = (empty($new_key_search)) ? $i : $new_key_search;
					
					//$doJoin = (empty($leftJoineds) || ((!empty($old_key_search)) && ($old_key_search != $keySearch)) );
					$doJoin = ( (empty($leftJoineds)) || (empty($new_key_search)) );
					
					if (count($rs) > 0) { //Hay relacion de derecha a izquierda
	
						//echo "D->I";
						
						if ($rs[0]['join_table'] != ""){
		
							if ($doJoin)
								$sqlJoin .= " LEFT JOIN ".$rs[0]['join_table']." ".$rs[0]['join_table'].$i." ON ";
							//Modificamos el nombre del campo para los siguientes usos
							$sqlFilterTableIndex[$rs[0]['rhs_key'].".".$field_values[$i][0]] = $keySearch;
							$field_values[$i][0] = $aux[0].$keySearch.".".$aux[1];
								
						} else {
		
							if ($doJoin)
								$sqlJoin .= " LEFT JOIN ".strtolower($aux[0])." ".strtolower($aux[0]).$i." ON ";
							//Modificamos el nombre del campo para los siguientes usos
							$sqlFilterTableIndex[$rs[0]['rhs_key'].".".$field_values[$i][0]] = $keySearch;
							$field_values[$i][0] = $aux[0].$keySearch.".".$aux[1];
								
						}
		
						if ($rs[0]['join_table'] != ""){
		
							//Mirar la relacion con la tabla intermedia
							if ($doJoin) {
								$sqlJoin .= "(".$rs[0]['rhs_table'].".".$rs[0]['rhs_key']."=".$rs[0]['join_table'].$i.".".$rs[0]['join_key_rhs']." AND ".$rs[0]['join_table'].$i.".deleted=0) ";
								$sqlJoin .= " LEFT JOIN ".$rs[0]['lhs_table']." ".$rs[0]['lhs_table'].$i." ON (".$rs[0]['join_table'].$i.".".$rs[0]['join_key_lhs']."=";
								$sqlJoin .= $rs[0]['lhs_table'].$i.".".$rs[0]['lhs_key']." AND ".$rs[0]['lhs_table'].$i.".deleted=0) ";
							}
								
						} else {
		
							//Hacer vinculacion directamente
							if ($doJoin) {
								if ($report_table != strtolower($aux[0]))
								$sqlJoin .= "(".$rs[0]['rhs_table'].".".$rs[0]['rhs_key']."=".$rs[0]['lhs_table'].$i.".".$rs[0]['lhs_key']." AND ".$rs[0]['rhs_table'].".deleted=0) ";
								else
								$sqlJoin .= "(".$rs[0]['rhs_table'].".".$rs[0]['rhs_key']."=".$rs[0]['lhs_table'].".".$rs[0]['lhs_key']." AND ".$rs[0]['rhs_table'].".deleted=0) ";
							}
								
						}
						
		
					} else { //Hay relacion de izquierda a derecha
		
						//echo "I->D";
						
						$sql_relationships = "SELECT DISTINCT lhs_table, lhs_key, rhs_table, rhs_key, join_table, join_key_lhs, join_key_rhs FROM relationships WHERE lhs_table='".$report_table."' AND rhs_table='".strtolower($auxTableName)."' AND lhs_key='".$field_values[$i][9]."'";
						$rs = $focus->getSelectionResults($sql_relationships);
		
						if (count($rs) > 0) {
	
							if ($rs[0]['join_table'] != ""){
		
								if ($doJoin)
									$sqlJoin .= " LEFT JOIN ".$rs[0]['join_table']." ".$rs[0]['join_table'].$i." ON ";
								//Modificamos el nombre del campo para los siguientes usos
								$sqlFilterTableIndex[$rs[0]['lhs_key'].".".$field_values[$i][0]] = $keySearch;
								$field_values[$i][0] = $aux[0].$keySearch.".".$aux[1];
		
							} else {
								
								if ($doJoin)
									$sqlJoin .= " LEFT JOIN ".strtolower($auxTableName)." ".strtolower($auxTableName).$i." ON ";
								//Modificamos el nombre del campo para los siguientes usos
								$sqlFilterTableIndex[$rs[0]['lhs_key'].".".$field_values[$i][0]] = $keySearch;
								$field_values[$i][0] = $aux[0].$keySearch.".".$aux[1];
		
							}
		
							if ($rs[0]['join_table'] != ""){
	
								//Mirar la relacion con la tabla intermedia
								if ($doJoin) {
									$sqlJoin .= "(".$rs[0]['lhs_table'].".".$rs[0]['lhs_key']."=".$rs[0]['join_table'].$i.".".$rs[0]['join_key_lhs']." AND ".$rs[0]['join_table'].$i.".deleted=0) ";
									$sqlJoin .= " LEFT JOIN ".$rs[0]['rhs_table']." ".$rs[0]['rhs_table'].$i." ON (".$rs[0]['join_table'].$i.".".$rs[0]['join_key_rhs']."=";
									$sqlJoin .= $rs[0]['rhs_table'].$i.".".$rs[0]['rhs_key']." AND ".$rs[0]['rhs_table'].$i.".deleted=0) ";
								}
									
							} else {
	
								//Hacer vinculacion directamente
								if ($doJoin) {
									if ($report_table != strtolower($aux[0]))
									$sqlJoin .= "(".$rs[0]['lhs_table'].".".$rs[0]['lhs_key']."=".$rs[0]['rhs_table'].$i.".".$rs[0]['rhs_key']." AND ".$rs[0]['rhs_table'].$i.".deleted=0) ";
									else
									$sqlJoin .= "(".$rs[0]['lhs_table'].".".$rs[0]['lhs_key']."=".$rs[0]['rhs_table'].".".$rs[0]['rhs_key']." AND ".$rs[0]['lhs_table'].".deleted=0) ";
								}
									
							}
		
						} else { //No hay fila de esta relacion en la tabla relationships (buscar en tabla "fields_meta_data")
	
							$sql_relationships = "SELECT DISTINCT name, type, ext2, ext3 FROM fields_meta_data WHERE custom_module='".$report_module."' AND type IN ('relate')";
							$rs = $focus->getSelectionResults($sql_relationships);
		
							$sqlJoin .= " LEFT JOIN ".$report_table."_cstm ON ".$report_table.".id=".$report_table."_cstm.id_c LEFT JOIN ".strtolower($rs[0]['ext2'])." ON ".$report_table."_cstm.".$rs[0]['ext3']."=".strtolower($rs[0]['ext2']).".id";
		
						}
		
					}
					
	
					if ($isCustomTable) {
									
						//echo "Custom";
						
						$myIndex = "";
						$emptyIndex = true;
						$auxCustomTableName = $aux[0];
						
						foreach ($sqlFilterTableIndex as $key=>$tableIndex) {
							
							$auxKey = explode(".", $key);
							$myIndex = $tableIndex;
							
							//echo "[".print_r($auxKey, true)."] [".print_r($aux2, true)."]";
							
							if ($auxKey[1] == $auxCustomTableName) {
								$emptyIndex = false;
								break;
							}
							
						}
			
						
						$doJoin2 = true;
						$n = 0;
						foreach ($sqlFilterTableIndex as $key=>$tableIndex) {
							
							$auxKey = explode(".", $key);
							
							//echo "if ((".$auxKey[0]." == ".$field_values[$i][9].") && (".$auxKey[1]." == ".$aux2[0]."\"_\"".$aux2[1]."))";
							
							if (($auxKey[0] == $field_values[$i][9]) && ($auxKey[1] == $aux[0])) {
								
								$n++;
								
								if ($n >= 2) {
									$doJoin2 = false;
									break;								
								}
								
							}
							
						}
							
							
						//echo " myIndex [".$myIndex."] ".$n;
						
						if ($emptyIndex) {
							
							$sqlFilterTableIndex[$field_values[$i][9].".".$aux2[0]] = $myIndex;
							//echo "emptyMyIndex [".$field_values[$i][9].".".$aux2[0]." = ".$myIndex."]";
							
						}
						
						
						if ($doJoin2)
							$sqlJoin .= " LEFT JOIN ".$aux[0]." ".$aux[0].$myIndex." ON ".$aux[0].$myIndex.".id_c=".$aux2[0].$myIndex.".id ";
						
						//echo "|".$field_values[$i][9].".".$aux2[0]."|";	
						
						$sqlFilterTableIndex[$field_values[$i][9].".".$auxTableName] = $i;
						$auxField = explode(".", $field_values[$i][0]);
						$field_values[$i][0] = $aux[0].$myIndex.".".$auxField[1];
							
							
					} else {
						
						//echo "No-Custom";
						//echo "\$sqlFilterTableIndex[\$field_values[\$i][9].".".\$aux2[0] = ".$sqlFilterTableIndex[$field_values[$i][9].".".$aux2[0]];
						
						if (!empty($sqlFilterTableIndex[$field_values[$i][9].".".$auxTableName])) {
							
							$sqlFilterTableIndex[$rs[0]['rhs_key'].".".$field_values[$i][0]] = $sqlFilterTableIndex[$field_values[$i][9].".".$auxTableName];
							$field_values[$i][0] = $aux[0].$sqlFilterTableIndex[$field_values[$i][9].".".$auxTableName].".".$aux[1];
							
						}
						
					}
					
				}
		
		
				$old_table_key = $auxTableName;
				$old_rhs_key = $field_values[$i][9];
				$old_key_search = array_search($old_table_key."|".$old_rhs_key, $leftJoineds);
				
				if (empty($old_key_search)) {
					$leftJoineds[$i] = $old_table_key."|".$old_rhs_key;
					$old_key_search = $i;
				}
		
		
		
			} else { //Related field relationship
	
				if (count($aux) == 2) {
		
					$class_name = $beanList[$report_module];
					require_once($beanFiles[$class_name]);
					$bean = new $class_name();
		
					$relatedInfo = $bean->get_related_fields();
		
					$tmpField = explode(".", $field_values[$i][9]);
					$tmpField = (count($tmpField) == 2) ? $tmpField[1] : $field_values[$i][9];
		
					$relatedTable = "";
					$relatedModule = "";
		
					foreach ($relatedInfo as $info){
		
						if ($info['id_name'] == $tmpField){
		
							$relatedModule = $info['module'];
							$relatedTable = strtolower($relatedModule);
							break;
		
						}
							
					}
		
					if ($field_values[$i][9] != ""){
		
						if ($isCustomTable){
								
							$myIndex = "";
							foreach ($sqlFilterTableIndex as $key=>$tableIndex) {
								
								$auxKey = explode(".", $key);
								$myIndex = $tableIndex;
								
								if ($auxKey[1] == $aux2[0])
									break;
								
							}
		
							if (empty($myIndex)) {
								
								$sqlJoin .= " LEFT JOIN ".$relatedTable." ".$relatedTable.$i." ON ".$report_table.".".$field_values[$i][9]."=".$relatedTable.$i.".id ";
								$myIndex = $i;
								
							}
								
							
							$sqlJoin .= " LEFT JOIN ".$aux[0]." ".$aux[0].$i." ON ".$aux[0].$i.".id_c=".$aux2[0].$myIndex.".id ";
							$sqlFilterTableIndex[$field_values[$i][9].".".$field_values[$i][0]] = $i;
							$auxField = explode(".", $field_values[$i][0]);
							$field_values[$i][0] = $aux[0].$i.".".$auxField[1];
								
						} else {
						
							//echo $report_table." - ".$field_values[$i][9];
							
							$tmpField = explode(".", $field_values[$i][9]);
							$realField = (count($tmpField) == 2) ? $field_values[$i][9] : $report_table.".".$field_values[$i][9];
							
							//Check if relates to custom table of report module table
							if (count($tmpField) == 2) {
								$explodedTmpTable = explode("_", $tmpField[0]);
								
								if ((($explodedTmpTable[1] == 'cstm') && ($explodedTmpTable[0] == $report_table)) && !$moduleCustomJoined) {
									$sqlJoin .= " LEFT JOIN ".$report_table."_cstm ON ".$report_table.".id=".$report_table."_cstm.id_c ";
									$moduleCustomJoined = true;
								}
							}
								
							$sqlJoin .= " LEFT JOIN ".$relatedTable." ".$relatedTable.$i." ON ".$realField."=".$relatedTable.$i.".id ";
							$sqlFilterTableIndex[$field_values[$i][9].".".$field_values[$i][0]] = $i;
							$auxField = explode(".", $field_values[$i][0]);
							$field_values[$i][0] = $relatedTable.$i.".".$auxField[1];
							
						}
							
					}
		
				}
		
			}
	
		}
		
		//echo "<br><br><br><br>".print_r($sqlFilterTableIndex, true);
		//echo "<br><br>".print_r($leftJoineds, true);
		//OBTENEMOS LA CLAUSULA SQLJOIN
		
		//echo $sqlJoin."<br>";
		
		$x = 0;
		//Añadimos indice a las tablas de los campos que lo necesiten
		
		foreach($filter_values as $one_filter){
		
			$fieldFilter = explode(".", $filter_values[$x][0]);
			$filter_values[$x][0] = (count($fieldFilter) > 1) ? $fieldFilter[0].$sqlFilterTableIndex[$filter_values[$x][5].".".$filter_values[$x][0]].".".$fieldFilter[1] : $filter_values[$x][0];
		
			$x++;
		
		}
			
		
		//OBTENEMOS LA CAUSULA "SELECT" con sus ALIAS
		$sqlSelect = "SELECT ";
		$columns = Array();
		$count_fields = 0;
		
		$hasGrouped = false;
		$groupSubTotalField = null;
		$groupSubTotalFieldAscSort = null;
		
		$custom_fields = false;
		
		$sqlTotals = "SELECT ";
		$sqlTotalsC = "SELECT ";
		$totals = Array();
		$count_totals = 0;
		
		//CREAR Y USAR SUBLISTA CON LOS CAMPOS QUE IR�N EN EL RESULSET UNICAMENTE
		$resulset_fields;
		
		$j=0;
		
		for ($i=0; $i<count($field_values); $i++){
			
			
			if ($field_values[$i][6] == "Grouped")
				$hasGrouped = true;
		
			$table = ((count(explode(".", $field_values[$i][0]))) == 1 ) ? $report_table."." : "";
		
			$tmpField = explode(".", $field_values[$i][0]);
		
			if ($tmpField[0] == $report_table."_cstm")
			$custom_fields = true;
		
		
			//Metemos lo campos que no tienen funcion asociada
			if (($field_values[$i][2] == "Yes") && (($field_values[$i][5] == "0") || ($field_values[$i][5] == "undefined"))){//Mostrar solo si display es Yes
		
				$sqlSelect .= $table.$field_values[$i][0]." AS '".$field_values[$i][1]."',";
				$columns[$count_fields] = $field_values[$i][1];
				$columnsO[$count_fields] = $field_values[$i][0];
		
				$count_fields++;
		
				$resulset_fields[$j] = $field_values[$i];
				$j++;
		
			}
		
			
			
			//Metemos los campos que tienen una funcion asociada en un array que generar� una subtabla con los totales
			if (($field_values[$i][2] == "Yes") && ($field_values[$i][5] != "undefined") && ($field_values[$i][5] != "0")){//Mostrar solo si display es Yes
		
				if ($groupSubTotalField == null) {
					$groupSubTotalField = $field_values[$i][1];
					$groupSubTotalFieldAscSort = $field_values[$i][3];
				}
					
				$sqlTotals .= $field_values[$i][5]."(".$table.$field_values[$i][0].") AS '".$field_values[$i][1]."',";
				$totals[$count_totals] = $field_values[$i];
				$count_totals++;
		
			}
			
			//Check if chart is displayable on Charts Div
			$chartDisplayable = false;
			$chartAlias = $field_values[$i][1];
	
			foreach ($chartInfo as $cInfo) {
				
				if (($field_values[$i][5] != '0') && ($field_values[$i][0] == $cInfo[0]) && ($cInfo[3] == 'yes')) {
					$chartDisplayable = true;
					$chartAlias = $cInfo[1];
					break;
				}
				
			}
			
			if ($chartDisplayable)
				$sqlTotalsC .= $field_values[$i][5]."(".$table.$field_values[$i][0].") AS '".$chartAlias."',";
			//Check if chart is displayable on Charts Div
				
		
		}
		
		$tmpChartInfo = Array();
		
		foreach ($chartInfo as $cInfo) {
			
			if ($cInfo[3] == 'yes')
				$tmpChartInfo[] = $cInfo;
			
		}
		
		$chartInfo = $tmpChartInfo;
		
		$sqlTotalsC = substr($sqlTotalsC, 0, -1);
		//CREAR Y USAR SUBLISTA CON LOS CAMPOS QUE IR�N EN EL RESULSET UNICAMENTE
		
		//Comprobar antes de hacer las querys que estos strings tienen mas de las 6 letras de "SELECT "
		
		$sqlSelect = substr($sqlSelect, 0, -1);
		$sqlTotals = substr($sqlTotals, 0, -1);
		
		//OBTENEMOS LA CAUSULA "FROM"
		$sqlFrom = " FROM ".$report_table;
		
		//añadimos un left join para los custom fields no related
		if (($custom_fields == "true") && (!$moduleCustomJoined))
			$sqlFrom .= " LEFT JOIN ".$report_table."_cstm ON ".$report_table.".id=".$report_table."_cstm.id_c ";
	
		
		//OBTENEMOS LA CAUSULA "WHERE"
		
		$sqlWhere = (count($filter_values) != 0) ? " WHERE ".$report_table.".deleted = 0 AND " : "";
		
		
		if ($filter_values[0][0] != ""){
		
			//if ($externalCall) {
			/*OLD OFFSET HANDLING
			$hourOffset = (($timedate->get_hour_offset(true, $gmtOffsetArray))*-3600)-date('Z');
			*/
			
			$phpDateTime = new DateTime(null, new DateTimeZone($userTZ));
			$hourOffset = $phpDateTime->getOffset()*-1;
			/*} else {
				$timedate->get_hour_offset(true, $current_user->getPreference("timezone"));
				$hourOffset = ($timedate->get_hour_offset(true, $current_user->getPreference("timezone")) >= 0) ? $timedate->get_hour_offset(true, $current_user->getPreference("timezone"))*3600 : $timedate->get_hour_offset(true, $current_user->getPreference("timezone"))*-3600;
			}*/
				
			//echo "\$hourOffset: ".$hourOffset." server OffSet: ".date('Z')/60;
			
			//echo "ASOL ".print_r($gmtOffsetArray, true)." -> ".$hourOffset;
		
			for ($i=0; $i<count($filter_values); $i++){
		
				
				$operator1 = "";
				$operator2 = "";
		
				//Escapamos la comilla simple para evitar conflictos
				$filter_values[$i][2] = preg_replace("/\\\\/", "\\", $filter_values[$i][2]);
				$filter_values[$i][2] = preg_replace("/&#039;/", "'", $filter_values[$i][2]);
				
				
				switch ($filter_values[$i][1]){
		
					case "equals":
						if ($filter_values[$i][4] == "datetime"){
							$operator1 = "BETWEEN";
							$operator2 = "AND";
		
							$date1 = explode("-", $filter_values[$i][2]);
							$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$date1[1],$date1[2],$date1[0])+$hourOffset);
							$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,59,59,$date1[1],$date1[2],$date1[0])+(24*3600)-(3600)+$hourOffset);
						} else {
							$operator1 = "=";
							$operator2 = "";
						}
						
						if ($filter_values[$i][4] == "bool")
							$filter_values[$i][2] = ($filter_values[$i][2] == "true") ? "1" : "0";
						
						break;
		
					case "not equals":
						if ($filter_values[$i][4] == "datetime"){
							$operator1 = "NOT BETWEEN";
							$operator2 = "AND";
		
							$date1 = explode("-", $filter_values[$i][2]);
							$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$date1[1],$date1[2],$date1[0])+$hourOffset);
							$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,59,59,$date1[1],$date1[2],$date1[0])+(24*3600)-(3600)+$hourOffset);
						} else {
							$operator1 = "!=";
							$operator2 = "";
						}
						
						if ($filter_values[$i][4] == "bool")
							$filter_values[$i][2] = ($filter_values[$i][2] == "true") ? "1" : "0";
						
						break;
		
					case "like":
						$operator1 = "LIKE";
						$operator2 = "";
						$filter_values[$i][2] = "%".$filter_values[$i][2]."%";
						break;
							
					case "not like":
						$operator1 = "NOT LIKE";
						$operator2 = "";
						$filter_values[$i][2] = "%".$filter_values[$i][2]."%";
						break;
		
					case "after date":
					case "more than":
						$operator1 = ">";
						$operator2 = "";
		
						if ($filter_values[$i][4] == "datetime"){
							$date1 = explode("-", $filter_values[$i][2]);
							$filter_values[$i][2] = date("Y-m-d H:59:59", @mktime(0,59,59,$date1[1],$date1[2],$date1[0])+(24*3600)-(3600)+$hourOffset);
						}
		
						break;
		
					case "before date":
					case "less than":
						$operator1 = "<";
						$operator2 = "";
		
						if ($filter_values[$i][4] == "datetime"){
							$date1 = explode("-", $filter_values[$i][2]);
							$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$date1[1],$date1[2],$date1[0])+$hourOffset);
						}
		
						break;
		
					case "between":
						$operator1 = "BETWEEN";
						$operator2 = "AND";
		
						if ($filter_values[$i][4] == "datetime"){
							$date1 = explode("-", $filter_values[$i][2]);
							$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$date1[1],$date1[2],$date1[0])+$hourOffset);
							$date2 = explode("-", $filter_values[$i][3]);
							$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,59,59,$date2[1],$date2[2],$date2[0])+(24*3600)-(3600)+$hourOffset);
						}
		
						break;
		
					case "not between":
						$operator1 = "NOT BETWEEN";
						$operator2 = "AND";
		
						if ($filter_values[$i][4] == "datetime"){
							$date1 = explode("-", $filter_values[$i][2]);
							$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$date1[1],$date1[2],$date1[0])+$hourOffset);
							$date2 = explode("-", $filter_values[$i][3]);
							$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,59,59,$date2[1],$date2[2],$date2[0])+(24*3600)-(3600)+$hourOffset);
						}
		
						break;
		
					case "one of":
						$operator1 = "IN";
						$operator2 = "";
						break;
		
					case "not one of":
						$operator1 = "NOT IN";
						$operator2 = "";
						break;
		
					case "last":
						switch ($filter_values[$i][2]){
		
							case "day":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(($filter_values[$i][3])*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()-(24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", time()-($filter_values[$i][3])*24*3600);
									$filter_values[$i][3] = date("Y-m-d", time()-(24*3600));
								}
								break;
		
							case "week":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaSemana = date("N", time()+$hourOffset)-1;
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(((($diaSemana-($week_start-1))+7)*24*3600) + (($filter_values[$i][3]-1)*7*24*3600))-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(((6-($diaSemana-($week_start-1)))-7)*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", time()-(((($diaSemana-($week_start-1))+7)*24*3600) + (($filter_values[$i][3]-1)*7*24*3600)));
									$filter_values[$i][3] = date("Y-m-d", time()+((6-($diaSemana-($week_start-1)))-7)*24*3600);
								}
								break;
		
							case "month":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$monthsDate = @mktime(0,0,0,date("m")-($filter_values[$i][3]),1,date("Y"));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $monthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()-($diaMes+1)*24*3600+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $monthsDate);
									$filter_values[$i][3] = date("Y-m-d", time()-($diaMes+1)*24*3600);
								}
								break;
									
							case "Fquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y")));
								}
								break;
		
							case "Nquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y")-$filter_values[$i][3])+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")-$filter_values[$i][3]));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y")-($filter_values[$i][3]))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y")-1)+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")-($filter_values[$i][3])));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")-1));
								}
								break;
								
								
							case "monday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last monday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last monday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last monday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last monday'));
								}
								break;
								
							case "tuesday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last tuesday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last tuesday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last tuesday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last tuesday'));
								}
								break;
								
							case "wednesday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last wednesday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last wednesday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last wednesday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last wednesday'));
								}
								break;
								
							case "thursday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last thursday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last thursday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last thursday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last thursday'));
								}
								break;
								
							case "friday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last friday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last friday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last friday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last friday'));
								}
								break;
								
							case "saturday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last saturday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last saturday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last saturday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last saturday'));
								}
								break;
								
							case "sunday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last sunday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last sunday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last sunday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last sunday'));
								}
								break;
								
							case "january":
								if (date("n") > 1)
									$monthNumber = date("n")-1;
								elseif (date("n") == 1)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(1-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "february":
								if (date("n") > 2)
									$monthNumber = date("n")-2;
								elseif (date("n") == 2)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(2-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "march":
								if (date("n") > 3)
									$monthNumber = date("n")-3;
								elseif (date("n") == 3)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(3-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "april":
								if (date("n") > 4)
									$monthNumber = date("n")-4;
								elseif (date("n") == 4)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(4-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "may":
								if (date("n") > 5)
									$monthNumber = date("n")-5;
								elseif (date("n") == 5)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(5-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "june":
								if (date("n") > 6)
									$monthNumber = date("n")-6;
								elseif (date("n") == 6)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(6-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "july":
								if (date("n") > 7)
									$monthNumber = date("n")-7;
								elseif (date("n") == 7)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(7-(date("n")));
								
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "august":
								if (date("n") > 8)
									$monthNumber = date("n")-8;
								elseif (date("n") == 8)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(8-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "september":
								if (date("n") > 9)
									$monthNumber = date("n")-9;
								elseif (date("n") == 9)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(9-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "october":
								if (date("n") > 10)
									$monthNumber = date("n")-10;
								elseif (date("n") == 10)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(10-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "november":
								if (date("n") > 11)
									$monthNumber = date("n")-11;
								elseif (date("n") == 11)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(11-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "december":
								if (date("n") > 12)
									$monthNumber = date("n")-12;
								elseif (date("n") == 12)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(12-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
		
						}
		
						$operator1 = "BETWEEN";
						$operator2 = "AND";
						break;
		
					case "not last":
						switch ($filter_values[$i][2]){
		
							case "day":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(($filter_values[$i][3])*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()-(24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", time()-($filter_values[$i][3])*24*3600);
									$filter_values[$i][3] = date("Y-m-d", time()-(24*3600));
								}
								break;
		
							case "week":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaSemana = date("N", time()+$hourOffset)-1;
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(((($diaSemana-($week_start-1))+7)*24*3600) + (($filter_values[$i][3]-1)*7*24*3600))-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(((6-($diaSemana-($week_start-1)))-7)*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", time()-(((($diaSemana-($week_start-1))+7)*24*3600) + (($filter_values[$i][3]-1)*7*24*3600)));
									$filter_values[$i][3] = date("Y-m-d", time()+((6-($diaSemana-($week_start-1)))-7)*24*3600);
								}
								break;
		
							case "month":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$monthsDate = @mktime(0,0,0,date("m")-($filter_values[$i][3]),1,date("Y"));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $monthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()-($diaMes+1)*24*3600+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $monthsDate);
									$filter_values[$i][3] = date("Y-m-d", time()-($diaMes+1)*24*3600);
								}
								break;
									
							case "Fquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y")));
								}
								break;
		
							case "Nquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y")-$filter_values[$i][3])+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")-$filter_values[$i][3]));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y")-($filter_values[$i][3]))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y")-1)+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")-($filter_values[$i][3])));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")-1));
								}
								break;
								
								
							case "monday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last monday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last monday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last monday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last monday'));
								}
								break;
								
							case "tuesday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last tuesday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last tuesday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last tuesday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last tuesday'));
								}
								break;
								
							case "wednesday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last wednesday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last wednesday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last wednesday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last wednesday'));
								}
								break;
								
							case "thursday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last thursday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last thursday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last thursday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last thursday'));
								}
								break;
								
							case "friday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last friday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last friday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last friday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last friday'));
								}
								break;
								
							case "saturday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last saturday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last saturday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last saturday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last saturday'));
								}
								break;
								
							case "sunday":
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date('Y-m-d H:00:00', strtotime('last sunday')+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", strtotime('last sunday')+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date('Y-m-d', strtotime('last sunday'));
									$filter_values[$i][3] = date("Y-m-d", strtotime('last sunday'));
								}
								break;
								
							case "january":
								if (date("n") > 1)
									$monthNumber = date("n")-1;
								elseif (date("n") == 1)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(1-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "february":
								if (date("n") > 2)
									$monthNumber = date("n")-2;
								elseif (date("n") == 2)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(2-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "march":
								if (date("n") > 3)
									$monthNumber = date("n")-3;
								elseif (date("n") == 3)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(3-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "april":
								if (date("n") > 4)
									$monthNumber = date("n")-4;
								elseif (date("n") == 4)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(4-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "may":
								if (date("n") > 5)
									$monthNumber = date("n")-5;
								elseif (date("n") == 5)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(5-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "june":
								if (date("n") > 6)
									$monthNumber = date("n")-6;
								elseif (date("n") == 6)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(6-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "july":
								if (date("n") > 7)
									$monthNumber = date("n")-7;
								elseif (date("n") == 7)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(7-(date("n")));
								
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "august":
								if (date("n") > 8)
									$monthNumber = date("n")-8;
								elseif (date("n") == 8)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(8-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "september":
								if (date("n") > 9)
									$monthNumber = date("n")-9;
								elseif (date("n") == 9)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(9-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "october":
								if (date("n") > 10)
									$monthNumber = date("n")-10;
								elseif (date("n") == 10)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(10-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "november":
								if (date("n") > 11)
									$monthNumber = date("n")-11;
								elseif (date("n") == 11)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(11-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
							case "december":
								if (date("n") > 12)
									$monthNumber = date("n")-12;
								elseif (date("n") == 12)
									$monthNumber = 12;
								else 	
									$monthNumber = 12-(12-(date("n")));
									
								$fistMonthsDate = @mktime(0,0,0,date("m")-($monthNumber),1,date("Y"));
								$lastMonthsDate = @mktime(0,0,0,date("m")-($monthNumber-1),1,date("Y"));
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $fistMonthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", $lastMonthsDate+$hourOffset-3600);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $fistMonthsDate);
									$filter_values[$i][3] = date("Y-m-d", $lastMonthsDate-(24*3600));
								}
								break;
								
		
						}
		
						$operator1 = "NOT BETWEEN";
						$operator2 = "AND";
						break;
		
					case "this":
						switch ($filter_values[$i][2]){
		
							case "day":
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d");
									$filter_values[$i][3] = date("Y-m-d");
								}
								
								break;
		
							case "week":
								$diaSemana = date("N", time()+$hourOffset)-1;
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(($diaSemana-($week_start-1))*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+((6-($diaSemana-($week_start-1)))*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()-(($diaSemana-($week_start-1))*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+((6-($diaSemana-($week_start-1)))*24*3600));
								}
								break;
		
							case "month":
								$diaMes = date("j", time()+$hourOffset)-1;
								$numDiasMes = date("t", time()+$hourOffset);
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-($diaMes*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(($numDiasMes-$diaMes-1)*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()-($diaMes*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+(($numDiasMes-$diaMes-1)*24*3600));
								} 
								break;
		
							case "Fquarter":
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								}
								break;
		
							case "Nquarter":
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+1)+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+1));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y"))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")));
								}
								break;
		
						}
		
						$operator1 = "BETWEEN";
						$operator2 = "AND";
						break;
		
					case "not this":
				switch ($filter_values[$i][2]){
		
							case "day":
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d");
									$filter_values[$i][3] = date("Y-m-d");
								}
								
								break;
		
							case "week":
								$diaSemana = date("N", time()+$hourOffset)-1;
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(($diaSemana-($week_start-1))*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+((6-($diaSemana-($week_start-1)))*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()-(($diaSemana-($week_start-1))*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+((6-($diaSemana-($week_start-1)))*24*3600));
								}
								break;
		
							case "month":
								$diaMes = date("j", time()+$hourOffset)-1;
								$numDiasMes = date("t", time()+$hourOffset);
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-($diaMes*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(($numDiasMes-$diaMes-1)*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()-($diaMes*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+(($numDiasMes-$diaMes-1)*24*3600));
								} 
								break;
		
							case "Fquarter":
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								}
								break;
		
							case "Nquarter":
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+1)+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+1));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y"))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")));
								}
								break;
		
						}
		
						$operator1 = "NOT BETWEEN";
						$operator2 = "AND";
						break;
						
						
					case "theese":
						
						switch ($filter_values[$i][2]){
	
							case "day":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(($filter_values[$i][3])*24*3600)-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", time()-($filter_values[$i][3])*24*3600);
									$filter_values[$i][3] = date("Y-m-d");
								}
								break;
		
							case "week":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								$diaSemana = date("N", time()+$hourOffset)-1;
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()-(((($diaSemana-($week_start-1))+7)*24*3600) + (($filter_values[$i][3]-1)*7*24*3600))-(date("G")*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+((6-($diaSemana-($week_start-1)))*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", time()-(((($diaSemana-($week_start-1))+7)*24*3600) + (($filter_values[$i][3]-1)*7*24*3600)));
									$filter_values[$i][3] = date("Y-m-d", time()+((6-($diaSemana-($week_start-1)))*24*3600));
								}
								break;
		
							case "month":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								$diaMes = date("j", time()+$hourOffset)-1;
								$monthsDate = @mktime(0,0,0,date("m")-($filter_values[$i][3]),1,date("Y"));
								$numDiasMes = date("t", time()+$hourOffset);
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", $monthsDate+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(($numDiasMes-$diaMes-1)*24*3600)+((24*3600)-((date("G")+1)*3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", $monthsDate);
									$filter_values[$i][3] = date("Y-m-d", time()+(($numDiasMes-$diaMes-1)*24*3600));
								}
								break;
									
							case "Fquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
									
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								}
								break;
		
							case "Nquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)-(3+(3*($filter_values[$i][3]-1))),date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y")-$filter_values[$i][3])+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+1)+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")-$filter_values[$i][3]));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+1));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
		
								$filter_values[$i][3] = $filter_values[$i][3] -1;
								
								if ($filter_values[$i][4] == "datetime"){
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y")-($filter_values[$i][3]))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y"))+((24*3600)-(3600))+$hourOffset);
								} else if ($filter_values[$i][4] == "date"){
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")-($filter_values[$i][3])));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")));
								}
								break;	
		
						}
		
						$operator1 = "BETWEEN";
						$operator2 = "AND";
						break;
		
					case "next":
						switch ($filter_values[$i][2]){
		
							case "day":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()+(1*24*3600)-((date("G"))*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(($filter_values[$i][3]+1)*24*3600)-((date("G")+1)*3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()+(1*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+(($filter_values[$i][3])*24*3600));
								}
								break;
		
							case "week":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaSemana = date("N", time()+$hourOffset)-1;
								
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()+((7-($diaSemana-($week_start-1)))*24*3600)-((date("G"))*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(((6-($diaSemana-($week_start-1)))+($filter_values[$i][3]*7)+1)*24*3600)-((date("G")+1)*3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()+((7-($diaSemana-($week_start-1)))*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+(((6-($diaSemana-($week_start-1)))+($filter_values[$i][3]*7))*24*3600));
								}
								break;
		
							case "month":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$mes = @mktime( 0, 0, 0, date("m")+$filter_values[$i][3], 1, date("Y"));
									
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")+1,1,date("Y"))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+$filter_values[$i][3],date("t", $mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")+1,1,date("Y")));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+$filter_values[$i][3],date("t", $mes),date("Y")));
								}
								break;
		
							case "Fquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y")));
								}
		
								break;
		
							case "Nquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y")+1)+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+$filter_values[$i][3]+1)+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")+1));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+$filter_values[$i][3]+1));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
									
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y")+1)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y")+$filter_values[$i][3])+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")+1));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")+$filter_values[$i][3]));
								}
								break;
		
						}
		
		
						$operator1 = "BETWEEN";
						$operator2 = "AND";
						break;
		
					case "not next":
				switch ($filter_values[$i][2]){
		
							case "day":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()+(1*24*3600)-((date("G"))*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(($filter_values[$i][3]+1)*24*3600)-((date("G")+1)*3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()+(1*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+(($filter_values[$i][3])*24*3600));
								}
								break;
		
							case "week":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaSemana = date("N", time()+$hourOffset)-1;
								
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", time()+((7-($diaSemana-($week_start-1)))*24*3600)-((date("G"))*3600)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", time()+(((6-($diaSemana-($week_start-1)))+($filter_values[$i][3]*7)+1)*24*3600)-((date("G")+1)*3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", time()+((7-($diaSemana-($week_start-1)))*24*3600));
									$filter_values[$i][3] = date("Y-m-d", time()+(((6-($diaSemana-($week_start-1)))+($filter_values[$i][3]*7))*24*3600));
								}
								break;
		
							case "month":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$mes = @mktime( 0, 0, 0, date("m")+$filter_values[$i][3], 1, date("Y"));
									
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")+1,1,date("Y"))+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+$filter_values[$i][3],date("t", $mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")+1,1,date("Y")));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+$filter_values[$i][3],date("t", $mes),date("Y")));
								}
								break;
		
							case "Fquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y")));
								}
		
								break;
		
							case "Nquarter":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$diaMes = date("j", time()+$hourOffset)-1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y"))+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y"))+(24*3600)-(3600)+$hourOffset);
								} else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,date("m")-($monthInQuarter-1)+3,date("d")-$diaMes,date("Y")));
									$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(3-$monthInQuarter)+(3*$filter_values[$i][3]),date("t",$mes),date("Y")));
								}
								break;
		
							case "Fyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
								$numMes = date("n", time()+$hourOffset);
		
		
								$year_month = $quarter_month;
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,$year_month,1,date("Y")+1)+$hourOffset);
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+$filter_values[$i][3]+1)+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,$year_month,1,date("Y")+1));
									$mes = @mktime( 0, 0, 0, date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)), 1, date("Y"));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,date("m")+(((3-$monthInQuarter)-3) - (($thisQuarter-1)*3)),date("t",$mes),date("Y")+$filter_values[$i][3]+1));
								}
								break;
		
							case "Nyear":
								if ($filter_values[$i][3] == "")
								$filter_values[$i][3] = 1;
									
								if ($filter_values[$i][4] == "datetime") {
									$filter_values[$i][2] = date("Y-m-d H:00:00", @mktime(0,0,0,1,1,date("Y")+1)+$hourOffset);
									$filter_values[$i][3] = date("Y-m-d H:59:59", @mktime(0,0,0,12,31,date("Y")+$filter_values[$i][3])+(24*3600)-(3600)+$hourOffset);
								}else if ($filter_values[$i][4] == "date") {
									$filter_values[$i][2] = date("Y-m-d", @mktime(0,0,0,1,1,date("Y")+1));
									$filter_values[$i][3] = date("Y-m-d", @mktime(0,0,0,12,31,date("Y")+$filter_values[$i][3]));
								}
								break;
		
						}
		
		
						$operator1 = "NOT BETWEEN";
						$operator2 = "AND";
						break;
							
					//EN CASO DE QUE HAYA ALGUN REPORT VIEJO, MANTENEMOS LAS OPCIONES DE FIXED_DATE
					case "fixed date":
		
						switch ($filter_values[$i][2]){
		
							case "today":
								$filter_values[$i][2] = date("Y-m-d 00:00:00");
								$filter_values[$i][3] = date("Y-m-d 23:59:59");
								break;
		
							case "yesterday":
								$filter_values[$i][2] = date("Y-m-d 00:00:00", time()-1*24*3600);
								$filter_values[$i][3] = date("Y-m-d 23:59:59", time()-1*24*3600);
								break;
		
							case "last n days":
								$filter_values[$i][2] = date("Y-m-d 00:00:00", time()-(($filter_values[$i][3])*24*3600));
								$filter_values[$i][3] = date("Y-m-d 23:59:59", time());
								break;
		
							case "this week":
								$diaSemana = date("N")-1;
								$filter_values[$i][2] = date("Y-m-d 00:00:00", time()-($diaSemana-($week_start-1))*24*3600);
								$filter_values[$i][3] = date("Y-m-d 23:59:59", time()+(6-($diaSemana-($week_start-1)))*24*3600);
								break;
		
							case "last week":
								$diaSemana = date("N")-1;
								$filter_values[$i][2] = date("Y-m-d 00:00:00", time()-(($diaSemana-($week_start-1))+7)*24*3600);
								$filter_values[$i][3] = date("Y-m-d 23:59:59", time()+((6-($diaSemana-($week_start-1)))-7)*24*3600);
								break;
		
							case "this month":
								$diaMes = date("j")-1;
								$numDiasMes = date("t");
								$filter_values[$i][2] = date("Y-m-d 00:00:00", time()-$diaMes*24*3600);
								$filter_values[$i][3] = date("Y-m-d 23:59:59", time()+($numDiasMes-$diaMes-1)*24*3600);
								break;
									
							case "last month":
								$diaMes = date("j")-1;
								$numDiasMes = date("d", time()-($diaMes+1)*24*3600);
								$filter_values[$i][2] = date("Y-m-d 00:00:00", time()-($diaMes+$numDiasMes)*24*3600);
								$filter_values[$i][3] = date("Y-m-d 23:59:59", time()-($diaMes+1)*24*3600);
								break;
		
							case "this fiscal quarter":
								$diaMes = date("j")-1;
								$numMes = date("n");
									
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								$filter_values[$i][2] = date("Y-m-d 00:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y")));
								$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
								$filter_values[$i][3] = date("Y-m-d 23:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								break;
		
							case "last fiscal quarter":
								$diaMes = date("j")-1;
								$numMes = date("n");
								$quarter_month = (($numMes-($quarter_month-1)) <= 0) ? $numMes+(12-($quarter_month-1)) : $numMes-($quarter_month-1);
								$thisQuarter = ceil($quarter_month/3);
								$monthInQuarter = $quarter_month-(3*($thisQuarter-1));
		
								$filter_values[$i][2] = date("Y-m-d 00:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-3,date("d")-$diaMes,date("Y")));
								$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
								$filter_values[$i][3] = date("Y-m-d 23:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y")));
								break;
									
							case "this natural quarter":
								$diaMes = date("j")-1;
								$numMes = date("n");
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								$filter_values[$i][2] = date("Y-m-d 00:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1),date("d")-$diaMes,date("Y")));
								$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter), 1, date("Y"));
								$filter_values[$i][3] = date("Y-m-d 23:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter),date("t",$mes),date("Y")));
								break;
		
							case "last natural quarter":
								$diaMes = date("j")-1;
								$numMes = date("n");
								$thisQuarter = ceil($numMes/3);
								$monthInQuarter = $numMes-(3*($thisQuarter-1));
		
								$filter_values[$i][2] = date("Y-m-d 00:00:00", @mktime(0,0,0,date("m")-($monthInQuarter-1)-3,date("d")-$diaMes,date("Y")));
								$mes = @mktime( 0, 0, 0, date("m")+(3-$monthInQuarter)-3, 1, date("Y"));
								$filter_values[$i][3] = date("Y-m-d 23:59:59", @mktime(0,0,0,date("m")+(3-$monthInQuarter)-3,date("t",$mes),date("Y")));
								break;
		
						}
		
						$operator1 = "BETWEEN";
						$operator2 = "AND";
		
						break;
						//EN CASO DE QUE HAYA ALGUN REPORT VIEJO, MANTENEMOS LAS OPCIONES DE FIXED_DATE
		
				}
		
		
				$table = ((count(explode(".", $filter_values[$i][0]))) == 1 ) ? $report_table."." : "";
		
				//A�adir tabla y . si campos es de la principal
		
				//Para los campos enum y que tenga como primer operador one of o not one of
				if (($filter_values[$i][4] == "enum") && (($filter_values[$i][1] == "one of") || ($filter_values[$i][1] == "not one of"))){
		
					$enum_fields = ($escapeTokensFilters == "true") ? explode("\${dollar}", $filter_values[$i][2]) : explode("$", $filter_values[$i][2]);
					$sqlWhere .= "(";
		
					if ($escapeTokensFilters == "true")
					$sqlWhere .= $table.$filter_values[$i][0]." ".$operator1." ('".str_replace("\${dollar}", "', '",$filter_values[$i][2])."') ";
					else
					$sqlWhere .= $table.$filter_values[$i][0]." ".$operator1." ('".str_replace("$", "', '",$filter_values[$i][2])."') ";
		
					if ($enum_fields[0] == ""){
		
						if ($filter_values[$i][1] == "one of")
						$sqlWhere .= "OR ".$table.$filter_values[$i][0]." IS NULL";
							
					} else {
		
						if ($filter_values[$i][1] == "not one of")
						$sqlWhere .= "OR ".$table.$filter_values[$i][0]." IS NULL";
							
					}
		
					$sqlWhere .= ") ";
		
				}else{
		
					if ((($filter_values[$i][2] == "") && (($operator1 == "=") || ($operator1 == "!="))) || (($filter_values[$i][2] != "") && ($operator1 == "!=")))
					$sqlWhere .= "(";
		
					if ($filter_values[$i][4] == "tinyint(1)")
					$sqlWhere .= $table.$filter_values[$i][0]." ".$operator1." ".$filter_values[$i][2]." ";
					else
					$sqlWhere .= $table.$filter_values[$i][0]." ".$operator1." '".$filter_values[$i][2]."' ";
		
					if ($filter_values[$i][2] == ""){
		
						if ($operator1 == "=")
						$sqlWhere .= "OR ".$table.$filter_values[$i][0]." IS NULL) ";
						else if ($operator1 == "!=")
						$sqlWhere .= "OR ".$table.$filter_values[$i][0]." IS NOT NULL) ";
							
					} else{
		
						if ($operator1 == "!=")
						$sqlWhere .= "OR ".$table.$filter_values[$i][0]." IS NULL) ";
		
					}
		
				}
		
		
				if ($operator2 != ""){
		
					$sqlWhere .= $operator2." '".$filter_values[$i][3]."'";
		
				}
		
		
				$sqlWhere .= " AND ";
		
			}
		
		}
		
		$sqlWhere = substr($sqlWhere, 0, -4);
		
		
		//Is Domains Installed
		if ($DomainsRow['count'] > 0) {
		
			if ((!$current_user->is_admin) || (($current_user->is_admin) && (!empty($current_user->asol_default_domain)))){
		
				require_once ('modules/asol_Domains/asol_Domains.php');
				$domainsBean = new asol_domains();
				$domainsBean->retrieve($current_user->asol_default_domain);
		
				if ($domainsBean->asol_domain_enabled) {
		
					$sqlWhere .= " AND ( (".$report_table.".asol_domain_id='".$current_user->asol_default_domain."')";
		
					if ($current_user->asol_only_my_domain == 0) {
							 
							
						//asol_domain_child_share_depth
		
						$parentQuery = $db->query("SELECT DISTINCT asol_domains_id_c as parent_domain FROM asol_domains WHERE id = '".$current_user->asol_default_domain."'");
						$parentRow = $db->fetchByAssoc($parentQuery);
						$parentDomain = $parentRow['parent_domain'];
						$i=1;
		
						while (!empty($parentDomain)) {
								
							$sqlWhere .= " OR ((".$report_table.".asol_domain_id = '".$parentRow['parent_domain']."') AND (".$report_table.".asol_domain_child_share_depth >= $i) AND (".$report_table.".asol_published_domain = 1)) ";
		
							$parentQuery = $db->query("SELECT DISTINCT asol_domains_id_c as parent_domain FROM asol_domains WHERE id = '".$parentDomain."'");
							$parentRow = $db->fetchByAssoc($parentQuery);
							$parentDomain = $parentRow['parent_domain'];
		
							$i++;
								
						}
		
						//asol_domain_child_share_depth condition
		
						//asol_multi_create_domain
						if ($report_table != 'users')
						$sqlWhere .= " OR ((".$report_table.".asol_multi_create_domain LIKE '%;".$current_user->asol_default_domain.";%') AND (".$report_table.".asol_published_domain = 1)) ";
						//asol_multi_create_domain
		
		
						//View hierarchy (any item above its hierarchy coul be seen)
						$childDomainsIds = (!empty($current_user->asol_child_domains_array)) ? $current_user->asol_child_domains_array : $current_user->getChildDomainsWithDepth($current_user->asol_default_domain);
						$childDomainsStr = Array();
						foreach ($childDomainsIds as $key=>$domainId) {
							if (!$domainId['enabled'])
							array_splice($childDomainsIds, $key, 1);
							else
							$childDomainsStr[] = $domainId['id'];
						}
						$sqlWhere .= (count($childDomainsIds) > 0) ? "OR (".$report_table.".asol_domain_id IN ('".implode("','", $childDomainsStr)."')) )" : ") " ;
		
					} else {
							
						$sqlWhere .= ") ";
		
					}
		
				} else {
		
					$sqlWhere .= " AND (1!=1) ";
		
				}
		
			}
		
		
		}
		//Is Domains Installed
		
		
		//OBTENEMOS LA CLAUSULA "GROUP BY"
		
		$sqlGroup = "";
		$details = Array();
		$group_by_seq = Array();
		
		$j=0;
		$l=0;
		for ($i=0; $i<count($field_values); $i++){
		
			if ($field_values[$i][6] == "Grouped"){
		
				$table = ((count(explode(".", $field_values[$i][0]))) == 1 ) ? $report_table."." : "";
				
				$group_by_seq[$j]['order'] = $field_values[$i][7];
				$group_by_seq[$j]['field'] = $table.$field_values[$i][0];
				$group_by_seq[$j]['alias'] = $field_values[$i][1];
		
				$j++;
		
			}
		
			//Comprobamos si alguno de los campos agrupados son detallados, si es as� lo amacenamos en un array $details
			if (($field_values[$i][6] == "Detail") || ($field_values[$i][6] == "Month Detail") || ($field_values[$i][6] == "Fiscal Quarter Detail") || ($field_values[$i][6] == "Natural Quarter Detail")) {
		
				$details[$l]['order'] = $field_values[$i][6];
		
				$table = ((count(explode(".", $field_values[$i][0]))) == 1 ) ? $report_table."." : "";
		
				$details[$l]['field'] = $table.$field_values[$i][0];
				$details[$l]['type'] = $field_values[$i][6];
				$details[$l]['format'] = $field_values[$i][8];
				$details[$l]['opts'] = $field_values[$i][12];
				$details[$l]['optsDb'] = $field_values[$i][13];
				$l++;
		
			}
		
		}
		
		if (count($details) != 0)
		sort($details);
		
		
		if (count($group_by_seq) != 0){
		
			sort($group_by_seq);
			$sqlGroup .= " GROUP BY ";
		
			for ($k=0; $k<count($group_by_seq); $k++){
		
				$table = ((count(explode(".", $group_by_seq[$k]['field']))) == 1 ) ? $report_table."." : "";
				$sqlGroup .= $table.$group_by_seq[$k]['field']." ,";
		
			}
		
		}
		
		$sqlGroup = substr($sqlGroup, 0, -1);
		
		
		//OBTENEMOS LA CAUSULA "ORDER BY"
		
		$sqlOrder = "";
		
		$order_by_seq = Array();
		
		$j=0;
		for ($i=0; $i<count($field_values); $i++){
		
			if ($field_values[$i][3] != "0"){
		
				$order_by_seq[$j]['order'] = $field_values[$i][4];
				$order_by_seq[$j]['field'] = $field_values[$i][0];
				$order_by_seq[$j]['dir'] = $field_values[$i][3];
		
				$j++;
			}
		
		}
		
		if (count($order_by_seq) != 0){
		
			sort($order_by_seq);
			$sqlOrder .= " ORDER BY ";
		
			for ($k=0; $k<count($order_by_seq); $k++){
		
				$table = ((count(explode(".", $order_by_seq[$k]['field']))) == 1 ) ? $report_table."." : "";
		
				$sqlOrder .= $table.$order_by_seq[$k]['field']." ".$order_by_seq[$k]['dir']." ,";
		
			}
		
		}
		
		$sqlOrder = substr($sqlOrder, 0, -1);
		
		
		//********************FIN PASO COMUN 1********************
		
		//Reordenamos el resultset en funcion de la cabecera pinchada en la pagina display
		if ($field_sort != ""){
		
			if ($sort_direction == "")
			$sort_direction = "ASC";
		
			$table = ((count(explode(".", $field_sort))) == 1 ) ? $report_table."." : "";
		
			//Reformatear nombre de la tabla si es un related field
			$sqlOrder = " ORDER BY ".$table.$field_sort." ".$sort_direction." ";
		
			if ($sort_direction == "ASC")
			$sort_direction = "DESC";
			else
			$sort_direction = "ASC";
		
		}
	
		
		//PAGINADO
		$rs = $focus->getSelectionResults("SELECT COUNT(*) AS total ".$sqlFrom.$sqlJoin.$sqlWhere.$sqlGroup);
		//Disable Reports with a max of entries & max of subgroups. To-do
		
		if (isset($group_by_seq[0]['field'])){
			$rsG = $focus->getSelectionResults("SELECT COUNT(DISTINCT ".$group_by_seq[0]['field'].") AS total ".$sqlFrom.$sqlJoin.$sqlWhere);
		
			$total_entries = (($rsG[0]['total'] == 0) && ($rs[0]['total'] != 0)) ? 1 : $rsG[0]['total'];
		
			if ($rs[0]['total'] == 0)
			$total_entries = 0;
		
			if (count($group_by_seq) != 0)
			$total_entries = count($rs);
		
		} else {
			$total_entries = $rs[0]['total'];
		
		}
		
		/*
		echo "Total Entries: ".$total_entries."<br>";
		
		if ($total_entries > 500) {
			echo "Informe demasiado grande, especifique su busqueda!";
			exit;
		}
		*/
		
		$page_number = isset($_REQUEST['page_number']) ? $_REQUEST['page_number'] : "";
		
		
		//OBTENEMOS LA CLAUSULA "LIMIT"
		if ($report_data['results_limit'] == "all"){
		
			$sqlLimit = " LIMIT ".$entries_per_page*$page_number.",".$entries_per_page;
			$sqlLimitExport = "";
		
			$total_entries_basic = $total_entries;
		
		} else {
		
			$res_limit = explode("\${dp}", $report_data['results_limit']);
		
		
			if ($res_limit[2] > $total_entries)
			$res_limit[2] = $total_entries;
		
		
			if ($res_limit[1] == 'first'){
		
				if ($entries_per_page >= $res_limit[2]) {
		
					$sqlLimit = " LIMIT 0,".$res_limit[2];
		
				} else {
		
					$limit_current_entries = ((($entries_per_page*$page_number)+$entries_per_page) > $res_limit[2]) ? ($res_limit[2]%$entries_per_page) : $entries_per_page;
					$sqlLimit = " LIMIT ".($entries_per_page*$page_number).",".$limit_current_entries;
		
				}
		
				$sqlLimitExport = " LIMIT 0,".$res_limit[2];
		
			} else { //last
		
				$limit_init_entry = ($total_entries < $res_limit[2]) ? ($entries_per_page*$page_number) : ($entries_per_page*$page_number)+($total_entries-$res_limit[2]);
		
				if ($entries_per_page >= $res_limit[2]) {
		
					$sqlLimit = " LIMIT ".($total_entries-$res_limit[2]).",".$res_limit[2];
		
				} else {
		
					$limit_current_entries = ((($entries_per_page*$page_number)+$entries_per_page) > $res_limit[2]) ? ($res_limit[2]%$entries_per_page) : $entries_per_page;
					$sqlLimit = " LIMIT ".$limit_init_entry.",".$limit_current_entries;
		
				}
		
				$sqlLimitExport = " LIMIT ".($total_entries-$res_limit[2]).",".$res_limit[2];
		
			}
		
			$total_entries_basic = ($total_entries <= $res_limit[2]) ? $total_entries : $res_limit[2];
		
		}
		
		
		if ($externalCall) {
			$sqlLimit = "";
		}
		
		
		//********************INICIO PASO COMUN 2********************
		//Comprobamos si se ha metido algun campo en el report, sino se corrige
		
		
		if (strlen($sqlSelect) <= 6){
			$columns[0] = "id";
			$sqlSelect .= " id";
			$sqlOrder .= "id";
		}
		
		//Comprobamos si se ha metido algun campo en los totals del report, sino se corrige
		if (strlen($sqlTotals) <= 6){
			$sqlTotals .= " COUNT(".$report_table.".id) AS 'TOTAL'";
			$totals[0][1] = "TOTAL";
		}
		
		
		//Calculamos extension clausula where para limitaciones
		if ($report_data['results_limit'] == "all"){
		
			$sqlLimitWhere = "";
		
		} else {
		
			$res_limit = explode("\${dp}", $report_data['results_limit']);
		
			$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlWhere.$sqlGroup.$sqlOrder;
			$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
			if (empty($limitedTotalsRs))
				$limitedTotalsRs = Array();
		
			$listIds = "";
			foreach ($limitedTotalsRs as $limitedRow){
				if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
					$listIds .= "'".$limitedRow['id']."',";
				else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($total_entries-$res_limit[2])))
					$listIds .= "'".$limitedRow['id']."',";
			}
		
			$listIds = substr($listIds, 0, -1);
		
			$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
		}
		
		
		//Si existe alg�n Detail group by desgranar este resultset en un array asociativo por el campo a detallar
		//y con contenido el que le corresponda. Crea una variable que indique si se va a agrupar Detalladamente
		//o no a la hora de visualizar la tabla del .tpl
		$hasDetail = false;
		//********************FIN PASO COMUN 2********************
		
		//********************INICIO PASO COMUN 3********************
		if (count($details) != 0){
		
			//Array asociativo por valor de cada agrupaci�n que contiene las filas de cada subgrupo
			$subGroups = Array();
			//Array asociativo por valor de cada agrupaci�n que contiene los subtotales de cada subgrupo
			$subTotals = Array();
		
			$current_entries = 0;
			$first_entrie = 0;
			//details contiene el indice y nombre del campo a agrupar: p.e.: "sales_stage"
			//for ($i=0; $i<count($details); $i++){//Inicio del for de cada group detallado
			//VER HASTA CUANTOS NIVELES SE PUEDE AGRUPAR DETALLADAMENTE E INCLUSO EN GENERAL
			$i=0;
		
		
			//para cada subgrupo obtenemos su resultset y la almacenamos dentro del array asociativo
			//Obtenemos tambi�n el resulset para los totales de ese subgrupo
		
		
			switch ($details[$i]['type']){
					
				case "Detail":
		
					//obtenemos los posibles valores de las agrupaciones a generar
					$sqlGroupsQuery = "SELECT DISTINCT ".$details[$i]['field']." AS 'group' ".$sqlFrom.$sqlJoin.$sqlWhere;
					$rsGroups = $focus->getSelectionResults($sqlGroupsQuery);
		
					
					//Reordenar rsGroups para ordenar subGrupos
					if (count($rsGroups) > 0)
					sort($rsGroups);
		
					//********************FIN PASO COMUN 3********************
		
					//ALGORITMO PARA EL PAGINADO DE LOS DETAIL GROUPING REPORTS
		
					$sizes;
					$fullSizes;
		
					for ($j=0; $j<count($rsGroups); $j++){
		
						if ($rsGroups[$j]['group'] == "")
						$rsGroups[$j]['group'] = "Nameless";
						else
						$rsGroups[$j]['group'] = str_replace("&quot;", "\"", str_replace("&#039;", "\'", $rsGroups[$j]['group']));
		
						$groupField = $details[$i]['field'];
						$subGroup = $rsGroups[$j]['group'];
		
						//formatear subGroup
		
						if ($subGroup != "Nameless")
						$sqlDetailGroupWhere = $sqlWhere." AND ".$groupField."='".$subGroup."' ";
						else
						$sqlDetailGroupWhere = $sqlWhere." AND ".$groupField." IS NULL ";
							
		
						$sqlDetailGroupQuery = "SELECT COUNT(".$report_table.".id) AS total ".$sqlFrom.$sqlJoin.$sqlDetailGroupWhere.$sqlGroup;
		
						
						$rsCount = $focus->getSelectionResults($sqlDetailGroupQuery);
		
						if ($report_data['results_limit'] == "all") {
							$sizes[$j] = $rsCount[0]['total'];
						} else {
							$res_limit = explode("\${dp}", $report_data['results_limit']);
							$sizes[$j] = ($rsCount[0]['total'] < $res_limit[2]) ? $rsCount[0]['total'] : $res_limit[2];
						}
		
						$fullSizes[$j] = $rsCount[0]['total'];
		
					}
		
		
					$init_group = 0;
					$end_group = 0;
					$index=0;
		
					for ($k=0; $k<=$page_number; $k++){
							
						$current_entries = 0;
							
						$current_entries += $sizes[$index];
		
						while (($current_entries < $entries_per_page) && ($index+1 < count($sizes))){
							$index++;
							$current_entries += $sizes[$index];
		
						}
							
						if ($k == ($page_number-1)){
							$init_group = $index+1;
						}
							
						if ($k == $page_number){
							$end_group = $index;
						}
							
						$index++;
						$first_entrie += $current_entries;
					}
		
					$first_entrie -= $current_entries;
		
					//ALGORITMO PARA EL PAGINADO DE LOS DETAIL GROUPING REPORTS
		
		
					$groupField = Array();
					$subGroup = Array();
					$subTotals = Array();
		
					//********************INICIO PASO COMUN 4********************
					for ($j=$init_group; $j<=$end_group; $j++){
		
						$groupField = $details[$i]['field'];
						$subGroup = $rsGroups[$j]['group'];
							
						if ($subGroup != "Nameless")
						$sqlDetailWhere = $sqlWhere." AND ".$groupField."='".$subGroup."' ";
						else {
							$sqlDetailWhere = $sqlWhere." AND ".$groupField." IS NULL ";
							$subGroup = $mod_strings['LBL_REPORT_NAMELESS'];
						}
		
		
							
						//OBTENEMOS LA CLAUSULA "LIMIT"
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimit = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							if ($res_limit[1] == "first"){
		
								$sqlLimit = " LIMIT 0,".$res_limit[2];
									
							} else { //last
		
								$limit_init_entry = ($fullSizes[$j] < $res_limit[2]) ? 0 : ($fullSizes[$j]-$res_limit[2]);
								$sqlLimit = " LIMIT ".$limit_init_entry.",".$res_limit[2];
									
							}
		
		
						}
		
						//Calculamos extension clausula where para limitaciones
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimitWhere = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder;
							$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
							//reordenamos el array por si esta ordenado descendentemente
							foreach ($limitedTotalsRs as $key=>$limitedTotal)
								$limitedTotalsRs[$key]['rownum'] = $key+1;
		
							$listIds = "";
							foreach ($limitedTotalsRs as $limitedRow){
								if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
									$listIds .= "'".$limitedRow['id']."',";
								else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
									$listIds .= "'".$limitedRow['id']."',";
							}
		
							$listIds = substr($listIds, 0, -1);
							$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
		
						}
		
		
						$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder.$sqlLimit;
						$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
						
		
						//*******************
						//Row Group Totals***
						//*******************
						
						if ($hasGrouped) {
									
							$groupingFieldAlias = $group_by_seq[0]["alias"];
	
							//echo print_r($rsDetail, true)."<br>";
							
							$groupColumnName = "";
							
							foreach ($rsDetail as $key=>$myRs) {
								
								$groupingVal = $myRs[$groupingFieldAlias];
								
								if (!empty($groupingVal))
									$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
								else
									$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
								
								$rsGroupingTotals = $focus->getSelectionResults($sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroupTotalWhere);
								
								foreach ($rsGroupingTotals as $key2=>$groupTotal) {
					
									foreach ($groupTotal as $keyName=>$groupTotalVal) {
										$rsDetail[$key][$keyName] = $groupTotalVal;
									}
								
								}
								
							}	
							
						}
						
						
						//*******************
						//Row Group Totals***
						//*******************
		
						
						//*************************FORMATEO DEL SUBGROUP
						
						if ($details[$i]["format"] == "enum") {
		
							$details[$i]["opts"] = str_replace("\${sq}", "'", $details[$i]["opts"]);
							$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $details[$i]["optsDb"]) : explode(",", $details[$i]["optsDb"]);
							$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $details[$i]["opts"]) : explode(",", $details[$i]["opts"]);
		
							foreach ($enumOptionsDb as $keyO=>$opt){
		
								if ($opt == $subGroup){
		
									$subGroup = $enumOptions[$keyO];
									break;
		
								}
		
							}
		
						} else if ($details[$i]["format"] == "datetime"){
		
							$subGroup = $timedate->handle_offset($subGroup, $timedate->get_db_date_time_format(), true, null, $userTZ);
		
						} else if ($details[$i]["format"] == "currency") {
		
							$params = array('currency_id' => $focus->currency_id, 'convert' => true);
							$subGroup = currency_format_number($subGroup, $params);
		
						}
		
						$subGroup = str_replace("\'", "'", $subGroup);
		
						//*************************FORMATEO DEL SUBGROUP
		
						for($k=0; $k<count($rsDetail); $k++){
		
							$subGroups[$subGroup][count($subGroups[$subGroup])] = $rsDetail[$k];
		
						}
		
						
						//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
						$sqlSubQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere;
						$rsSubTotals = $focus->getSelectionResults($sqlSubQueryTotals);
		
						
						
						//REFORMATEAR DATE; DATETIME Y CURRENCY
						$formatedSubTotalsRs = $rsSubTotals;
							
						if (count($formatedSubTotalsRs[0]) == 0)
							$formatedSubTotalsRs[0] = Array();
						$k = 0;
							
						//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
		
						foreach ($formatedSubTotalsRs[0] as $key=>$value){
		
							$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
							
							if ($total8 == "date") {
		
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
							} else if ($total8 == "datetime") {
									
								$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
							} else if ($total8 == "currency") {
		
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$formatedSubTotalsRs[0][$key] = currency_format_number($value, $params);
									
							} else
							$formatedSubTotalsRs[0][$key] = $value;
		
		
							$k++;
		
						}
							
						$rsSubTotals = $formatedSubTotalsRs;
		
						$subTotals[$subGroup] = $rsSubTotals[0];
							
					}
		
					//********************FIN PASO COMUN 4********************
		
		
					//**************************************OBTENEMOS EL RESULTSET SIN PAGINADO PARA LOS EXPORTS
		
					if (($report_data['results_limit'] != "all") || ($allowExportGeneratedFile)) {
					
						//Array asociativo por valor de cada agrupaci�n que contiene las filas de cada subgrupo
						$subGroupsExport = Array();
						//Array asociativo por valor de cada agrupaci�n que contiene los subtotales de cada subgrupo
						$subTotalsExport = Array();
			
						$init_group = 0;
						$end_group = count($rsGroups)-1;
			
						$groupField = Array();
						$subGroup = Array();
			
						for ($j=$init_group; $j<=$end_group; $j++){
			
							$groupField = $details[$i]['field'];
							$subGroup = $rsGroups[$j]['group'];
								
							if ($subGroup != "Nameless")
							$sqlDetailWhere = $sqlWhere." AND ".$groupField."='".$subGroup."' ";
							else {
								$sqlDetailWhere = $sqlWhere." AND ".$groupField." IS NULL ";
								$subGroup = $mod_strings['LBL_REPORT_NAMELESS'];
							}
			
			
							//OBTENEMOS LA CLAUSULA "LIMIT"
							if ($report_data['results_limit'] == "all"){
			
								$sqlLimit = "";
			
							} else {
			
								$res_limit = explode("\${dp}", $report_data['results_limit']);
			
								if ($res_limit[1] == 'first'){
			
									$sqlLimit = " LIMIT 0,".$res_limit[2];
										
								} else { //last
			
									$limit_init_entry = ($fullSizes[$j] < $res_limit[2]) ? 0 : ($fullSizes[$j]-$res_limit[2]);
									$sqlLimit = " LIMIT ".$limit_init_entry.",".$res_limit[2];
			
								}
			
			
							}
			
			
							//Calculamos extension clausula where para limitaciones
							if ($report_data['results_limit'] == "all"){
			
								$sqlLimitWhere = "";
			
							} else {
			
								$res_limit = explode("\${dp}", $report_data['results_limit']);
			
								$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder;
								$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
			
								//reordenamos el array por si esta ordenado descendentemente
								foreach ($limitedTotalsRs as $key=>$limitedTotal)
								$limitedTotalsRs[$key]['rownum'] = $key+1;
			
			
								$listIds = "";
								foreach ($limitedTotalsRs as $limitedRow){
									if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
									$listIds .= "'".$limitedRow['id']."',";
									else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
									$listIds .= "'".$limitedRow['id']."',";
								}
			
								$listIds = substr($listIds, 0, -1);
			
								$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
			
							}
			
			
							$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder.$sqlLimit;
							$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
			
							
							//*******************
							//Row Group Totals***
							//*******************
							
							if ($hasGrouped) {
										
								$groupingFieldAlias = $group_by_seq[0]["alias"];
								
								//echo print_r($rsDetail, true)."<br>";
								
								$groupColumnName = "";
								
								foreach ($rsDetail as $key=>$myRs) {
									
									$groupingVal = $myRs[$groupingFieldAlias];
									
									if (!empty($groupingVal))
										$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
									else
										$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
										
									$rsGroupingTotals = $focus->getSelectionResults($sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroupTotalWhere);
									
									foreach ($rsGroupingTotals as $key2=>$groupTotal) {
						
										foreach ($groupTotal as $keyName=>$groupTotalVal) {
											$rsDetail[$key][$keyName] = $groupTotalVal;
										}
									
									}
									
								}	
								
							}
							
							
							//*******************
							//Row Group Totals***
							//*******************
							
			
							//*************************FORMATEO DEL SUBGROUP
			
							if ($details[$i]["format"] == "enum") {
			
								$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $details[$i]["optsDb"]) : explode(",", $details[$i]["optsDb"]);
								$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $details[$i]["opts"]) : explode(",", $details[$i]["opts"]);
			
								foreach ($enumOptionsDb as $keyO=>$opt){
			
									if ($opt == $subGroup){
			
										$subGroup = $enumOptions[$keyO];
										break;
			
									}
			
								}
			
							} else if ($details[$i]["format"] == "datetime"){
			
								$subGroup = $timedate->handle_offset($subGroup, $timedate->get_db_date_time_format(), true, null, $userTZ);
			
							} else if ($details[$i]["format"] == "currency") {
			
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$subGroup = currency_format_number($subGroup, $params);
			
							}
			
							$subGroup = str_replace("\'", "'", $subGroup);
			
							//*************************FORMATEO DEL SUBGROUP
			
							for($k=0; $k<count($rsDetail); $k++){
			
								$subGroupsExport[$subGroup][count($subGroupsExport[$subGroup])] = $rsDetail[$k];
			
							}
								
							//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
							$sqlSubQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere;
							$rsSubTotalsExport = $focus->getSelectionResults($sqlSubQueryTotals);
							$subTotalsLimit[] = $rsSubTotalsExport[0];
			
							//REFORMATEAR DATE; DATETIME Y CURRENCY
							$formatedSubTotalsRsExport = $rsSubTotalsExport;
								
							$k = 0;
								
							//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
			
			
							foreach ($formatedSubTotalsRsExport[0] as $key=>$value){
			
								$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
								
								if ($total8 == "date") {
			
									if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
									$formatedSubTotalsRsExport[0][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
			
								} else if ($total8 == "datetime") {
										
									$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
									if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
									$formatedSubTotalsRsExport[0][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
			
								} else if ($total8 == "currency") {
			
									$params = array('currency_id' => $focus->currency_id, 'convert' => true);
									$formatedSubTotalsRsExport[0][$key] = currency_format_number($value, $params);
										
								} else
								$formatedSubTotalsRsExport[0][$key] = $value;
			
			
			
								$k++;
			
							}
								
			
			
							$rsSubTotalsExport = $formatedSubTotalsRsExport;
			
							$subTotalsExport[$subGroup] = $rsSubTotalsExport[0];
								
			
						}
					
					}
		
					//**************************************OBTENEMOS EL RESULTSET SIN PAGINADO PARA LOS EXPORTS
		
					//********************INICIO PASO COMUN 5********************
					//*********************************************************************/
					//******Generar valores para el grafico de totales de registros********/
					//*********************************************************************/
		
					$subTotalsC = Array();
		
					if (($report_charts != "Tabl") && (strlen($report_data['selected_charts']) > 9)) {
							
						for ($j=0; $j<=count($rsGroups)-1; $j++){
		
							$groupFieldC = $details[$i]['field'];
							$subGroupC = $rsGroups[$j]['group'];
		
							if ($subGroupC != "Nameless")
							$sqlDetailWhereC = $sqlWhere." AND ".$groupFieldC."='".$subGroupC."' ";
							else {
								$sqlDetailWhereC = $sqlWhere." AND ".$groupFieldC." IS NULL ";
								$subGroupC = $mod_strings['LBL_REPORT_NAMELESS'];
							}
		
							//*************************FORMATEO DEL SUBGROUP
		
							if ($details[$i]["format"] == "enum") {
		
								$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $details[$i]["optsDb"]) : explode(",", $details[$i]["optsDb"]);
								$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $details[$i]["opts"]) : explode(",", $details[$i]["opts"]);
		
								foreach ($enumOptionsDb as $keyO=>$opt){
		
									if ($opt == $subGroupC){
		
										$subGroupC = $enumOptions[$keyO];
										break;
		
									}
		
								}
		
							} else if ($details[$i]["format"] == "datetime"){
		
								$subGroupC = $timedate->handle_offset($subGroupC, $timedate->get_db_date_time_format(), true, null, $userTZ);
									
							} else if ($details[$i]["format"] == "currency") {
		
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$subGroupC = currency_format_number($subGroupC, $params);
									
							}
		
							$subGroupC = str_replace("\'", "'", $subGroupC);
		
							//*************************FORMATEO DEL SUBGROUP
		
		
							//Calculamos extension clausula where para limitaciones
							if ($report_data['results_limit'] == "all"){
									
								$sqlLimitWhere = "";
									
							} else {
		
								$res_limit = explode("\${dp}", $report_data['results_limit']);
		
								$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhereC.$sqlGroup.$sqlOrder;
								$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
								//reordenamos el array por si esta ordenado descendentemente
								foreach ($limitedTotalsRs as $key=>$limitedTotal)
									$limitedTotalsRs[$key]['rownum'] = $key+1;
		
								$listIds = "";
								foreach ($limitedTotalsRs as $limitedRow){
									if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
										$listIds .= "'".$limitedRow['id']."',";
									else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
										$listIds .= "'".$limitedRow['id']."',";
								}
									
								$listIds = substr($listIds, 0, -1);
		
								$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
							}
		
		
		
							$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroup.$sqlOrder;
							$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
		
		
							//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
							$sqlSubQueryTotalsC = $sqlTotalsC.$sqlFrom.$sqlJoin.$sqlDetailWhereC.$sqlLimitWhere;
							$rsSubTotalsC = $focus->getSelectionResults($sqlSubQueryTotalsC);
		
							$subTotalsC[$subGroupC] = $rsSubTotalsC[0];
		
						}
		
		
						$chartValues = Array();
						$subGroupsChart = Array();
						$chartsHttpQueryUrls = (!isset($_REQUEST['chartsHttpQueryUrls'])) ? array() : explode("\${pipe}", $_REQUEST['chartsHttpQueryUrls']);
		
						foreach($subTotalsC as $key=>$values){
		
							//Recortar string de subgrupo si es demasiado largo (10chars) - S�lo para php charts
							//$subGroupsChart[count($subGroupsChart)] = (strlen($key) > 10) ? substr($key, 0, 10) : $key ;
							$subGroupsChart[count($subGroupsChart)] = $key ;
		
							foreach($values as $keyV=>$value){
		
								$chartValues[$keyV][count($chartValues[$keyV])] = $value;
		
							}
		
						}
		
						//Por cada subtotal que haya (y del que se quiera hacer chart), a�adir urlchart a un aray de Url's
						
						$c=0;
		
						foreach($chartValues as $key=>$value){
		
							if (($chartInfo[$c][3] == 'yes') && ($chartInfo[$c][4] == 'pie')){
									
								$urlChart[count($urlChart)] = generateSwfPieChart(count($urlChart), $chartInfo[$c][1], $subGroupsChart, $value, count($subGroupsChart), (empty($chartsHttpQueryUrls)) ? null : $chartsHttpQueryUrls[count($urlChart)]);
								$chartInfo[$c]['type'] = 'PieChart';
								$chartInfo[$c]['subgroups'] = count($subGroupsChart);
								$chartSubGroupsValues[] = count($subGroupsChart);
								
							}
		
							if (($chartInfo[$c][3] == 'yes') && ($chartInfo[$c][4] == 'bar')){
									
								$urlChart[count($urlChart)] = generateSwfBarChart(count($urlChart), $chartInfo[$c][1], $subGroupsChart, $value, count($subGroupsChart), (empty($chartsHttpQueryUrls)) ? null : $chartsHttpQueryUrls[count($urlChart)]);
								$chartInfo[$c]['type'] = 'BarChart';
								$chartInfo[$c]['subgroups'] = count($subGroupsChart);
								$chartSubGroupsValues[] = count($subGroupsChart);
									
							}
		
							$c++;
						}
						
						
					}
		
					/**********************************************************************/
					//******Generar valores para el grafico de totales de registros********/
					//*********************************************************************/
		
					if (($report_data['results_limit'] != "all") || ($allowExportGeneratedFile)) {
						
						//Calculamos los totales a mano para las agrupaciones limitadas
						$LimitedTotals = Array();
						
						if (empty($subTotalsLimit))
							$subTotalsLimit = array();
			
						foreach ($totals as $key=>$total){
			
							$LimitedValue = "";
			
							if (empty($total[5]))
								$total[5] = "COUNT";
			
							switch ($total[5]) {
			
								case "COUNT":
								case "SUM":
									foreach ($subTotalsLimit as $subVal)
										$LimitedValue += $subVal[$total[1]];
									break;
			
								case "MIN":
									foreach ($subTotalsLimit as $subVal) {
										if (empty($LimitedValue))
											$LimitedValue = $subVal[$total[1]];
										else if ($subVal[$total[1]] <= $LimitedValue)
											$LimitedValue = $subVal[$total[1]];
									}
									break;
			
								case "MAX":
									foreach ($subTotalsLimit as $subVal) {
										if (empty($LimitedValue))
											$LimitedValue = $subVal[$total[1]];
										else if ($subVal[$total[1]] >= $LimitedValue)
											$LimitedValue = $subVal[$total[1]];
									}
									break;
			
								case "AVG":
									$c=0;
									foreach ($subTotalsLimit as $subVal) {
										$LimitedValue += $subVal[$total[1]];
										$c++;
									}
									$LimitedValue /= $c;
									break;
										
							}
			
							$LimitedTotals[0][$total[1]] = $LimitedValue;
								
						}
		
					}
					//********************FIN PASO COMUN 5********************
		
		
					break;
		
				case "Month Detail":
		
					//obtenemos los posibles valores de las agrupaciones a generar
					$sqlGroupsQuery = "SELECT DISTINCT MONTH(".$details[$i]['field'].") AS 'group' ".$sqlFrom.$sqlJoin.$sqlWhere;
					$rsGroups = $focus->getSelectionResults($sqlGroupsQuery);
		
		
					//Reordenar rsGroups para ordenar subGrupos
					sort($rsGroups);
		
		
					//ALGORITMO PARA EL PAGINADO DE LOS DETAIL GROUPING REPORTS
		
					$sizes;
					$fullSizes;
		
					for ($j=0; $j<count($rsGroups); $j++){
							
						$groupField = $details[$i]['field'];
						$subGroup = $rsGroups[$j]['group'];
							
						$sqlDetailGroupWhere = $sqlWhere." AND MONTH(".$groupField.")='".$subGroup."' ";
						$sqlDetailGroupQuery = "SELECT COUNT(".$report_table.".id) AS total ".$sqlFrom.$sqlJoin.$sqlDetailGroupWhere.$sqlGroup;
						$rsCount = $focus->getSelectionResults($sqlDetailGroupQuery);
							
						if ($report_data['results_limit'] == "all") {
							$sizes[$j] = $rsCount[0]['total'];
						} else {
							$res_limit = explode("\${dp}", $report_data['results_limit']);
							$sizes[$j] = ($rsCount[0]['total'] < $res_limit[2]) ? $rsCount[0]['total'] : $res_limit[2];
						}
		
						$fullSizes[$j] = $rsCount[0]['total'];
							
					}
		
					$init_group = 0;
					$end_group = 0;
					$index=0;
		
					for ($k=0; $k<=$page_number; $k++){
							
						$current_entries = 0;
							
						$current_entries += $sizes[$index];
							
							
						while (($current_entries < $entries_per_page) && ($index+1 < count($sizes))){
							$index++;
							$current_entries += $sizes[$index];
		
						}
		
						if ($k == ($page_number-1)){
							$init_group = $index+1;
		
						}
							
						if ($k == $page_number){
							$end_group = $index;
						}
							
						$index++;
						$first_entrie += $current_entries;
					}
		
					$first_entrie -= $current_entries;
		
		
					$groupField = Array();
					$subGroup = Array();
					$subTotals = Array();
		
		
					//********************INICIO PASO COMUN 6********************
					for ($j=$init_group; $j<=$end_group; $j++){
		
						$groupField = $details[$i]['field'];
						$subGroup = $rsGroups[$j]['group'];
						$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.")='".$subGroup."' ";
		
		
						//OBTENEMOS LA CLAUSULA "LIMIT"
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimit = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							if ($res_limit[1] == 'first'){
		
								$sqlLimit = " LIMIT 0,".$res_limit[2];
									
							} else { //last
		
								$limit_init_entry = ($fullSizes[$j] < $res_limit[2]) ? 0 : ($fullSizes[$j]-$res_limit[2]);
								$sqlLimit = " LIMIT ".$limit_init_entry.",".$res_limit[2];
									
							}
		
						}
		
		
						//Calculamos extension clausula where para limitaciones
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimitWhere = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder;
							$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
							//reordenamos el array por si esta ordenado descendentemente
							foreach ($limitedTotalsRs as $key=>$limitedTotal)
								$limitedTotalsRs[$key]['rownum'] = $key+1;
		
							$listIds = "";
							foreach ($limitedTotalsRs as $limitedRow){
								if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
									$listIds .= "'".$limitedRow['id']."',";
								else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
									$listIds .= "'".$limitedRow['id']."',";
							}
		
							$listIds = substr($listIds, 0, -1);
		
							$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
						}
		
		
		
						$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroup.$sqlOrder;
						$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
						
						
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						if ($hasGrouped) {
									
							$groupingFieldAlias = $group_by_seq[0]["alias"];
							
							//echo print_r($rsDetail, true)."<br>";
							
							$groupColumnName = "";
							
							foreach ($rsDetail as $key=>$myRs) {
								
								$groupingVal = $myRs[$groupingFieldAlias];
								
								if (!empty($groupingVal))
									$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
								else
									$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
									
								$rsGroupingTotals = $focus->getSelectionResults($sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroupTotalWhere);
								
								foreach ($rsGroupingTotals as $key2=>$groupTotal) {
					
									foreach ($groupTotal as $keyName=>$groupTotalVal) {
										$rsDetail[$key][$keyName] = $groupTotalVal;
									}
								
								}
								
							}	
							
						}
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						
						
						//Cambiar n� por nombre Mes
						$subGroup = date("F", @mktime(0, 0, 0, $subGroup, 10));
							
						for($k=0; $k<count($rsDetail); $k++){
		
							$subGroups[$subGroup][count($subGroups[$subGroup])] = $rsDetail[$k];
		
						}
							
						//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
						$sqlSubQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere;
						$rsSubTotals = $focus->getSelectionResults($sqlSubQueryTotals);
		
						
						
						//REFORMATEAR DATE; DATETIME Y CURRENCY
						$formatedSubTotalsRs = $rsSubTotals;
		
		
						$k = 0;
							
						//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
							
						foreach ($formatedSubTotalsRs[0] as $key=>$value){
		
							$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
		
							if ($total8 == "date") {
		
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
							} else if ($total8 == "datetime") {
									
								$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
							} else if ($total8 == "currency") {
		
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$formatedSubTotalsRs[0][$key] = currency_format_number($value, $params);
									
							} else
							$formatedSubTotalsRs[0][$key] = $value;
		
		
							$k++;
		
						}
							
		
						$rsSubTotals = $formatedSubTotalsRs;
							
						$subTotals[$subGroup] = $rsSubTotals[0];
							
					}
					//********************FIN PASO COMUN 6********************
		
					//**************************************OBTENEMOS EL RESULTSET SIN PAGINADO PARA LOS EXPORTS
		
					//Array asociativo por valor de cada agrupaci�n que contiene las filas de cada subgrupo
					$subGroupsExport = Array();
					//Array asociativo por valor de cada agrupaci�n que contiene los subtotales de cada subgrupo
					$subTotalsExport = Array();
		
					$init_group = 0;
					$end_group = count($rsGroups)-1;
		
		
					for ($j=$init_group; $j<=$end_group; $j++){
		
						$groupField = $details[$i]['field'];
						$subGroup = $rsGroups[$j]['group'];
							
						$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.")='".$subGroup."' ";
		
		
		
						//OBTENEMOS LA CLAUSULA "LIMIT"
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimit = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							if ($res_limit[1] == 'first'){
		
								$sqlLimit = " LIMIT 0,".$res_limit[2];
									
							} else { //last
		
								$limit_init_entry = ($fullSizes[$j] < $res_limit[2]) ? 0 : ($fullSizes[$j]-$res_limit[2]);
								$sqlLimit = " LIMIT ".$limit_init_entry.",".$res_limit[2];
									
							}
		
						}
		
		
						//Calculamos extension clausula where para limitaciones
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimitWhere = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder;
							$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
							//reordenamos el array por si esta ordenado descendentemente
							foreach ($limitedTotalsRs as $key=>$limitedTotal)
							$limitedTotalsRs[$key]['rownum'] = $key+1;
		
							$listIds = "";
							foreach ($limitedTotalsRs as $limitedRow){
								if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
								$listIds .= "'".$limitedRow['id']."',";
								else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
								$listIds .= "'".$limitedRow['id']."',";
							}
		
							$listIds = substr($listIds, 0, -1);
		
							$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
						}
		
		
		
						$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroup.$sqlOrder;
						$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
		
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						if ($hasGrouped) {
									
							$groupingFieldAlias = $group_by_seq[0]["alias"];
							
							//echo print_r($rsDetail, true)."<br>";
							
							$groupColumnName = "";
							
							foreach ($rsDetail as $key=>$myRs) {
								
								$groupingVal = $myRs[$groupingFieldAlias];
								
								if (!empty($groupingVal))
									$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
								else
									$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
									
								$rsGroupingTotals = $focus->getSelectionResults($sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroupTotalWhere);
								
								foreach ($rsGroupingTotals as $key2=>$groupTotal) {
					
									foreach ($groupTotal as $keyName=>$groupTotalVal) {
										$rsDetail[$key][$keyName] = $groupTotalVal;
									}
								
								}
								
							}	
							
						}
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						
						//Cambiar n� por nombre Mes
						$subGroup = date("F", @mktime(0, 0, 0, $subGroup, 10));
							
						for($k=0; $k<count($rsDetail); $k++){
		
							$subGroupsExport[$subGroup][count($subGroupsExport[$subGroup])] = $rsDetail[$k];
		
						}
							
						//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
						$sqlSubQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere;
						$rsSubTotals = $focus->getSelectionResults($sqlSubQueryTotals);
						$subTotalsLimit[] = $rsSubTotals[0];
		
		
						//REFORMATEAR DATE; DATETIME Y CURRENCY
						$formatedSubTotalsRs = $rsSubTotals;
							
						$k = 0;
							
						//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
							
						foreach ($formatedSubTotalsRs[0] as $key=>$value){
		
							$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
		
							if ($total8 == "date") {
		
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
							} else if ($total8 == "datetime") {
									
								$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
							} else if ($total8 == "currency") {
		
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$formatedSubTotalsRs[0][$key] = currency_format_number($value, $params);
									
							} else
							$formatedSubTotalsRs[0][$key] = $value;
		
		
		
							$k++;
		
						}
							
		
						$rsSubTotals = $formatedSubTotalsRs;
							
						$subTotalsExport[$subGroup] = $rsSubTotals[0];
							
					}
		
					//**************************************OBTENEMOS EL RESULTSET SIN PAGINADO PARA LOS EXPORTS
		
					//********************INICIO PASO COMUN 7********************
					//*********************************************************************/
					//******Generar valores para el grafico de totales de registros********/
					//*********************************************************************/
		
					$subTotalsC = Array();
		
					if ($report_charts != "Tabl") {
		
						for ($j=0; $j<=count($rsGroups)-1; $j++){
		
							$groupFieldC = $details[$i]['field'];
							$subGroupC = $rsGroups[$j]['group'];
		
							$sqlDetailWhereC = $sqlWhere." AND MONTH(".$groupFieldC.")='".$subGroupC."' ";
		
							//Cambiar n� por nombre Mes
							$subGroupC = date("F", @mktime(0, 0, 0, $subGroupC, 10));
		
		
							//Calculamos extension clausula where para limitaciones
							if ($report_data['results_limit'] == "all"){
									
								$sqlLimitWhere = "";
									
							} else {
		
								$res_limit = explode("\${dp}", $report_data['results_limit']);
		
								$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhereC.$sqlGroup.$sqlOrder;
								$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
								//reordenamos el array por si esta ordenado descendentemente
								foreach ($limitedTotalsRs as $key=>$limitedTotal)
									$limitedTotalsRs[$key]['rownum'] = $key+1;
		
								$listIds = "";
								foreach ($limitedTotalsRs as $limitedRow){
									if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
										$listIds .= "'".$limitedRow['id']."',";
									else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
										$listIds .= "'".$limitedRow['id']."',";
								}
									
								$listIds = substr($listIds, 0, -1);
		
								$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
							}
		
							//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
							$sqlSubQueryTotalsC = $sqlTotalsC.$sqlFrom.$sqlJoin.$sqlDetailWhereC.$sqlLimitWhere;
							$rsSubTotalsC = $focus->getSelectionResults($sqlSubQueryTotalsC);
		
							$subTotalsC[$subGroupC] = $rsSubTotalsC[0];
		
						}
		
		
		
						$chartValues = Array();
						$subGroupsChart = Array();
						$chartsHttpQueryUrls = (!isset($_REQUEST['chartsHttpQueryUrls'])) ? array() : explode("\${pipe}", $_REQUEST['chartsHttpQueryUrls']);
							
		
						foreach($subTotalsC as $key=>$values){
		
							$subGroupsChart[count($subGroupsChart)] = $key ;
		
							foreach($values as $keyV=>$value){
		
								$chartValues[$keyV][count($chartValues[$keyV])] = $value;
		
							}
		
						}
		
						//Por cada subtotal que haya (y del que se quiera hacer chart), a�adir urlchart a un aray de Url's
						$c=0;
		
						
						foreach($chartValues as $key=>$value){
		
							if (($chartInfo[$c][3] == 'yes') && ($chartInfo[$c][4] == 'pie')){
									
								$urlChart[count($urlChart)] = generateSwfPieChart(count($urlChart), $chartInfo[$c][1], $subGroupsChart, $value, count($subGroupsChart), (empty($chartsHttpQueryUrls)) ? null : $chartsHttpQueryUrls[count($urlChart)]);
								$chartInfo[$c]['type'] = 'PieChart';
								$chartInfo[$c]['subgroups'] = count($subGroupsChart);
								$chartSubGroupsValues[] = count($subGroupsChart);
								
							}
		
							if (($chartInfo[$c][3] == 'yes') && ($chartInfo[$c][4] == 'bar')){
									
								$urlChart[count($urlChart)] = generateSwfBarChart(count($urlChart), $chartInfo[$c][1], $subGroupsChart, $value, count($subGroupsChart), (empty($chartsHttpQueryUrls)) ? null : $chartsHttpQueryUrls[count($urlChart)]);
								$chartInfo[$c]['type'] = 'BarChart';
								$chartInfo[$c]['subgroups'] = count($subGroupsChart);
								$chartSubGroupsValues[] = count($subGroupsChart);
									
							}
		
							$c++;
						}
						
		
					}
		
					/**********************************************************************/
					//******Generar valores para el grafico de totales de registros********/
					//*********************************************************************/
		
		
					//Calculamos los totales a mano para las agrupaciones limitadas
					$LimitedTotals = Array();
		
					if (empty($subTotalsLimit))
						$subTotalsLimit = array();
					
					foreach ($totals as $key=>$total){
		
						$LimitedValue = "";
		
						switch ($total[5]) {
		
							case "COUNT":
							case "SUM":
								foreach ($subTotalsLimit as $subVal)
									$LimitedValue += $subVal[$total[1]];
								break;
		
							case "MIN":
								foreach ($subTotalsLimit as $subVal) {
									if (empty($LimitedValue))
										$LimitedValue = $subVal[$total[1]];
									else if ($subVal[$total[1]] <= $LimitedValue)
										$LimitedValue = $subVal[$total[1]];
								}
								break;
		
							case "MAX":
								foreach ($subTotalsLimit as $subVal) {
									if (empty($LimitedValue))
										$LimitedValue = $subVal[$total[1]];
									else if ($subVal[$total[1]] >= $LimitedValue)
										$LimitedValue = $subVal[$total[1]];
								}
								break;
		
							case "AVG":
								$c=0;
								foreach ($subTotalsLimit as $subVal) {
									$LimitedValue += $subVal[$total[1]];
									$c++;
								}
								$LimitedValue /= $c;
								break;
									
						}
		
						$LimitedTotals[0][$total[1]] = $LimitedValue;
		
					}
		
		
					//********************FIN PASO COMUN 7********************
		
					break;
		
					//********************INICIO PASO COMUN 8********************
				case "Natural Quarter Detail": //En este caso modificar el array meses y dejarlo tal cual est�
				case "Fiscal Quarter Detail":
		
					//Creo un array con los meses y lo reordeno en funcion del mes del quarter fiscal inicial
					$meses = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
		
					if ($details[$i]['type'] == "Fiscal Quarter Detail"){
		
						$auxMeses;
		
						$j=0;
						for ($k=$quarter_month-1; $k<count($meses);$k++){
							$auxMeses[$j] = $meses[$k];
							$j++;
						}
		
						for ($k=0; $k<$quarter_month-1;$k++){
							$auxMeses[$j] = $meses[$k];
							$j++;
						}
		
						$meses = $auxMeses;
		
					}
		
					//obtenemos los posibles valores de las agrupaciones a generar (Meses)
					$sqlGroupsQuery = "SELECT DISTINCT MONTH(".$details[$i]['field'].") AS 'group' ".$sqlFrom.$sqlJoin.$sqlWhere;
					$rsGroups = $focus->getSelectionResults($sqlGroupsQuery);
		
					//Formatear $rsGroups para que solo contendo un valor por posible quarter
					$quarterGroups;
					$first = false;
					$second = false;
					$third = false;
					$forth = false;
		
					$quarterGroups[0] = "";
					$quarterGroups[1] = "";
					$quarterGroups[2] = "";
					$quarterGroups[3] = "";
		
					for ($j=0; $j<count($rsGroups); $j++){
							
						$subGroup = $rsGroups[$j]['group'];
							
						if ((($subGroup == $meses[0]) || ($subGroup == $meses[1]) || ($subGroup == $meses[2])) && ($first == false)){
							//First Quarter
							$quarterGroups[0] = $rsGroups[$j]['group'];
							$first = true;
		
						}else if ((($subGroup == $meses[3]) || ($subGroup == $meses[4]) || ($subGroup == $meses[5])) && ($second == false)){
							//Second Quarter
							$quarterGroups[1] = $rsGroups[$j]['group'];
							$second = true;
		
						}else if ((($subGroup == $meses[6]) || ($subGroup == $meses[7]) || ($subGroup == $meses[8])) && ($third == false)){
							//Third Quarter
							$quarterGroups[2] = $rsGroups[$j]['group'];
							$third = true;
		
						}else if ((($subGroup == $meses[9]) || ($subGroup == $meses[10]) || ($subGroup == $meses[11])) && ($forth == false)){
							//Forth Quarter
							$quarterGroups[3] = $rsGroups[$j]['group'];
							$forth = true;
		
						}
							
					}
		
		
					//Reorganizar array de quarterGroups
					$quarterGroupsfixed;
					for ($k=0; $k<count($quarterGroups); $k++){
						if ($quarterGroups[$k] != ""){
							$quarterGroupsfixed[count($quarterGroupsfixed)] = $quarterGroups[$k];
						}
					}
		
					$quarterGroups = $quarterGroupsfixed;
		
					//********************FIN PASO COMUN 8********************
		
					//ALGORITMO PARA EL PAGINADO DE LOS DETAIL GROUPING REPORTS
		
					$fullSizes[0] = "";
					$fullSizes[1] = "";
					$fullSizes[2] = "";
					$fullSizes[3] = "";
		
					for ($j=0; $j<count($rsGroups); $j++){
							
						$groupField = $details[$i]['field'];
						$subGroup = $rsGroups[$j]['group'];
							
						$sqlDetailGroupWhere = $sqlWhere." AND MONTH(".$groupField.")='".$subGroup."' ";
						$sqlDetailGroupQuery = "SELECT COUNT(".$report_table.".id) AS total ".$sqlFrom.$sqlJoin.$sqlDetailGroupWhere.$sqlGroup;
						$rsCount = $focus->getSelectionResults($sqlDetailGroupQuery);
							
						if (($subGroup == $meses[0]) || ($subGroup == $meses[1]) || ($subGroup == $meses[2])){
							//First Quarter
							$fullSizes[0] += $rsCount[0]['total'];
		
						}else if (($subGroup == $meses[3]) || ($subGroup == $meses[4]) || ($subGroup == $meses[5])){
							//Second Quarter
							$fullSizes[1] += $rsCount[0]['total'];
		
						}else if (($subGroup == $meses[6]) || ($subGroup == $meses[7]) || ($subGroup == $meses[8])){
							//Third Quarter
							$fullSizes[2] += $rsCount[0]['total'];
		
						}else if (($subGroup == $meses[9]) || ($subGroup == $meses[10]) || ($subGroup == $meses[11])){
							//Forth Quarter
							$fullSizes[3] += $rsCount[0]['total'];
						}
		
					}
		
					foreach ($fullSizes as $j=>$fullSize){
						if ($report_data['results_limit'] == "all") {
							$sizes[$j] += $fullSize;
						} else {
							$res_limit = explode("\${dp}", $report_data['results_limit']);
							$sizes[$j] += ($fullSize < $res_limit[2]) ? $fullSize : $res_limit[2];
						}
					}
		
					//Reorganizar array de quarterGroups
					$sizesfixed;
					$m=0;
					for ($k=0; $k<count($sizes); $k++){
						if ($sizes[$k] != ""){
							$sizesfixed[$m] = $sizes[$k];
							$m++;
						}
					}
		
					$sizes = $sizesfixed;
		
					$fullSizesfixed;
					$m=0;
					for ($k=0; $k<count($fullSizes); $k++){
						if ($fullSizes[$k] != ""){
							$fullSizesfixed[$m] = $fullSizes[$k];
							$m++;
						}
					}
		
					$fullSizes = $fullSizesfixed;
		
					$init_group = 0;
					$end_group = 0;
					$index=0;
		
					for ($k=0; $k<=$page_number; $k++){
							
						$current_entries = 0;
							
						$current_entries += $sizes[$index];
		
						while (($current_entries < $entries_per_page) && ($index+1 < count($sizes))){
							$index++;
							$current_entries += $sizes[$index];
						}
		
						if ($k == ($page_number-1)){
							$init_group = $index+1;
						}
							
						if ($k == $page_number){
							$end_group = $index;
						}
							
						$index++;
						$first_entrie += $current_entries;
					}
		
					$first_entrie -= $current_entries;
		
		
					$groupField = Array();
					$subGroup = Array();
					$subTotals = Array();
		
		
					//********************INICIO PASO COMUN 9********************
					for ($j=$init_group; $j<=$end_group; $j++){
		
						$groupField = $details[$i]['field'];
							
							
						$subGroup = $quarterGroups[$j];
							
						if (($subGroup == $meses[0]) || ($subGroup == $meses[1]) || ($subGroup == $meses[2])){
							//First Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[0]."', '".$meses[1]."', '".$meses[2]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "1st Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "1st Natural Quarter";
		
						}else if (($subGroup == $meses[3]) || ($subGroup == $meses[4]) || ($subGroup == $meses[5])){
							//Second Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[3]."', '".$meses[4]."', '".$meses[5]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "2nd Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "2nd Natural Quarter";
		
						}else if (($subGroup == $meses[6]) || ($subGroup == $meses[7]) || ($subGroup == $meses[8])){
							//Third Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[6]."', '".$meses[7]."', '".$meses[8]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "3rd Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "3rd Natural Quarter";
		
						}else if (($subGroup == $meses[9]) || ($subGroup == $meses[10]) || ($subGroup == $meses[11])){
							//Forth Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[9]."', '".$meses[10]."', '".$meses[11]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "4th Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "4th Natural Quarter";
		
						}
							
		
		
						//OBTENEMOS LA CLAUSULA "LIMIT"
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimit = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							if ($res_limit[1] == 'first'){
		
								$sqlLimit = " LIMIT 0,".$res_limit[2];
									
							} else { //last
		
								$limit_init_entry = ($fullSizes[$j] < $res_limit[2]) ? 0 : ($fullSizes[$j]-$res_limit[2]);
								$sqlLimit = " LIMIT ".$limit_init_entry.",".$res_limit[2];
									
							}
		
						}
		
		
		
						//Calculamos extension clausula where para limitaciones
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimitWhere = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder;
							$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
							//reordenamos el array por si esta ordenado descendentemente
							foreach ($limitedTotalsRs as $key=>$limitedTotal)
								$limitedTotalsRs[$key]['rownum'] = $key+1;
		
							$listIds = "";
							foreach ($limitedTotalsRs as $limitedRow){
								if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
									$listIds .= "'".$limitedRow['id']."',";
								else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
									$listIds .= "'".$limitedRow['id']."',";
							}
		
							$listIds = substr($listIds, 0, -1);
		
							$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
						}
		
		
							
						$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder.$sqlLimit;
						$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
		
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						if ($hasGrouped) {
									
							$groupingFieldAlias = $group_by_seq[0]["alias"];
							
							//echo print_r($rsDetail, true)."<br>";
							
							$groupColumnName = "";
							
							foreach ($rsDetail as $key=>$myRs) {
								
								$groupingVal = $myRs[$groupingFieldAlias];
								
								if (!empty($groupingVal))
									$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
								else
									$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
									
								$rsGroupingTotals = $focus->getSelectionResults($sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroupTotalWhere);
								
								foreach ($rsGroupingTotals as $key2=>$groupTotal) {
					
									foreach ($groupTotal as $keyName=>$groupTotalVal) {
										$rsDetail[$key][$keyName] = $groupTotalVal;
									}
								
								}
								
							}	
							
						}
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						
						
						for($k=0; $k<count($rsDetail); $k++){
		
							$subGroups[$subGroup][count($subGroups[$subGroup])] = $rsDetail[$k];
		
						}
							
						//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
						$sqlSubQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere;
						$rsSubTotals = $focus->getSelectionResults($sqlSubQueryTotals);
		
						//REFORMATEAR DATE; DATETIME Y CURRENCY
						$formatedSubTotalsRs = $rsSubTotals;
		
							
						$k = 0;
							
						//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
							
						foreach ($formatedSubTotalsRs[0] as $key=>$value){
		
							$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
							
							if ($total8 == "date") {
		
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
							} else if ($total8 == "datetime") {
									
								$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
							} else if ($total8 == "currency") {
		
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$formatedSubTotalsRs[0][$key] = currency_format_number($value, $params);
									
							} else
							$formatedSubTotalsRs[0][$key] = $value;
		
		
		
							$k++;
		
						}
		
						$rsSubTotals = $formatedSubTotalsRs;
		
						$subTotals[$subGroup] = $rsSubTotals[0];
							
					}
					//********************FIN PASO COMUN 9********************
		
		
					//**************************************OBTENEMOS EL RESULTSET SIN PAGINADO PARA LOS EXPORTS
		
					//Array asociativo por valor de cada agrupaci�n que contiene las filas de cada subgrupo
					$subGroupsExport = Array();
					//Array asociativo por valor de cada agrupaci�n que contiene los subtotales de cada subgrupo
					$subTotalsExport = Array();
		
					$init_group = 0;
					$end_group = count($rsGroups)-1;
		
		
					for ($j=$init_group; $j<=$end_group; $j++){
		
						$groupField = $details[$i]['field'];
							
						$subGroup = $quarterGroups[$j];
							
						if (($subGroup == $meses[0]) || ($subGroup == $meses[1]) || ($subGroup == $meses[2])){
							//First Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[0]."', '".$meses[1]."', '".$meses[2]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "1st Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "1st Natural Quarter";
		
						}else if (($subGroup == $meses[3]) || ($subGroup == $meses[4]) || ($subGroup == $meses[5])){
							//Second Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[3]."', '".$meses[4]."', '".$meses[5]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "2nd Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "2nd Natural Quarter";
		
						}else if (($subGroup == $meses[6]) || ($subGroup == $meses[7]) || ($subGroup == $meses[8])){
							//Third Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[6]."', '".$meses[7]."', '".$meses[8]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "3rd Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "3rd Natural Quarter";
		
						}else if (($subGroup == $meses[9]) || ($subGroup == $meses[10]) || ($subGroup == $meses[11])){
							//Forth Quarter
							$sqlDetailWhere = $sqlWhere." AND MONTH(".$groupField.") IN ('".$meses[9]."', '".$meses[10]."', '".$meses[11]."') ";
		
							if ($details[$i]['type'] == "Fiscal Quarter Detail")
							$subGroup = "4th Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
							else
							$subGroup = "4th Natural Quarter";
		
						}
		
		
		
		
						//OBTENEMOS LA CLAUSULA "LIMIT"
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimit = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							if ($res_limit[1] == 'first'){
		
								$sqlLimit = " LIMIT 0,".$res_limit[2];
									
							} else { //last
		
								$limit_init_entry = ($fullSizes[$j] < $res_limit[2]) ? 0 : ($fullSizes[$j]-$res_limit[2]);
								$sqlLimit = " LIMIT ".$limit_init_entry.",".$res_limit[2];
									
							}
		
						}
		
		
						//Calculamos extension clausula where para limitaciones
						if ($report_data['results_limit'] == "all"){
		
							$sqlLimitWhere = "";
		
						} else {
		
							$res_limit = explode("\${dp}", $report_data['results_limit']);
		
							$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhere.$sqlGroup.$sqlOrder;
							$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
							//reordenamos el array por si esta ordenado descendentemente
							foreach ($limitedTotalsRs as $key=>$limitedTotal)
							$limitedTotalsRs[$key]['rownum'] = $key+1;
		
							$listIds = "";
							foreach ($limitedTotalsRs as $limitedRow){
								if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
								$listIds .= "'".$limitedRow['id']."',";
								else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
								$listIds .= "'".$limitedRow['id']."',";
							}
		
							$listIds = substr($listIds, 0, -1);
		
							$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
						}
		
		
						$sqlDetailQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroup.$sqlOrder;
						$rsDetail = $focus->getSelectionResults($sqlDetailQuery);
							
						
						//*******************
						//Row Group Totals***
						//*******************
						
						if ($hasGrouped) {
									
							$groupingFieldAlias = $group_by_seq[0]["alias"];
							
							//echo print_r($rsDetail, true)."<br>";
							
							$groupColumnName = "";
							
							foreach ($rsDetail as $key=>$myRs) {
								
								$groupingVal = $myRs[$groupingFieldAlias];
								
								
								if (!empty($groupingVal))
									$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
								else
									$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
							
								$rsGroupingTotals = $focus->getSelectionResults($sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere.$sqlGroupTotalWhere);
								
								foreach ($rsGroupingTotals as $key2=>$groupTotal) {
					
									foreach ($groupTotal as $keyName=>$groupTotalVal) {
										$rsDetail[$key][$keyName] = $groupTotalVal;
									}
								
								}
								
							}	
							
						}
						
						
						//*******************
						//Row Group Totals***
						//*******************
						
						
						
						for($k=0; $k<count($rsDetail); $k++){
		
							if (!empty($subGroup))
							$subGroupsExport[$subGroup][count($subGroupsExport[$subGroup])] = $rsDetail[$k];
		
						}
							
						//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
						$sqlSubQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlDetailWhere.$sqlLimitWhere;
						$rsSubTotals = $focus->getSelectionResults($sqlSubQueryTotals);
						$subTotalsLimit[] = $rsSubTotals[0];
		
						//REFORMATEAR DATE; DATETIME Y CURRENCY
						$formatedSubTotalsRs = $rsSubTotals;
		
							
						$k = 0;
							
						//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
							
						foreach ($formatedSubTotalsRs[0] as $key=>$value){
		
							$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
		
							if ($total8 == "date") {
		
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
							} else if ($total8 == "datetime") {
									
								$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedSubTotalsRs[0][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
							} else if ($total8 == "currency") {
		
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$formatedSubTotalsRs[0][$key] = currency_format_number($value, $params);
									
							} else
							$formatedSubTotalsRs[0][$key] = $value;
		
							$k++;
		
						}
							
		
						$rsSubTotals = $formatedSubTotalsRs;
		
						$subTotalsExport[$subGroup] = $rsSubTotals[0];
							
					}
		
		
					//**************************************OBTENEMOS EL RESULTSET SIN PAGINADO PARA LOS EXPORTS
		
		
					//********************INICIO PASO COMUN 10********************
					//*********************************************************************/
					//******Generar valores para el grafico de totales de registros********/
					//*********************************************************************/
		
					$subTotalsC = Array();
					
					if ($report_data['report_charts'] != "Tabl") {
		
						for ($j=0; $j<=count($quarterGroups)-1; $j++){
		
		
							$groupFieldC = $details[$i]['field'];
		
		
							$subGroupC = $quarterGroups[$j];
		
							if (($subGroupC == $meses[0]) || ($subGroupC == $meses[1]) || ($subGroupC == $meses[2])){
								//First Quarter
								$sqlDetailWhereC = $sqlWhere." AND MONTH(".$groupFieldC.") IN ('".$meses[0]."', '".$meses[1]."', '".$meses[2]."') ";
		
								if ($details[$i]['type'] == "Fiscal Quarter Detail")
								$subGroupC = "1st Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
								else
								$subGroupC = "1st Natural Quarter";
		
							}else if (($subGroupC == $meses[3]) || ($subGroupC == $meses[4]) || ($subGroupC == $meses[5])){
								//Second Quarter
								$sqlDetailWhereC = $sqlWhere." AND MONTH(".$groupFieldC.") IN ('".$meses[3]."', '".$meses[4]."', '".$meses[5]."') ";
		
								if ($details[$i]['type'] == "Fiscal Quarter Detail")
								$subGroupC = "2nd Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
								else
								$subGroupC = "2nd Natural Quarter";
		
							}else if (($subGroupC == $meses[6]) || ($subGroupC == $meses[7]) || ($subGroupC == $meses[8])){
								//Third Quarter
								$sqlDetailWhereC = $sqlWhere." AND MONTH(".$groupFieldC.") IN ('".$meses[6]."', '".$meses[7]."', '".$meses[8]."') ";
		
								if ($details[$i]['type'] == "Fiscal Quarter Detail")
								$subGroupC = "3rd Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
								else
								$subGroupC = "3rd Natural Quarter";
		
							}else if (($subGroupC == $meses[9]) || ($subGroupC == $meses[10]) || ($subGroupC == $meses[11])){
								//Forth Quarter
								$sqlDetailWhereC = $sqlWhere." AND MONTH(".$groupFieldC.") IN ('".$meses[9]."', '".$meses[10]."', '".$meses[11]."') ";
		
								if ($details[$i]['type'] == "Fiscal Quarter Detail")
								$subGroupC = "4th Fiscal Quarter"; //Si es natural editar el nombre del subgrupo
								else
								$subGroupC = "4th Natural Quarter";
		
							}
		
		
							$sqlDetailQueryC = $sqlSelect.$sqlFrom.$sqlJoin.$sqlDetailWhereC.$sqlGroup.$sqlOrder;
							$rsDetailC = $focus->getSelectionResults($sqlDetailQueryC);
		
		
							for($k=0; $k<count($rsDetailC); $k++){
		
								$subGroupsC[$subGroupC][count($subGroupsC[$subGroupC])] = $rsDetailC[$k];
		
							}
		
		
		
							//Calculamos extension clausula where para limitaciones
							if ($report_data['results_limit'] == "all"){
									
								$sqlLimitWhere = "";
									
							} else {
		
								$res_limit = explode("\${dp}", $report_data['results_limit']);
		
								$sqlLimitedTotals = "SELECT @rownum:=@rownum+1 AS rownum, ".$report_table.".id FROM (SELECT @rownum:=0) r, ".substr($sqlFrom, 5)." ".$sqlJoin.$sqlDetailWhereC.$sqlGroup.$sqlOrder;
								$limitedTotalsRs = $focus->getSelectionResults($sqlLimitedTotals);
		
								//reordenamos el array por si esta ordenado descendentemente
								foreach ($limitedTotalsRs as $key=>$limitedTotal)
									$limitedTotalsRs[$key]['rownum'] = $key+1;
		
								$listIds = "";
								foreach ($limitedTotalsRs as $limitedRow){
									if (($res_limit[1] == 'first') && ($limitedRow['rownum'] <= $res_limit[2]))
										$listIds .= "'".$limitedRow['id']."',";
									else if (($res_limit[1] == 'last') && ($limitedRow['rownum'] > ($fullSizes[$j]-$res_limit[2])))
										$listIds .= "'".$limitedRow['id']."',";
								}
									
								$listIds = substr($listIds, 0, -1);
		
								$sqlLimitWhere = " AND ".$report_table.".id IN (".$listIds.") ";
		
							}
		
		
							//Obtenemos el resultado de la query de los SubTotales para el subgrupo actual
							$sqlSubQueryTotalsC = $sqlTotalsC.$sqlFrom.$sqlJoin.$sqlDetailWhereC.$sqlLimitWhere;
							$rsSubTotalsC = $focus->getSelectionResults($sqlSubQueryTotalsC);
		
							$subTotalsC[$subGroupC] = $rsSubTotalsC[0];
		
						}
		
		
						$chartValues = Array();
						$subGroupsChart = Array();
						$chartsHttpQueryUrls = (!isset($_REQUEST['chartsHttpQueryUrls'])) ? array() : explode("\${pipe}", $_REQUEST['chartsHttpQueryUrls']);
		
		
						foreach($subTotalsC as $key=>$values){
		
							//Recortar string de subgrupo si es demasiado largo (8chars)
							//$subGroupsChart[count($subGroupsChart)] = (strlen($key) > 8) ? substr($key, 0, 11) : $key ;
							$subGroupsChart[count($subGroupsChart)] = $key ;
		
							foreach($values as $keyV=>$value){
		
								$chartValues[$keyV][count($chartValues[$keyV])] = $value;
		
							}
		
						}
		
						//Por cada subtotal que haya (y del que se quiera hacer chart), a�adir urlchart a un aray de Url's
						$c=0;
		
						foreach($chartValues as $key=>$value){
		
							if (($chartInfo[$c][3] == 'yes') && ($chartInfo[$c][4] == 'pie')){
									
								$urlChart[count($urlChart)] = generateSwfPieChart(count($urlChart), $chartInfo[$c][1], $subGroupsChart, $value, count($subGroupsChart), (empty($chartsHttpQueryUrls)) ? null : $chartsHttpQueryUrls[count($urlChart)]);
								$chartInfo[$c]['type'] = 'PieChart';
								$chartInfo[$c]['subgroups'] = count($subGroupsChart);
								$chartSubGroupsValues[] = count($subGroupsChart);
								
							}
		
							if (($chartInfo[$c][3] == 'yes') && ($chartInfo[$c][4] == 'bar')){
									
								$urlChart[count($urlChart)] = generateSwfBarChart(count($urlChart), $chartInfo[$c][1], $subGroupsChart, $value, count($subGroupsChart), (empty($chartsHttpQueryUrls)) ? null : $chartsHttpQueryUrls[count($urlChart)]);
								$chartInfo[$c]['type'] = 'BarChart';
								$chartInfo[$c]['subgroups'] = count($subGroupsChart);
								$chartSubGroupsValues[] = count($subGroupsChart);
									
							}
		
							$c++;
						}
		
					}
		
					/**********************************************************************/
					//******Generar valores para el grafico de totales de registros********/
					//*********************************************************************/
		
		
					//Calculamos los totales a mano para las agrupaciones limitadas
					$LimitedTotals = Array();
		
					if (empty($subTotalsLimit))
						$subTotalsLimit = array();
					
					foreach ($totals as $key=>$total){
		
						$LimitedValue = "";
		
						switch ($total[5]) {
		
							case "COUNT":
							case "SUM":
								foreach ($subTotalsLimit as $subVal)
									$LimitedValue += $subVal[$total[1]];
								break;
		
							case "MIN":
								foreach ($subTotalsLimit as $subVal) {
									if (empty($LimitedValue))
										$LimitedValue = $subVal[$total[1]];
									else if ($subVal[$total[1]] <= $LimitedValue)
										$LimitedValue = $subVal[$total[1]];
								}
								break;
		
							case "MAX":
								foreach ($subTotalsLimit as $subVal) {
									if (empty($LimitedValue))
										$LimitedValue = $subVal[$total[1]];
									else if ($subVal[$total[1]] >= $LimitedValue)
										$LimitedValue = $subVal[$total[1]];
								}
								break;
		
							case "AVG":
								$c=0;
								foreach ($subTotalsLimit as $subVal) {
									$LimitedValue += $subVal[$total[1]];
									$c++;
								}
								$LimitedValue /= $c;
								break;
									
						}
		
						$LimitedTotals[0][$total[1]] = $LimitedValue;
		
					}
		
		
					//********************FIN PASO COMUN 10********************
		
					break;
		
			}
		
		
			//}//Fin del for de cada group detallado
		
		
			//********************INICIO PASO COMUN 11********************
			//*********************************FORMATEO DEL RESULTSET**********************************
		
			
			if ($hasGrouped) {
				//Add totals info to main fields array
				foreach ($totals as $key=>$myTotal)			
					$resulset_fields[] = $myTotal;
				//Add totals info to main fields array
			}
			
			
			//Order resultset for grouped totals
			if (($hasGrouped) && (!empty($groupSubTotalField)) && ($groupSubTotalFieldAscSort != '0')) {
				
				foreach ($subGroups as $key=>$group)
					sortAssocArray($subGroups[$key], $groupSubTotalField, ($groupSubTotalFieldAscSort == 'ASC') ? true : false, true);
				
			}
			
			
			//REFORMATEAR DATE, DATETIME Y CURRENCY
			$formatedRs = $subGroups;
		
			foreach ($formatedRs as $key=>$subGroup){
		
				foreach ($subGroup as $keyG=>$values){
		
					//$k=0;//Indice de los valores de cada fila
					$j=0;
		
					foreach ($values as $keyV=>$value){
		
						if ($resulset_fields[$j][8] == "enum") {
		
							$resulset_fields[$j][12] = str_replace("\${sq}", "'", $resulset_fields[$j][12]);
		
							$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$j][13]) : explode(",", $resulset_fields[$j][13]);
							$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$j][12]) : explode(",", $resulset_fields[$j][12]);
		
							foreach ($enumOptionsDb as $keyO=>$opt){
		
								if ($opt == $formatedRs[$key][$keyG][$keyV]){
		
									$formatedRs[$key][$keyG][$keyV] = $enumOptions[$keyO];
									break;
		
								}
		
							}
		
						} else if ($resulset_fields[$j][8] == "date") {
		
							if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
							$formatedRs[$key][$keyG][$keyV] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
						} else if ($resulset_fields[$j][8] == "datetime") {
		
							$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
							if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
							$formatedRs[$key][$keyG][$keyV] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
						} else if ($resulset_fields[$j][8] == "currency") {
		
							$params = array('currency_id' => $focus->currency_id, 'convert' => true);
							$formatedRs[$key][$keyG][$keyV] = currency_format_number($value, $params);
		
						} else
						$formatedRs[$key][$keyG][$keyV] = $value;
		
						$j++;
		
					}
		
				}
		
		
			}
		
			$subGroups = $formatedRs;
		
		
			//******************************************************************************************
			//********************FIN PASO COMUN 11********************
		
			
			//Order resultsetExport for grouped totals
			if (($hasGrouped) && (!empty($groupSubTotalField)) && ($groupSubTotalFieldAscSort != '0')) {
				
				foreach ($subGroupsExport as $key=>$group)
					sortAssocArray($subGroupsExport[$key], $groupSubTotalField, ($groupSubTotalFieldAscSort == 'ASC') ? true : false, true);
				
			}
			
		
			if (($report_data['results_limit'] != "all") || ($allowExportGeneratedFile)) {
			
				//REFORMATEAR DATE; DATETIME, CURRENCY Y ENUM
				$formatedRsExport = $subGroupsExport;
			
				foreach ($formatedRsExport as $key=>$subGroup){
			
					foreach ($subGroup as $keyG=>$values){
			
						//$k=0;//Indice de los valores de cada fila
						$j=0;
			
						foreach ($values as $keyV=>$value){
			
							if ($resulset_fields[$j][8] == "enum") {
			
								$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$j][13]) : explode(",", $resulset_fields[$j][13]);
								$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$j][12]) : explode(",", $resulset_fields[$j][12]);
			
								foreach ($enumOptionsDb as $keyO=>$opt){
			
									if ($opt == $formatedRsExport[$key][$keyG][$keyV]){
			
										$formatedRsExport[$key][$keyG][$keyV] = $enumOptions[$keyO];
										break;
			
									}
			
								}
			
							} else if ($resulset_fields[$j][8] == "date") {
			
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedRsExport[$key][$keyG][$keyV] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
			
							} else if ($resulset_fields[$j][8] == "datetime") {
			
								$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
								if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
								$formatedRsExport[$key][$keyG][$keyV] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
			
							} else if ($resulset_fields[$j][8] == "currency") {
			
								$params = array('currency_id' => $focus->currency_id, 'convert' => true);
								$formatedRsExport[$key][$keyG][$keyV] = currency_format_number($value, $params);
			
							} else
							$formatedRsExport[$key][$keyG][$keyV] = $value;
			
							$j++;
			
								
						}
			
					}
			
			
				}
			
				$subGroupsExport = $formatedRsExport;
	
			
			}
		
			//******************************************************************************************
		
			//Obtenemos los valores relaciones con el paginado
		
			if ($report_data['results_limit'] != "all") {
				$total_entries_basic = 0;
				foreach ($subGroupsExport as $subExp)
				$total_entries_basic += count($subExp);
				$data['total_entries'] = $total_entries_basic;
			} else {
				$data['total_entries'] = $total_entries;
			}
		
		
			$data['first_entrie'] = $first_entrie;
			$data['current_entries'] = (!empty($current_entries_limit)) ? $current_entries_limit : $current_entries;
			$data['page_number'] = $page_number;
			//Calcular numero de paginas en funciones de array sizes
			$parcial = 0;
			$num_pages = 0;
			for ($k=0; $k<count($sizes); $k++){
		
				$parcial += $sizes[$k];
		
				if (($parcial >= $entries_per_page)){
					$num_pages++;
					$parcial = 0;
				}
		
			}
		
			$data['num_pages'] = ($parcial == 0) ? $num_pages-1 : $num_pages;
		
		
			$hasDetail = true;
		
			if ($allowExportGeneratedFile) {
			
				$exportedReport['resultset'] = $subGroupsExport;
				$exportedReport['subTotals'] = $subTotalsExport;
			
			}
		
		} else {
		
			$GLOBALS['log']->debug("ASOL******************************************** Simple Report");
			
			//Obtenemos el resultado de la Query generada
			$sqlQuery = $sqlSelect.$sqlFrom.$sqlJoin.$sqlWhere.$sqlGroup.$sqlOrder.$sqlLimit;
			
			if ($allowExportGeneratedFile)
				$sqlQueryExport = $sqlSelect.$sqlFrom.$sqlJoin.$sqlWhere.$sqlGroup.$sqlOrder.$sqlLimitExport;
		
			$rs = $focus->getSelectionResults($sqlQuery);
	
			
			if ($allowExportGeneratedFile)
				$rsExport = $focus->getSelectionResults($sqlQueryExport);
		
		
			//*******************
			//Row Group Totals***
			//*******************
			if (count($group_by_seq) != 0)
				$sqlQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlWhere;
			else
				$sqlQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlWhere.$sqlLimitWhere;
			
			
			if ($hasGrouped) {
				
				$groupingFieldAlias = $group_by_seq[0]["alias"];
				$groupColumnName = "";
				
				$GLOBALS['log']->debug("ASOL******************************************** Execution Querys");
				
				foreach ($rs as $key=>$myRs) {
					
					$groupingVal = $myRs[$groupingFieldAlias];
					
					if (!empty($groupingVal))
						$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
					else
						$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
						
					$rsGroupingTotals = $focus->getSelectionResults($sqlQueryTotals.$sqlGroupTotalWhere);
					
					foreach ($rsGroupingTotals as $key2=>$groupTotal) {
		
						foreach ($groupTotal as $keyName=>$groupTotalVal) {
							$rs[$key][$keyName] = $groupTotalVal;
							$groupColumnName = $keyName;
						}
					
					}
					
				}

				
				if ($allowExportGeneratedFile) {
					
					$GLOBALS['log']->debug("ASOL******************************************** Export Querys");
					
					foreach ($rsExport as $key=>$myRs) {
						
						$groupingVal = $myRs[$groupingFieldAlias];
						
						if (!empty($groupingVal))
							$sqlGroupTotalWhere = " AND ".$group_by_seq[0]["field"]." = '".$groupingVal."'";
						else
							$sqlGroupTotalWhere = " AND (".$group_by_seq[0]["field"]." = '".$groupingVal."' OR ".$group_by_seq[0]["field"]." IS NULL)";
							
						$rsGroupingTotals = $focus->getSelectionResults($sqlQueryTotals.$sqlGroupTotalWhere);
						
						foreach ($rsGroupingTotals as $key2=>$groupTotal) {
			
							foreach ($groupTotal as $keyName=>$groupTotalVal) {
								$rsExport[$key][$keyName] = $groupTotalVal;
								$groupColumnName = $keyName;
							}
						
						}
						
					}
				
				}
				
			}	
			//*******************
			//Row Group Totals***
			//*******************
	
			
			//Order resultset for grouped totals
			if (($hasGrouped) && (!empty($groupSubTotalField)) && ($groupSubTotalFieldAscSort != '0'))
				sortAssocArray($rs, $groupSubTotalField, ($groupSubTotalFieldAscSort == 'ASC') ? true : false, true);
			
		
			//REFORMATEAR DATE; DATETIME Y CURRENCY
			$formatedRs = $rs;
			
			
			if ($allowExportGeneratedFile)
				$formatedRsExport = $rsExport;
		
			
			//Order resultsetExport for grouped totals
			if ($allowExportGeneratedFile) {
	
				if (($hasGrouped) && (!empty($groupSubTotalField)) && ($groupSubTotalFieldAscSort != '0'))
					sortAssocArray($formatedRsExport, $groupSubTotalField, ($groupSubTotalFieldAscSort == 'ASC') ? true : false, true);
			
			}
		
			for ($j=0; $j<count($formatedRs); $j++){
		
				$k = 0;
		
				//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
			
				
				//Add totals info to main fields array
				foreach ($totals as $key=>$myTotal)			
					$resulset_fields[] = $myTotal;
				//Add totals info to main fields array
		
				
				
				foreach ($formatedRs[$j] as $key=>$value){
					
		
					if ($resulset_fields[$k][8] == "enum") {
							
						$resulset_fields[$k][12] = str_replace("\${sq}", "'", $resulset_fields[$k][12]);
							
						$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$k][13]) : explode(",", $resulset_fields[$k][13]);
						$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$k][12]) : explode(",", $resulset_fields[$k][12]);
							
		
						foreach ($enumOptionsDb as $keyO=>$opt) {
		
							if ($opt == $formatedRs[$j][$key]){
									
								$formatedRs[$j][$key] = $enumOptions[$keyO];
								break;
									
							}
		
						}
							
					} else if ($resulset_fields[$k][8] == "date") {
							
						if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
						$formatedRs[$j][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
							
					} else if ($resulset_fields[$k][8] == "datetime") {
							
						$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
						if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
						$formatedRs[$j][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
							
		
					} else if ($resulset_fields[$k][8] == "currency") {
		
						$params = array('currency_id' => $focus->currency_id, 'convert' => true);
						$formatedRs[$j][$key] = currency_format_number($value, $params);
		
					} else {
					
						$formatedRs[$j][$key] = $value;
		
					}
		
					$k++;
		
				}
		
			}
		
	
			//Hacer el formateo tb para la query del export
			if ($allowExportGeneratedFile) {
				
				for ($j=0; $j<count($formatedRsExport); $j++){
			
					$k = 0;
			
					//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
			
					foreach ($formatedRsExport[$j] as $key=>$value){
			
			
						if ($resulset_fields[$k][8] == "enum") {
			
							$resulset_fields[$k][12] = str_replace("\${sq}", "'", $resulset_fields[$k][12]);
			
							$enumOptionsDb = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$k][13]) : explode(",", $resulset_fields[$k][13]);
							$enumOptions = ($escapeTokensFiltersComma = "true") ? explode("\${comma}", $resulset_fields[$k][12]) : explode(",", $resulset_fields[$k][12]);
								
							foreach ($enumOptionsDb as $keyO=>$opt){
			
								if ($opt == $formatedRsExport[$j][$key]){
										
									$formatedRsExport[$j][$key] = $enumOptions[$keyO];
									break;
										
								}
			
							}
								
						} else if ($resulset_fields[$k][8] == "date") {
								
							if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
							$formatedRsExport[$j][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
								
						} else if ($resulset_fields[$k][8] == "datetime") {
								
							$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
							if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
							$formatedRsExport[$j][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
								
			
						} else if ($resulset_fields[$k][8] == "currency") {
			
							$params = array('currency_id' => $focus->currency_id, 'convert' => true);
							$formatedRsExport[$j][$key] = currency_format_number($value, $params);
			
						} else
						$formatedRsExport[$j][$key] = $value;
			
			
						$k++;
			
					}
			
				}
			
			}
		
		
			$rs = $formatedRs;
			if ($allowExportGeneratedFile)
				$rsExport = $formatedRsExport;
		
		
			$data['total_entries'] = $total_entries_basic;
			$data['entries_per_page'] = $entries_per_page;
			$data['current_entries'] = count($rs);
			$data['page_number'] = $page_number;
			$data['num_pages'] = (($data['total_entries'] % $entries_per_page) != 0) ? floor($data['total_entries'] / $entries_per_page) : floor($data['total_entries'] / $entries_per_page) -1 ;
		
			if ($allowExportGeneratedFile)
				$exportedReport['resultset'] = $rsExport;
		
		}
		
		
		$data['page_number_label'] = $data['page_number'] + 1;
		$data['num_pages_label'] = $data['num_pages'] + 1;
		//echo "page_number:".($data['page_number']+1)." - num_pages:".($data['num_pages']+1);
		
		if ($allowExportGeneratedFile)
			$exportedReport['hasDetail'] = $hasDetail;
		
		//********************INICIO PASO COMUN 12********************
		//Obtenemos el resultado de la query de los Totales
		if (!$hasDetail) {
			if (count($group_by_seq) != 0)
				$sqlQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlWhere;
			else
				$sqlQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlWhere.$sqlLimitWhere;
		} else
			$sqlQueryTotals = $sqlTotals.$sqlFrom.$sqlJoin.$sqlWhere;
		
			
		$rsTotals = $focus->getSelectionResults($sqlQueryTotals);
		
		
		if ($hasGrouped) {
			//*******************
			//Row Group Totals***
			//*******************
			foreach ($totals as $key=>$myTotal)	{		
				$columns[] = $myTotal[1];
				$columnsO[] = "";
			}
			//*******************
			//Row Group Totals***
			//*******************
		}
		
		
		//REFORMATEAR DATE; DATETIME Y CURRENCY
		$formatedTotalsRs = $rsTotals;
		
		for ($j=0; $j<count($formatedTotalsRs); $j++){
		
			$k = 0;
		
			//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
		
			foreach ($formatedTotalsRs[$j] as $key=>$value){
		
				$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
					
				if ($total8 == "date") {
		
					if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
					$formatedTotalsRs[$j][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
		
				} else if ($total8 == "datetime") {
		
					$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
					if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
					$formatedTotalsRs[$j][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
		
		
				} else if ($total8 == "currency") {
		
					$params = array('currency_id' => $focus->currency_id, 'convert' => true);
					$formatedTotalsRs[$j][$key] = currency_format_number($value, $params);
		
				} else
				$formatedTotalsRs[$j][$key] = $value;
		
				$k++;
					
			}
		
		}
		
		$rsTotals = $formatedTotalsRs;
		
		if (($report_data['results_limit'] != "all") || ($allowExportGeneratedFile)) {
		
			//Formateamos los totales con filtro de limite
			//REFORMATEAR DATE; DATETIME Y CURRENCY
			$formatedLimitedTotals = $LimitedTotals;
			
			for ($j=0; $j<count($formatedLimitedTotals); $j++){
			
				$k = 0;
			
				//Comprobar que el elemento actual no es un total, si lo es pasar al siguiente elemento
			
				foreach ($formatedLimitedTotals[$j] as $key=>$value){
			
					$total8 = (!empty($totals[$k][8])) ? $totals[$k][8] : "";
						
					if ($total8 == "date") {
			
						if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
						$formatedLimitedTotals[$j][$key] = $timedate->swap_formats($value, $GLOBALS['timedate']->dbDayFormat, $userDateFormat);
			
					} else if ($total8 == "datetime") {
			
						$value = $timedate->handle_offset($value, $timedate->get_db_date_time_format(), true, null, $userTZ);
						if((!$timedate->check_matching_format($value, $userDateFormat)) && ($value!=""))
						$formatedLimitedTotals[$j][$key] = $timedate->swap_formats($value, $timedate->get_db_date_time_format(), $userDateTimeFormat);
			
			
					} else if ($total8 == "currency") {
			
						$params = array('currency_id' => $focus->currency_id, 'convert' => true);
						$formatedLimitedTotals[$j][$key] = currency_format_number($value, $params);
			
					} else
					$formatedLimitedTotals[$j][$key] = $value;
			
					$k++;
						
				}
			
			}
			
			$LimitedTotals = $formatedLimitedTotals;
		
		}
		
		
		if (!empty($LimitedTotals))
			$rsTotals = $LimitedTotals;
		
		
		if ($allowExportGeneratedFile) {
			
			$exportedReport['totals'] = $rsTotals;
			$exportedReport['headers'] = $columns;
			$exportedReport['headersTotals'] = $totals;
			
			$exportedReport['current_user_id'] = $current_user->id;
			
			
			//Guardamos el fichero en disco por si surge un export
			$exportedReportName = preg_replace ('/[^a-zA-Z0-9]/', '', $report_data['report_name']);
			$reportNameNoSpaces = strtolower(str_replace(":", "", str_replace(" ", "_", $exportedReportName)));
			$exportedReportFile = $reportNameNoSpaces."_".dechex(time()).dechex(rand(0,999999)).".txt";
			
			$exportFolder = "modules/Reports/tmpReportFiles/";
			
			$exportFile = fopen($exportFolder.$exportedReportFile, "w");
			fwrite($exportFile, serialize($exportedReport));
			fclose($exportFile);
		
		}
		
		//Guardamos el fichero en disco por si surge un export
		//********************FIN PASO COMUN 12********************
		
		
		if (!isset($_REQUEST['return_action'])){
			//Actualizo la variable Last run  del report ejecutado
			//Actualizar usando query directamente, sino el date_modified se cambia tb y solo debe cambiarse si se edita en la pantalla de edicion
			$update = "UPDATE reports SET last_run = '".gmdate("Y-m-d H:i:s")."' WHERE id = '".$record."' LIMIT 1";
			$focus->db->query($update);
		
			if ($asolLogLevelEnabled)
				$GLOBALS['log']->asol("ASOL-----------------------------------------------Updated last_run for Report with Id [".$_REQUEST['record']."]");
			else
				$GLOBALS['log']->debug("ASOL-----------------------------------------------Updated last_run for Report with Id [".$_REQUEST['record']."]");
				
			
			/*
			if ((isset($sugar_config['asolReportsDispatcherMaxRequests'])) && ($sugar_config['asolReportsDispatcherMaxRequests'] > 0) && (isset($_REQUEST["reportRequestId"]))) { //Only if dispatcher is activated
			
				$updateDispatcher = "UPDATE reports_dispatcher SET status = 'terminated' WHERE id = '".$_REQUEST["reportRequestId"]."' LIMIT 1";
				$focus->db->query($updateDispatcher);
				
			}
			*/
		
		}
	
	
	}
	

	?>
	
	<html>
	<head>
	
	<script type="text/javascript" src="modules/Reports/templates/swfobject/src/swfobject.js"></script>
	<?php
	if ($DomainsRow['count'] <= 0) echo '<script type="text/javascript" src="modules/Reports/templates/jquery.js"></script>';
	?>
	<script type="text/javascript" src="modules/Reports/templates/reports.js?version=221"></script>
	
	<script type="text/javascript">

	function setXmlCharts(){
	
		<?php foreach ($urlChart as $key=>$value){ ?>
			
			var flashvars = {};
			
			<?php
				echo 'flashvars.inputFile = "'.$value.'"';
			?>   
			flashvars.swfLocation = "include/SugarCharts/swf/";
			
			<?php 
				if (file_exists("themes/default/images/sugarColors.xml")) 
					echo 'flashvars.inputColorScheme = "themes/default/images/sugarColors.xml";';
				else 
					echo 'flashvars.inputColorScheme = "themes/'.$theme.'/images/sugarColors.xml";';
			?>
	
			flashvars.c = "1";
			
			<?php
				if (file_exists("cache/themes/Sugar/css/chart.css")) 
					echo 'flashvars.inputStyleSheet = "themes/default/css/chart.css";';
				else 
					echo 'flashvars.inputStyleSheet = "themes/'.$theme.'/css/chart.css";';
			
				echo 'flashvars.inputLanguage = "modules/Reports/language/chart_strings.'.$current_language.'.lang.xml";';
			
				$w = 600;
				$h = 600;
				
				
				if ($chartInfo[$key]['type'] == 'BarChart')
		        	$w = ($chartInfo[$key]['subgroups'] > $w/100) ? $w + ((($chartInfo[$key]['subgroups']) -($w/100))*86) : $w;
		        	
		        if (!$isDashlet) {
	        		echo 'flashvars.myWidth = "'.$w.'";';
	        		echo 'flashvars.myHeight = "'.$h.'";';
		        } else {
		        	$h = 480;
	        		echo 'flashvars.myWidth = $("#dashlet_'.$dashletId.'", parent.document.body).width()-40;';
	        		echo 'flashvars.myHeight = "'.$h.'";';
		        }
	        ?>
			
	
	
			var params = {};
			params.quality = "high";
			params.wmode = "transparent";
			params.menu = "false";
			params.allowscriptaccess = "always";
			var attributes = {}
			
			<?php 
		
			
			if (!$isDashlet)
				echo 'swfobject.embedSWF("include/SugarCharts/swf/ASOLchart.swf", "ASOLflash_'.$key.'", "'.$w.'", "'.$h.'", "10.0.0", "", flashvars, params, attributes);'; 
			else 
				echo 'swfobject.embedSWF("include/SugarCharts/swf/ASOLchart.swf", "ASOLflash_'.$key.'", $("#dashlet_'.$dashletId.'", parent.document.body).width()-40, "'.$h.'", "10.0.0", "", flashvars, params, attributes);';
				
			?>
	
	
		<?php
		}
		?>

	}
	</script>
	
	</head>
	
	<?php
	
	
	
	//Asignamos los valores para el ordenado
	$report_data['field_sort'] = $field_sort;
	$report_data['sort_direction'] = $sort_direction;
	
	if (!empty($LimitedTotals))
		$rsTotals = $LimitedTotals;

	$reportFields = ($hasDetail) ? $subGroups : $rs;


	if ((isset($_REQUEST['sourceCall'])) && ($_REQUEST['sourceCall'] == "httpReportRequest")) {
		
		
		if ((isset($_REQUEST['schedulerCall'])) && ($_REQUEST['schedulerCall'] == 'true')) {//Scheduled Reports


			//$exportedReportFile
			$tmpFilesDir = "modules/Reports/tmpReportFiles/";
			
			
			//Generar array con emails a enviar Report
			$emails = explode(",", $report_data['email_list']);
			$blind_copy = explode(",", $report_data['email_blind_copy']);
		
			$mail = new SugarPHPMailer();
		
			$mail->setMailerForSystem();
		
			$user = new User();
		
			//created by
			$mail_config = $user->getEmailInfo($report_data['created_by']);
		
			$mail->From = $mail_config['email'];
			$mail->FromName = $mail_config['name'];
		
			//Timeout del envio de correo
			$mail->Timeout=30;
			$mail->CharSet = "UTF-8";
		
			//Emails de los destinatarios
		
			for ($k=0; $k<count($emails); $k++){
		
				if ($emails[$k] != "")
				$mail->AddAddress($emails[$k]);
		
			}
		
			//Emails de los destinatarios copias ocultas
			for ($k=0; $k<count($blind_copy); $k++){
		
				if ($blind_copy[$k] != "")
				$mail->AddBCC($blind_copy[$k]);
		
			}
		
			if ($report_data['scheduled_images'] == "1"){
		
				//Generamos la url para reconstruir el report en un entryPoint
		
				//http://localhost/sugarCRM/index.php?entryPoint=scheduledEmailReport&module=Reports&xmlFiles=modules/Reports/tmpReportFiles/0_20100726T113715.xml|modules/Reports/tmpReportFiles/1_20100726T113715.xml&txtFile=leads_ie_v_8.0_1280137035.txt&subGroups=1|1&types=PieChart|BarChart
		
				//Generamos un string con el numero de grupos de cada chart
				$infos = Array();
				$types = Array();
		
				foreach ($chartInfo as $key=>$info){
					$infos[$key] = $info["subgroups"];
					$types[$key] = $info["type"];
				}
		
				$uri = "http://".$host_name;
				$uri .= "/index.php";
				$uri .= "?entryPoint=scheduledEmailReport&module=Reports&xmlFiles=";
		
				foreach($urlChart as $key=>$xml){
					$uri .= $xml."|";
				}
		
				$uri = substr($uri, 0, -1);
		
				$uri .= "&txtFile=".$exportedReportFile;
		
				$uri .= "&subGroups=".implode("|", $infos)."&types=".implode("|", $types);
		
				if ($asolLogLevelEnabled)
					$GLOBALS['log']->asol("ASOL----------------------------------------------------------scheduledImages is enabled - URI Rebuild: ".$uri);
				else
					$GLOBALS['log']->debug("ASOL----------------------------------------------------------scheduledImages is enabled - URI Rebuild: ".$uri);
					
				//Generamos la url para reconstruir el report en un entryPoint
		
			}
		
			//Datos del email en si
			$mail->Subject = "Report: ".$report_data['report_name'];
		
			$mail->Body = "<b>Report Name: </b>".$report_data['report_name']."<br>";
			$mail->Body .= "<b>Report Module: </b>".$app_list_strings["moduleList"][$report_data['report_module']]."<br>";
			$mail->Body .= "<b>Report Description: </b>".$report_data['description'];
		
			if ($report_data['scheduled_images'] == "1"){
		
				$mail->Body .= "<br><br>";
				$mail->Body .= "<a href='".$uri."'>".$mod_strings['LBL_REPORT_EMAIL_TTL_TEXT_1']."</a> ".$mod_strings['LBL_REPORT_EMAIL_TTL_TEXT_2']."<br><br>";
				$mail->Body .= "<i>".$mod_strings['LBL_REPORT_EMAIL_AVAILABLE_TEXT_1']." ".$scheduled_files_ttl." ".$mod_strings['LBL_REPORT_EMAIL_AVAILABLE_TEXT_2']."</i>";
		
			}
		
		
			//Mensaje en caso de que el destinatario no admita emails en formato html
			$mail->AltBody = "Report Name: ".$report_data['report_name']."\n";
			$mail->AltBody .= "Report Module: ".$app_list_strings["moduleList"][$report_data['report_module']]."\n";
			$mail->AltBody .= "Report Description: ".$report_data['description'];
		
			if ($scheduled_images == "1"){
		
				$mail->AltBody .= "\n\n";
				$mail->AltBody .= $mod_strings['LBL_REPORT_ALT_EMAIL_TTL_TEXT'].": ".$uri."\n\n";
				$mail->AltBody .= $mod_strings['LBL_REPORT_EMAIL_AVAILABLE_TEXT_1']." ".$scheduled_files_ttl." ".$mod_strings['LBL_REPORT_EMAIL_AVAILABLE_TEXT_2'];
		
			}
		

			if (!$hasDetail){
		
				$rsExport = $rs;
				$subTotalsExport = "";
		
			} else {
		
				$rsExport = $subGroups;
				$SubTotalsExport = $subTotals;
		
			}
		
		
			if ($report_data['report_charts'] != 'Char') {//If only charts Report, do not attach a generated file
			
				switch ($report_data['report_attachment_format']){
			
			
					//Añadir dos parametros a generatePDF: urls de los xml y cantidad de subgrupos de los mismos
			
					case "PDF":
						$adjunto = generatePDF($report_data['report_name'] , $app_list_strings["moduleList"][$report_data['report_module']], $report_data['description'], $columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, $pdf_orientation, Array(), false, true, 100, time(), $userTZlabel, $report_data['row_index_display'], $current_user->asol_default_domain);
						break;
					case "HTML":
						$adjunto = generatePDF($report_data['report_name'] , $app_list_strings["moduleList"][$report_data['report_module']], $report_data['description'], $columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, $pdf_orientation, Array(), true, true, 100, time(), $userTZlabel, $report_data['row_index_display'], $current_user->asol_default_domain);
						break;
					case "CSV":
						$adjunto = generateCsv($report_data['report_name'] ,$columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, true, $report_data['row_index_display']);
						break;
			
				}
				
				
				//Añadimos el Report como fichero adjunto del e-mail
				$mail->AddAttachment(getcwd()."/".$tmpFilesDir.$adjunto, $adjunto);
				
			}
		
			$success = $mail->Send();
		
			$tries=1;
			while ((!$success) && ($tries < 5)) {
		
				sleep(5);
				$success = $mail->Send();
				$tries++;
		
			}
		
			if ($report_data['report_charts'] != 'Char')
				unlink(getcwd()."/".$tmpFilesDir.$adjunto);

			
		} else {
			
			$tmpFilesDir = "modules/Reports/tmpReportFiles/";
			$httpHtmlFile = $_REQUEST['httpHtmlFile'];
			
			include "modules/Reports/DetailViewHttpSave.php";
			
		}
		
	} else {
	
		//Asignamos valores a smarty
		$smarty = new Sugar_Smarty();
		
		
		$smarty->assign('urlChart', $urlChart);
		//Vemos si el usuario activo puedo editar el report y por lo tanto si va a poder visualizar el boton "Edit" (El Administrador lo puedo todo)
		if (($current_user->id == $report_data['created_by']) || ($current_user->is_admin))
		$smarty->assign('can_edit', true);
		else
		$smarty->assign('can_edit', false);
		
		
		//Asignamos los valores generales del report a ejecutar
		$smarty->assign('report_name', $report_name);
		$smarty->assign('report_data', $report_data);
		//Asignamos  todos los valores de la conculta principal
		//Si hay alguna agrupacion detallado asignar el array de subgrupos
		$smarty->assign('columns', $columns);
		$smarty->assign('columnsO', $columnsO);
		$smarty->assign('columnsCount', ($report_data['row_index_display'] == '1') ? count($columns)+1 : count($columns));
		
	
		$smarty->assign('fields', $reportFields);
		
		if ($hasDetail)
			$smarty->assign('subTotals', $subTotals);
	
	
		//enviamos tb el flag que indica si hay o no subgrupos
		$smarty->assign('hasDetail',$hasDetail);
		//Asgnamos todos los valores relacionados con los totales
		$smarty->assign('totalColumns', $totals);
		
		
		$smarty->assign('totals', $rsTotals);
		
		
		//Asignamos los valores para el paginado
		$smarty->assign('data', $data);
		//Asignamos el nombre del fichero que contiene el exported Report
		$smarty->assign('exportedReportFile', $exportedReportFile);
		
		//Asignamos la variable que define si estamos en el display de un dashlet o no
		$smarty->assign('isDashlet', $isDashlet);
		$smarty->assign('dashletId', $dashletId);
		
		//assign value if report is called from bssPosClient
		$smarty->assign('externalCall', $externalCall);
		
		
		//Filters panel search array
		$smarty->assign('filtersPanel', (empty($filters_panel)) ? false : $filters_panel);
		$smarty->assign('filtersHiddenInputs', $filtersHiddenInputs);
		$smarty->assign('searchCriteria', $searchCriteria);
		
		
		//TRAZAS
		//$smarty->assign('query', $sqlQuery." -> ".($thisQuarter)." -> ".$monthInQuarter);
		//$smarty->assign('queryR', count($subTotals));
		//$smarty->assign('queryTotals', $sqlQueryTotals);
		//$smarty->assign('details', $sqlGroupsQuery);
		//$smarty->assign('subgroups', $details[0]['type']);
		
		//$smarty->assign('init_group', $init_group);
		//$smarty->assign('end_group', $end_group);
		//$smarty->assign('sizes', implode(",",$sizes));
		//$smarty->assign('quarterGroups', implode(",",$quarterGroups));
		//TRAZAS
		
		
		//Asignamos todos los labels de $mod_Srings & $app_strings
		$smarty->assign('externalFilters', $external_filters);
		
		$smarty->assign('LNK_LIST_START', $app_strings['LNK_LIST_START']);
		$smarty->assign('LNK_LIST_PREVIOUS', $app_strings['LNK_LIST_PREVIOUS']);
		$smarty->assign('LNK_LIST_NEXT', $app_strings['LNK_LIST_NEXT']);
		$smarty->assign('LNK_LIST_END', $app_strings['LNK_LIST_END']);
		$smarty->assign('LBL_EDIT_BUTTON_LABEL', $app_strings['LBL_EDIT_BUTTON_LABEL']);
		$smarty->assign('LBL_REPORT_DISPLAYING', $mod_strings['LBL_REPORT_DISPLAYING']);
		$smarty->assign('LBL_REPORT_EXECUTE', $mod_strings['LBL_REPORT_EXECUTE']);
		$smarty->assign('LBL_REPORT_SEARCH_CRITERIA', $mod_strings['LBL_REPORT_SEARCH_CRITERIA']);
		$smarty->assign('LBL_REPORT_RESULTS', $mod_strings['LBL_REPORT_RESULTS']);
		$smarty->assign('LBL_REPORT_NO_RESULTS', $mod_strings['LBL_REPORT_NO_RESULTS']);
		$smarty->assign('LBL_REPORT_TOTALS', $mod_strings['LBL_REPORT_TOTALS']);
		$smarty->assign('LBL_REPORT_SUBTOTALS', $mod_strings['LBL_REPORT_SUBTOTALS']);
		$smarty->assign('LBL_REPORT_CHARTS', $mod_strings['LBL_REPORT_CHARTS']);
		$smarty->assign('LBL_REPORT_REFRESH', $mod_strings['LBL_REPORT_REFRESH']);
		$smarty->assign('LBL_REPORT_EXPORT_HTML', $mod_strings['LBL_REPORT_EXPORT_HTML']);
		$smarty->assign('LBL_REPORT_EXPORT_PDF', $mod_strings['LBL_REPORT_EXPORT_PDF']);
		$smarty->assign('LBL_REPORT_EXPORT_CSV', $mod_strings['LBL_REPORT_EXPORT_CSV']);
		$smarty->assign('LBL_REPORT_SEND_EMAIL', $mod_strings['LBL_REPORT_SEND_EMAIL']);
		$smarty->assign('MSG_REPORT_SEND_EMAIL_ALERT', $mod_strings['MSG_REPORT_SEND_EMAIL_ALERT']);
		$smarty->assign('LBL_REPORT_FLASH_WARNING', $mod_strings['LBL_REPORT_FLASH_WARNING']);
		
		if ($report_data['email_blind_copy'] != "")
		$smarty->assign('LBL_REPORT_BLIND_COPY', "\\n".$mod_strings['LBL_REPORT_BLIND_COPY'].":\\n");
		else
		$smarty->assign('LBL_REPORT_BLIND_COPY', "");
		
		$smarty->assign('REPORTS_ACL_EDIT', ACLController::checkAccess('Reports', 'edit', true));
		
		$smarty->assign('chartSubGroupsValues', implode(",", $chartSubGroupsValues));
		
		$smarty->display('modules/Reports/templates/DetailView.tpl');
		
	}

} else {
	
	
	$pageNumber = (empty($_REQUEST['page_number'])) ? "" : "&page_number=".$_REQUEST['page_number'];
	$sortingField = (empty($_REQUEST['field_sort'])) ? "" : "&field_sort=".$_REQUEST['field_sort']."&sort_direction=".$_REQUEST['sort_direction'];
	$externalFilters = (empty($_REQUEST['external_filters'])) ? "" : "&external_filters=".$_REQUEST['external_filters'];
	$searchCriteria = (!isset($_REQUEST['search_criteria'])) ? "" : "&search_criteria=1";
	$filtersHiddenInputs = (empty($_REQUEST['filters_hidden_inputs'])) ? "" : "&filters_hidden_inputs=".$_REQUEST['filters_hidden_inputs'];
	$currentUserId = "&currentUserId=".$current_user->id;
	$isDashletQuery = (!empty($isDashlet)) ? "&dashlet=true" : "";		
			
	
	$asolUrlQuery = $pageNumber.$sortingField.$externalFilters.$searchCriteria.$filtersHiddenInputs.$currentUserId.$isDashletQuery;
    
    
	require_once('modules/Reports/Report.php');
	$focus = new Report();
	//Ver si hay charts para pasar los nombres
	$rsHttp = $focus->getSelectionResults("SELECT * FROM reports WHERE id = '".$_REQUEST['record']."'", false);
	
	$chartsUrls = array();
	$chartsInfo = array();
	$charts = (empty($rsHttp[0]['report_charts_detail'])) ? array() : explode("\${pipe}", $rsHttp[0]['report_charts_detail']);
	
	
	$tmpFilesDir = "modules/Reports/tmpReportFiles/";
	
	
	//Guardamos el fichero en disco por si surge un export
	$exportedReportName = preg_replace ('/[^a-zA-Z0-9]/', '', $rsHttp[0]['name']);
	$reportNameNoSpaces = strtolower(str_replace(":", "", str_replace(" ", "_", $exportedReportName)));
	$httpHtmlFile = $reportNameNoSpaces."_".dechex(time()).dechex(rand(0,999999)).".html";
	
	
	foreach ($charts as $chart) {

		$chartinfo = explode("\${dp}", $chart);
		
		$prefixChart = str_replace(" ", "_", $prefixChart);
		$xmlName = count($chartsUrls)."_".dechex(time()).dechex(rand(0,999999)).".xml";
	
		if ($chartinfo[3] == 'yes') {
			
			$chartsInfo[] = $chartinfo;
			$chartsUrls[] = $tmpFilesDir.$xmlName;
		
		}
		
	}
	
	$chartsQueryUrls = (empty($chartsUrls)) ? "" : "&chartsHttpQueryUrls=".implode("\${pipe}", $chartsUrls);
	
	echo '
	<html>
	
	<head>
		<script type="text/javascript" src="modules/Reports/templates/jquery.js"></script>
		<script type="text/javascript" src="modules/Reports/templates/swfobject/src/swfobject.js"></script>
		<script type="text/javascript" src="modules/Reports/templates/reports.js?version=221"></script>
	';
	?>
		<script>
		function setUpUserInputCalendars(){

			<?php
				 $httpFilters = explode("\${pipe}", $rsHttp[0]['report_filters']);
				 
				 foreach ($httpFilters as $httpFilter) {
				 	
				 	$oneFilterValues = explode("\${dp}", $httpFilter);
				 	
				 	if ((($oneFilterValues[4] == "datetime") || ($oneFilterValues[4] == "date")) && ($oneFilterValues[11] == "user_input") && (!empty($oneFilterValues[9]))) {	
				 		
				 		echo "Calendar.setup ({ inputField : '".$oneFilterValues[9]."_1' , daFormat : '".$timedate->get_cal_date_format()."', button : '".$oneFilterValues[9]."_trigger1' , singleClick : true, dateStr : '', step : 1, weekNumbers:false });";
				 	
				 		if (($oneFilterValues[1] == "between") || ($oneFilterValues[1] == "not between"))
				 			echo "Calendar.setup ({ inputField : '".$oneFilterValues[9]."_2' , daFormat : '".$timedate->get_cal_date_format()."', button : '".$oneFilterValues[9]."_trigger2' , singleClick : true, dateStr : '', step : 1, weekNumbers:false });";
				 			
				 	}
				 		
				 }
			?>
			
		}
		
		function setHttpXmlCharts(){

			var chartSubGroupsValues = document.getElementById("chartSubGroupsValues").value;
			var groupsCountValues = chartSubGroupsValues.split(',');
			
			
		<?php foreach ($chartsUrls as $key=>$value){ ?>
			
			var flashvars = {};
			
			<?php
				echo 'flashvars.inputFile = "'.$value.'"';
			?>   
			flashvars.swfLocation = "include/SugarCharts/swf/";
			
			<?php 
				if (file_exists("themes/default/images/sugarColors.xml")) 
					echo 'flashvars.inputColorScheme = "themes/default/images/sugarColors.xml";';
				else 
					echo 'flashvars.inputColorScheme = "themes/'.$theme.'/images/sugarColors.xml";';
			?>
	
			flashvars.c = "1";
			
			<?php
				if (file_exists("cache/themes/Sugar/css/chart.css")) 
					echo 'flashvars.inputStyleSheet = "themes/default/css/chart.css";';
				else 
					echo 'flashvars.inputStyleSheet = "themes/'.$theme.'/css/chart.css";';
			
				echo 'flashvars.inputLanguage = "modules/Reports/language/chart_strings.'.$current_language.'.lang.xml";';
			
				echo 'defaultWidth = 600;';
				echo 'defaultHeight = 600;';

				
				if ($chartsInfo[$key][4] == 'bar') {
                	echo 'defaultWidth = (groupsCountValues['.$key.'] > defaultWidth/100) ? defaultWidth + ((( groupsCountValues['.$key.'] ) -(defaultWidth/100))*86) : defaultWidth;';                                                                  
				}
		        	
        		echo 'flashvars.myWidth = defaultWidth;';
        		echo 'flashvars.myHeight = defaultHeight;';

	        ?>
			
	
	
			var params = {};
			params.quality = "high";
			params.wmode = "transparent";
			params.menu = "false";
			params.allowscriptaccess = "always";
			var attributes = {}
			
			<?php 
		
				echo 'swfobject.embedSWF("include/SugarCharts/swf/ASOLchart.swf", "ASOLflash_'.$key.'", defaultWidth, defaultHeight, "10.0.0", "", flashvars, params, attributes);'; 
			
			?>
	
	
			<?php
			}
			?>

		}
		</script>
	
<?php 
	
	$waitForReport = false;
	$reportRequestId = ""; 
	/*
	if ((isset($sugar_config['asolReportsDispatcherMaxRequests'])) && ($sugar_config['asolReportsDispatcherMaxRequests'] > 0)) {
		
		$reportsDispatcherSql = "SELECT COUNT(id) as 'reportsThreads' FROM reports_dispatcher WHERE status = 'executing'";
		$reportsDispatcherRs = $db->query($reportsDispatcherSql);
		$reportsDispatcherRow = $db->fetchByAssoc($reportsDispatcherRs);
		
		$requestId = create_guid();
		$reportRequestId = "&reportRequestId=".$requestId;
		
		if ($reportsDispatcherRow[0]["reportsThreads"] >= $sugar_config['asolReportsDispatcherMaxRequests']) { //Put Report in queue
			
			$queueReportSql = "INSERT INTO 'reportsThreads' VALUES ('".$requestId."', '".$_REQUEST['record']."', '".$httpHtmlFile."', '".implode("\${pipe}", $chartsUrls)."', 'waiting', '".gmdate('Y-m-d H:i:s')."', '', '".gmdate('Y-m-d H:i:s')."', 'manual', '".$current_user->id."')";
			$db->query($queueReportSql);
			$waitForReport = true;
			
		} else {
			
			$queueReportSql = "INSERT INTO 'reportsThreads' VALUES ('".$requestId."', '".$_REQUEST['record']."', '".$httpHtmlFile."', '".implode("\${pipe}", $chartsUrls)."', 'executing', '".gmdate('Y-m-d H:i:s')."', '', '".gmdate('Y-m-d H:i:s')."', 'manual', '".$current_user->id."')";
			$db->query($queueReportSql);
			$waitForReport = false;
			
		}
		
	}*/

	
	if (!$waitForReport) { //Execute report if not is waiting in queue
	
		$ch = curl_init();
		$requestedUrl = $sugar_config["asolReportsCurlRequestUrl"].'index.php?entryPoint=viewReport&record='.$_REQUEST['record'].'&language='.$current_language.'&sourceCall=httpReportRequest'.$chartsQueryUrls.$asolUrlQuery.'&httpHtmlFile='.$httpHtmlFile.$reportRequestId;
	
		curl_setopt($ch, CURLOPT_URL, $requestedUrl);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1);
		
		curl_exec($ch);
		curl_close($ch);
		
	}
	
	
	$checkHttpFileTimeout = (isset($sugar_config["asolReportsCheckHttpFileTimeout"])) ? $sugar_config["asolReportsCheckHttpFileTimeout"] : "2000";
	
	echo '
		<script>';

		if ($isDashlet) {
								
			/**/
			echo 
			'function setIframeHeight(isFirstTime, counterSameHeight, currentHeight){
			
				var count = (currentHeight == $("#reportDiv").height()) ? counterSameHeight+1 : 0;
				var heightJQ = $("#reportDiv").height();
				var deltaHeight = 0;';
		
				if ((count($chartsUrls) == 1) && ($rsHttp[0]['report_charts'] == "Char"))
					echo 'deltaHeight = 8;';
				else
					echo 'deltaHeight = 40;';
				
				echo 
				'$("#asolReportDashlet_'.$dashletId.'", parent.document.body).css("height", heightJQ+deltaHeight);
			
				if (isFirstTime)
					$("#asolReportDashlet_'.$dashletId.'", parent.document.body).css("visibility", "visible");
			
				if (count < 10)
					setTimeout("setIframeHeight("+false+", "+count+", "+heightJQ+")", 500);
			
			}';
		
		}

		echo '
		function sendAjaxRequest() {
		
			$(function () { 
	
			    $.ajax({
			        type: "POST",
			        url: \''.$sugar_config["asolReportsExtHttpUrl"].'index.php?entryPoint=asol_CheckHttpFileExists&httpHtmlFile='.$httpHtmlFile.$reportRequestId.'\',
			        async: true,
			        cache: false,
			        success: function (data) {
			        
			        	if (data.substring(0, 5) == "false") {
			        		
			        		setTimeout("sendAjaxRequest()", '.$checkHttpFileTimeout.');
			        	
						} else if (data.substring(0, 4) == "exec") {
						
							$("#loadingText").html("'.$mod_strings['LBL_REPORT_LOADING'].'");
							setTimeout("sendAjaxRequest()", '.$checkHttpFileTimeout.');
						
						} else {
						
			            	$("#externalHtmlReport").html(data);
			        		setHttpXmlCharts();
			        		setUpUserInputCalendars();';
			        		
							if ($isDashlet) {
								
								echo 
								'function setIframeHeight(isFirstTime, counterSameHeight, currentHeight){
								
									var count = (currentHeight == $("#reportDiv").height()) ? counterSameHeight+1 : 0;
									var heightJQ = $("#reportDiv").height();
									var deltaHeight = 0;';
							
									if ((count($chartsUrls) == 1) && ($rsHttp[0]['report_charts'] == "Char"))
										echo 'deltaHeight = 8;';
									else
										echo 'deltaHeight = 40;';
									
									echo 
									'$("#asolReportDashlet_'.$dashletId.'", parent.document.body).css("height", heightJQ+deltaHeight);
								
									if (isFirstTime)
										$("#asolReportDashlet_'.$dashletId.'", parent.document.body).css("visibility", "visible");
								
									if (count < 10)
										setTimeout("setIframeHeight("+false+", "+count+", "+heightJQ+")", 500);
								
								}
												
								$(document).ready(function() {
								
									$("#header").remove();
								    $("#footer").remove();
								    $("#reportTable").css("width", $("#dashlet_'.$dashletId.'", parent.document.body).width()-40);
								    $("#chartTable").css("width", $("#dashlet_'.$dashletId.'", parent.document.body).width()-40);
								    
								    $("#loadingGIF", parent.document.body).remove();
								    $("#loadingTEXT", parent.document.body).remove();
							
								    $("#content").css("margin-left", "0px");
								    $("#content").css("margin-right", "0px");';
								
								    if ((count($chartsUrls) == 1) && ($rsHttp[0]['report_charts'] == "Char")) {
										echo 
								    	'$("#moduleTitle").remove();
								        $("#moduleFooter").remove();
								        $("#chartsHeader").remove();
								        $("#chartsContent").removeClass("list view");
								        $("#content").css("margin-top", "-16px");
								        $("#asolReportDashlet_'.$dashletId.'", parent.document.body).attr("scrolling", "no");';
								    }
							
								echo '
								setTimeout("setIframeHeight("+true+", "+0+", "+$("#reportDiv").height()+")", 500);

							    });';
								
							} 
			        		
			            	
			            echo '}
			            	
					}
			    });
	
			}); 
		
		}
			
		</script>
		

		
	</head>
	
	<body onLoad="sendAjaxRequest();">
	
		<div id="externalHtmlReport" name="externalHtmlReport">
			<img id="loadingExternalReport" style="display:inline" src="themes/default/images/img_loading.gif"/>
		      <span style="display:inline" id="loadingText">&nbsp;';
	
			if ($waitForReport)
				echo $mod_strings['LBL_REPORT_WAITING'];
			else
				echo $mod_strings['LBL_REPORT_LOADING'];
	    
	    echo '</span>
		</div>
	
	</body>
	</html>
	';
}

?>