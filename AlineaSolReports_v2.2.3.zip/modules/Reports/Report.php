<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

 
class Report extends SugarBean {
        
	var $id;
	var $name;
	var $date_entered;
	var $date_modified;
	var $modified_user_id;
	var $created_by;
	var $description;
	var $deleted;
	var $assigned_user_id ;
	var $last_run;
	var $report_module;
	var $report_scope;
	var $report_fields;
	var $report_filters;
	var $report_type;
	var $report_attachment_format;
	var $report_tasks;
	var $report_charts;
	var $report_charts_detail;
	var $scheduled_images;
	var $row_index_display;
	var $results_limit;
	var $email_list;

	var $table_name = "reports";
	var $object_name = "Report";
	var $module_dir = "Reports";
	
	var $importable = true;
	var $tablePath;
	var $joinSegments;
	var $rootGuid;
	var $fromString;

	var $evalSQLFunctions = true;
	var $maxDepth; 

	function Report() {
		parent::SugarBean();
	}
	
	function bean_implements($interface){
		switch($interface){
			case 'ACL':return true;
		}
		return false;
	}
	
	function get_summary_text()
	{
		return $this->name;
	}

	function fill_in_additional_detail_fields() 
	{
		parent::fill_in_additional_detail_fields();
	}

	function getSelectionResults($query, $useAlternativeDb = true, $offset = 0, $entries = 0){
		
		global $sugar_config, $db;
		
		$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;
		
 		$retArray = array();
		
		if ((!isset($sugar_config["asolReportsDbAddress"])) || (!$useAlternativeDb)) {
			
			$queryResults = $db->query($query);
		
			while($queryRow = $db->fetchByAssoc($queryResults))
			{
				$retArray[] = $queryRow;
			}
			
		} else {
			
			$mysqli = new mysqli($sugar_config["asolReportsDbAddress"], $sugar_config["asolReportsDbUser"], $sugar_config["asolReportsDbPassword"], $sugar_config["asolReportsDbName"], $sugar_config["asolReportsDbPort"]);
			
			if (mysqli_connect_errno()) {
			    printf("Connect failed: %s\n", mysqli_connect_error());
			    exit();
			}

			$mysqli->set_charset("utf8");
			
			$queryResults = $mysqli->query($query);
	
			if ($asolLogLevelEnabled)
				$GLOBALS['log']->asol("ASOL_Reports query ----> [ ".$query." ]");
			else
				$GLOBALS['log']->debug("ASOL_Reports query ----> [ ".$query." ]");
			
			if (!$queryResults) {
				
				$GLOBALS['log']->fatal("ASOL_Reports ErrorQuery ----> [ ".mysqli_error($mysqli)." ]");
			
			} else {

				while($queryRow = $queryResults->fetch_assoc())
				{
					$retArray[] = $queryRow;
				}
			
			}
			
			if ($queryResults)
				$queryResults->close();
			
			mysqli_close($mysqli);
			
		}
		
		return $retArray;

	}

	function getFieldInfoFromVardefs($module, $field) {
		////////////////////////////////////////////////////////////////////////////////////////
		// patch to solve a bug in table "relationships": the module "campaigns" is in lowercase
		if ($module == 'campaigns') {
			$module = 'Campaigns';
		}
		////////////////////////////////////////////////////////////////////////////////////////
		
		global $beanList, $beanFiles, $app_list_strings;
		$class_name = $beanList[$module];
		require_once($beanFiles[$class_name]);
		$bean = new $class_name();
		$field_defs = $bean->field_defs;
		
		$result = '';
		foreach ($field_defs as $name=>$values) {
			if ($name == $field) {
			
				if ($values['type'] == 'currency') {
					$result = 'currency';
				 } else if (($values['type'] == 'enum') || ($values['type'] == 'multienum') || ($values['type'] == 'radioenum')) {
					
				 	$valOptions = (!empty($values['options'])) ? $values['options'] : "";
				 	
					if ($valOptions != '') {
						
						if (count($app_list_strings[$values['options']]) == 0)
							$app_list_strings[$values['options']] = Array();
													
						$result = implode('|', $app_list_strings[$values['options']]);
						
					} else if ($values['function'] != '') {
						
						$result = implode('|', $values['function']());
						
					}
				
				}
				break;
			}
		}
	
		return $result;
	}

function getFieldInfoFromVardefsLabels($module, $field) {
	////////////////////////////////////////////////////////////////////////////////////////
	// patch to solve a bug in table "relationships": the module "campaigns" is in lowercase
	if ($module == 'campaigns') {
		$module = 'Campaigns';
	}
	////////////////////////////////////////////////////////////////////////////////////////
	
	global $beanList, $beanFiles, $app_list_strings;
	$class_name = $beanList[$module];
	require_once($beanFiles[$class_name]);
	$bean = new $class_name();
	$field_defs = $bean->field_defs;
	$result = '';
	foreach ($field_defs as $name=>$values) {
		if ($name == $field) {
			if (($values['type'] == 'enum') || ($values['type'] == 'multienum') || ($values['type'] == 'radioenum')) {
				
				$valOptions = (!empty($values['options'])) ? $values['options'] : "";
				
				if ($valOptions != '') {
					
					foreach ($app_list_strings[$values['options']] as $key=>$value){
						
						$result .= $key."|";
						
					}
					
					$result = substr($result, 0, -1);
					
				} else if ($values['function'] != '') {
					
					foreach ($values['function']() as $key=>$value){
						
						$result .= $key."|";
						
					}
					
					$result = substr($result, 0, -1);
					
				}
			
			}
			break;
		}
	}
	return $result;
}

}
?>
