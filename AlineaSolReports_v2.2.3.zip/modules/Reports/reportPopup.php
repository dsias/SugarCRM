<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

error_reporting(E_ALL & ~E_NOTICE);  


global $mod_strings, $sugar_config;
	
$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;

	
if ($asolLogLevelEnabled)
	$GLOBALS['log']->asol("ASOL------------------------------------------------------Entering reportPopup.php");
else 
	$GLOBALS['log']->debug("ASOL------------------------------------------------------Entering reportPopup.php");

echo "<html>";

echo "<head>";
echo "<link rel='shortcut icon' href='themes/default/images/sugar_icon.ico'>";
echo "<script language='javascript'>";

if ((!empty($_REQUEST['domainId'])) && is_file("modules/Reports/templates/".$_REQUEST['domainId'].".css"))
	$customCssFile =  $_REQUEST['domainId'].".css";
else
	$customCssFile =  "reports.css";

echo '

function getHTTPObject(){
	var http;
	/*@cc_on
	@if(@_jscript_version>=5)
		try{
			http=new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e){
			try{
				http=new ActiveXObject("Microsoft.XMLHTTP");
			}catch(e2){
				http=false;
			}
		}
	@else 
		http=false;
	@end @*/
	if(!http && typeof XMLHttpRequest!=\'undefined\'){
		try{
			http=new XMLHttpRequest();
		}catch(e){
			http=false;
		}
	}
	return http;
}

var http=getHTTPObject();

// URL: url to send data
// postString format: p1=v1&p2=v2&(...)
function postAjaxWithFunction(url, postString, f){
	http.open("POST", url, true);
	http.setRequestHeader(\'Content-Type\', \'application/x-www-form-urlencoded; charset=ISO-8859-1\');
	http.onreadystatechange=f;
	try{
		http.send(postString);
	}catch(e){
	}
}

function callBack(){

	if (http.readyState == 4){
	
		document.getElementById("loadingGIF").style.display="none";
		document.getElementById("loadingText").style.display="none";
		document.getElementById("downloadButton").style.display="inline";
	
	}
}

function callBackEmails(){

	if (http.readyState == 4){
	
		window.close();
	
	}
}

function downloadFile(){

	var id = http.responseText;
	
	var urlFile = "index.php?entryPoint=reportDownload&fileName="+id;
	opener.location.href = urlFile;

	window.close();
	
}

function downloadFileExplorer(){

	var id = http.responseText;
	
	var urlFile = "index.php?entryPoint=reportDownload&fileName="+id;
	window.location.href = urlFile;
	
}

function downloadFileCSS(){
	
	var urlFile = "index.php?entryPoint=reportDownload&op=css&fileName=reports_original.css";
	opener.location.href = urlFile;

	window.close();
	
}

function downloadFileExplorerCSS(){

	var urlFile = "index.php?entryPoint=reportDownload&op=css&fileName=reports_original.css";
	
	window.location.href = urlFile;
	
}

function downloadFileCustomCSS(){
	
	var urlFile = "index.php?entryPoint=reportDownload&op=css&fileName='.$customCssFile.'";
	opener.location.href = urlFile;

	window.close();
	
}

function downloadFileExplorerCustomCSS(){

	var urlFile = "index.php?entryPoint=reportDownload&op=css&fileName='.$customCssFile.'";
	window.location.href = urlFile;
	
}

function printExportJS(){

	var LBL_REPORT_DOWNLOAD_REPORT = \''.$mod_strings['LBL_REPORT_DOWNLOAD_REPORT'].'\';
	
	var customB = document.getElementById(\'buttonExport\');
	
	if (customB) {
		
		var inHTML = \'<input type="button" style="display:none" id="downloadButton" \';
		if (navigator.userAgent.indexOf("Firefox")!=-1)  {
			inHTML += \'onclick="downloadFile()"\';
		} else {
			inHTML += \'onclick="downloadFileExplorer()"\';
		}
		
		inHTML += \' value="\'+LBL_REPORT_DOWNLOAD_REPORT+\'">\';

		customB.innerHTML = inHTML;

	}
		
}

function printCssJS(){
		 
	var LBL_ASOL_DOWNLOAD_CSS = \''.$mod_strings['LBL_ASOL_DOWNLOAD_CSS'].'\';
	
	var customB = document.getElementById(\'buttonCSS\');
	
	if (customB) {
	
		var inHTML = \'<input type="button" style="display:inline" id="downloadButton" \';
		if (navigator.userAgent.indexOf("Firefox")!=-1)  {
			inHTML += \'onclick="downloadFileCSS()"\';
		} else {
			inHTML += \'onclick="downloadFileExplorerCSS()"\';
		}
		
		inHTML += \' value="\'+LBL_ASOL_DOWNLOAD_CSS+\'">\';

		customB.innerHTML = inHTML;

	}
	
}

function printCustomCssJS(){
		 
	var LBL_ASOL_DOWNLOAD_CUSTOM_CSS = \''.$mod_strings['LBL_ASOL_DOWNLOAD_CUSTOM_CSS'].'\';
	
	var customB = document.getElementById(\'buttonCustomCSS\');
	
	if (customB) {
	
		var inHTML = \'<input type="button" style="display:inline" id="downloadButton" \';
		if (navigator.userAgent.indexOf("Firefox")!=-1)  {
			inHTML += \'onclick="downloadFileCustomCSS()"\';
		} else {
			inHTML += \'onclick="downloadFileExplorerCustomCSS()"\';
		}
		
		inHTML += \' value="\'+LBL_ASOL_DOWNLOAD_CUSTOM_CSS+\'">\';
		
		customB.innerHTML = inHTML;

	}
	
}

';

echo "function doPOST(){";

echo "var postStr = 'exportedReportFile=".$_REQUEST['exportedReportFile']."&return_action=".$_REQUEST['return_action']."&pngs=".rawurlencode($_REQUEST['pngs'])."';";

if ($asolLogLevelEnabled)
	$GLOBALS['log']->asol("ASOL---------------------------------"."var postStr = 'exportedReportFile=".$_REQUEST['exportedReportFile']."&return_action=".$_REQUEST['return_action']."&pngs=".rawurlencode($_REQUEST['pngs'])."';");
else
	$GLOBALS['log']->debug("ASOL---------------------------------"."var postStr = 'exportedReportFile=".$_REQUEST['exportedReportFile']."&return_action=".$_REQUEST['return_action']."&pngs=".rawurlencode($_REQUEST['pngs'])."';");	

if ($_REQUEST['return_action'] == "ManualTasks"){
	
	echo "postAjaxWithFunction('index.php?entryPoint=vRender', postStr, callBackEmails);";
	
} else if ($_REQUEST['return_action'] != "downloadCSS") {

	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL----------------------------------- Beggining for Http Post Request to vRender.php");
	else
		$GLOBALS['log']->debug("ASOL----------------------------------- Beggining for Http Post Request to vRender.php");
		
	echo "postAjaxWithFunction('index.php?entryPoint=vRender', postStr, callBack);";
	
}

echo "}";

echo "</script>";
echo "</head>";

echo "<body onload='printExportJS(); printCssJS(); printCustomCssJS(); doPOST()'>";

if ($_REQUEST['return_action'] == "ManualTasks"){
	
	echo "<div>";
	echo "<img id='loadingGIF' style='display:inline' src='themes/default/images/img_loading.gif' /><span style='display:inline' id='loadingText'> ".$mod_strings['LBL_REPORT_SENDING_EMAILS']."</span>";
	echo "</div>";
	
} else if (($_REQUEST['return_action'] != "downloadCSS") && ($_REQUEST['return_action'] != "downloadCustomCSS")) {
	
	echo "<div>";
	echo "<img id='loadingGIF' style='display:inline' src='themes/default/images/img_loading.gif' /><span style='display:inline' id='loadingText'> ".$mod_strings['LBL_REPORT_LOADING']."</span>";
	echo "</div>";
	
} 


if (($_REQUEST['return_action'] != "ManualTasks") && ($_REQUEST['return_action'] != "downloadCSS") && ($_REQUEST['return_action'] != "downloadCustomCSS")){

	echo "<span id='buttonExport'></span>";
	
} else if ($_REQUEST['return_action'] == "downloadCSS"){

	echo "<span id='buttonCSS'></span>";
	
} else if ($_REQUEST['return_action'] == "downloadCustomCSS"){
	
	echo "<span id='buttonCustomCSS'></span>";
	
} 
	
echo "</body>";

echo "</html>";

?>