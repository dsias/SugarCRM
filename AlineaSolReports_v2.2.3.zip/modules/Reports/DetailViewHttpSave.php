<?php 

$columnsCount = ($report_data['row_index_display'] == '1') ? count($columns)+1 : count($columns);

$disabledPaginationButtonsBack = (($data['num_pages'] == 0) || ($data['page_number'] == 0)) ? "disabled" : "";
$disabledPaginationButtonsForward = (($data['num_pages'] == 0) || ($data['page_number'] == $data['num_pages']) || ($data['total_entries'] == 0)) ? "disabled" : "";

$paginationStartImg = (($data['num_pages'] == 0) || ($data['page_number'] == 0)) ? "themes/default/images/start_off.gif" : "themes/default/images/start.gif";
$paginationPreviousImg = (($data['num_pages'] == 0) || ($data['page_number'] == 0)) ? "themes/default/images/previous_off.gif" : "themes/default/images/previous.gif";
$paginationNextImg = (($data['num_pages'] == 0) || ($data['page_number'] == $data['num_pages']) || ($data['total_entries'] == 0)) ? "themes/default/images/next_off.gif" : "themes/default/images/next.gif";
$paginationEndImg = (($data['num_pages'] == 0) || ($data['page_number'] == $data['num_pages']) || ($data['total_entries'] == 0)) ? "themes/default/images/end_off.gif" : "themes/default/images/end.gif";

$paginationSortDirection = ($report_data['sort_direction'] == 'ASC') ? "DESC" : "ASC";

$previousPage = ($data['page_number'] > 0) ? $data['page_number']-1 : '0';
$nextPage = ($data['page_number'] < $data['num_pages']) ? $data['page_number']+1 : $data['num_pages'];

												

$detailViewHttpFile = '<body onLoad="setXmlCharts();">

	<form id="display_form" name="display_form" method="post" action="index.php">
	
		<input type="hidden" value="Reports" name="module">
		<input type="hidden" value="EditView" name="action">
		<input type="hidden" value="" name="return_module">
		<input type="hidden" value="" name="return_action">
		<input type="hidden" value="'.$report_data['record'].'" name="record">
		<input type="hidden" value="'.$report_data['report_scope'].'" name="init_report_scope">
		<input type="hidden" value="'.$data['page_number'].'" name="page_number">
		
		<input type="hidden" value="'.$report_data['field_sort'].'" name="field_sort">
		<input type="hidden" value="'.$report_data['sort_direction'].'" name="sort_direction">
	
		<input type="hidden" value="" name="pngs">
		<input type="hidden" value="'.implode(",", $chartSubGroupsValues).'" id="chartSubGroupsValues">
	
		<input type="hidden" id="display_external_filters" name="external_filters" value="'.$external_filters.'">
		<input type="hidden" id="display_search_criteria" name="search_criteria" value="'.$searchCriteria.'">
	
	</form>
	
	<form id="export_form" name="export_form" method="post" action="index.php?entryPoint=reportPopup" target="ExportWindow">
	
		<input type="hidden" value="'.$report_data['record'].'" name="record">
		<input type="hidden" value="" name="return_action">
		<input type="hidden" value="" name="pngs">
		<input type="hidden" value="Reports" name="module">
		<input type="hidden" value="'.$exportedReportFile.'" name="exportedReportFile">
	
	</form>

<div id="reportDiv" class="alineasol_reports">

<table id="reportTable" style="width: 100%">

	<tbody>
	<tr>
		<td>
		
			<div><div id="moduleTitle" class="moduleTitle">
				<h3>'.$mod_strings['LBL_REPORT_DISPLAYING'].': '.$report_name.'</h3>
			</div></div>	
			
';
		
		if (!empty($filters_panel)) {
				
		$detailViewHttpFile .=
			'<div>
				<div>
				<form id="criteria_form" name="criteria_form" method="post" action="./index.php?module=Reports&action=DetailView&record='.$report_data['record'].'">
				<table cellspacing="0" cellpadding="0" border="0" width="100%" class="formHeader h3Row">
				<tbody><tr>
					
					<input type="hidden" id="filters_hidden_inputs" name="filters_hidden_inputs" value="'.$filtersHiddenInputs.'">
					<input type="hidden" id="external_filters" name="external_filters" value="'.$external_filters.'">
					<input type="hidden" id="search_criteria" name="search_criteria" value="'.$searchCriteria.'">
					
					<td nowrap="">
						<h3><span>'.$mod_strings['LBL_REPORT_SEARCH_CRITERIA'];
		
		$detailViewHttpFile .= 
						($filtersHiddenInputs) ? '&nbsp;&nbsp;<input type="submit" value="'.$mod_strings['LBL_REPORT_EXECUTE'].'" onClick="document.getElementById(\'external_filters\').value = format_external_filters();">' : '';
		$detailViewHttpFile .= 		
						'</span></h3>
		
					</td>
					<td width="100%">
						<img height="1" width="1" src="themes/default/images/blank.gif" alt="">
					</td>
					
					<table id="search_criteria">
						<tbody>
							<tr>';
							
								foreach ($filters_panel as $key=>$item) {
									$detailViewHttpFile .=
										'<td><span></span>
											<table class="list view" style="text-align: center">
												<tr>
													<td>
														<input id="filterType" type="hidden" value="'.$item['type'].'">
														<input id="filterRef" type="hidden" value="'.$item['reference'].'"><span>'.$item['label'].'</span></td>
												</tr>
												<tr>';
									
									$detailViewHttpFile .= ((!$item['genLabel']) || ($item['type'] == 'user_input')) ? '<td><span style="vertical-align: top; font-weight: bold">'.$item['opp'].'</span>&nbsp;&nbsp;'.$item['input1'].'&nbsp;&nbsp;'.$item['input2'].'</td>' : '<td><span style="vertical-align: top; font-weight: bold">'.$item['genLabel'].'</span></td>';
													
									$detailViewHttpFile .=		
												'</tr>
											</table>
										</td>';
								}
								
		$detailViewHttpFile .=
							'</tr>
						</tbody>
					</table>
		
				</tr></tbody>
				</table>
				</form>
				</div>
			</div>';
		}
			
		if (($filtersHiddenInputs == false) || ($searchCriteria == true)) {
			
			 $detailViewHttpFile .=
				'<div>';
				
				if (($report_data['report_charts'] == "Both") || ($report_data['report_charts'] == "Tabl")) {
				
					$detailViewHttpFile .=
					'<div>
					
					<table cellspacing="0" cellpadding="0" border="0" width="100%" class="formHeader h3Row">
					<tbody><tr>
						
						<td nowrap="">';
					
							if ($data['total_entries'] > 0)
								$detailViewHttpFile .= '<h3><span>'.$mod_strings['LBL_REPORT_RESULTS'].'</span></h3>';
							else
								$detailViewHttpFile .= '<h3><span>'.$mod_strings['LBL_REPORT_NO_RESULTS'].'</span></h3>';

					$detailViewHttpFile .=
						'</td>
						<td width="100%">
							<img height="1" width="1" src="themes/default/images/blank.gif" alt="">
						</td>
			
					</tr></tbody>
					</table>
					
					</div>
					
					<table class="list view">
						<tbody>
		
							<tr class="pagination">
								<td colspan="8">
									<table cellspacing="0" cellpadding="0" border="0" width="100%" class="paginationTable">
										<tbody><tr>
																
											<td nowrap="nowrap" align="right" width="1%" class="paginationChangeButtons">';
												
												$detailViewHttpFile .=
												'<button '.$disabledPaginationButtonsBack.' class="button" title="{$LNK_LIST_START}" name="listViewStartButton" type="button" onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value=0; document.display_form.return_action.value=\'\';document.display_form.submit()">
													<img height="11" border="0" align="absmiddle" width="13" alt="Start" src="'.$paginationStartImg.'">
												</button>
												
												<button '.$disabledPaginationButtonsBack.' title="{$LNK_LIST_PREVIOUS}" class="button" name="listViewPrevButton" type="button"  onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value='.$previousPage.';document.display_form.return_action.value=\'\'; document.display_form.submit()">
													<img height="11" border="0" align="absmiddle" width="8" alt="Previous" src="'.$paginationPreviousImg.'">
												</button>

												<span class="pageNumbers">Page '.$data['page_number_label'].' of '.$data['num_pages_label'].'</span>
												
												<button '.$disabledPaginationButtonsForward.' title="{$LNK_LIST_NEXT}" class="button" name="listViewNextButton" type="button" onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value='.$nextPage.'; document.display_form.return_action.value=\'\';document.display_form.submit()">
													<img height="11" border="0" align="absmiddle" width="8" alt="Next" src="'.$paginationNextImg.'">
												</button>
												
												<button '.$disabledPaginationButtonsForward.' title="{$LNK_LIST_END}" name="listViewEndButton" class="button" type="button"  onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value='.$data['num_pages'].';document.display_form.return_action.value=\'\'; document.display_form.submit()">
									 				<img height="11" border="0" align="absmiddle" width="13" alt="End" src="'.$paginationEndImg.'">
												</button>
											
											</td>
						
										</tr></tbody>
									</table>
								</td>
								
							</tr>';
							
							if ($hasDetail == false) {
					
								$detailViewHttpFile .=
								'<tr>';
								
									if ($report_data['row_index_display'] == '1')
										$detailViewHttpFile .= '<th>N&deg;</th>';
									
								
								foreach($columns as $columnKey=>$column) {

									$detailViewHttpFile .= '<th>';
						    			if (($columnsO[$columnKey] != "") && (!$externalCall)) {
						    				
						    				$initSortDirection = ($report_data['field_sort'] != $columnsO[$columnKey]) ? "document.display_form.sort_direction.value = 'ASC'; ": "";
						    				if (($report_data['field_sort'] == $columnsO[$columnKey]) && ($report_data['sort_direction'] == 'ASC')) 
						    					$sortingImg = "themes/default/images/arrow_down.gif";
						    				else if (($report_data['field_sort'] == $columnsO[$columnKey]) && ($report_data['sort_direction'] == 'DESC')) 
						    					$sortingImg = "themes/default/images/arrow_up.gif";
						    				else 
						    					$sortingImg = "themes/default/images/arrow.gif";
						    					
							    			$detailViewHttpFile .=
						    				'<a class="listViewThLinkS1" OnMouseOver="this.style.cursor=\'pointer\'" OnMouseOut="this.style.cursor=\'default\'" onclick="'.$initSortDirection.'document.display_form.field_sort.value=\''.$columnsO[$columnKey].'\'; document.display_form.action.value=\'DetailView\'; document.display_form.return_action.value=\'\'; document.display_form.submit();">'.$column.'</a>
							    			&nbsp;<img height="10" border="0" align="absmiddle" width="8" src="'.$sortingImg.'">';
						    			} else {
						    				$detailViewHttpFile .= $column;
						    			}
						    		$detailViewHttpFile .= '</th>';
			
								}

								$detailViewHttpFile .=
								'</tr>';
								
								foreach ($reportFields as $fieldKey=>$field) {
								
								$detailViewHttpFile .=
						    	'<tr>';
						    		
									if ($report_data['row_index_display'] == '1')
										$detailViewHttpFile .= '<td>'.($data['page_number']*$data['entries_per_page']+$fieldKey+1).'</td>';
									
									foreach ($field as $value) {
										$detailViewHttpFile .= '<td>'.$value.'</td>';
									} 
									
								$detailViewHttpFile .= 
								'</tr>';
			
								}
								
								
							} else {

								foreach ($reportFields as $key=>$item) {
								

									$detailViewHttpFile .= 
			  						'<tr><td class="list edit" colspan='.$columnsCount.'><h3><i>'.$key.'</i></h3></td></tr>
			  						
			  						<tr>';
			  						
										if ($report_data['row_index_display'] == '1')
											$detailViewHttpFile .= '<th>N&deg;</th>';
									
										foreach ($columns as $columnKey=>$column) {

											$detailViewHttpFile .=
						    				'<th>';
						    					if (($columnsO[columns_sec] != "") && (!$externalCall)) {

						    						$initSortDirection = ($report_data['field_sort'] != $columnsO[$columnKey]) ? "document.display_form.sort_direction.value = 'ASC';": "";
						    						if (($report_data['field_sort'] == $columnsO[$columnKey]) && ($report_data['sort_direction'] == 'ASC'))
						    							$sortingImg = "themes/default/images/arrow_down.gif";
						    						else if (($report_data['field_sort'] == $columnsO[$columnKey]) && ($report_data['sort_direction'] == 'DESC'))
						    							$sortingImg = "themes/default/images/arrow_up.gif";
						    						else
						    							$sortingImg = "themes/default/images/arrow.gif";
						    					
						    						$detailViewHttpFile .= 
							    					'<a class="listViewThLinkS1" OnMouseOver="this.style.cursor=\'pointer\'" OnMouseOut="this.style.cursor=\'default\'" onclick="'.$initSortDirection.' document.display_form.field_sort.value=\''.$columnsO[$columnKey].'\'; document.display_form.action.value=\'DetailView\';document.display_form.return_action.value=\'\'; document.display_form.submit()">'.$column.'</a>
							    					&nbsp;<img height="10" border="0" align="absmiddle" width="8" src="'.$sortingImg.'">';
						    					} else {
						    						$detailViewHttpFile .= $column;
						    					}
						    				$detailViewHttpFile .=
						    				'</th>';
			
										}
			  						
									$detailViewHttpFile .=
			  						'</tr>';
			  						
									foreach ($item as $key2=>$item2) {
			  						
										$detailViewHttpFile .=
			  							'<tr>';
										
											if ($report_data['row_index_display'] == '1')
												$detailViewHttpFile .= '<td>'.($key2+1).'</td>';
										
			  								foreach ($item2 as $key3=>$item3)
			  									$detailViewHttpFile .= '<td>'.$item3.'</td>';
	
			  							$detailViewHttpFile .=
			  							'</tr>';
			  						
			  						}
			  						
			  						$detailViewHttpFile .=
			  						'<td colspan='.$columnsCount.'>
			  						
			  						<table class="list view" border=1>
			  						
			  						<tr>
			  						<td rowspan=2 class="list view" style="width:20%"><center><h3><b>'.$key.' '.$mod_strings['LBL_REPORT_SUBTOTALS'].'</b></h3></center></td>';
			  						
									foreach ($subTotals[$key] as $key4=>$item4)
										$detailViewHttpFile .= '<th>'.$key4.'</th>';

									$detailViewHttpFile .= 
									'</tr>
			
									<tr>';
									
									foreach ($subTotals[$key] as $key5=>$item5)
										$detailViewHttpFile .= '<td>'.$item5.'</td>';
									
									$detailViewHttpFile .= 
									'</tr>
			  						
			  						</table>
			  						
			  						</td>';
			  						
								}
						
							
							}
		
							$detailViewHttpFile .= 
							'<tr class="pagination">
								<td colspan="8">
									<table cellspacing="0" cellpadding="0" border="0" width="100%" class="paginationTable">
										<tbody><tr>
																
											<td nowrap="nowrap" align="right" width="1%" class="paginationChangeButtons">';
												
												$detailViewHttpFile .=
												'<button '.$disabledPaginationButtonsBack.' class="button" title="{$LNK_LIST_START}" name="listViewStartButton" type="button" onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value=0; document.display_form.return_action.value=\'\';document.display_form.submit()">
													<img height="11" border="0" align="absmiddle" width="13" alt="Start" src="'.$paginationStartImg.'">
												</button>
												
												<button '.$disabledPaginationButtonsBack.' title="{$LNK_LIST_PREVIOUS}" class="button" name="listViewPrevButton" type="button"  onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value='.$previousPage.';document.display_form.return_action.value=\'\'; document.display_form.submit()">
													<img height="11" border="0" align="absmiddle" width="8" alt="Previous" src="'.$paginationPreviousImg.'">
												</button>

												<span class="pageNumbers">Page '.$data['page_number_label'].' of '.$data['num_pages_label'].'</span>
												
												<button '.$disabledPaginationButtonsForward.' title="{$LNK_LIST_NEXT}" class="button" name="listViewNextButton" type="button" onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value='.$nextPage.'; document.display_form.return_action.value=\'\';document.display_form.submit()">
													<img height="11" border="0" align="absmiddle" width="8" alt="Next" src="'.$paginationNextImg.'">
												</button>
												
												<button '.$disabledPaginationButtonsForward.' title="{$LNK_LIST_END}" name="listViewEndButton" class="button" type="button"  onClick="document.display_form.sort_direction.value=\''.$paginationSortDirection.'\'; document.display_form.action.value=\'DetailView\';document.display_form.page_number.value='.$data['num_pages'].';document.display_form.return_action.value=\'\'; document.display_form.submit()">
									 				<img height="11" border="0" align="absmiddle" width="13" alt="End" src="'.$paginationEndImg.'">
												</button>
											
											</td>
						
										</tr></tbody>
									</table>
								</td>
								
							</tr>
		
						</tbody>
					</table>';
					
					
					if ($data['total_entries'] > 0) {
					
						$detailViewHttpFile .=
						'<table cellspacing="0" cellpadding="0" border="0" width="100%" class="formHeader h3Row">
						<tbody><tr>
							
							<td nowrap="">
								<h3><span>'.$mod_strings['LBL_REPORT_TOTALS'].'</span></h3>
							</td>
							<td width="100%">
								<img height="1" width="1" src="themes/default/images/blank.gif" alt="">
							</td>
				
						</tr></tbody>
						</table>
				
						
						<table id="totalTable" class="list view">
							<tbody>
								
								<tr>';
								
									foreach ($totals as $totalColumn)		
						    			$detailViewHttpFile .= '<th>'.$totalColumn[1].'</th>';

						    	$detailViewHttpFile .=
								'</tr>';
								
						    	foreach ($rsTotals as $total) {
		
						    		$detailViewHttpFile .=
						    		'<tr>';
						    		
						    			foreach ($total as $value)
											$detailViewHttpFile .= '<td>'.$value.'</td>';
			
									$detailViewHttpFile .=
									'</tr>';
			
						    	}
					$detailViewHttpFile .=				
						'</tbody>
					</table>';
					
				}
				
			}

				
				if (count($urlChart) > 0) {
				
				$detailViewHttpFile .=
				'<table id="chartsHeader" cellspacing="0" cellpadding="0" border="0" width="100%" class="formHeader h3Row">
				<tbody><tr>
					
					<td nowrap="">
						<h3><span>'.$mod_strings['LBL_REPORT_CHARTS'].'</span></h3>
					</td>
					<td width="100%">
						<img height="1" width="1" src="themes/default/images/blank.gif" alt="">
					</td>
		
				</tr></tbody>
				</table>
				
				<table id="chartsContent" class="list view">
					<tbody>		
					
						<tr><td>';
	
						foreach ($urlChart as $key=>$value) {					
							
							$detailViewHttpFile .=
							'<div id="ASOLflash_'.$key.'"> 
   								
   								<strong>'.$mod_strings['LBL_REPORT_FLASH_WARNING'].'</strong>   
   								<a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Descargar Adobe Flash Player" /></a>        
							
							</div>'; 
								
								
						} 
						
						$detailViewHttpFile .=
						'</td></tr>
						
					
					</tbody>
				</table>';
				
				}
				
				$detailViewHttpFile .=
				'</div>
				
			
				<table id="moduleFooter" cellspacing="0" cellpadding="0" border="0" width="100%" class="formHeader h3Row">
				<tbody><tr>
					
					<td width="100%">
						<img height="1" width="1" src="themes/default/images/blank.gif" alt="">
					</td>
		
				</tr></tbody>
				</table>';
	
			}
		
	
				if (!$isDashlet) {
			
					if (($filtersHiddenInputs == false) || ($searchCriteria == true))
						$detailViewHttpFile .= '<input id="reportbutton_refresh" type="button" title="'.$mod_strings['LBL_REPORT_REFRESH'].'" class="button" onclick="document.display_form.action.value=\'DetailView\';document.display_form.return_action.value=\'refresh\'; document.display_form.field_sort.value=\'\';document.display_form.sort_direction.value=\'\'; document.display_form.submit()" name="button" value="'.$mod_strings['LBL_REPORT_REFRESH'].'">';
					
					if ((($current_user->id == $report_data['created_by']) || ($current_user->is_admin)) && (ACLController::checkAccess('Reports', 'edit', true)))
						$detailViewHttpFile .= '<input id="reportbutton_edit" type="button" title="'.$app_strings['LBL_EDIT_BUTTON_LABEL'].'" class="button" onclick="document.display_form.action.value=\'EditView\'; document.display_form.return_action.value=\'\'; document.display_form.submit()" name="button" value="'.$app_strings['LBL_EDIT_BUTTON_LABEL'].'">';
					
					if (($filtersHiddenInputs == false) || ($searchCriteria == true)) {
						
						if (!$hasDetail) {
							
							$detailViewHttpFile .= '<input id="reportbutton_html" type="button" title="'.$mod_strings['LBL_REPORT_EXPORT_HTML'].'" class="button" onclick="document.export_form.return_action.value=\'ExportHtml\'; document.export_form.pngs.value = \'\'; window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();" name="button" value="'.$mod_strings['LBL_REPORT_EXPORT_HTML'].'">';
						
						} else {
	
							$detailViewHttpFile .= '<input id="reportbutton_html" type="button" title="'.$mod_strings['LBL_REPORT_EXPORT_HTML'].'" class="button" onclick="document.export_form.return_action.value=\'ExportHtml\'; var chartArray = new Array(); ';
							
							foreach ($urlChart as $key=>$value)
								$detailViewHttpFile .= 'var flashObject = document.getElementById(\'ASOLflash_'.$key.'\'); chartArray['.$key.'] = flashObject.getEncodedPNG();';
							
							$detailViewHttpFile .= 'document.export_form.pngs.value = chartArray.join(\'%pngSeparator\'); window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();" name="button" value="'.$mod_strings['LBL_REPORT_EXPORT_HTML'].'">';
						
						}
							
						if (!$hasDetail) {
	
							$detailViewHttpFile .= '<input id="reportbutton_pdf" type="button" title="'.$mod_strings['LBL_REPORT_EXPORT_PDF'].'" class="button" onclick="document.export_form.return_action.value=\'ExportPdf\'; document.export_form.pngs.value = \'\'; window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();" name="button" value="'.$mod_strings['LBL_REPORT_EXPORT_PDF'].'">';
						
						} else {
	
							$detailViewHttpFile .= '<input id="reportbutton_pdf" type="button" title="'.$mod_strings['LBL_REPORT_EXPORT_PDF'].'" class="button" onclick="document.export_form.return_action.value=\'ExportPdf\'; var chartArray = new Array(); ';
							
							foreach ($urlChart as $key=>$value)
								$detailViewHttpFile .= 'var flashObject = document.getElementById(\'ASOLflash_'.$key.'\'); chartArray['.$key.'] = flashObject.getEncodedPNG();';
	
							$detailViewHttpFile .= 'document.export_form.pngs.value = chartArray.join(\'%pngSeparator\'); window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();" name="button" value="'.$mod_strings['LBL_REPORT_EXPORT_PDF'].'">';
						
						}
							
						$detailViewHttpFile .= '<input id="reportbutton_csv" type="button" title="'.$mod_strings['LBL_REPORT_EXPORT_CSV'].'" class="button" onclick="document.export_form.return_action.value=\'ExportCsv\'; document.export_form.pngs.value = \'\'; window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();" name="button" value="'.$mod_strings['LBL_REPORT_EXPORT_CSV'].'">';
						
						if (ACLController::checkAccess('Reports', 'edit', true)) {
	
							if ((($report_data['report_attachment_format'] == "PDF") || ($report_data['report_attachment_format'] == "HTML")) && ($hasDetail)) {
							
								$detailViewHttpFile .= '<input id="reportbutton_email" type="button" title="'.$mod_strings['LBL_REPORT_SEND_EMAIL'].'" class="button" onclick="document.export_form.return_action.value=\'ManualTasks\'; var chartArray = new Array();';
								
								foreach ($urlChart as $key=>$value)
									$detailViewHttpFile .= 'var flashObject = document.getElementById(\'ASOLflash_'.$key.'\'); chartArray['.$key.'] = flashObject.getEncodedPNG();';
								
								$detailViewHttpFile .= 'document.export_form.pngs.value = chartArray.join(\'%pngSeparator\'); if (confirm(\''.$mod_strings['MSG_REPORT_SEND_EMAIL_ALERT'].':\n'.$report_data['email_list'].$labelBlindCopy.$report_data['email_blind_copy'].' ?\')){ window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();}" name="button" value="'.$mod_strings['LBL_REPORT_SEND_EMAIL'].'">';
							
							} else {
							
								$labelBlindCopy = ($report_data['email_blind_copy'] != "") ? "\\n".$mod_strings['LBL_REPORT_BLIND_COPY'].":\\n" : "";
							
								$detailViewHttpFile .= '<input id="reportbutton_email" type="button" title="'.$mod_strings['LBL_REPORT_SEND_EMAIL'].'" class="button" onclick="document.export_form.return_action.value=\'ManualTasks\'; document.export_form.pngs.value = \'\'; if (confirm(\''.$mod_strings['MSG_REPORT_SEND_EMAIL_ALERT'].':\n'.$report_data['email_list'].$labelBlindCopy.$report_data['email_blind_copy'].' ?\')){ window.open(\'\', \'ExportWindow\', \'width=300,height=100,location=0,status=0,scrollbars=0\'); document.export_form.submit();}" name="button" value="'.$mod_strings['LBL_REPORT_SEND_EMAIL'].'">';
							
							}
						
						}
				
					}
				
				}
			
		$detailViewHttpFile .= 
		'</td>
	</tr>
	</tbody>
</table>

</div>

</body>
</html>';
		
		
$exportHttpFile = fopen($tmpFilesDir.$httpHtmlFile, "w");
fwrite($exportHttpFile, $detailViewHttpFile);
fclose($exportHttpFile);

		
		
?>