<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


global $current_user, $timedate, $app_list_strings, $sugar_config;

$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;

if ($asolLogLevelEnabled)
	$GLOBALS['log']->asol("ASOL-----------------------------------------------------Entering at vRender.php");
else
	$GLOBALS['log']->debug("ASOL-----------------------------------------------------Entering at vRender.php");

require_once("include/SugarPHPMailer.php");
require_once('modules/Reports/Report.php');
require_once('modules/Reports/ReportExcel.php');
require_once('modules/Reports/ReportPDF.php');
require_once('modules/Reports/ReportChart.php');
require_once('modules/Users/User.php');

$return_action = $_REQUEST['return_action'];


$exportFolder = "modules/Reports/tmpReportFiles/";
$currentDir = getcwd()."/";

$exportedReportFile = (isset($_REQUEST['exportedReportFile'])) ? $_REQUEST['exportedReportFile'] : "";
//$report_ids = explode("|", $_REQUEST['report_ids']);


if ($exportedReportFile != "") {//Es un export normal
	
	$fileName = $exportFolder.$exportedReportFile;
	$exportFile = fopen($fileName, "r");
	$serializedReport = fread($exportFile, filesize($fileName));
	$report = unserialize($serializedReport);
	fclose($exportFile);
	
	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL-------------------------------------------- Txt File Readed: Report name-> ".$report["reportName"]);
	else
		$GLOBALS['log']->debug("ASOL-------------------------------------------- Txt File Readed: Report name-> ".$report["reportName"]);
	
	//Volcamos el contenido del report exportado en variables
	$report_name = $report["reportName"];
	$report_module = $report["module"];
	$description = $report["description"];
	$hasDetail = $report["hasDetail"];
	$pdf_orientation = $report["pdf_orientation"];
	$pdf_img_scaling_factor = $report["pdf_img_scaling_factor"];
	
	$report_charts = $report["report_charts"];
	$report_attachment_format = $report["report_attachment_format"];
	$row_index_display = $report["row_index_display"];
	
	$tmpEmail = explode("\${pipe}", $report["email_list"]);
	$email_list = $tmpEmail[0];
	$email_blind_copy = $tmpEmail[1];
	
	$created_by = $report["created_by"];
	
	$columns = $report["headers"];
	$totals = $report["headersTotals"];
	$rsTotals = $report["totals"];
	
	$rs = $report["resultset"];
	$subGroups = $report["resultset"];
	
	$subTotals = $report["subTotals"];
	
	
	$reportDate = filectime($fileName);
		
	$theUser = new User();
	$theUser->retrieve($report["current_user_id"]);
	$gmtZone = $theUser->getUserDateTimePreferences();
	$userTZ = $theUser->getPreference("timezone")." ".$gmtZone["userGmt"];
	
}

if ($return_action == "ExportCsv"){
	
	
	if (!$hasDetail){

		$rsExport = $rs;
		$subTotalsExport = "";

	} else {

		$rsExport = $subGroups;
		$SubTotalsExport = $subTotals;

	}


	$filePath = generateCsv($report_name ,$columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, true, $row_index_display);
	
	echo $filePath;

} else if ($return_action == "ExportHtml"){

	if (!$hasDetail){

		$rsExport = $rs;
		$subTotalsExport = "";
		$pngSrcs = Array();

	} else {

		$rsExport = $subGroups;
		$SubTotalsExport = $subTotals;
		$pngSrcs = Array();

		if (($report_charts == "Char") || ($report_charts == "Both")) {
			
			//Generamos las imagenes
			$pngs = explode("%pngSeparator", $_REQUEST['pngs']);
	
	
			$today = dechex(time()).dechex(rand(0,999999));
			
			foreach ($pngs as $key=>$png){
	
				$filename = $key."_".$today.'.png';
				$somecontent = base64_decode($png);
	
				if ($handle = fopen($exportFolder.$filename, 'w'))
				if (!fwrite($handle, $somecontent) === FALSE)
				fclose($handle);
	
				$pngSrcs[$key] = $filename;
	
			}

		}
			
	}

	if ($report_charts == "Char") {

		$rsExport = Array();
		$rsTotals = Array();
		
	}
	
	$filePath = generatePDF($report_name , $report_module, $description, $columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, $pdf_orientation, $pngSrcs, true, true, 100, $reportDate, $userTZ, $row_index_display, $theUser->asol_default_domain);

	echo $filePath;
	
	
} else if ($return_action == "ExportPdf"){
	
	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL----------------------------------------------------------------I am in ExportPDF");
	else
		$GLOBALS['log']->debug("ASOL----------------------------------------------------------------I am in ExportPDF");
		
	if (!$hasDetail){

		$rsExport = $rs;
		$subTotalsExport = "";
		$pngSrcs = Array();

	} else {

		$rsExport = $subGroups;
		$SubTotalsExport = $subTotals;
		$pngSrcs = Array();

		if (($report_charts == "Char") || ($report_charts == "Both")) {
		
			//Generamos las imagenes
			$pngs = explode("%pngSeparator", rawurldecode($_REQUEST['pngs']));
	
			$today = dechex(time()).dechex(rand(0,999999));
			
			foreach ($pngs as $key=>$png){
		
				$filename = $key."_".$today.'.png';
				$somecontent = base64_decode($png);
	
				if ($handle = fopen($exportFolder.$filename, 'w+'))
				if (!fwrite($handle, $somecontent) === FALSE)
				fclose($handle);
	
				$pngSrcs[$key] = $filename;
	
			}
			
		} 

	}
	
	if ($report_charts == "Char") {

		$columns = Array();
		$rsExport = Array();
		$rsTotals = Array();
		
	}
	
	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL--------------------------------- Before generatePDF mem_use:".memory_get_usage()." Bytes");
	else
		$GLOBALS['log']->debug("ASOL--------------------------------- Before generatePDF mem_use:".memory_get_usage()." Bytes");
		
	//Enviar el html a convertir en PDF desde el template y generarlo aqui con DOMPDF
	$filePath = generatePDF($report_name , $report_module, $description, $columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, $pdf_orientation, $pngSrcs, false, true, $pdf_img_scaling_factor, $reportDate, $userTZ, $row_index_display, $theUser->asol_default_domain);

	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL--------------------------------- After generatePDF: ".$filePath." - mem_use:".memory_get_usage()." Bytes");
	else
		$GLOBALS['log']->debug("ASOL--------------------------------- After generatePDF: ".$filePath." - mem_use:".memory_get_usage()." Bytes");
	
	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL--------------------------------- Memory Peak Usage: ".memory_get_peak_usage()." Bytes");
	else
		$GLOBALS['log']->debug("ASOL--------------------------------- Memory Peak Usage: ".memory_get_peak_usage()." Bytes");
	
	echo $filePath;
	
} else if ($return_action == "ManualTasks"){
	
	//Generar array con emails a enviar Report
	$emails = explode(",",$email_list);
	$blind_copy = explode(",", $email_blind_copy);

	$mail = new SugarPHPMailer();

	$mail->setMailerForSystem();

	$user = new User();

	//created by
	$mail_config = $user->getEmailInfo($created_by);

	$mail->From = $mail_config['email'];
	$mail->FromName = $mail_config['name'];

	//Timeout del envio de correo

	$mail->Timeout=30;
	$mail->CharSet = "UTF-8";

	//Emails de los destinatarios
	for ($k=0; $k<count($emails); $k++){

		if ($emails[$k] != "")
		$mail->AddAddress($emails[$k]);

	}

	//Emails de los destinatarios copias ocultas
	for ($k=0; $k<count($blind_copy); $k++){

		if ($blind_copy[$k] != "")
		$mail->AddBCC($blind_copy[$k]);

	}
	

	//Datos del email en si
	$mail->Subject = "Report: ".$report_name;

	$mail->Body = "<b>Report Name: </b>".$report_name."<br>";
	$mail->Body .= "<b>Report Module: </b>".$report_module."<br>";
	$mail->Body .= "<b>Report Description: </b>".$description;

	//Mensaje en caso de que el destinatario no admita emails en formato html
	$mail->AltBody = "Report Name: ".$report_name."\n";
	$mail->AltBody .= "Report Module: ".$report_module."\n";
	$mail->AltBody .= "Report Description: ".$description;

	$pngSrcs = Array();

	if (!$hasDetail){

		$rsExport = $rs;
		$subTotalsExport = "";

	} else {

		$rsExport = $subGroups;
		$SubTotalsExport = $subTotals;

		if ($report_attachment_format != "CSV"){

			if (($report_charts == "Char") || ($report_charts == "Both")) {
			
				//Generamos las imagenes
				$pngs = explode("%pngSeparator", $_REQUEST['pngs']);
	
				$today = dechex(time()).dechex(rand(0,999999));
	
				foreach ($pngs as $key=>$png){
					
					$filename = $key."_".$today.'.png';
					$somecontent = base64_decode($png);
	
					if ($handle = fopen($exportFolder.$filename, 'w+'))
					if (!fwrite($handle, $somecontent) === FALSE)
					fclose($handle);
	
					$pngSrcs[$key] = $filename;
	
				}
			
			}

		}

	}


	switch ($report_attachment_format){

		case "HTML":
			if ($report_charts == "Char") {
		
				$columns = Array();
				$rsExport = Array();
				$rsTotals = Array();
				
			}	
			$adjunto = generatePDF($report_name , $report_module, $description, $columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, $pdf_orientation, $pngSrcs, true, true, 100, $reportDate, $userTZ, $row_index_display, $theUser->asol_default_domain);
			break;

		case "PDF":
			if ($report_charts == "Char") {
		
				$columns = Array();
				$rsExport = Array();
				$rsTotals = Array();
				
			}
			$adjunto = generatePDF($report_name , $report_module, $description, $columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, $pdf_orientation, $pngSrcs, false, true, $pdf_img_scaling_factor, $reportDate, $userTZ, $row_index_display, $theUser->asol_default_domain);
			break;

		case "CSV":
			$adjunto = generateCsv($report_name ,$columns, $rsExport, $totals, $rsTotals, $SubTotalsExport, $hasDetail, true, $row_index_display);
			break;

	}

	//A�adimos el Report como fichero adjunto del e-mail
	$mail->AddAttachment($currentDir.$exportFolder.$adjunto, $adjunto);

	//Exito sera true si el email se envio satisfactoriamente, false en caso comtrario
	$success = $mail->Send();


	$tries=1;
	while ((!$success) && ($tries < 5)) {

		sleep(5);
		$success = $mail->Send();
		$tries++;

	}

	unlink($currentDir.$exportFolder.$adjunto);

	echo "EmailsSent";

}

?>