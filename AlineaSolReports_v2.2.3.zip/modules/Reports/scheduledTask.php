<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

error_reporting(E_ALL & ~E_NOTICE);


//Generar a mayores report entero y almacenarlo en disco como "NOMBRE_REPORT_TIMESTAMP"
$exportedReport = Array();

global $timedate, $current_language, $mod_strings, $app_list_strings, $beanList, $beanFiles, $db, $sugar_config;

$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;



$tmpFilesDir = "modules/Reports/tmpReportFiles/";

require_once('modules/Reports/Report.php');
require_once('modules/Users/User.php');

//Obtenemos un listado con todos los reports que sean scheduled

$focus = new Report();

//obtenemos la configuracion de los reports para el admin
$sqlCfgAdmin = "SELECT config FROM asol_config WHERE created_by = '1'";
$rsCfgAdmin = $focus->getSelectionResults($sqlCfgAdmin, false);
$cfgAdmin = explode("|",$rsCfgAdmin[0]['config']);
$scheduled_files_ttl = (empty($cfgAdmin[5])) ? "7" : $cfgAdmin[5];

$sqlScheduled = "SELECT * FROM reports WHERE report_type = 'scheduled' AND report_tasks IS NOT NULL AND email_list IS NOT NULL AND deleted=0";
$scheduledReports = $focus->getSelectionResults($sqlScheduled, false);

$currentW = gmdate("w");
$currentJ = gmdate("j");
$currentH = gmdate("H");
$currentI = gmdate("i");

$currentDate = gmdate("Y-m-d");

//Separamos en dos arrays los id's de los Reports con imagenes y los resulsets de los reports con adjuntos CSV

$scheduled_reports = Array();

if (count($scheduledReports) == 0)
$scheduledReports = Array();

foreach ($scheduledReports as $key=>$scheduledReport){

	$reportTasks = explode("|", $scheduledReport['report_tasks']);

	foreach ($reportTasks as $task){

		//Quitar etiqueta de GMT
		if (strpos($task, "\${GMT}") !== false)
		$task = substr($task, 0, -6);

		$taskValues = explode(":", $task);
		$hourValue = explode(",", $taskValues[3]);

		$min = $hourValue[1];
		$hour = $hourValue[0];

		if ($taskValues[5] == "active"){

			switch ($taskValues[1]){

				case "weekly":
					$dayWeek = $taskValues[2];
					$dayMonth = "-1";
					break;

				case "monthly":
					$dayWeek = "-1";
					$dayMonth = $taskValues[2];
					break;

				case "daily":
					$dayWeek = "-1";
					$dayMonth = "-1";
					break;
			}

			if (((($currentW == $dayWeek%7) || ($currentJ == $dayMonth) || ($taskValues[1] == "daily")) &&
			($currentH == $hour) && ($currentI == $min)) && ($taskValues[5] == "active") &&
			($currentDate <= $taskValues[4]) &&(!$isSent)) {

				$scheduled_reports[count($scheduled_reports)] = $scheduledReports[$key];

				if ($asolLogLevelEnabled)
					$GLOBALS['log']->asol("ASOL-----------------------------------------------------Scheduled Reports Ids: ".$scheduledReport['id']);
				else 
					$GLOBALS['log']->debug("ASOL-----------------------------------------------------Scheduled Reports Ids: ".$scheduledReport['id']);
				
					
				//Se rompe el bucle foreach una vez se haya comprobado que hay que realizar una tarea
				break;

			}//Fin de la condicion de que se cumpla la fecha y hora


		}//Fin de la condicion de que la tarea actual est� activa


	}

}

for ($a=0; $a<count($scheduled_reports); $a++){

	$record = $scheduled_reports[$a]['id'];
	$rs = $focus->getSelectionResults("SELECT * FROM reports WHERE id = '".$record."'", false);
	
	$currentUserId = $rs[0]['created_by'];
	
	/*
	if ((isset($sugar_config['asolReportsDispatcherMaxRequests'])) && ($sugar_config['asolReportsDispatcherMaxRequests'] > 0)) {


		$reportRequestId = ""; 
		
		
		$reportsDispatcherSql = "SELECT COUNT(id) as 'reportsThreads' FROM reports_dispatcher WHERE status = 'executing'";
		$reportsDispatcherRs = $db->query($reportsDispatcherSql);
		$reportsDispatcherRow = $db->fetchByAssoc($reportsDispatcherRs);
		
		$requestId = create_guid();
		$reportRequestId = "&reportRequestId=".$requestId;
		
		if ($reportsDispatcherRow[0]["reportsThreads"] >= $sugar_config['asolReportsDispatcherMaxRequests']) { //Put Report in queue
			
			$queueReportSql = "INSERT INTO 'reportsThreads' VALUES ('".$requestId."', '".$record."', '', '', 'waiting', '".gmdate('Y-m-d H:i:s')."', '', '".gmdate('Y-m-d H:i:s')."', 'manual', '".$currentUserId."')";
			$db->query($queueReportSql);
			
		} else {
			
			$queueReportSql = "INSERT INTO 'reportsThreads' VALUES ('".$requestId."', '".$record."', '', '', 'executing', '".gmdate('Y-m-d H:i:s')."', '', '".gmdate('Y-m-d H:i:s')."', 'manual', '".$currentUserId."')";
			$db->query($queueReportSql);
			
			$ch = curl_init();
			$requestedUrl = $sugar_config["asolReportsCurlRequestUrl"].'index.php?entryPoint=viewReport&record='.$record.'&language='.$current_language.'&sourceCall=httpReportRequest&currentUserId='.$currentUserId.$reportRequestId."&schedulerCall=true";
		
			curl_setopt($ch, CURLOPT_URL, $requestedUrl);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_TIMEOUT, 1);
			
			curl_exec($ch);
			curl_close($ch);
			
		}
		
	
	} else {//Standard Execution
		*/
	
		$ch = curl_init();
		$requestedUrl = $sugar_config["asolReportsCurlRequestUrl"].'index.php?entryPoint=viewReport&record='.$record.'&language='.$current_language.'&sourceCall=httpReportRequest&currentUserId='.$currentUserId."&schedulerCall=true";
	
		curl_setopt($ch, CURLOPT_URL, $requestedUrl);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		//curl_setopt($ch, CURLOPT_TIMEOUT, 1);
		
		curl_exec($ch);
		curl_close($ch);
	/*	
	}
	*/
	
	

}//FIN DEL BUCLE FOR PRINCIPAL


//Buscamos todos los ficheros de la carpeta tmpReportFiles que tengan más de una semana y los eliminamos
$directorio = opendir($tmpFilesDir);
$aWeek = time() - (3600*24*$scheduled_files_ttl);

while ($archivo = readdir($directorio)) {

	//echo $archivo.": ".date('Y-m-d H:i:s', filemtime($tmpFilesDir.$archivo))." < ".date('Y-m-d H:i:s', $aWeek)."<br>";
	
	if ((filemtime($tmpFilesDir.$archivo) < $aWeek) && ( endsWith(strtolower($archivo), ".xml") || endsWith(strtolower($archivo), ".html") || endsWith(strtolower($archivo), ".zip") || endsWith(strtolower($archivo), ".pdf") || endsWith(strtolower($archivo), ".png") || endsWith(strtolower($archivo), ".txt") || endsWith(strtolower($archivo), ".csv") ))
	unlink ($tmpFilesDir.$archivo);

}
closedir($directorio);

function endsWith( $str, $sub ) {
	return ( substr( $str, strlen( $str ) - strlen( $sub ) ) == $sub );
}


?>