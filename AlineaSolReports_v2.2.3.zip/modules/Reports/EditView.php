<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


global $timedate, $current_user, $db, $mod_strings, $app_strings, $app_list_strings, $beanList, $beanFiles;


if(!ACLController::checkAccess('Reports', 'edit', true))
	die("<font color='red'>".$app_strings["LBL_EMAIL_DELETE_ERROR_DESC"]."</font>"); 


//Instanciamos nuestra clase Report que extiende de SugarBean
$focus = new Report();
$return_action = (isset($_REQUEST['return_action'])) ? $_REQUEST['return_action'] : ""; //devuelve la accion a ejecutar
//Solo se recogera si venimos del index para editar un report ya existente
$record = (isset($_REQUEST['record'])) ? $_REQUEST['record'] : "";

$focus->retrieve($record);


//Is Domains Installed
$DomainsQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name='AlineaSolDomains' AND status='installed'");
$DomainsRow = $db->fetchByAssoc($DomainsQuery);

if ($DomainsRow['count'] > 0) {

	$GLOBALS['log']->debug("*********************** ASOL: not default domain ".$_REQUEST['module'].": logic hook before_retrieve");

	if ($return_action != "duplicate") {

		$DomainIdNameQuery = $db->query("SELECT reports.asol_domain_id as domain_id, asol_domains.name as domain_name FROM reports LEFT JOIN asol_domains ON reports.asol_domain_id=asol_domains.id WHERE reports.id='".$record."'");
		$DomainIdNameRow = $db->fetchByAssoc($DomainIdNameQuery);

		if ((($current_user->is_admin) && (!empty($current_user->asol_domain_id))) || (!$current_user->is_admin)) {

			if ((($_REQUEST['action'] == "DetailView") || ($_REQUEST['action'] == "EditView")) && (isset($_REQUEST['update_domain'])) && ($_REQUEST['update_domain'] != $DomainIdNameRow['domain_id']))
			header("Location: index.php?module=".$_REQUEST['module']."&action=index&update_domain=".$current_user->asol_domain_id);

			if ( (($_REQUEST['action'] == "DetailView") || ($_REQUEST['action'] == "EditView")) && ($current_user->asol_default_domain != $DomainIdNameRow['domain_id'])) {

				if (!empty($_REQUEST['record'])) {

					if (!isset($_REQUEST['update_domain'])) {

						header("Location: index.php?module=Home&action=changeDomain&domain_id=".$DomainIdNameRow['domain_id']."&domain_name=".$DomainIdNameRow['domain_name']."&return_module=".$_REQUEST['module']."&return_action=".$_REQUEST['action']."&return_record=".$_REQUEST['record']);
							
					} else {
							
						if (!isset($_REQUEST['is_update'])) {

							header("Location: index.php?module=".$_REQUEST['module']."&action=index");

						}

					}

				}
					
			}

		}

	}

}
//Is Domains Installed


$report_name = (isset($_REQUEST['report_name'])) ? $_REQUEST['report_name'] : $focus->name;



if (isset($_REQUEST['assigned_user_id']))
$assigned_user_id = $_REQUEST['assigned_user_id'];
else
$assigned_user_id = (!empty($focus->assigned_user_id)) ? $focus->assigned_user_id : $current_user->id;

if (isset($_REQUEST['assigned_user_name']))
$assigned_user_name = $_REQUEST['assigned_user_name'];
else {
	$userNamequery = $db->query("SELECT user_name FROM users WHERE id='".$assigned_user_id."'");
	$userNameRow = $db->fetchByAssoc($userNamequery);
	$assigned_user_name = $userNameRow['user_name'];
}

$description = (isset($_REQUEST['description'])) ? $_REQUEST['description'] : $focus->description;
$report_module = (isset($_REQUEST['report_module'])) ? $_REQUEST['report_module'] : $focus->report_module; //devuelve el tipo de modulo seleccionado


if (isset($_REQUEST['init_report_scope']))
	$report_scope = $_REQUEST['init_report_scope'];
else if (isset($_REQUEST['report_scope']))
	$report_scope = ($_REQUEST['report_scope'] == "role") ? $_REQUEST['report_scope']."\${dp}".implode("\${comma}", $_REQUEST['report_scope_role']) : $_REQUEST['report_scope'];
else
	$report_scope = (!empty($focus->report_scope)) ? $focus->report_scope : "private" ; //devuelve el ambito del report creado

$report_type = (isset($_REQUEST['report_type'])) ? $_REQUEST['report_type'] : $focus->report_type; //devuelve el tipo de report seleccionado: manual o scheduled
$report_attachment_format = (isset($_REQUEST['report_attachment_format'])) ? $_REQUEST['report_attachment_format'] : $focus->report_attachment_format; //devuelve el tipo de adjunto de los emails a enviar: html, pdf o csv
$report_charts = (isset($_REQUEST['report_charts'])) ? $_REQUEST['report_charts'] : $focus->report_charts;
$scheduled_images = (isset($_REQUEST['scheduled_images'])) ? $_REQUEST['scheduled_images'] : $focus->scheduled_images;

$rhs_key = (isset($_REQUEST['rhs_key'])) ? $_REQUEST['rhs_key'] : ""; //recogemos la clave de relacion para los campos del LEFT JOIN
$relate_Field = (isset($_REQUEST['rhs_key'])) ? $_REQUEST['rhs_key'] : ""; //devuelve el campo del modulo seleccionado para obtener sus related fields

$selected_fields = (isset($_REQUEST['selected_fields'])) ? $_REQUEST['selected_fields'] : $focus->report_fields;
$selected_filters = (isset($_REQUEST['selected_filters'])) ? $_REQUEST['selected_filters'] : $focus->report_filters;
$selected_tasks = (isset($_REQUEST['selected_tasks'])) ? $_REQUEST['selected_tasks'] : $focus->report_tasks;

$row_index_display = (isset($_REQUEST['row_index_display'])) ? $_REQUEST['row_index_display'] : $focus->row_index_display;

$tmp_results_limit = (isset($_REQUEST['results_limit'])) ? explode("\${dp}", $_REQUEST['results_limit']) : explode("\${dp}", $focus->results_limit);

if (isset($_REQUEST['results_limit']))
$results_limit['operator'] = (!empty($_REQUEST['results_limit'])) ? $tmp_results_limit[0] : "all";
else
$results_limit['operator'] = (!empty($focus->results_limit)) ? $tmp_results_limit[0] : "all";
$results_limit['first_param'] = (isset($tmp_results_limit[1])) ? $tmp_results_limit[1] : "";
$results_limit['second_param'] = (isset($tmp_results_limit[2])) ? $tmp_results_limit[2] : "";

$escapeTokensFiltersComma = "true";
$escapeTokensFields = "true";
$escapeTokensFilters = "true";
$versionFields = "";
$versionFilters = "";

$posFields = strpos($selected_fields, "\${v");
$posFilters = strpos($selected_filters, "\${v");
$posTask = strpos($selected_tasks, "\${GMT}");

if ($posFields === false){

	$versionFields = "\${v1.0.0}";
	$escapeTokensFields = "false";

}else{ //Si field tiene version

	$versionFields = substr($selected_fields, -9, 9);

	if ($versionFields < "\${v1.3.1}")
	$escapeTokensFields = "false";
	else
	$escapeTokensFields = "true";

	$selected_fields = substr($selected_fields, 0, -9);

}

if ($posFilters === false){

	$versionFilters = "\${v1.0.0}";
	$escapeTokensFiltersComma = "false";
	$escapeTokensFilters = "false";

}else{ //Si filters tiene version

	$versionFilters = substr($selected_filters, -9, 9);

	if ($versionFilters < "\${v1.3.0}"){
		$escapeTokensFiltersComma = "false";
		$escapeTokensFilters = "false";
	}else if ($versionFilters == "\${v1.3.0}"){
		$escapeTokensFiltersComma = "false";
		$escapeTokensFilters = "true";
	}else {
		$escapeTokensFiltersComma = "true";
		$escapeTokensFilters = "true";
	}

	$selected_filters = substr($selected_filters, 0, -9);

}


if ($record == ""){
	$escapeTokensFields = "true";
	$escapeTokensFiltersComma = "true";
	$escapeTokensFilters = "true";
}

//formateo las fechas de los filtros

if ($escapeTokensFilters == "true")
$filterValues = explode("\${pipe}", $selected_filters);
else
$filterValues = explode("|", $selected_filters);


foreach ($filterValues as $key=>$value){

	if ($escapeTokensFilters == "true")
	$values = explode("\${dp}", $value);
	else
	$values = explode(":", $value);

	$val4 = (!empty($values[4])) ? $values[4] : "";

	if ((($val4 == "date") || ($val4 == "datetime")) && (($values[1] != "last") && ($values[1] != "this") && ($values[1] != "theese") && ($values[1] != "next") && ($values[1] != "not last") && ($values[1] != "not this") && ($values[1] != "not next"))){

		if((!$timedate->check_matching_format($values[2], $timedate->get_date_format())) && ($values[2]!="")) {

			$values[2] = $timedate->swap_formats($values[2], $GLOBALS['timedate']->dbDayFormat, $timedate->get_date_format() );
		}

		if((!$timedate->check_matching_format($values[3], $timedate->get_date_format())) && ($values[3]!="")) {

			$values[3] = $timedate->swap_formats($values[3], $GLOBALS['timedate']->dbDayFormat, $timedate->get_date_format() );
		}

	}

	if ($escapeTokensFilters == "true")
	$filterValues[$key] = implode("\${dp}", $values);
	else
	$filterValues[$key] = implode(":", $values);


}

if ($escapeTokensFilters == "true")
$filters = implode("\${pipe}", $filterValues);
else
$filters = implode("|", $filterValues);


$selected_filters = $filters;


if (strpos($selected_tasks, "\${GMT}") !== false)
$selected_tasks = substr($selected_tasks, 0, -6);



//reformateamos las fechas de selected task al formato de visualizacion definido por el usuario
$tasks = explode("|", $selected_tasks);


if (($tasks[0] == "") || ($tasks[0] == "\${GMT}"))
$tasks = Array();

if ((!isset($_REQUEST['selected_tasks'])) || ($return_action == 'duplicate')) {

	if (($return_action != "reOrderFieldsUp") && ($return_action != "reOrderFieldsDown") && ($return_action != "reOrderFiltersUp") && ($return_action != "reOrderFiltersDown")){

		foreach ($tasks as $key=>$task){

			$taskValues = explode(":", $task);

			$time1 = explode(",", $taskValues[3]);
			$auxDateTime = $timedate->handle_offset(date("Y")."-".date("m")."-".date("d")." ".$time1[0].":".$time1[1], $timedate->get_db_date_time_format());

			$auxDateTimeArray = explode(" ", $auxDateTime);
			$taskValues[3] = implode(",", explode(":", $auxDateTimeArray[1]));

			if((!$timedate->check_matching_format($taskValues[4], $timedate->get_date_format())) && ($taskValues[4]!=""))
			$taskValues[4] = $timedate->swap_formats($taskValues[4], $GLOBALS['timedate']->dbDayFormat, $timedate->get_date_format() );

			$tasks[$key] = implode(":", $taskValues);
		}

	}

}


$selected_tasks = implode("|", $tasks);

$selected_charts = (isset($_REQUEST['selected_charts'])) ? substr($_REQUEST['selected_charts'], 0, -9) : substr($focus->report_charts_detail, 0, -9);


$emailArray = explode("\${pipe}", $focus->email_list);

$email_tmp_list = (count($emailArray) == 2) ? $emailArray[0] : "";
$email_list = (isset($_REQUEST['email_list'])) ? $_REQUEST['email_list'] : $email_tmp_list;

$email_blind_tmp_list = (count($emailArray) == 2) ? $emailArray[1] : "";
$email_blind_copy = (isset($_REQUEST['email_blind_copy'])) ? $_REQUEST['email_blind_copy'] : $email_blind_tmp_list;

$rowIndex = (isset($_REQUEST['rowIndex'])) ? $_REQUEST['rowIndex'] : "";

if ($rowIndex != -1){

	//Reordenar los selected fields en funcion del indice
	if ($escapeTokensFields == "true") {
		$sorted_fields = explode("\${pipe}", $selected_fields);
	} else {
		$sorted_fields = explode("|", $selected_fields);
	}

	//Reordenar los selected filters en funcion del indice
	if ($escapeTokensFilters == "true") {
		$sorted_filters = explode("\${pipe}", $selected_filters);
	} else {
		$sorted_filters = explode("|", $selected_filters);
	}


	$swapVar ="";
	//Hacemos un swap entre el elemento de index-1 y el de index si index no es mayor que el no de elementos
	if ($return_action == "reOrderFieldsDown"){

		if ($rowIndex < count($sorted_fields)){
			$swapVar = $sorted_fields[$rowIndex-1];
			$sorted_fields[$rowIndex-1] = $sorted_fields[$rowIndex];
			$sorted_fields[$rowIndex] = $swapVar;
		}


		if ($escapeTokensFields == "true")
		$selected_fields = implode("\${pipe}", $sorted_fields);
		else
		$selected_fields = implode("|", $sorted_fields);


		//Hacemos un swap entre el elemento de index-1 y el de index-2 si index-2 no es menor que zero
	}else if ($return_action == "reOrderFieldsUp"){

		if ($rowIndex > 1){
			$swapVar = $sorted_fields[$rowIndex-1];
			$sorted_fields[$rowIndex-1] = $sorted_fields[$rowIndex-2];
			$sorted_fields[$rowIndex-2] = $swapVar;
		}

		if ($escapeTokensFields == "true")
		$selected_fields = implode("\${pipe}", $sorted_fields);
		else
		$selected_fields = implode("|", $sorted_fields);

	}else if ($return_action == "reOrderFiltersDown"){

		if ($rowIndex < count($sorted_filters)){
			$swapVar = $sorted_filters[$rowIndex-1];
			$sorted_filters[$rowIndex-1] = $sorted_filters[$rowIndex];
			$sorted_filters[$rowIndex] = $swapVar;
		}

		if ($escapeTokensFilters == "true")
		$selected_filters = implode("\${pipe}", $sorted_filters);
		else
		$selected_filters = implode("|", $sorted_filters);

	}else if ($return_action == "reOrderFiltersUp"){

		if ($rowIndex > 1){
			$swapVar = $sorted_filters[$rowIndex-1];
			$sorted_filters[$rowIndex-1] = $sorted_filters[$rowIndex-2];
			$sorted_filters[$rowIndex-2] = $swapVar;
		}

		if ($escapeTokensFilters == "true")
		$selected_filters = implode("\${pipe}", $sorted_filters);
		else
		$selected_filters = implode("|", $sorted_filters);

	}


}


if (($report_module != '')){

	$class_name = $beanList[$report_module];
	require_once($beanFiles[$class_name]);
	$bean = new $class_name();

	$table = $bean->table_name;


	//Check if custom table exists 
	$cstmTableExists = $focus->getSelectionResults("SHOW tables like '".$table."_cstm'", false);

	$rs = $focus->getSelectionResults("SHOW COLUMNS FROM ".$table, false);

	//Eliminamos campo deleted del array rs
	for ($i=0; $i<count($rs); $i++){

		if ($rs[$i]['Field'] == "deleted") {
			array_splice($rs, $i, 1);
			break;
		}

	}


	$rs_c = $focus->getSelectionResults("SELECT name, type FROM fields_meta_data WHERE custom_module='".$report_module."' AND type NOT IN ('id', 'relate', 'html', 'iframe', 'encrypt')", false);
	$rs_cr = $focus->getSelectionResults("SELECT name, type, ext2, ext3 FROM fields_meta_data WHERE custom_module='".$report_module."' AND type IN ('relate')", false);

	if (count($rs_c) == 0)
	$rs_c = Array();

	if (count($rs_cr) == 0)
	$rs_cr = Array();

	foreach ($rs_c as $custom_field){

		$rs[count($rs)]['Field'] = $table."_cstm.".$custom_field["name"];
		$rs[count($rs)-1]['Type'] = $custom_field["type"];

	}

	foreach ($rs_cr as $custom_field){

		$rs[count($rs)]['Field'] = $table."_cstm.".$custom_field["ext3"];
		$rs[count($rs)-1]['Type'] = $custom_field["type"];
		$rs[count($rs)-1]['RelateModule'] = $custom_field["ext2"];

	}

	$i=0;

	$fields = array(); //Array con los campos de la tabla seleccionada
	$fields_labels = array(); //Array con los labels de los campos de la tabla seleccionada
	$fields_type = array(); // Array con los tipos de campos de cada elemento del array $fields
	$fields_options = array(); // Array con las opciones (campos tipo "enum") de cada elemento del array $fields
	$fields_options_db = array();
	$has_related = array(); //Array que indica si los elementos de la tabla fields tienen relacion con alguna otra tabla
	$related_fields = array(); //Array con los campos related del campo pasado como parametro en el form
	$related_fields_labels = array(); //Array con los labels de los campos de la tabla seleccionada
	$related_fields_type = array();; // Array con los tipos de campos de cada elemento del array $related_fields
	$related_fields_options = array(); // Array con las opciones (campos tipo "enum") de cada elemento del array $related_fields
	$related_fields_options_db = array();


	foreach($rs as $value){

		if ($value['Type'] != "non-db"){

			$fields[$i] = $value['Field'];
			$auxField = explode(".", $fields[$i]);
			$auxField = (count($auxField) == 2) ? $auxField[1 ]: $fields[$i];
			$fields_options[$i] = $focus->getFieldInfoFromVardefs($report_module, $auxField);
			$fields_options_db[$i] = $focus->getFieldInfoFromVardefsLabels($report_module, $auxField);


			if ($fields_options[$i] == 'currency') {
				$fields_type[$i] = 'currency';
			} else if ($fields_options[$i] != '') {
				$fields_type[$i] = 'enum';
			} else {
				$fields_type[$i] = $value['Type'];
			}


			if ($value['Field'] == "id"){

				$fields_labels[$i] = "id";
				//Si el campo a relacionar es el ID, buscar en la tabla relationships
				$tmpField = explode(".", $value['Field']);
				$tmpField = (count($tmpField) == 2) ? $tmpField[1] : $value['Field'];

				$rshr = $focus->getSelectionResults("SELECT DISTINCT lhs_module, lhs_table FROM relationships WHERE rhs_module LIKE '".$report_module."' AND rhs_key LIKE '".$tmpField."'", false);

				//Buscamos tb en la otra direccion
				$rshl = $focus->getSelectionResults("SELECT DISTINCT rhs_module, rhs_table FROM relationships WHERE lhs_module LIKE '".$report_module."' AND lhs_key LIKE '".$tmpField."'", false);
					
				if (count($rshr) == 0)
				$rshr = Array();

				if (count($rshl) == 0)
				$rshl = Array();

				foreach($rshl as $v){ //Evitar tablas repetidas

					$duplicatedTable = false;

					foreach($rshr as $v2){

						if ($v['rhs_table'] == $v2['lhs_table']){
							$duplicatedTable = true;
							break;
						}

					}

					if ($duplicatedTable == false) {
						$rshr[count($rshr)]['lhs_table'] = $v['rhs_table'];
						$rshr[count($rshr)-1]['lhs_module'] = $v['rhs_module'];
					}

				}

				if ((count($rshr) > 0) || ($value['Type'] == "relate"))
				$has_related[$i] = "true";
				else
				$has_related[$i] = "false";

					
				if($relate_Field == $value['Field']){

					$j=0;
					$k=0;

					if(count($rshr) > 0) {

						while ($j < count($rshr)){

							$relatedTable = $rshr[$j]['lhs_table'];

							$rsrf = $focus->getSelectionResults("SHOW COLUMNS FROM ".$relatedTable, false);

							//Check if custom table exists 
							$cstmTableExists = $focus->getSelectionResults("SHOW tables like '".$relatedTable."_cstm'", false);
							
							if(count($cstmTableExists) == 0)
								$rsrfc = array();
							else
								$rsrfc =  $focus->getSelectionResults("SHOW COLUMNS FROM ".$relatedTable."_cstm", false);


							foreach ($rsrfc as $customField){
								if ($customField['Field'] != "id_c"){
									$customField['Field'] = $relatedTable."_cstm.".$customField['Field'];
									$rsrf[count($rsrf)] = $customField;
								}
							}


							foreach($rsrf as $val){
								
								$auxField = explode(".", $val['Field']);
								$theField = (count($auxField) == 2) ? $auxField[1] : $val['Field'];
								
								$related_fields[$k] = (count(explode(".", $val['Field'])) == 1) ? $relatedTable.".".$val['Field'] : $val['Field'];
									
								$related_fields_options[$k] = $focus->getFieldInfoFromVardefs($rshr[$j]['lhs_module'], $theField);
								$related_fields_options_db[$k] = $focus->getFieldInfoFromVardefsLabels($rshr[$j]['lhs_module'], $theField);
								
								

								if ($related_fields_options[$k] == 'currency') {
									$related_fields_type[$k] = 'currency';
								} else if ($related_fields_options[$k] != '') {
									$related_fields_type[$k] = 'enum';
								} else {
									$related_fields_type[$k] = $val['Type'];
								}
								$k++;
							}

							$j++;

						}

					} else {


						$related_class_name = $beanList[$value['RelateModule']];
						require_once($beanFiles[$related_class_name]);
						$related_bean = new $related_class_name();
							
						$relatedTable = $related_bean->table_name;
							

						$rsrf = $focus->getSelectionResults("SHOW COLUMNS FROM ".$relatedTable, false);
						
						//Check if custom table exists 
						$cstmTableExists = $focus->getSelectionResults("SHOW tables like '".$relatedTable."_cstm'", false);
						
						if(count($cstmTableExists) == 0)
							$rsrfc = array();
						else
							$rsrfc =  $focus->getSelectionResults("SHOW COLUMNS FROM ".$relatedTable."_cstm", false);
							
							
						foreach ($rsrfc as $customField){
							$rsrf[count($rsrf)] = $customField;
						}
							
						foreach($rsrf as $val){
							$related_fields[$k] = $relatedTable.".".$val['Field'];
							$related_fields_options[$k] = $focus->getFieldInfoFromVardefs($value['RelateModule'], $val['Field']);
							$related_fields_options_db[$k] = $focus->getFieldInfoFromVardefsLabels($value['RelateModule'], $val['Field']);

							if ($related_fields_options[$k] == 'currency') {
								$related_fields_type[$k] = 'currency';
							} else if ($related_fields_options[$k] != '') {
								$related_fields_type[$k] = 'enum';
							} else {
								$related_fields_type[$k] = $val['Type'];
							}
							$k++;
						}

						$j++;

					}

				}
					
			} else { //Buscar a traves del metodo get_related_fields() del bean

				$bean = new $class_name();

				$relatedInfo = $bean->get_related_fields();

				$tmpField = explode(".", $value['Field']);
				$tmpField = (count($tmpField) == 2) ? $tmpField[1] : $value['Field'];

				foreach ($relatedInfo as $info){

					$info_id_name = (!empty($info['id_name'])) ? $info['id_name'] : "";

					if ($info_id_name == $tmpField){
						$fields_labels[$i] = $info['name'];
						$has_related[$i] = "true";
						break;
							
					} else{
						$fields_labels[$i] = $tmpField;
						$has_related[$i] = "false";

					}

				}

				$relatedTable = "";
				$relatedModule = "";
					
				if($relate_Field == $value['Field']) {

					foreach ($relatedInfo as $info){

						if ($info['id_name'] == $tmpField){

							$relatedModule = $info['module'];

							$related_class_name = $beanList[$relatedModule];
							require_once($beanFiles[$related_class_name]);
							$related_bean = new $related_class_name();

							$relatedTable = $related_bean->table_name;

							break;

						}

					}

					$k = 0;


					$rsrf = $focus->getSelectionResults("SHOW COLUMNS FROM ".$relatedTable, false);

					//Eliminamos campo deleted del array rsrf
					for ($j=0; $j<count($rsrf); $j++){

						if ($rsrf[$j]['Field'] == "deleted") {
							array_splice($rsrf, $j, 1);
							break;
						}

					}

					//Check if custom table exists 
					$cstmTableExists = $focus->getSelectionResults("SHOW tables like '".$relatedTable."_cstm'", false);
					
					if(count($cstmTableExists) == 0)
						$rsrfc = array();
					else
						$rsrfc =  $focus->getSelectionResults("SHOW COLUMNS FROM ".$relatedTable."_cstm", false);
						

					foreach ($rsrfc as $customField){
						if ($customField['Field'] != "id_c"){
							$customField['Field'] = $relatedTable."_cstm.".$customField['Field'];
							$rsrf[count($rsrf)] = $customField;
						}
					}

					foreach($rsrf as $val){

						$related_fields[$k] = (count(explode(".", $val['Field'])) == 1) ? $relatedTable.".".$val['Field'] : $val['Field'];

						$valExp = explode(".", $val['Field']);
						$auxVal = (count(explode(".", $val['Field'])) == 1) ? $val['Field'] : $valExp[1];

						$related_fields_options[$k] = $focus->getFieldInfoFromVardefs($relatedModule, $auxVal);
						$related_fields_options_db[$k] = $focus->getFieldInfoFromVardefsLabels($relatedModule, $auxVal);

						if ($related_fields_options[$k] == 'currency') {
							$related_fields_type[$k] = 'currency';
						} else if ($related_fields_options[$k] != '') {
							$related_fields_type[$k] = 'enum';
						} else {
							$related_fields_type[$k] = $val['Type'];
						}
						$k++;
					}

				}

			}

		}

		$i++;
	}


}


//Obtener los m�dulo a los que tiene acceso el usuario activo
$acl_modules = ACLAction::getUserActions($current_user->id);

$i=0;
foreach($acl_modules as $key=>$mod){

	if($mod['module']['access']['aclaccess'] >= 0){

		$module[$i] = $key;
		$translatedModule[$i] = (isset($app_list_strings['moduleList'][$key])) ? $app_list_strings['moduleList'][$key] : $key;
		$i++;

	}

}

//si la accion de retorno es duplicate, suprimimos el id del Report para forzar que se cree una nueva copia de mismo
if ($return_action == "duplicate"){
	$record = "";
	
	$report_scope = ($current_user->is_admin) ? "private" : (strpos($report_scope, 'role') !== false) ? str_replace("role", "private", $report_scope) : $report_scope;
	$assigned_user_id = $current_user->id;
	$assigned_user_name = $current_user->user_name;
}


$smarty = new Sugar_Smarty();

$smarty->assign('escapeTokensFiltersComma', $escapeTokensFiltersComma);
$smarty->assign('escapeTokensFields', $escapeTokensFields);
$smarty->assign('escapeTokensFilters', $escapeTokensFilters);
$smarty->assign('available_modules', $module);
$smarty->assign('available_translated_modules', $translatedModule);

//Enviamos el formato de la fecha
$smarty->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());


$smarty->assign('fields', (!empty($fields)) ? $fields : array());
$smarty->assign('fields_labels', (!empty($fields_labels)) ? $fields_labels : array());
$smarty->assign('fields_labels_js', (!empty($fields_labels)) ? implode("\${pipe}", $fields_labels) : array());

$smarty->assign('types', (!empty($fields_type)) ? implode(',',$fields_type) : array());

if ($escapeTokensFields == "true"){

	$smarty->assign('options', (!empty($fields_options)) ? implode('${comma}',str_replace("'", "\${sq}", $fields_options)) : "");
	$smarty->assign('options_db', (!empty($fields_options_db)) ? implode('${comma}',str_replace("'", "\${sq}", $fields_options_db)) : "");

}else{

	if (count($fields_options) != 0)
	$smarty->assign('options', implode(',',str_replace("'", "\${sq}", $fields_options)));
	if (count($fields_options_db) != 0)
	$smarty->assign('options_db', implode(',',str_replace("'", "\${sq}", $fields_options_db)));

}

$smarty->assign('related', (!empty($has_related)) ? $has_related : array());

$smarty->assign('related_fields', (!empty($related_fields)) ? $related_fields : array());
$smarty->assign('related_fields_types', (!empty($related_fields_type)) ? implode(',',$related_fields_type) : array());

if ($escapeTokensFields == "true") {

	$smarty->assign('related_fields_options', (!empty($related_fields_options)) ? implode('${comma}',str_replace("'", "\${sq}", $related_fields_options)) : "");
	$smarty->assign('related_fields_options_db', (!empty($related_fields_options_db)) ? implode('${comma}',str_replace("'", "\${sq}", $related_fields_options_db)) : "");

} else {

	$smarty->assign('related_fields_options', (!empty($related_fields_options)) ? implode(',',str_replace("'", "\${sq}", $related_fields_options)) : "");
	$smarty->assign('related_fields_options_db', (!empty($related_fields_options_db)) ? implode(',',str_replace("'", "\${sq}", $related_fields_options_db)) : "");

}

//recordamos los campos introducidos
$smarty->assign('record', $record);
$smarty->assign('sel_module', $report_module);

$smarty->assign('sel_scope', ($report_scope == 'public') ? $report_scope : (strpos($report_scope, 'private') !== false) ? 'private' : 'role' );
$smarty->assign('sel_type', $report_type);
$smarty->assign('sel_format', $report_attachment_format);
$smarty->assign('scheduled_images', $scheduled_images);
$smarty->assign('row_index_display', $row_index_display);
$smarty->assign('results_limit', $results_limit);
$smarty->assign('sel_chart', $report_charts);
$smarty->assign('report_name', $report_name);
$smarty->assign('assigned_user_name', $assigned_user_name);
$smarty->assign('description', $description);
$smarty->assign('assigned_user_id', $assigned_user_id);
$smarty->assign('rhs_key', $rhs_key);

$smarty->assign('field_rows', $selected_fields);
$smarty->assign('filter_rows', $selected_filters);
$smarty->assign('task_rows', $selected_tasks);
$smarty->assign('chart_rows', $selected_charts);

$smarty->assign('email_list', $email_list);
$smarty->assign('email_blind_copy', $email_blind_copy);

//Asignamos todos los labels de $mod_Srings & $app_strings
$smarty->assign('LBL_SAVE_BUTTON_LABEL', $app_strings['LBL_SAVE_BUTTON_LABEL']);
$smarty->assign('LBL_CANCEL_BUTTON_LABEL', $app_strings['LBL_CANCEL_BUTTON_LABEL']);
$smarty->assign('LBL_CLEAR_BUTTON_LABEL', $app_strings['LBL_CLEAR_BUTTON_LABEL']);
$smarty->assign('LBL_SELECT_BUTTON_LABEL', $app_strings['LBL_SELECT_BUTTON_LABEL']);

$smarty->assign('LBL_REPORT_NAME', $mod_strings['LBL_REPORT_NAME']);
$smarty->assign('LBL_REPORT_MODULE', $mod_strings['LBL_REPORT_MODULE']);
$smarty->assign('LBL_REPORT_ASSIGNED_TO', $mod_strings['LBL_REPORT_ASSIGNED_TO']);

$smarty->assign('LBL_REPORT_SCOPE', $mod_strings['LBL_REPORT_SCOPE']);
$smarty->assign('LBL_REPORT_TYPE', $mod_strings['LBL_REPORT_TYPE']);
$smarty->assign('LBL_REPORT_EMAIL_ATTACHMENT_FORMAT', $mod_strings['LBL_REPORT_EMAIL_ATTACHMENT_FORMAT']);
$smarty->assign('LBL_REPORT_DESCRIPTION', $mod_strings['LBL_REPORT_DESCRIPTION']);

$smarty->assign('LBL_REPORT_DISPLAY_OPTS', $mod_strings['LBL_REPORT_DISPLAY_OPTS']);
$smarty->assign('LBL_REPORT_DISPLAY_TABLE', $mod_strings['LBL_REPORT_DISPLAY_TABLE']);
$smarty->assign('LBL_REPORT_DISPLAY_TABLECHART', $mod_strings['LBL_REPORT_DISPLAY_TABLECHART']);
$smarty->assign('LBL_REPORT_DISPLAY_CHART', $mod_strings['LBL_REPORT_DISPLAY_CHART']);

$smarty->assign('LBL_REPORT_EMAIL_LINK', $mod_strings['LBL_REPORT_EMAIL_LINK']);
$smarty->assign('LBL_REPORT_EMAIL_LINK_EXPLAIN', $mod_strings['LBL_REPORT_EMAIL_LINK_EXPLAIN']);

$smarty->assign('LBL_REPORT_MANUAL', $mod_strings['LBL_REPORT_MANUAL']);
$smarty->assign('LBL_REPORT_SCHEDULED', $mod_strings['LBL_REPORT_SCHEDULED']);
$smarty->assign('LBL_REPORT_PRIVATE', $mod_strings['LBL_REPORT_PRIVATE']);
$smarty->assign('LBL_REPORT_PUBLIC', $mod_strings['LBL_REPORT_PUBLIC']);
$smarty->assign('LBL_REPORT_ROLE', $mod_strings['LBL_REPORT_ROLE']);

$smarty->assign('LBL_REPORT_CREATE', $mod_strings['LBL_REPORT_CREATE']);
$smarty->assign('LBL_REPORT_FIELDS_FILTERS', $mod_strings['LBL_REPORT_FIELDS_FILTERS']);
$smarty->assign('LBL_REPORT_SCHEDULED_TASKS', $mod_strings['LBL_REPORT_SCHEDULED_TASKS']);
$smarty->assign('LBL_REPORT_DISTRIBUTION_LIST', $mod_strings['LBL_REPORT_DISTRIBUTION_LIST']);

$smarty->assign('LBL_REPORT_FIELDS', $mod_strings['LBL_REPORT_FIELDS']);
$smarty->assign('LBL_REPORT_ADD_FIELDS', $mod_strings['LBL_REPORT_ADD_FIELDS']);
$smarty->assign('LBL_REPORT_RELATED_FIELDS', $mod_strings['LBL_REPORT_RELATED_FIELDS']);
$smarty->assign('LBL_REPORT_ADD_RELATED_FIELDS', $mod_strings['LBL_REPORT_ADD_RELATED_FIELDS']);
$smarty->assign('LBL_REPORT_SHOW_RELATED', $mod_strings['LBL_REPORT_SHOW_RELATED']);
$smarty->assign('LBL_REPORT_COLUMNS', $mod_strings['LBL_REPORT_COLUMNS']);
$smarty->assign('LBL_REPORT_FILTERS', $mod_strings['LBL_REPORT_FILTERS']);
$smarty->assign('LBL_REPORT_EMAIL_LIST', $mod_strings['LBL_REPORT_EMAIL_LIST']);

$smarty->assign('LBL_REPORT_DATABASE_FIELD', $mod_strings['LBL_REPORT_DATABASE_FIELD']);
$smarty->assign('LBL_REPORT_ALIAS', $mod_strings['LBL_REPORT_ALIAS']);
$smarty->assign('LBL_REPORT_DISPLAY', $mod_strings['LBL_REPORT_DISPLAY']);
$smarty->assign('LBL_REPORT_SORT_DIRECTION', $mod_strings['LBL_REPORT_SORT_DIRECTION']);
$smarty->assign('LBL_REPORT_SORT_SEQUENCE', $mod_strings['LBL_REPORT_SORT_SEQUENCE']);
$smarty->assign('LBL_REPORT_FUCTION', $mod_strings['LBL_REPORT_FUCTION']);
$smarty->assign('LBL_REPORT_GROUP_BY_LAYOUT', $mod_strings['LBL_REPORT_GROUP_BY_LAYOUT']);
$smarty->assign('LBL_REPORT_GROUP_BY_SEQUENCE', $mod_strings['LBL_REPORT_GROUP_BY_SEQUENCE']);

$smarty->assign('LBL_REPORT_ADD_FILTER', $mod_strings['LBL_REPORT_ADD_FILTER']);
$smarty->assign('LBL_REPORT_DELETE_ROW', $mod_strings['LBL_REPORT_DELETE_ROW']);
$smarty->assign('LBL_REPORT_ROW_UP', $mod_strings['LBL_REPORT_ROW_UP']);
$smarty->assign('LBL_REPORT_ROW_DOWN', $mod_strings['LBL_REPORT_ROW_DOWN']);

$smarty->assign('LBL_REPORT_DELETE_FILTER', $mod_strings['LBL_REPORT_DELETE_FILTER']);
$smarty->assign('LBL_REPORT_FILTER_UP', $mod_strings['LBL_REPORT_FILTER_UP']);
$smarty->assign('LBL_REPORT_FILTER_DOWN', $mod_strings['LBL_REPORT_FILTER_DOWN']);

$smarty->assign('LBL_REPORT_CHARTS_TITLE', $mod_strings['LBL_REPORT_CHARTS_TITLE']);

$smarty->assign('LBL_REPORT_CHARTS_FIELD', $mod_strings['LBL_REPORT_CHARTS_FIELD']);
$smarty->assign('LBL_REPORT_CHARTS_NAME', $mod_strings['LBL_REPORT_CHARTS_NAME']);
$smarty->assign('LBL_REPORT_CHARTS_FUNCTION', $mod_strings['LBL_REPORT_CHARTS_FUNCTION']);
$smarty->assign('LBL_REPORT_CHARTS_TYPE', $mod_strings['LBL_REPORT_CHARTS_TYPE']);
$smarty->assign('LBL_REPORT_CHARTS_PIE', $mod_strings['LBL_REPORT_CHARTS_PIE']);
$smarty->assign('LBL_REPORT_CHARTS_BAR', $mod_strings['LBL_REPORT_CHARTS_BAR']);

$smarty->assign('LBL_REPORT_TASKS', $mod_strings['LBL_REPORT_TASKS']);
$smarty->assign('LBL_REPORT_TASK_NAME', $mod_strings['LBL_REPORT_TASK_NAME']);
$smarty->assign('LBL_REPORT_EXECUTION_RANGE', $mod_strings['LBL_REPORT_EXECUTION_RANGE']);
$smarty->assign('LBL_REPORT_DAY_VALUE', $mod_strings['LBL_REPORT_DAY_VALUE']);
$smarty->assign('LBL_REPORT_TIME_VALUE', $mod_strings['LBL_REPORT_TIME_VALUE']);
$smarty->assign('LBL_REPORT_EXECUTION_END_DATE', $mod_strings['LBL_REPORT_EXECUTION_END_DATE']);
$smarty->assign('LBL_REPORT_TASK_STATE', $mod_strings['LBL_REPORT_TASK_STATE']);
$smarty->assign('LBL_REPORT_ADD_TASK', $mod_strings['LBL_REPORT_ADD_TASK']);
$smarty->assign('LBL_REPORT_DELETE_TASK', $mod_strings['LBL_REPORT_DELETE_TASK']);

$smarty->assign('LBL_REPORT_EMAIL_LIST', $mod_strings['LBL_REPORT_EMAIL_LIST']);
$smarty->assign('LBL_REPORT_EMAIL_LIST_TIP', $mod_strings['LBL_REPORT_EMAIL_LIST_TIP']);

$smarty->assign('LBL_REPORT_OPERATOR', $mod_strings['LBL_REPORT_OPERATOR']);
$smarty->assign('LBL_REPORT_ROW_REF', $mod_strings['LBL_REPORT_ROW_REF']);

$smarty->assign('LBL_REPORT_BEHAVIOR', $mod_strings['LBL_REPORT_BEHAVIOR']);
$smarty->assign('LBL_REPORT_USER_INPUT_OPTS', $mod_strings['LBL_REPORT_USER_INPUT_OPTS']);
$smarty->assign('LBL_REPORT_AUTO', $mod_strings['LBL_REPORT_AUTO']);
$smarty->assign('LBL_REPORT_VISIBLE', $mod_strings['LBL_REPORT_VISIBLE']);
$smarty->assign('LBL_REPORT_USER_INPUT', $mod_strings['LBL_REPORT_USER_INPUT']);

$smarty->assign('LBL_REPORT_FIRST_PARAMETER', $mod_strings['LBL_REPORT_FIRST_PARAMETER']);
$smarty->assign('LBL_REPORT_SECOND_PARAMETER', $mod_strings['LBL_REPORT_SECOND_PARAMETER']);

$smarty->assign('LBL_REPORT_EMAIL_LIST', $mod_strings['LBL_REPORT_EMAIL_LIST']);
$smarty->assign('LBL_REPORT_EMAIL_LIST_TIP', $mod_strings['LBL_REPORT_EMAIL_LIST_TIP']);
$smarty->assign('LBL_REPORT_BLIND_COPY_LIST', $mod_strings['LBL_REPORT_BLIND_COPY_LIST']);

$smarty->assign('LBL_REPORT_DELETE_FILTER_ALERT', $mod_strings['LBL_REPORT_DELETE_FILTER_ALERT']);
$smarty->assign('LBL_REPORT_DELETE_ROW_ALERT', $mod_strings['LBL_REPORT_DELETE_ROW_ALERT']);
$smarty->assign('LBL_REPORT_DELETE_TASK_ALERT', $mod_strings['LBL_REPORT_DELETE_TASK_ALERT']);
$smarty->assign('LBL_REPORT_INVALID_EMAIL_ALERT', $mod_strings['LBL_REPORT_INVALID_EMAIL_ALERT']);
$smarty->assign('LBL_REPORT_EMPTY_EXECUTION_END_DATE_ALERT', $mod_strings['LBL_REPORT_EMPTY_EXECUTION_END_DATE_ALERT']);
$smarty->assign('LBL_REPORT_CHART_TIP', $mod_strings['LBL_REPORT_CHART_TIP']);
$smarty->assign('LBL_REPORT_ALPHANUMERIC_ALERT', $mod_strings['LBL_REPORT_ALPHANUMERIC_ALERT']);
$smarty->assign('LBL_REPORT_TOKENS_ALERT', $mod_strings['LBL_REPORT_TOKENS_ALERT']);

$smarty->assign('LBL_REPORT_MONTHLY', $mod_strings['LBL_REPORT_MONTHLY']);
$smarty->assign('LBL_REPORT_WEEKLY', $mod_strings['LBL_REPORT_WEEKLY']);
$smarty->assign('LBL_REPORT_DAILY', $mod_strings['LBL_REPORT_DAILY']);
$smarty->assign('LBL_REPORT_ACTIVE', $mod_strings['LBL_REPORT_ACTIVE']);
$smarty->assign('LBL_REPORT_INACTIVE', $mod_strings['LBL_REPORT_INACTIVE']);

$smarty->assign('LBL_REPORT_MONDAY', $mod_strings['LBL_REPORT_MONDAY']);
$smarty->assign('LBL_REPORT_TUESDAY', $mod_strings['LBL_REPORT_TUESDAY']);
$smarty->assign('LBL_REPORT_WEDNESDAY', $mod_strings['LBL_REPORT_WEDNESDAY']);
$smarty->assign('LBL_REPORT_THURSDAY', $mod_strings['LBL_REPORT_THURSDAY']);
$smarty->assign('LBL_REPORT_FRIDAY', $mod_strings['LBL_REPORT_FRIDAY']);
$smarty->assign('LBL_REPORT_SATURDAY', $mod_strings['LBL_REPORT_SATURDAY']);
$smarty->assign('LBL_REPORT_SUNDAY', $mod_strings['LBL_REPORT_SUNDAY']);


$smarty->assign('LBL_REPORT_JANUARY', $mod_strings['LBL_REPORT_JANUARY']);
$smarty->assign('LBL_REPORT_FEBRUARY', $mod_strings['LBL_REPORT_FEBRUARY']);
$smarty->assign('LBL_REPORT_MARCH', $mod_strings['LBL_REPORT_MARCH']);
$smarty->assign('LBL_REPORT_APRIL', $mod_strings['LBL_REPORT_APRIL']);
$smarty->assign('LBL_REPORT_MAY', $mod_strings['LBL_REPORT_MAY']);
$smarty->assign('LBL_REPORT_JUNE', $mod_strings['LBL_REPORT_JUNE']);
$smarty->assign('LBL_REPORT_JULY', $mod_strings['LBL_REPORT_JULY']);
$smarty->assign('LBL_REPORT_AUGUST', $mod_strings['LBL_REPORT_AUGUST']);
$smarty->assign('LBL_REPORT_SEPTEMBER', $mod_strings['LBL_REPORT_SEPTEMBER']);
$smarty->assign('LBL_REPORT_OCTOBER', $mod_strings['LBL_REPORT_OCTOBER']);
$smarty->assign('LBL_REPORT_NOVEMBER', $mod_strings['LBL_REPORT_NOVEMBER']);
$smarty->assign('LBL_REPORT_DECEMBER', $mod_strings['LBL_REPORT_DECEMBER']);


$smarty->assign('LBL_REPORT_YES', $mod_strings['LBL_REPORT_YES']);
$smarty->assign('LBL_REPORT_NO', $mod_strings['LBL_REPORT_NO']);
$smarty->assign('LBL_REPORT_GROUPED', $mod_strings['LBL_REPORT_GROUPED']);
$smarty->assign('LBL_REPORT_DETAIL', $mod_strings['LBL_REPORT_DETAIL']);
$smarty->assign('LBL_REPORT_MONTH_DETAIL', $mod_strings['LBL_REPORT_MONTH_DETAIL']);
$smarty->assign('LBL_REPORT_FQUARTER_DETAIL', $mod_strings['LBL_REPORT_FQUARTER_DETAIL']);
$smarty->assign('LBL_REPORT_NQUARTER_DETAIL', $mod_strings['LBL_REPORT_NQUARTER_DETAIL']);
$smarty->assign('LBL_REPORT_ASC', $mod_strings['LBL_REPORT_ASC']);
$smarty->assign('LBL_REPORT_DESC', $mod_strings['LBL_REPORT_DESC']);
$smarty->assign('LBL_REPORT_UNAVAILABLE', $mod_strings['LBL_REPORT_UNAVAILABLE']);

$smarty->assign('LBL_REPORT_EQUALS', $mod_strings['LBL_REPORT_EQUALS']);
$smarty->assign('LBL_REPORT_NOT_EQUALS', $mod_strings['LBL_REPORT_NOT_EQUALS']);
$smarty->assign('LBL_REPORT_LIKE', $mod_strings['LBL_REPORT_LIKE']);
$smarty->assign('LBL_REPORT_NOT_LIKE', $mod_strings['LBL_REPORT_NOT_LIKE']);
$smarty->assign('LBL_REPORT_ONE_OF', $mod_strings['LBL_REPORT_ONE_OF']);
$smarty->assign('LBL_REPORT_NOT_ONE_OF', $mod_strings['LBL_REPORT_NOT_ONE_OF']);
$smarty->assign('LBL_REPORT_BEFORE_DATE', $mod_strings['LBL_REPORT_BEFORE_DATE']);
$smarty->assign('LBL_REPORT_AFTER_DATE', $mod_strings['LBL_REPORT_AFTER_DATE']);
$smarty->assign('LBL_REPORT_BETWEEN', $mod_strings['LBL_REPORT_BETWEEN']);
$smarty->assign('LBL_REPORT_NOT_BETWEEN', $mod_strings['LBL_REPORT_NOT_BETWEEN']);
$smarty->assign('LBL_REPORT_LAST', $mod_strings['LBL_REPORT_LAST']);
$smarty->assign('LBL_REPORT_NOT_LAST', $mod_strings['LBL_REPORT_NOT_LAST']);
$smarty->assign('LBL_REPORT_THIS', $mod_strings['LBL_REPORT_THIS']);
$smarty->assign('LBL_REPORT_NOT_THIS', $mod_strings['LBL_REPORT_NOT_THIS']);
$smarty->assign('LBL_REPORT_THEESE', $mod_strings['LBL_REPORT_THEESE']);
$smarty->assign('LBL_REPORT_NEXT', $mod_strings['LBL_REPORT_NEXT']);
$smarty->assign('LBL_REPORT_NOT_NEXT', $mod_strings['LBL_REPORT_NOT_NEXT']);

$smarty->assign('LBL_REPORT_LESS_THAN', $mod_strings['LBL_REPORT_LESS_THAN']);
$smarty->assign('LBL_REPORT_MORE_THAN', $mod_strings['LBL_REPORT_MORE_THAN']);

$smarty->assign('LBL_REPORT_DAY', $mod_strings['LBL_REPORT_DAY']);
$smarty->assign('LBL_REPORT_WEEK', $mod_strings['LBL_REPORT_WEEK']);
$smarty->assign('LBL_REPORT_MONTH', $mod_strings['LBL_REPORT_MONTH']);
$smarty->assign('LBL_REPORT_FQUARTER', $mod_strings['LBL_REPORT_FQUARTER']);
$smarty->assign('LBL_REPORT_NQUARTER', $mod_strings['LBL_REPORT_NQUARTER']);
$smarty->assign('LBL_REPORT_FYEAR', $mod_strings['LBL_REPORT_FYEAR']);
$smarty->assign('LBL_REPORT_NYEAR', $mod_strings['LBL_REPORT_NYEAR']);
$smarty->assign('LBL_REPORT_TRUE', $mod_strings['LBL_REPORT_TRUE']);
$smarty->assign('LBL_REPORT_FALSE', $mod_strings['LBL_REPORT_FALSE']);

$smarty->assign('LBL_REPORT_ALL', $mod_strings['LBL_REPORT_ALL']);
$smarty->assign('LBL_REPORT_LIMIT', $mod_strings['LBL_REPORT_LIMIT']);
$smarty->assign('LBL_REPORT_FIRST_RESULTS', $mod_strings['LBL_REPORT_FIRST_RESULTS']);
$smarty->assign('LBL_REPORT_LAST_RESULTS', $mod_strings['LBL_REPORT_LAST_RESULTS']);


//mostramos el template
$smarty->display('modules/Reports/templates/EditView.tpl');

?>