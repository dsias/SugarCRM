<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


$dictionary['Report'] = array('table' => 'reports','audited'=>true, 'unified_search' => true,'duplicate_merge'=>true,
		'comment' => 'AlineaSol Reports module',
		'fields' => array (
  
  'description' =>
  array (
    'name' => 'description',
    'vname' => 'LBL_DESCRIPTION',
    'type' => 'varchar',
    'len' => '255',
    'comment' => 'Report description',
    'importable' => 'required',
  ),
  'last_run' =>
  array (
    'name' => 'last_run',
    'vname' => 'LBL_LAST_RUN',
    'type' => 'datetime',
    'comment' => 'Last execution of the report',
    'importable' => 'required',
  ),
  'report_module' =>
  array (
    'name' => 'report_module',
    'vname' => 'LBL_REPORT_MODULE',
    'type' => 'varchar',
    'len' => '50',
    'comment' => 'Module of the report',
    'importable' => 'required',
  ),
  'report_scope' =>
  array (
    'name' => 'report_scope',
    'vname' => 'LBL_REPORT_SCOPE',
    'type' => 'text',
    'comment' => 'Scope of the report',
  ),
  'report_fields' =>
  array (
    'name' => 'report_fields',
    'vname' => 'LBL_REPORT_FIELDS',
    'type' => 'text',
    'comment' => 'Fields of the report',
  ),
  'report_filters' =>
  array (
    'name' => 'report_filters',
    'vname' => 'LBL_REPORT_FILTERS',
    'type' => 'text',
    'comment' => 'Filters of the report',
  ),
  'report_charts_detail' =>
  array (
    'name' => 'report_charts_detail',
    'vname' => 'LBL_REPORT_CHARTS_DETAIL',
    'type' => 'text',
    'comment' => 'Charts of the report',
  ),
  'report_type' =>
  array (
    'name' => 'report_type',
    'vname' => 'LBL_REPORT_TYPE',
    'type' => 'varchar',
    'len' => '12',
    'comment' => 'report type: manual or scheduled',
    'importable' => 'required',
  ),
  'report_attachment_format' =>
  array (
    'name' => 'report_attachment_format',
    'vname' => 'LBL_REPORT_ATTACHMENT_FORMAT',
    'type' => 'varchar',
    'len' => '8',
    'comment' => 'report attachment format: html, pdf or csv',
    'importable' => 'required',
  ),
  'report_tasks' =>
  array (
    'name' => 'report_tasks',
    'vname' => 'LBL_REPORT_TASKS',
    'type' => 'varchar',
    'len' => '255',
    'comment' => 'Tasks of the report',
  ),
  'report_charts' =>
  array (
    'name' => 'report_charts',
    'vname' => 'LBL_REPORT_CHARTS',
    'type' => 'varchar',
    'len' => '4',
    'comment' => 'Display or not report charts',
  ),
  'email_list' =>
  array (
    'name' => 'email_list',
    'vname' => 'LBL_EMAIL_LIST',
    'type' => 'varchar',
    'len' => '255',
    'comment' => 'Email list to distribute scheduled or manual reports',
  ),
  'scheduled_images' =>
  array (
    'name' => 'scheduled_images',
    'vname' => 'LBL_SCHEDULED_IMAGES',
    'type' => 'tinyint',
    'len' => '1',
    'comment' => 'Activates or deactivates the images on scheduled report emails',
  ),
  'row_index_display' =>
  array (
    'name' => 'row_index_display',
    'vname' => 'LBL_ROW_INDEX_DISPLAY',
    'type' => 'tinyint',
    'len' => '1',
    'default' => '0',
    'comment' => 'Activates or deactivates the index display at display screen',
  ),
  'results_limit' =>
  array (
    'name' => 'results_limit',
    'vname' => 'LBL_RESULTS_LIMIT',
    'type' => 'varchar',
    'len' => '255',
    'default' => 'all',
    'comment' => 'limit the entries for the Report main query: first or last n entries',
  ),
)

//This enables optimistic locking for Saves From EditView
	,'optimistic_locking'=>true,
);


VardefManager::createVardef('Reports','Report', array('default', 'assignable',));

?>
