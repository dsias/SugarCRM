<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $current_user, $mod_strings, $app_strings, $timedate, $app_list_strings, $db, $sugar_config;

if(!ACLController::checkAccess('Reports', 'list', true))
	die("<font color='red'>".$app_strings["LBL_EMAIL_DELETE_ERROR_DESC"]."</font>"); 


error_reporting(E_ALL & ~E_NOTICE);  

require_once('modules/Reports/Report.php');
require_once('modules/Administration/asolConfigBean.php');

/*ASOL
$phpDateTime = new DateTime(null, new DateTimeZone($current_user->getPreference("timezone")));
$hourOffset = $phpDateTime->getOffset();
echo $hourOffset." / ".($hourOffset/3600)."h";
ASOL*/

$tmpFilesDir = "modules/Reports/tmpReportFiles/";
$currentDir = getcwd()."/";

//recogemos las variables del formulario de busqueda de Reports
//Cambiar nombre variables para que al cancelar no se monte un cristo
$name = (isset($_REQUEST['name_basic'])) ? $_REQUEST['name_basic'] : "";
$report_module = (isset($_REQUEST['module_type_basic'])) ? $_REQUEST['module_type_basic'] : "";
$report_scope = (isset($_REQUEST['scope_basic'])) ? $_REQUEST['scope_basic'] : "";
$report_type = (isset($_REQUEST['type_basic'])) ? $_REQUEST['type_basic'] : "";
$assigned_user_id = (isset($_REQUEST['assigned_user_id'])) ? $_REQUEST['assigned_user_id'] : "";
$assigned_user_name = (isset($_REQUEST['assigned_user_name'])) ? $_REQUEST['assigned_user_name'] : "";
$return_action = (isset($_REQUEST['return_action'])) ? $_REQUEST['return_action'] : "";
$email_list = (isset($_REQUEST['email_list'])) ? $_REQUEST['email_list'] : "";

$selectedRows = (isset($_REQUEST['selectedRows'])) ? $_REQUEST['selectedRows'] : "";

//recogemos el orden y el campo por el que se ordena el report actual
$field_sort = (isset($_REQUEST['field_sort'])) ? $_REQUEST['field_sort'] : "";
$sort_direction = (isset($_REQUEST['sort_direction'])) ? $_REQUEST['sort_direction'] : "";

//Instanciamos nuestra clase Report que extiende de SugarBean
$focus = new Report();


//obtenemos las entradas por p�gina de la tabla asol_config
$sqlCfg = "SELECT id, config FROM asol_config WHERE created_by = '".$current_user->id."'";
$rsCfg = $focus->getSelectionResults($sqlCfg, false);


//Comprobamos si existe una entrada de configuracion para el usuario actvo
//sino existe se crea
$focusCfg = new AsolConfig();

$sqlCfg = "SELECT id, config FROM asol_config WHERE created_by = '".$current_user->id."'";
$rsCfg = $focus->getSelectionResults($sqlCfg, false);

if (count($rsCfg) == 0){
	
	$sqlCfgAux = "SELECT config FROM asol_config WHERE created_by = '1'";
	$rsCfgAux = $focus->getSelectionResults($sqlCfgAux, false);
	
	$cfgAux = explode("|",$rsCfgAux[0]['config']);
		
	$db->query("INSERT IGNORE INTO `asol_config` (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `deleted`, `config`) VALUES ('".create_guid()."', '".$current_user->name."', '".gmdate("Y-m-d H:i:s")."', '".gmdate("Y-m-d H:i:s")."', '".$current_user->id."', '".$current_user->id."', 0, '".$cfgAux[0]."|15|landscape|".$cfgAux[3]."|120|".$cfgAux[5]."')");

	$rsCfg = $focus->getSelectionResults($sqlCfg, false);
}

$cfg = explode("|",$rsCfg[0]['config']);
$entries_per_page = $cfg[1];


//Obtener los m�dulo a los que tiene acceso el usuario activo
$sqlModules = "";

$acl_modules = ACLAction::getUserActions($current_user->id);


$i=0;
foreach($acl_modules as $key=>$mod){

	if($mod['module']['access']['aclaccess'] >= 0){
	
		$module[$i] = $key;
		$translatedModule[$i] = (isset($app_list_strings['moduleList'][$key])) ? $app_list_strings['moduleList'][$key] : $key;
		$sqlModules .= "'".$key."',";
		$i++;
		
	}

}

$sqlModules = substr($sqlModules, 0, -1);


//Is Domains Installed
$DomainsQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name='AlineaSolDomains' AND status='installed'");
$DomainsRow = $db->fetchByAssoc($DomainsQuery);
//Is Domains Installed


//Paginado
$sql = "SELECT reports.*, users.user_name";
if ($DomainsRow['count'] > 0)
	$sql .= ", asol_domains.name as domain_name";
$sqlFrom = " FROM reports";
$sqlJoin = " LEFT JOIN users ON reports.assigned_user_id=users.id";
if ($DomainsRow['count'] > 0)
	$sqlJoin .= " LEFT JOIN asol_domains ON reports.asol_domain_id=asol_domains.id";
$sqlWhere = " WHERE reports.deleted = 0 AND reports.name LIKE '%".$name."%' AND reports.report_module LIKE '%".$report_module."%'";
//Filtramos los Reports de los modulos al que el user activo no tiene acceso
$sqlWhere .= " AND reports.report_module IN (".$sqlModules.") AND reports.report_scope LIKE '%".$report_scope."%'";
$sqlWhere .= " AND reports.report_type LIKE '%".$report_type."%'";

if (!$current_user->is_admin) {

	$idsRoles = array();
	$queryUserRoles = $db->query("SELECT DISTINCT role_id FROM acl_roles_users WHERE user_id='".$current_user->id."' AND deleted=0");
	while($queryRow = $db->fetchByAssoc($queryUserRoles))
		$idsRoles[] = $queryRow['role_id'];
		
	$sqlWhere .= " AND (report_scope = 'public' OR reports.assigned_user_id = '".$current_user->id."' OR reports.created_by = '".$current_user->id."'";

	$sqlWhereRoles = " OR ((report_scope LIKE 'role%') AND (";
	foreach ($idsRoles as $idRole)
		$sqlWhereRoles .= " report_scope LIKE '%".$idRole."%' OR";
	$sqlWhereRoles = substr($sqlWhereRoles, 0, -2)."))";
	
	if (empty($idsRoles))
		$sqlWhereRoles = "";
		
	$sqlWhere .= $sqlWhereRoles." )";
	
}


//Is Domains Installed
if ($DomainsRow['count'] > 0) {

	if ((!$current_user->is_admin) || (($current_user->is_admin) && (!empty($current_user->asol_default_domain)))){
				
		require_once ('modules/asol_Domains/asol_Domains.php');
		$domainsBean = new asol_domains();
		$domainsBean->retrieve($current_user->asol_default_domain);
		
		if ($domainsBean->asol_domain_enabled) {
				
			$sqlWhere .= " AND ( (reports.asol_domain_id='".$current_user->asol_default_domain."')";
			
			if ($current_user->asol_only_my_domain == 0) {
			
				//asol_domain_child_share_depth
				
				$parentQuery = $db->query("SELECT DISTINCT asol_domains_id_c as parent_domain FROM asol_domains WHERE id = '".$current_user->asol_default_domain."'");
				$parentRow = $db->fetchByAssoc($parentQuery);
				$parentDomain = $parentRow['parent_domain'];
				$i=1;
				
				while (!empty($parentDomain)) {
				
					$sqlWhere .= " OR ((reports.asol_domain_id = '".$parentRow['parent_domain']."') AND (reports.asol_domain_child_share_depth >= $i) AND (reports.asol_published_domain = 1)) ";
					
					$parentQuery = $db->query("SELECT DISTINCT asol_domains_id_c as parent_domain FROM asol_domains WHERE id = '".$parentDomain."'");
					$parentRow = $db->fetchByAssoc($parentQuery);
					$parentDomain = $parentRow['parent_domain'];
					
					$i++;
				
				} 
				
				//asol_domain_child_share_depth condition
				
				//asol_multi_create_domain 
				$sqlWhere .= " OR ((reports.asol_multi_create_domain LIKE '%;".$current_user->asol_default_domain.";%') AND (reports.asol_published_domain = 1)) ";
				//asol_multi_create_domain 
				
				
				//View hierarchy (any item above its hierarchy coul be seen)
				$childDomainsIds = (!empty($current_user->asol_child_domains_array)) ? $current_user->asol_child_domains_array : $current_user->getChildDomainsWithDepth($current_user->asol_default_domain);
				$childDomainsStr = Array();
				foreach ($childDomainsIds as $key=>$domainId) {
					if (!$domainId['enabled'])
						array_splice($childDomainsIds, $key, 1);
					else
						$childDomainsStr[] = $domainId['id'];
				}
				$sqlWhere .= (count($childDomainsIds) > 0) ? "OR (reports.asol_domain_id IN ('".implode("','", $childDomainsStr)."')) )" : ") " ;

			} else {
			
				$sqlWhere .= ") ";
				
			}
			
		} else {
		
			$sqlWhere .= " AND (1!=1) ";
			
		}
					
	
	}
	
}
//Is Domains Installed


$sqlJoinWhere = " AND users.user_name LIKE '%".$assigned_user_name."%'";

$rs = $focus->getSelectionResults("SELECT COUNT(reports.id) AS total FROM reports".$sqlJoin.$sqlWhere.$sqlJoinWhere, false);

$total_entries = $rs[0]['total'];


$page_number = (isset($_REQUEST['page_number'])) ? $_REQUEST['page_number'] : 0;

$sqlOrder = " ORDER BY reports.name ASC";

if ($field_sort != ""){
	
	if ($sort_direction == "")
		$sort_direction = "ASC";
	
	$sqlOrder = " ORDER BY ".$field_sort." ".$sort_direction." ";
	
	if ($sort_direction == "ASC")
		$sort_direction = "DESC";
	else
		$sort_direction = "ASC";
		
}

$sqlLimit = " LIMIT ".$entries_per_page*$page_number.",".$entries_per_page;

$rs = $focus->getSelectionResults($sql.$sqlFrom.$sqlJoin.$sqlWhere.$sqlJoinWhere.$sqlOrder.$sqlLimit, false);


$i=0;

$rows = Array();
$translatedRows = Array();

if (count($rs) > 0){

	foreach($rs as $value){
	
		//echo print_r($value, true)."<br>";
	
		$rows[$i][0] = $value['id'];
		$rows[$i][1] = $value['name'];
		$rows[$i][2] = $value['report_module'];
		$translatedRows[$i][2] = (isset($app_list_strings['moduleList'][$value['report_module']])) ? $app_list_strings['moduleList'][$value['report_module']] : $value['report_module'];

		$value['date_modified'] = $timedate->handle_offset($value['date_modified'], $timedate->get_db_date_time_format());
		if((!$timedate->check_matching_format($value['date_modified'], $timedate->get_date_format())) && ($value['date_modified']!=""))
		$rows[$i][3] = $timedate->swap_formats($value['date_modified'], $timedate->get_db_date_time_format(), $timedate->get_date_time_format());

		$rows[$i][4] = $value['report_fields'];
		$rows[$i][5] = $value['report_filters'];
		$rows[$i][6] = $value['description'];
		$rows[$i][7] = $value['assigned_user_id'];
		$rows[$i][8] = $value['user_name'];

		$value['last_run'] = $timedate->handle_offset($value['last_run'], $timedate->get_db_date_time_format());
		if((!$timedate->check_matching_format($value['last_run'], $timedate->get_date_format())) && ($value['last_run']!=""))
		$rows[$i][9] = $timedate->swap_formats($value['last_run'], $timedate->get_db_date_time_format(), $timedate->get_date_time_format());
		
		
		$rows[$i][10] = $value['report_scope'];
		
		if (strpos($value['report_scope'], "public") !== false)
			$translatedRows[$i][10] = $mod_strings['LBL_REPORT_PUBLIC'];
		else if (strpos($value['report_scope'], "private") !== false)
			$translatedRows[$i][10] = $mod_strings['LBL_REPORT_PRIVATE'];
		else
			$translatedRows[$i][10] = $mod_strings['LBL_REPORT_ROLE'];
		
		//$translatedRows[$i][10] = ($value['report_scope'] == "public") ? $mod_strings['LBL_REPORT_PUBLIC'] : $mod_strings['LBL_REPORT_PRIVATE'];
		
		$rows[$i][11] = (($current_user->id == $value['created_by']) || ($current_user->is_admin)) ? true : false;
		$rows[$i][12] = $value['report_type'];
		$translatedRows[$i][12] = ($value['report_type'] == "manual") ? $mod_strings['LBL_REPORT_MANUAL'] : $mod_strings['LBL_REPORT_SCHEDULED'];
		
		if (strpos($value['report_tasks'], "\${GMT}") !== false)
			$value['report_tasks'] = substr($value['report_tasks'], 0, -6);
			
		$rows[$i][13] = $value['report_tasks'];
		
		$tmpEmail = explode("\${pipe}", $value['email_list']);
		$rows[$i][14] = $tmpEmail[0];
		$rows[$i][19] = $tmpEmail[1];
		
		$rows[$i][16] = $value['report_attachment_format'];
		$rows[$i][17] = $value['report_charts'];
		$rows[$i][18] = $value['scheduled_images'];
		$rows[$i][20] = $value['row_index_display'];
		$rows[$i][21] = $value['results_limit'];
		$rows[$i][22] = $value['report_charts_detail'];
		
		
		//Is Domains Installed
		if ($DomainsRow['count'] > 0)
			$rows[$i][23] = $value["domain_name"];
		//Is Domains Installed
		
		
		$tasks = explode("|",$value['report_tasks']);
		
		$taskState = "";
		
		$actualDate = gmdate("Y-m-d");
		
		for ($l=0; $l<count($tasks); $l++){
			
			if (($value['report_type'] == "scheduled")){
			
				$currentTasks = explode(":",$tasks[$l]);
				
				if ((($currentTasks[5] == "inactive") || ($currentTasks[4] < $actualDate)) && (($taskState == "I") || ($taskState == ""))){
					$taskState = "I";
				}	
				
				if ((($currentTasks[5] == "active") || ($currentTasks[4] >= $actualDate)) && (($taskState == "A") || ($taskState == ""))){
					$taskState = "A";
				}
				
				if ((($currentTasks[5] == "inactive") || ($currentTasks[4] < $actualDate)) && ($taskState == "A")){
					$taskState = "S";
				}
	
				if ((($currentTasks[5] == "active") && ($currentTasks[4] >= $actualDate)) && ($taskState == "I")){
					$taskState = "S";
				}
					
			}
				
		}
		
		$rows[$i][15] = $taskState;

		$i++;
	}

}

//Obtenemos los valores relaciones con el paginado
$data['total_entries'] = $total_entries;
$data['entries_per_page'] = $entries_per_page;
$data['current_entries'] = count($rs);
$data['page_number'] = $page_number;
$data['num_pages'] = (($total_entries % $entries_per_page) != 0) ? floor($total_entries / $entries_per_page) : floor($total_entries / $entries_per_page) -1 ;

//creamos una nueva instancia de smarty
$smarty = new Sugar_Smarty();

//le asignamos los valores necesarios smarty

//Is Domains Installed
if ($DomainsRow['count'] > 0) {
	$smarty->assign('is_domains_installed', 1);
	$smarty->assign('LBL_REPORT_DOMAIN', $mod_strings['LBL_REPORT_DOMAIN']);
} else 
	$smarty->assign('is_domains_installed', 0);
//Is Domains Installed

$smarty->assign('available_modules', $module);
$smarty->assign('available_translated_modules', $translatedModule);

$smarty->assign('name', $name);
$smarty->assign('report_module', $report_module);
$smarty->assign('report_scope', $report_scope);
$smarty->assign('report_type', $report_type);
$smarty->assign('assigned_user_id', $assigned_user_id);
$smarty->assign('assigned_user_name', $assigned_user_name);

$smarty->assign('rows', $rows);
$smarty->assign('translatedRows', $translatedRows);
$smarty->assign('data', $data);

//Asignamos los valores para el ordenado
$smarty->assign('field_sort', $field_sort);
$smarty->assign('sort_direction', $sort_direction);


//Asignamos todos los labels de $mod_Srings & $app_strings
$smarty->assign('LBL_REPORT_NAME', $mod_strings['LBL_REPORT_NAME']);
$smarty->assign('LBL_REPORT_MODULE', $mod_strings['LBL_REPORT_MODULE']);
$smarty->assign('LBL_REPORT_LAST_RUN', $mod_strings['LBL_REPORT_LAST_RUN']);
$smarty->assign('LBL_REPORT_LAST_UPDATE', $mod_strings['LBL_REPORT_LAST_UPDATE']);
$smarty->assign('LBL_REPORT_ASSIGNED_USER', $mod_strings['LBL_REPORT_ASSIGNED_USER']);
$smarty->assign('LBL_REPORT_SCOPE', $mod_strings['LBL_REPORT_SCOPE']);
$smarty->assign('LBL_REPORT_TYPE', $mod_strings['LBL_REPORT_TYPE']);
$smarty->assign('LBL_REPORT_ASSIGNED_TO', $mod_strings['LBL_REPORT_ASSIGNED_TO']);
$smarty->assign('LBL_REPORT_SELECT_FILE', $mod_strings['LBL_REPORT_SELECT_FILE']);

$smarty->assign('LBL_REPORT_ALL', $mod_strings['LBL_REPORT_ALL']);
$smarty->assign('LBL_REPORT_MANUAL', $mod_strings['LBL_REPORT_MANUAL']);
$smarty->assign('LBL_REPORT_SCHEDULED', $mod_strings['LBL_REPORT_SCHEDULED']);
$smarty->assign('LBL_REPORT_PRIVATE', $mod_strings['LBL_REPORT_PRIVATE']);
$smarty->assign('LBL_REPORT_PUBLIC', $mod_strings['LBL_REPORT_PUBLIC']);
$smarty->assign('LBL_REPORT_ROLE', $mod_strings['LBL_REPORT_ROLE']);
$smarty->assign('LBL_REPORT_IMPORT', $mod_strings['LBL_REPORT_IMPORT']);
$smarty->assign('LBL_REPORT_EXPORT', $mod_strings['LBL_REPORT_EXPORT']);
$smarty->assign('LBL_REPORTS_LIST', $mod_strings['LBL_REPORTS_LIST']);
$smarty->assign('LBL_REPORTS_HOME', $mod_strings['LBL_REPORTS_HOME']);
$smarty->assign('MSG_REPORT_DELETE_ALERT', $mod_strings['MSG_REPORT_DELETE_ALERT']);

$smarty->assign('LBL_REPORT_EXECUTE', $mod_strings['LBL_REPORT_EXECUTE']);
$smarty->assign('LBL_REPORT_COPY', $mod_strings['LBL_REPORT_COPY']);
$smarty->assign('LBL_REPORT_EDIT', $mod_strings['LBL_REPORT_EDIT']);
$smarty->assign('LBL_REPORT_EXPORT_ONE', $mod_strings['LBL_REPORT_EXPORT_ONE']);

$smarty->assign('LBL_DELETE', $app_strings['LBL_DELETE']);

$smarty->assign('LBL_SEARCH', $app_strings['LBL_SEARCH_BUTTON_LABEL']);
$smarty->assign('LBL_CLEAR_BUTTON_LABEL', $app_strings['LBL_CLEAR_BUTTON_LABEL']);
$smarty->assign('LBL_SELECT_BUTTON_LABEL', $app_strings['LBL_SELECT_BUTTON_LABEL']);

$smarty->assign('LNK_LIST_START', $app_strings['LNK_LIST_START']);
$smarty->assign('LNK_LIST_PREVIOUS', $app_strings['LNK_LIST_PREVIOUS']);
$smarty->assign('LNK_LIST_NEXT', $app_strings['LNK_LIST_NEXT']);
$smarty->assign('LNK_LIST_END', $app_strings['LNK_LIST_END']);


$smarty->assign('REPORTS_ACL_VIEW', ACLController::checkAccess('Reports', 'view', true));
$smarty->assign('REPORTS_ACL_EDIT', ACLController::checkAccess('Reports', 'edit', true));
$smarty->assign('REPORTS_ACL_DELETE', ACLController::checkAccess('Reports', 'delete', true));
$smarty->assign('REPORTS_ACL_IMPORT', ACLController::checkAccess('Reports', 'import', true));
$smarty->assign('REPORTS_ACL_EXPORT', ACLController::checkAccess('Reports', 'export', true));


/*
//TRAZAS
$smarty->assign('selectedRows', $cfgAux[0]);
$smarty->assign('sql2', $sql2);
$smarty->assign('modStr', $mod_strings['LBL_REPORT_FIELDS']);
*/

//finalmente mostramos la plantilla cn los valores recibidos
$smarty->display('modules/Reports/templates/index.tpl');


if ($return_action == "exportReport"){
	
	if ((empty($selectedRows)) || (count($selectedRows) == 0)) {
		
		//Obtener los datos de cada report y meterlos en exported reports de $k
		$sqlExport = "SELECT name, description, report_module, report_fields, report_filters, report_type, report_tasks, email_list, created_by, report_charts, report_attachment_format, scheduled_images, row_index_display, results_limit, report_charts_detail FROM reports WHERE id='".$_REQUEST['record']."'";
		$rsExport = $focus->getSelectionResults($sqlExport, false);
		
			
		//creamos un array bidmensional indexado y asociativo con una celda por cada campo del report
		$exportedReport[0]["version"] = "ASOLcrm Reports v 2.0.0";
		
		$exportedReport[0]["name"] = $rsExport[0]['name'];
		$exportedReport[0]["description"] = $rsExport[0]['description'];
		$exportedReport[0]["report_module"] = $rsExport[0]['report_module'];
		$exportedReport[0]["report_fields"] = $rsExport[0]['report_fields'];
		$exportedReport[0]["report_filters"] = $rsExport[0]['report_filters'];	
		
		$exportedReport[0]["report_type"] = $rsExport[0]['report_type'];
		$exportedReport[0]["report_tasks"] = $rsExport[0]['report_tasks'];
		$exportedReport[0]["email_list"] = $rsExport[0]['email_list'];
		
		$exportedReport[0]["report_charts"] = $rsExport[0]['report_charts'];
		$exportedReport[0]["report_attachment_format"] = $rsExport[0]['report_attachment_format'];
		
		$exportedReport[0]["scheduled_images"] = $rsExport[0]['scheduled_images'];
		
		$exportedReport[0]["row_index_display"] = $rsExport[0]['row_index_display'];
		$exportedReport[0]["results_limit"] = $rsExport[0]['results_limit'];
		
		$exportedReport[0]["report_charts_detail"] = $rsExport[0]['report_charts_detail'];
		
		$exportName = $rsExport[0]['name'];

	} else {
		
		$l=0;
		
		for ($k=0; $k<count($selectedRows); $k++){
			
			//Obtener los datos de cada report y meterlos en exported reports de $k
			$sqlExport = "SELECT name, description, report_module, report_fields, report_filters, report_type, report_tasks, email_list, created_by, report_charts, report_attachment_format, scheduled_images, row_index_display, results_limit, report_charts_detail FROM reports WHERE id='".$selectedRows[$k]."'";
			$rsExport = $focus->getSelectionResults($sqlExport, false);
			
			//if ($rsExport[0]['created_by'] == $current_user->id){

				$exportedReport[$l]["version"] = "ASOLcrm Reports v 2.0.0";
			
				$exportedReport[$l]["name"] = $rsExport[0]['name'];
				$exportedReport[$l]["description"] = $rsExport[0]['description'];
				$exportedReport[$l]["report_module"] = $rsExport[0]['report_module'];
				$exportedReport[$l]["report_fields"] = $rsExport[0]['report_fields'];
				$exportedReport[$l]["report_filters"] = $rsExport[0]['report_filters'];	
				
				$exportedReport[$l]["report_type"] = $rsExport[0]['report_type'];
				$exportedReport[$l]["report_tasks"] = $rsExport[0]['report_tasks'];
				$exportedReport[$l]["email_list"] = $rsExport[0]['email_list'];
				
				$exportedReport[$l]["report_charts"] = $rsExport[0]['report_charts'];
				$exportedReport[$l]["report_attachment_format"] = $rsExport[0]['report_attachment_format'];
				
				$exportedReport[$l]["scheduled_images"] = $rsExport[0]['scheduled_images'];
				
				$exportedReport[$l]["row_index_display"] = $rsExport[0]['row_index_display'];
				$exportedReport[$l]["results_limit"] = $rsExport[0]['results_limit'];
				
				$exportedReport[$l]["report_charts_detail"] = $rsExport[0]['report_charts_detail'];
				
				$l++;
			
			//}
			
		}
		
		if (count($selectedRows) == 1)
			$exportName = $exportedReport[0]["name"];
		else 
			$exportName = "ASOL Report"."_".date("Ymd")."T".date("Hi");
		
	}
	
	
	$serializedFile = serialize($exportedReport);

	
	header("Cache-Control: private");
	header("Content-Type: application/octet-stream");
	header('Content-Disposition: attachment; filename="'.$exportName.'.txt"');
	header("Content-Description: File Transfer");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".mb_strlen($serializedFile, '8bit'));
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Pragma: public");
	 
	ob_clean();
	flush();

	echo $serializedFile;

	exit;


} else if ($return_action == "importReport"){

	$size = $_FILES['importedReport']['size'];// tama�o en bytes del archivo recibido
	$type = $_FILES['importedReport']['type'];// tipo mime del archivo, por ejemplo image/gif
	$name = $_FILES['importedReport']['name'];// nombre original del archivo
	$tmpName = $_FILES['importedReport']['tmp_name'];// nombre del archivo temporal


	if ($name != "") {

		//guardamos el archivo a la carpeta files
		$target =  $currentDir.$tmpFilesDir.time()."_".$name;

		copy($_FILES['importedReport']['tmp_name'],$target);

		$descriptor = fopen($target, "r");

		$serializedReport = fread($descriptor, filesize($target));
		$report = unserialize($serializedReport);

		fclose($descriptor);
		unlink($target);

		for ($k=0; $k<count($report); $k++){ 
		
			if ((count($report[$k]) == 11) && ($report[$k]['version'] == "ASOLcrm Reports v 1.1")){
	
				$focus->id = "";
				//Comprobar si existe un report con el mismo nombre para el usuario
				$flag = false;
				for ($i=0; $i<count($rows); $i++){
					
					if ($report[$k]['name'] == $rows[$i][1]){
						$flag = true;
						break;
					}		
					
				}
				
				if (!$flag)
					$focus->name = $report[$k]['name'];
				else 
					$focus->name = $report[$k]['name']."_".date("Ymd")."T".date("Hi");
				
				$focus->description = $report[$k]['description'];
				$focus->assigned_user_id = $current_user->id;
				$focus->report_module = $report[$k]['report_module'];
				$focus->report_scope = "private";
				$focus->report_fields = $report[$k]['report_fields'];
				$focus->report_filters = $report[$k]['report_filters'];
				$focus->report_type = $report[$k]['report_type'];
				$focus->report_attachment_format = $report[$k]['report_attachment_format'];
				$focus->report_charts = $report[$k]['report_charts'];
				
				$focus->report_tasks = $report[$k]['report_tasks'];
				$focus->email_list = $report[$k]['email_list'];
					
				$focus->save();
				
			} else if ((count($report[$k]) == 12) && ($report[$k]['version'] == "ASOLcrm Reports v 1.2.2")){
	
				$focus->id = "";
				//Comprobar si existe un report con el mismo nombre para el usuario
				$flag = false;
				for ($i=0; $i<count($rows); $i++){
					
					if ($report[$k]['name'] == $rows[$i][1]){
						$flag = true;
						break;
					}		
					
				}
				
				if (!$flag)
					$focus->name = $report[$k]['name'];
				else 
					$focus->name = $report[$k]['name']."_".date("Ymd")."T".date("Hi");
				
				$focus->description = $report[$k]['description'];
				$focus->assigned_user_id = $current_user->id;
				$focus->report_module = $report[$k]['report_module'];
				$focus->report_scope = "private";
				$focus->report_fields = $report[$k]['report_fields'];
				$focus->report_filters = $report[$k]['report_filters'];
				$focus->report_type = $report[$k]['report_type'];
				$focus->report_attachment_format = $report[$k]['report_attachment_format'];
				$focus->report_charts = $report[$k]['report_charts'];
				
				$focus->report_tasks = $report[$k]['report_tasks'];
				$focus->email_list = $report[$k]['email_list'];

				$focus->scheduled_images = $report[$k]['scheduled_images'];
			
				$focus->save();
				
			} else if ((count($report[$k]) == 15) && ($report[$k]['version'] == "ASOLcrm Reports v 2.0.0")) {
			
				$focus->id = "";
				//Comprobar si existe un report con el mismo nombre para el usuario
				$flag = false;
				for ($i=0; $i<count($rows); $i++){
					
					if ($report[$k]['name'] == $rows[$i][1]){
						$flag = true;
						break;
					}		
					
				}
				
				if (!$flag)
					$focus->name = $report[$k]['name'];
				else 
					$focus->name = $report[$k]['name']."_".date("Ymd")."T".date("Hi");
				
				$focus->description = $report[$k]['description'];
				$focus->assigned_user_id = $current_user->id;
				$focus->report_module = $report[$k]['report_module'];
				$focus->report_scope = "private";
				$focus->report_fields = $report[$k]['report_fields'];
				$focus->report_filters = $report[$k]['report_filters'];
				$focus->report_type = $report[$k]['report_type'];
				$focus->report_attachment_format = $report[$k]['report_attachment_format'];
				$focus->report_charts = $report[$k]['report_charts'];
				
				$focus->report_tasks = $report[$k]['report_tasks'];
				$focus->email_list = $report[$k]['email_list'];

				$focus->scheduled_images = $report[$k]['scheduled_images'];
				
				$focus->row_index_display = $report[$k]['row_index_display'];
				$focus->results_limit = $report[$k]['results_limit'];
				
				$focus->report_charts_detail = $report[$k]['report_charts_detail'];
			
				$focus->save();
			
			} else {
				
				$focus->id = "";
				//Comprobar si existe un report con el mismo nombre para el usuario
				$flag = false;
				for ($i=0; $i<count($rows); $i++){
					
					if ($report[$k]['name'] == $rows[$i][1]){
						$flag = true;
						break;
					}		
					
				}
				
				if (!$flag)
					$focus->name = $report[$k]['name'];
				else 
					$focus->name = $report[$k]['name']."_".date("Ymd")."T".date("Hi");
				
				$focus->description = $report[$k]['description'];
				$focus->assigned_user_id = $current_user->id;
				$focus->report_module = $report[$k]['report_module'];
				$focus->report_scope = "private";
				$focus->report_fields = $report[$k]['report_fields'];
				$focus->report_filters = $report[$k]['report_filters'];
				$focus->report_type = "manual";
				$focus->report_attachment_format = "HTML";
				$focus->report_charts = "No";
				
				$focus->report_tasks = "";
				$focus->email_list = "";
					
				$focus->save();
				
			}

		}
		
		header("Location: ./index.php?module=Reports&action=index");

	}

} 

?>