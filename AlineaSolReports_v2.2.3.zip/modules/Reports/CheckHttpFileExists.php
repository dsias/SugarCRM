<?php

global $db;

$tmpFilesDir = "modules/Reports/tmpReportFiles/";
$httpHtmlFile = $_REQUEST['httpHtmlFile'];

if (!file_exists($tmpFilesDir.$httpHtmlFile)) {

	$returnedString = "false";

	/*
	if ((isset($sugar_config['asolReportsDispatcherMaxRequests'])) && ($sugar_config['asolReportsDispatcherMaxRequests'] > 0) && (isset($_REQUEST["reportRequestId"]))) { //Only if dispatcher is activated
		
		$sqlExecuting = "SELECT status FROM reports_dispatcher WHERE id='".$_REQUEST["reportRequestId"]."' LIMIT 1";
		$rsExecuting = $db->query($sqlExecuting);
		$rowExecuting = $db->fetchByAssoc($rsExecuting);
		
		if ($rowExecuting[0]["status"] == "executing")		
			$returnedString = "exec";
		
		$sqlLastRecall = "UPDATE reports_dispatcher SET last_recall='".gmdate("Y-m-d H:i:s")."' WHERE id='".$_REQUEST["reportRequestId"]."'";
		$db->query($sqlLastRecall);
			
	}*/
	
	echo $returnedString;

} else {

    $importHttpFile = fopen($tmpFilesDir.$httpHtmlFile, "r");
    $HttpContent = fread($importHttpFile, filesize($tmpFilesDir.$httpHtmlFile));
    fclose($importHttpFile);

    echo $HttpContent;

}

?>