<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $timedate, $current_user, $sugar_config;

$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;


$focus = new Report();

//Si es un nuevo report, no se le pasa el id, si ya existe se le pasa el id para realizar el update del registro

$delete = (!isset($_REQUEST['delete'])) ? false : ($_REQUEST['delete'] == "true") ? true : false;

if (!$delete) {

	if ($_REQUEST['record'] != "")
		$focus->id = $_REQUEST['record'];
	
	$focus->name = $_REQUEST['report_name'];
	
	$focus->assigned_user_id = $_REQUEST['assigned_user_id'];
	$focus->description = $_REQUEST['description'];
	$focus->report_module = $_REQUEST['report_module'];
	
	$report_scope_role_array = (isset($_REQUEST['report_scope_role'])) ? $_REQUEST['report_scope_role'] : array();
	$focus->report_scope = ($_REQUEST['report_scope'] == "public") ? $_REQUEST['report_scope'] : $_REQUEST['report_scope']."\${dp}".implode("\${comma}", $report_scope_role_array);
	$focus->report_charts = $_REQUEST['report_charts'];
	$focus->scheduled_images = (!isset($_REQUEST['scheduled_images'])) ? 0 : ($_REQUEST['scheduled_images'] == 1) ? 1 : 0;
	$focus->report_fields = $_REQUEST['selected_fields'];
	$focus->report_charts_detail = $_REQUEST['selected_charts']; 
	$focus->row_index_display = ($_REQUEST['row_index_display'] == 1) ? 1 : 0;
	$focus->results_limit = $_REQUEST['results_limit'];
	//formateo las fechas de los filtros
	$filterValues = ($_REQUEST['selected_filters'] == "\${v2.2.0}") ? array() : explode("\${pipe}", $_REQUEST['selected_filters']);
	
	foreach ($filterValues as $key=>$value){
		
		$values = explode("\${dp}", $value);
		
		if ((($values[4] == "date") || ($values[4] == "datetime")) && (($values[1] != "last") && ($values[1] != "this") && ($values[1] != "theese") && ($values[1] != "next") && ($values[1] != "not last") && ($values[1] != "not this") && ($values[1] != "not next"))){
			
			if((!$timedate->check_matching_format($values[2], $GLOBALS['timedate']->dbDayFormat)) && ($values[2]!="")) {

				$values[2] = $timedate->swap_formats($values[2], $timedate->get_date_format(), $GLOBALS['timedate']->dbDayFormat );
			}
			
			if((!$timedate->check_matching_format($values[3], $GLOBALS['timedate']->dbDayFormat)) && ($values[3]!="")) {

				$values[3] = $timedate->swap_formats($values[3], $timedate->get_date_format(), $GLOBALS['timedate']->dbDayFormat );
			}
			
		}

		
		$filterValues[$key] = implode("\${dp}", $values);
		
	}
	
	$filters = empty($filterValues) ? "\${v2.2.0}" : implode("\${pipe}", $filterValues);
	
	$focus->report_filters = $filters;
	$focus->report_type = $_REQUEST['report_type'];
	$focus->report_attachment_format = $_REQUEST['report_attachment_format'];
	
	//reformatear la fecha de finalizacion de las areas progrmadas al formato de la BDD
	$tasks = ($_REQUEST['selected_tasks'] == "\${GMT}") ? array() : explode("|", $_REQUEST['selected_tasks']);
	
	foreach($tasks as $key=>$task){
		
		$values = explode(":", $task);
		
		if((!$timedate->check_matching_format($values[4], $GLOBALS['timedate']->dbDayFormat)) && ($values[4]!=""))
			$values[4] = $timedate->swap_formats($values[4], $timedate->get_date_format(), $GLOBALS['timedate']->dbDayFormat );
		
		
		$userTZ = $current_user->getPreference("timezone");
		
		$phpDateTime = new DateTime(null, new DateTimeZone($userTZ));
		$hourOffset = $phpDateTime->getOffset()*-1;
		
		/*OLD OFFSET HANDLING
		$gmtOffsetArray = $timezones[$userTZ];
		$hourOffset = (($timedate->get_hour_offset(true, $gmtOffsetArray))*-3600)-date('Z');
		*/
		
		$time1 = explode(",", $values[3]);
		$values[3] = date("H,i", @mktime($time1[0],$time1[1],0,date("m"),date("d"),date("Y"))+$hourOffset);
		
		$tasks[$key] = implode(":", $values);
			
	}
	
	$focus->report_tasks = (empty($tasks)) ? "\${GMT}" : implode("|", $tasks);
	$focus->email_list = $_REQUEST['email_list']."\${pipe}".$_REQUEST['email_blind_copy'];
	
} else {
	
	$focus->id = $_REQUEST['record'];
	$focus->deleted = 1;

}

$focus->save();

//Redireccionar a la pantalla 'search.php'
if(isset($_POST['return_module']) && $_POST['return_module'] != "") $return_module = $_POST['return_module'];
else $return_module = "Reports";
if(isset($_POST['return_action']) && $_POST['return_action'] != "") $return_action = $_POST['return_action'];
else $return_action = "index";
if(isset($_POST['return_id']) && $_POST['return_id'] != "") $return_id = $_POST['return_id'];

	
if ($asolLogLevelEnabled)
	$GLOBALS['log']->asol("ASOL-----------------------------------------------Saved record with id of ".$focus->id);
else
	$GLOBALS['log']->debug("ASOL-----------------------------------------------Saved record with id of ".$focus->id);

header("Location: index.php?action=".$return_action."&module=".$return_module);

?>