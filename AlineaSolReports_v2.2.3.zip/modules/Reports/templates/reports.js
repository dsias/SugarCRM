function RememberRows(idTable, row_Values, calendar_dateformat, AddButton, DeleteButton, ArrowUp, ArrowDown, DeleteFilter, FilterUp, FilterDown, DeleteRowAlert, DeleteFilterAlert, AlphanumericAlert, lbl_yes, lbl_no, lbl_grouped, lbl_detail, lbl_month_detail, lbl_fquarter_detail, lbl_nquarter_detail, lbl_asc, lbl_desc, lbl_unavailable, lbl_equals, lbl_not_equals, lbl_less_than, lbl_more_than, lbl_like, lbl_not_like, lbl_one_of, lbl_not_one_of, lbl_before_date, lbl_after_date, lbl_between, lbl_not_between, lbl_last, lbl_not_last, lbl_this, lbl_not_this, lbl_theese, lbl_next, lbl_not_next, lbl_day, lbl_week, lbl_month, lbl_fquarter, lbl_nquarter, lbl_fyear, lbl_nyear, lbl_true, lbl_false, lbl_pie, lbl_bar, lbl_monday, lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday, lbl_january, lbl_february, lbl_march, lbl_april, lbl_may, lbl_june, lbl_july, lbl_august, lbl_september, lbl_october, lbl_november, lbl_december, lbl_auto, lbl_visible, lbl_user_input, escapeTokens) {

        var table = document.getElementById(idTable);

        var rows = (escapeTokens == "true") ? row_Values.split("${pipe}") : row_Values.split("|");

        if (row_Values != "") {

                for (var i = 0; i < rows.length; i++) {

                        var values = (escapeTokens == "true") ? rows[i].split("${dp}") : rows[i].split(":");

                        var row = document.createElement("tr");
                        row.setAttribute("class", "oddListRowS1");
                        
                        var cell_Field = document.createElement("td");
                        var cell_Alias = document.createElement("td");
                        var cell_Display = document.createElement("td");
                        var cell_Sort_Dir = document.createElement("td");
                        var cell_Sort_Seq = document.createElement("td");
                        var cell_Function = document.createElement("td");
                        var cell_Layout_Group = document.createElement("td");
                        var cell_Group_By_Seq = document.createElement("td");
                        var cell_Buttons = document.createElement("td");
                        cell_Buttons.align = "right";
                        var cell_Order_Arrows = document.createElement("td");

                        cell_Field.innerHTML = "<b>" + values[0] + "</b>";

                        cell_Alias.innerHTML = "<input type='text' name='alias' class='alias' size='15' maxlength='' value='"
                                        + values[1] + "' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

                        cell_Display.innerHTML = (values[2] == "Yes") ? "<select class='display' name='display'>"
                                        + "<option value='Yes' selected>"+lbl_yes+"</option>"
                                        + "<option value='No'>"+lbl_no+"</option>" + "</select>"
                                        : "<select class='display' name='display'>"
                                                        + "<option value='Yes'>"+lbl_yes+"</option>"
                                                        + "<option value='No' selected>"+lbl_no+"</option>"
                                                        + "</select>";

                        if (values[3] == "0")
                                cell_Sort_Dir.innerHTML = "<select class='sort_dir' name='sort_dir'>"
                                                + "<option  value='0' selected></option>"
                                                + "<option  value='ASC'>"+lbl_asc+"</option>"
                                                + "<option value='DESC'>"+lbl_desc+"</option>" + "</select>";
                        else if (values[3] == "ASC")
                                cell_Sort_Dir.innerHTML = "<select class='sort_dir' name='sort_dir'>"
                                                + "<option value='0'></option>"
                                                + "<option value='ASC' selected>"+lbl_asc+"</option>"
                                                + "<option value='DESC'>"+lbl_desc+"</option>" + "</select>";
                        else
                                cell_Sort_Dir.innerHTML = "<select class='sort_dir' name='sort_dir'>"
                                                + "<option value='0'></option>"
                                                + "<option value='ASC'>"+lbl_asc+"</option>"
                                                + "<option value='DESC' selected>"+lbl_desc+"</option>"
                                                + "</select>";

                        cell_Sort_Seq.innerHTML = "<input type='text' name='sort_seq' class='sort_seq' size='4' maxlength='' value='"
                                        + values[4] + "' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

						if (values[8].indexOf("int") === 0)
							values[8] = "int";
		
						
                        switch (values[8]) {

                        case "int":
						case "double":
                        case "currency":
						case "enum":
                            if (values[5] == "0")
                                    cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                    + "<option value='0' selected></option>"
                                                    + "<option value='COUNT'>COUNT</option>"
                                                    + "<option value='MIN'>MIN</option>"
                                                    + "<option value='MAX'>MAX</option>"
                                                    + "<option value='SUM'>SUM</option>"
                                                    + "<option value='AVG'>AVG</option>" + "</select>";
                            else if (values[5] == "COUNT")
                                	cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
	                                                + "<option value='0'></option>"
	                                                + "<option value='COUNT' selected>COUNT</option>"
	                                                + "<option value='MIN'>MIN</option>"
	                                                + "<option value='MAX'>MAX</option>"
	                                                + "<option value='SUM'>SUM</option>"
	                                                + "<option value='AVG'>AVG</option>" + "</select>";
                            else if (values[5] == "MIN")
                                    cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                    + "<option value='0'></option>"
                                                    + "<option value='COUNT'>COUNT</option>"
                                                    + "<option value='MIN' selected>MIN</option>"
                                                    + "<option value='MAX'>MAX</option>"
                                                    + "<option value='SUM'>SUM</option>"
                                                    + "<option value='AVG'>AVG</option>" + "</select>";
                            else if (values[5] == "MAX")
                                    cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                    + "<option value='0'></option>"
                                                    + "<option value='COUNT'>COUNT</option>"
                                                    + "<option value='MIN'>MIN</option>"
                                                    + "<option value='MAX' selected>MAX</option>"
                                                    + "<option value='SUM'>SUM</option>"
                                                    + "<option value='AVG'>AVG</option>" + "</select>";
                            else if (values[5] == "SUM")
                                    cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                    + "<option value='0'></option>"
                                                    + "<option value='COUNT'>COUNT</option>"
                                                    + "<option value='MIN'>MIN</option>"
                                                    + "<option value='MAX'>MAX</option>"
                                                    + "<option value='SUM' selected>SUM</option>"
                                                    + "<option value='AVG'>AVG</option>" + "</select>";
                            else
                                    cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                    + "<option value='0'></option>"
                                                    + "<option value='COUNT'>COUNT</option>"
                                                    + "<option value='MIN'>MIN</option>"
                                                    + "<option value='MAX'>MAX</option>"
                                                    + "<option value='SUM'>SUM</option>"
                                                    + "<option value='AVG' selected>AVG</option>"
                                                    + "</select>";
                            break;
                                
                        case "datetime":
                        case "date":
                                if (values[5] == "0")
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='MIN'>MIN</option>"
                                                        + "<option value='MAX'>MAX</option>" + "</select>";
                                else if (values[5] == "MIN")
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='MIN' selected>MIN</option>"
                                                        + "<option value='MAX'>MAX</option>" + "</select>";
                                else
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='MIN'>MIN</option>"
                                                        + "<option value='MAX' selected>MAX</option>"
                                                        + "</select>"

                                break;

                        case "bool":
                        case "tinyint(1)":
                        	if (values[5] == "0")
                                cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                + "<option value='0' selected></option>"
                                                + "<option value='COUNT'>COUNT</option>"
                                                + "<option value='SUM'>SUM</option>" + "</select>";
		                        else if (values[5] == "COUNT")
		                                cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
		                                                + "<option value='0'></option>"
		                                                + "<option value='COUNT' selected>COUNT</option>"
		                                                + "<option value='SUM'>SUM</option>" + "</select>";
		                        else
		                                cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
		                                                + "<option value='0'></option>"
		                                                + "<option value='COUNT'>COUNT</option>"
		                                                + "<option value='SUM' selected>SUM</option>"
		                                                + "</select>"
		
		                        break;
                                break;

                        default:
                                cell_Function.innerHTML = (values[5] == "0") ? "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                + "<option value='0' selected></option>"
                                                + "<option value='COUNT'>COUNT</option>" + "</select>"
                                                : "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"false\", \""+values[0]+"\", \""+values[1]+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                                + "<option value='0'></option>"
                                                                + "<option value='COUNT' selected>COUNT</option>"
                                                                + "</select>"
                                break;

                        }

                        switch (values[8]) {

                        case "datetime":
                        case "date":

                                if (values[6] == "0") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail'>"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail'>"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail'>"+lbl_nquarter_detail+"</option></select>";

                                } else if (values[6] == "Grouped") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped' selected>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail'>"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail'>"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail'>"+lbl_nquarter_detail+"</option></select>";

                                } else if (values[6] == "Detail") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail' selected>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail'>"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail'>"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail'>"+lbl_nquarter_detail+"</option></select>";

                                } else if (values[6] == "Month Detail") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail' selected>"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail'>"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail'>"+lbl_nquarter_detail+"</option></select>";

                                } else if (values[6] == "Fiscal Quarter Detail") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail'>"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail' selected>"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail'>"+lbl_nquarter_detail+"</option></select>";

                                } else if (values[6] == "Natural Quarter Detail") {
                                                cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail'>"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail'>"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail' selected>"+lbl_nquarter_detail+"</option></select>";
                                }

                                break;

                        default:
                                if (values[6] == "0") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option></select>";
                                } else if (values[6] == "Grouped") {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped' selected>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option></select>";
                                } else {
                                        cell_Layout_Group.innerHTML = "<select class='layout'>"
                                                        + "<option value='0'></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail' selected>"+lbl_detail+"</option></select>";
                                }
                                break;
                        }

                        cell_Group_By_Seq.innerHTML = "<input type='text' name='group_seq' class='group_seq' size='4' maxlength='' value='"
                                        + values[7] + "' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

                        if (!values[13])
                               values[13] = values[12];

                        var commaToken = (escapeTokens == "true") ? "${comma}" : ",";
                        var dpToken = (escapeTokens == "true") ? "${dp}" : ":";
						
						if (values[12].split("${comma}").length <= 1)
							commaToken = ",";
						
                        cell_Buttons.innerHTML = "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_addline.png' alt='"
                                        + values[0]
                                        + "${dp}"
                                        + values[8]
                                        + "${dp}"
                                        + values[12].split(commaToken).join("|")
                                        + "${dp}"
                                        + values[13].split(commaToken).join("|")
                                        + "' title=\""+AddButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='InsertFilters(\"filters_Table\", (this.alt.split(\""+dpToken+"\"))[0], (this.alt.split(\""+dpToken+"\"))[1], (this.alt.split(\""+dpToken+"\"))[2], (this.alt.split(\""+dpToken+"\"))[3], \""
                                        + values[9]
                                        + "\", "
                                        + values[11]
                                        + ",\""
                                        + calendar_dateformat
                                        + "\", \""
                                        + DeleteFilter
                                        + "\", \""
                                        + FilterUp
                                        + "\", \""
                                        + FilterDown
                                        + "\", \""
                                        + DeleteFilterAlert
                                        + "\", \"" + lbl_equals + "\", \"" + lbl_not_equals + "\", \"" + lbl_less_than + "\", \"" + lbl_more_than + "\", \"" + lbl_like + "\", \"" + lbl_not_like + "\", \"" + lbl_one_of + "\", \"" + lbl_not_one_of + "\", \"" + lbl_before_date + "\", \"" + lbl_after_date + "\", \"" + lbl_between + "\", \"" + lbl_not_between + "\", \"" + lbl_last + "\", \"" + lbl_not_last + "\", \"" + lbl_this + "\", \"" + lbl_not_this + "\", \"" + lbl_theese + "\", \"" + lbl_next + "\", \"" + lbl_not_next + "\", \"" + lbl_day + "\", \"" + lbl_week + "\", \"" + lbl_month + "\", \"" + lbl_fquarter + "\", \"" + lbl_nquarter + "\", \"" + lbl_fyear + "\", \"" + lbl_nyear + "\", \"" + lbl_true + "\", \"" + lbl_false + "\", \"" + lbl_monday + "\", \"" + lbl_tuesday + "\", \"" + lbl_wednesday + "\", \"" + lbl_thursday + "\", \"" + lbl_friday + "\", \"" + lbl_saturday + "\", \"" + lbl_sunday + "\", \"" + lbl_january + "\", \"" + lbl_february + "\", \"" + lbl_march + "\", \"" + lbl_april + "\", \"" + lbl_may + "\", \"" + lbl_june + "\", \"" + lbl_july + "\", \"" + lbl_august + "\", \"" + lbl_september + "\", \"" + lbl_october + "\", \"" + lbl_november + "\", \"" + lbl_december + "\", \"" + lbl_auto + "\", \"" + lbl_visible + "\", \"" + lbl_user_input
										+ "\", \""
                                        + escapeTokens
                                        + "\")' name='add_button'>"
                                        + "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteRowAlert+"\")) { delete_field_filters(\"filters_Table\", \""+values[9]+"\", \""+values[0]+"\"); this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode); insert_Chart(\"charts_Table\", \""+values[10]+"\", \""+values[11]+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }' name='del_button'>"
                                        + "<input type='hidden' name='value_type' value='"
                                        + values[8] + "'>"
                                        + "<input type='hidden' name='key' value='" + values[9]
                                        + "'>" + "<input type='hidden' name='is_Related' value='"
                                        + values[10] + "'>"
                                        + "<input type='hidden' name='index' value='" + values[11]
                                        + "'>" + "<input type='hidden' name='options' value='"
                                        + values[12].split(commaToken).join("${comma}") + "'>"
                                        + "<input type='hidden' name='options_db' value='"
                                        + values[13].split(commaToken).join("${comma}") + "'>";

                        cell_Order_Arrows.innerHTML = "&nbsp;<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_up.png' title=\""+ArrowUp+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFieldsUp'; document.create_form.rowIndex.value='"
                                        + (table.getElementsByTagName("tr").length - 1)
                                        + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">"
                                        + "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_down.png' title=\""+ArrowDown+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFieldsDown'; document.create_form.rowIndex.value='"
                                        + (table.getElementsByTagName("tr").length - 1)
                                        + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table');  document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">";

                        row.appendChild(cell_Field);
                        row.appendChild(cell_Alias);
                        row.appendChild(cell_Display);
                        row.appendChild(cell_Sort_Dir);
                        row.appendChild(cell_Sort_Seq);
                        row.appendChild(cell_Function);
                        row.appendChild(cell_Layout_Group);
                        row.appendChild(cell_Group_By_Seq);
                        row.appendChild(cell_Buttons);
                        row.appendChild(cell_Order_Arrows);

                        table.appendChild(row);

                }

        }

}

function RememberFilters(idTable, filter_Values, calendar_dateformat, DeleteButton, ArrowUp, ArrowDown, DeleteFilterAlert, lbl_equals, lbl_not_equals, lbl_less_than, lbl_more_than, lbl_like, lbl_not_like, lbl_one_of, lbl_not_one_of, lbl_before_date, lbl_after_date, lbl_between, lbl_not_between, lbl_last, lbl_not_last, lbl_this, lbl_not_this, lbl_theese, lbl_next, lbl_not_next, lbl_day, lbl_week, lbl_month, lbl_fquarter, lbl_nquarter, lbl_fyear, lbl_nyear, lbl_true, lbl_false, lbl_monday, lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday, lbl_january, lbl_february, lbl_march, lbl_april, lbl_may, lbl_june, lbl_july, lbl_august, lbl_september, lbl_october, lbl_november, lbl_december, lbl_auto, lbl_visible, lbl_user_input, escapeTokens, escapeTokensComma) {

        var param1 = new Array();
        var param2 = new Array();

        var table = document.getElementById(idTable);

        var filters = (escapeTokens == "true") ? filter_Values.split("${pipe}") : filter_Values.split("|") ;


        if (filter_Values != "") {

                for ( var i = 0; i < filters.length; i++) {

                        var values = (escapeTokens == "true") ? filters[i].split("${dp}") : filters[i].split(":") ;

                        // recuperamos las opciones de los comboBoxes
						//if (values[7].split("${comma}").length <= 1)
							//escapeTokensComma = false;
							
						
                        var options = (escapeTokensComma == "true") ? values[7].split("${comma}") : values[7].split(",");
                        var options_db;

                        if (!values[8]){

                                values[8] = values[7];
                                options_db = (escapeTokensComma == "true") ? values[7].split("${comma}") : values[7].split(",");

                        }else{

                                options_db = (escapeTokensComma == "true") ? values[8].split("${comma}") : values[8].split(",");

                        }

                        var row = document.createElement("tr");
                        row.setAttribute("class", "oddListRowS1");

                        var cell_Field = document.createElement("td");
                        var cell_Alias = document.createElement("td");
                        var cell_Ref = document.createElement("td");
                        var cell_Behavior = document.createElement("td");
                        var cell_UserInputOptions = document.createElement("td");
                        var cell_Operator = document.createElement("td");
                        var cell_First_Parameter = document.createElement("td");
                        var cell_Second_Parameter = document.createElement("td");
                        var cell_Button = document.createElement("td");
                        cell_Button.align = "right";
                        var cell_Order_Arrows = document.createElement("td");

                        cell_Field.innerHTML = "<b>" + values[0] + "</b>";

                        cell_Alias.innerHTML = (typeof(values[10])=="undefined") ? "<input class='alias' type='text' value=''>" : "<input class='alias' type='text' value='" + values[10] + "'>";
                        
                        cell_Ref.innerHTML = (typeof(values[9])=="undefined") ? "<input class='filter_ref' type='text' value=''>" : "<input class='filter_ref' type='text' value='" + values[9] + "'>";
						
                        switch (values[11]) {
                        
	                        case "auto":
	                        	cell_Behavior.innerHTML = "<select class='behavior' name='behavior'>" +
	                        			"<option value='auto' selected>"+lbl_auto+"</option>" +
	                        			"<option value='visible'>"+lbl_visible+"</option>" +
	                        			"<option value='user_input'>"+lbl_user_input+"</option>" +
	                        			"</select>";
	                        	break;
	                        	
	                        case "visible":
	                        	cell_Behavior.innerHTML = "<select class='behavior' name='behavior'>" +
	                        			"<option value='auto'>"+lbl_auto+"</option>" +
	                        			"<option value='visible' selected>"+lbl_visible+"</option>" +
	                        			"<option value='user_input'>"+lbl_user_input+"</option>" +
	                        			"</select>";
	                        	break;
	                        	
	                        case "user_input":
	                        	cell_Behavior.innerHTML = "<select class='behavior' name='behavior'>" +
	                        			"<option value='auto'>"+lbl_auto+"</option>" +
	                        			"<option value='visible'>"+lbl_visible+"</option>" +
	                        			"<option value='user_input' selected>"+lbl_user_input+"</option>" +
	                        			"</select>";
	                        	break;
                        	
                        	
                        }
                
                        cell_UserInputOptions.innerHTML = "<input class='input_opts' type='text' value='" + values[12] + "'>";
                        
						if (values[4].indexOf("int") === 0)
							values[4] = "int";
						
                        switch (values[4]) {

							case "enum":
									if (values[1] == "equals")
											cell_Operator.innerHTML = "<select onChange='if (this.selectedIndex >= 2){this.parentNode.parentNode.cells[6].childNodes[0].multiple=true;this.parentNode.parentNode.cells[6].childNodes[0].size=3;} else {this.parentNode.parentNode.cells[6].childNodes[0].multiple=false;this.parentNode.parentNode.cells[6].childNodes[0].size=1;}'>"
															+ "<option value='equals' selected>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='one of'>"+lbl_one_of+"</option>"
															+ "<option value='not one of'>"+lbl_not_one_of+"</option>"
															+ "</select>";
									else if (values[1] == "not equals")
											cell_Operator.innerHTML = "<select onChange='if (this.selectedIndex >= 2){this.parentNode.parentNode.cells[6].childNodes[0].multiple=true;this.parentNode.parentNode.cells[6].childNodes[0].size=3;} else {this.parentNode.parentNode.cells[6].childNodes[0].multiple=false;this.parentNode.parentNode.cells[6].childNodes[0].size=1;}'>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals' selected>"+lbl_not_equals+"</option>"
															+ "<option value='one of'>"+lbl_one_of+"</option>"
															+ "<option value='not one of'>"+lbl_not_one_of+"</option>"
															+ "</select>";
									else if (values[1] == "one of")
											cell_Operator.innerHTML = "<select onChange='if (this.selectedIndex >= 2){this.parentNode.parentNode.cells[6].childNodes[0].multiple=true;this.parentNode.parentNode.cells[6].childNodes[0].size=3;} else {this.parentNode.parentNode.cells[6].childNodes[0].multiple=false;this.parentNode.parentNode.cells[6].childNodes[0].size=1;}'>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='one of' selected>"+lbl_one_of+"</option>"
															+ "<option value='not one of'>"+lbl_not_one_of+"</option>"
															+ "</select>";
									else if (values[1] == "not one of")
											cell_Operator.innerHTML = "<select onChange='if (this.selectedIndex >= 2){this.parentNode.parentNode.cells[6].childNodes[0].multiple=true;this.parentNode.parentNode.cells[6].childNodes[0].size=3;} else {this.parentNode.parentNode.cells[6].childNodes[0].multiple=false;this.parentNode.parentNode.cells[6].childNodes[0].size=1;}'>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='one of'>"+lbl_one_of+"</option>"
															+ "<option value='not one of' selected>"+lbl_not_one_of+"</option>"
															+ "</select>";

									var opciones = "";

									for ( var y = 0; y < options_db.length; y++) {

											var sel = "";
											var dollarToken = (escapeTokens == "true") ? "${dollar}" : "$";

											for ( var z = 0; z < (values[2].split(dollarToken)).length; z++) {

													var optVal = (escapeTokens == "true") ? (values[2].split("${dollar}"))[z] : (values[2].split("$"))[z] ;

													if (options_db[y] == optVal) {
															sel = " selected";
													} else {
															if (sel == "")
																	sel = "";
													}

											}

											opciones += "<option" + sel + " value='"+options_db[y]+"'>" + options[y].replace(/\${sq}/g, "\'" )
															+ "</option>";

									}

									// rehacer toda la lista de opciones en funcion del Index y de
									// si es o no related field
									if ((values[1] == "one of") || (values[1] == "not one of"))
											cell_First_Parameter.innerHTML = "<select name='Param1[]' class='Param1' multiple size=3>"
															+ opciones + "</select>";
									else
											cell_First_Parameter.innerHTML = "<select name='Param1[]' class='Param1'>"
															+ opciones + "</select>";

									cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' size='16' maxlength='' value='' style='display:none;'>";

									break;
									
							case "int":
							case "double":
							case "currency":
									if (values[1] == "equals")
											cell_Operator.innerHTML = "<select>"
															+ "<option value='equals' selected>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='less than'>"+lbl_less_than+"</option>"
															+ "<option value='more than'>"+lbl_more_than+"</option>"
															+ "</select>";
									else if (values[1] == "not equals")
											cell_Operator.innerHTML = "<select>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals' selected>"+lbl_not_equals+"</option>"
															+ "<option value='less than'>"+lbl_less_than+"</option>"
															+ "<option value='more than'>"+lbl_more_than+"</option>"
															+ "</select>";
									else if (values[1] == "less than")
											cell_Operator.innerHTML = "<select>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='less than' selected>"+lbl_less_than+"</option>"
															+ "<option value='more than'>"+lbl_more_than+"</option>"
															+ "</select>";
									else
											cell_Operator.innerHTML = "<select>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='less than'>"+lbl_less_than+"</option>"
															+ "<option value='more than' selected>"+lbl_more_than+"</option>"
															+ "</select>";

									cell_First_Parameter.innerHTML = "<input type='text' name='Param1' class='Param1' value='"
													+ values[2] + "'>";
									cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' value='' style='display:none;'>";
									break;

							case "datetime":
							case "date":

									if (values[1] == "equals")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals' selected>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "not equals")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals' selected>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "before date")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date' selected>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "after date")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date' selected>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "between")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between' selected>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "not between")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between' selected>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "last")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last' selected>"+lbl_last+"</option>"
															+ "<option value='not last'>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "not last")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last' selected>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "this")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last' selected>"+lbl_not_last+"</option>"
															+ "<option value='this' selected>"+lbl_this+"</option>"
															+ "<option value='not this'>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "not this")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last' selected>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this' selected>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "theese")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
														+ "<option value='equals'>"+lbl_equals+"</option>"
														+ "<option value='not equals'>"+lbl_not_equals+"</option>"
														+ "<option value='before date'>"+lbl_before_date+"</option>"
														+ "<option value='after date'>"+lbl_after_date+"</option>"
														+ "<option value='between'>"+lbl_between+"</option>"
														+ "<option value='not between'>"+lbl_not_between+"</option>"
														+ "<option value='last'>"+lbl_last+"</option>"
														+ "<option value='not last' selected>"+lbl_not_last+"</option>"
														+ "<option value='this'>"+lbl_this+"</option>"
														+ "<option value='not this'>"+lbl_not_this+"</option>"
														+ "<option value='theese' selected>"+lbl_theese+"</option>"
														+ "<option value='next'>"+lbl_next+"</option>"
														+ "<option value='not next'>"+lbl_not_next+"</option>"
														+ "</select>";
									else if (values[1] == "next")
										cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last' selected>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this' selected>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next' selected>"+lbl_next+"</option>"
															+ "<option value='not next'>"+lbl_not_next+"</option>"
															+ "</select>";
									else if (values[1] == "not next")
											cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) {this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else {this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
															+ "<option value='equals'>"+lbl_equals+"</option>"
															+ "<option value='not equals'>"+lbl_not_equals+"</option>"
															+ "<option value='before date'>"+lbl_before_date+"</option>"
															+ "<option value='after date'>"+lbl_after_date+"</option>"
															+ "<option value='between'>"+lbl_between+"</option>"
															+ "<option value='not between'>"+lbl_not_between+"</option>"
															+ "<option value='last'>"+lbl_last+"</option>"
															+ "<option value='not last' selected>"+lbl_not_last+"</option>"
															+ "<option value='this'>"+lbl_this+"</option>"
															+ "<option value='not this' selected>"+lbl_not_this+"</option>"
															+ "<option value='theese'>"+lbl_theese+"</option>"
															+ "<option value='next'>"+lbl_next+"</option>"
															+ "<option value='not next' selected>"+lbl_not_next+"</option>"
															+ "</select>";

									var fixed_str = "";

									switch (values[2]) {

									case "day":
											fixed_str = "<option value='day' selected>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
											break;

									case "week":
											fixed_str = "<option value='day'>"+lbl_day+"</option>"
													+ "<option value='week' selected>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
											break;

									case "month":
											fixed_str = "<option value='day'>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month' selected>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
									break;

									case "Nquarter":
											fixed_str = "<option value='day'>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter' selected>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
											break;

									case "Fquarter":
											fixed_str = "<option value='day'>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter' selected>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
											break;

									case "Nyear":
											fixed_str = "<option value='day'>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear' selected>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
											break;

									case "Fyear":
											fixed_str = "<option value='day'>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear' selected>"+lbl_fyear+"</option>";
											
											if ((values[1] == "last") || (values[1] == "not last"))
												fixed_str += "<option value='monday'>"+lbl_monday+"</option>"
						                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
						                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
						                                + "<option value='thursday'>"+lbl_thursday+"</option>"
						                                + "<option value='friday'>"+lbl_friday+"</option>"
						                                + "<option value='saturday'>"+lbl_saturday+"</option>"
						                                + "<option value='sunday'>"+lbl_sunday+"</option>"
						                                
						                                + "<option value='january'>"+lbl_january+"</option>"
						                                + "<option value='february'>"+lbl_february+"</option>"
						                                + "<option value='march'>"+lbl_march+"</option>"
						                                + "<option value='april'>"+lbl_april+"</option>"
						                                + "<option value='may'>"+lbl_may+"</option>"
						                                + "<option value='june'>"+lbl_june+"</option>"
						                                + "<option value='july'>"+lbl_july+"</option>"
						                                + "<option value='august'>"+lbl_august+"</option>"
						                                + "<option value='september'>"+lbl_september+"</option>"
						                                + "<option value='october'>"+lbl_october+"</option>"
						                                + "<option value='november'>"+lbl_november+"</option>"
						                                + "<option value='december'>"+lbl_december+"</option>";
											
											break;

									case "monday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday' selected>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "tuesday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday' selected>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "wednesday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday' selected>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "thursday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday' selected>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "friday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday' selected>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "saturday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday' selected>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "sunday":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday' selected>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "january":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january' selected>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "february":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february' selected>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "march":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march' selected>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "april":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april' selected>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "may":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may' selected>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "june":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june' selected>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "july":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july' selected>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "august":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august' selected>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "september":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september' selected>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "october":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october' selected>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "november":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november' selected>"+lbl_november+"</option>"
				                                + "<option value='december'>"+lbl_december+"</option>";
										
										break;
										
									case "december":
										fixed_str = "<option value='day'>"+lbl_day+"</option>"
												+ "<option value='week'>"+lbl_week+"</option>"
												+ "<option value='month'>"+lbl_month+"</option>"
												+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
												+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
												+ "<option value='Nyear'>"+lbl_nyear+"</option>"
												+ "<option value='Fyear'>"+lbl_fyear+"</option>"
										
												+ "<option value='monday'>"+lbl_monday+"</option>"
				                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
				                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
				                                + "<option value='thursday'>"+lbl_thursday+"</option>"
				                                + "<option value='friday'>"+lbl_friday+"</option>"
				                                + "<option value='saturday'>"+lbl_saturday+"</option>"
				                                + "<option value='sunday'>"+lbl_sunday+"</option>"
				                                
				                                + "<option value='january'>"+lbl_january+"</option>"
				                                + "<option value='february'>"+lbl_february+"</option>"
				                                + "<option value='march'>"+lbl_march+"</option>"
				                                + "<option value='april'>"+lbl_april+"</option>"
				                                + "<option value='may'>"+lbl_may+"</option>"
				                                + "<option value='june'>"+lbl_june+"</option>"
				                                + "<option value='july'>"+lbl_july+"</option>"
				                                + "<option value='august'>"+lbl_august+"</option>"
				                                + "<option value='september'>"+lbl_september+"</option>"
				                                + "<option value='october'>"+lbl_october+"</option>"
				                                + "<option value='november'>"+lbl_november+"</option>"
				                                + "<option value='december' selected>"+lbl_december+"</option>";
										
										break;
											
									default:
											fixed_str = "<option value='day' selected>"+lbl_day+"</option>"
													+ "<option value='week'>"+lbl_week+"</option>"
													+ "<option value='month'>"+lbl_month+"</option>"
													+ "<option value='Nquarter'>"+lbl_nquarter+"</option>"
													+ "<option value='Fquarter'>"+lbl_fquarter+"</option>"
													+ "<option value='Nyear'>"+lbl_nyear+"</option>"
													+ "<option value='Fyear'>"+lbl_fyear+"</option>";
											break;

									}

									if ((values[1] == "last") || (values[1] == "this") || (values[1] == "theese") || (values[1] == "next") || (values[1] == "not last") || (values[1] == "not this") || (values[1] == "not next")) {

											cell_First_Parameter.innerHTML = "<input type='text' id='Param1_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' value='' style='display:none;' disabled='true'>"
															+ "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' style='display:none'>"
															+ "<span></span>"
															+ "<select style='display:inline;' onChange='if (this.selectedIndex >= 7) { this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; } else if ((this.parentNode.parentNode.cells[5].childNodes[0].value != \"this\") && (this.parentNode.parentNode.cells[5].childNodes[0].value != \"not this\")) { this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\"; }'>"
															+ fixed_str + "</select>";


											param1[param1.length] = (table.getElementsByTagName("tr").length - 1);

									} else {

											cell_First_Parameter.innerHTML = "<input type='text' id='Param1_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' value='"
															+ values[2]
															+ "'  disabled='true'>"
															+ "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "'>"
															+ "<span></span>"
															+ "<select style='display:none;' onChange='if (this.selectedIndex >= 7) { this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; } else if ((this.parentNode.parentNode.cells[5].childNodes[0].value != \"this\") && (this.parentNode.parentNode.cells[5].childNodes[0].value != \"not this\")) { this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\"; }'>"
															+ fixed_str
															+ "</select>";

											param1[param1.length] = (table.getElementsByTagName("tr").length - 1);

									}

									if ((values[1] == "between") || (values[1] == "not between")) {
											cell_Second_Parameter.innerHTML = "<input type='text' id='Param2_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' value='"
															+ values[3]
															+ "' style='display:inline;' disabled='true'>"
															+ "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger2_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' style='display:inline'>";

											param2[param2.length] = (table.getElementsByTagName("tr").length - 1);

									} else if ((values[1] == "last") || (values[1] == "next") || (values[1] == "not last") || (values[1] == "not next") || (values[1] == "theese")) {

											cell_Second_Parameter.innerHTML = "<input type='text' id='Param2_"
													+ (table.getElementsByTagName("tr").length - 1)
													+ "' value='"
													+ values[3]
													+ "' style='display:inline;'>"
													+ "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger2_"
													+ (table.getElementsByTagName("tr").length - 1)
													+ "' style='display:none'>";

											param2[param2.length] = (table.getElementsByTagName("tr").length - 1);

									} else {
											cell_Second_Parameter.innerHTML = "<input type='text' id='Param2_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' value='"
															+ values[3]
															+ "' style='display:none;' disabled='true'>"
															+ "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger2_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' style='display:none'>";

											param2[param2.length] = (table.getElementsByTagName("tr").length - 1);

									}

									if (values[2] == "last n days") {
											cell_Second_Parameter.innerHTML = "<input type='text' id='Param2_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' value='"
															+ values[3]
															+ "' style='display:inline;' disabled='true'>"
															+ "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger2_"
															+ (table.getElementsByTagName("tr").length - 1)
															+ "' style='display:none'>";

											param2[param2.length] = (table.getElementsByTagName("tr").length - 1);

									}

									break;

							case "bool":
							case "tinyint(1)":
									cell_Operator.innerHTML = (values[1] == "equals") ? "<select>"
													+ "<option value='equals' selected>"+lbl_equals+"</option>"
													+ "<option value='not equals'>"+lbl_not_equals+"</option>"
													+ "</select>"
													: "<select>"
																	+ "<option value='equals'>"+lbl_equals+"</option>"
																	+ "<option value='not equals' selected>"+lbl_not_equals+"</option>"
																	+ "</select>";

									cell_First_Parameter.innerHTML = (values[2] == "true") ? "<select>"
													+ "<option value='true' selected>"+lbl_true+"</option>"
													+ "<option value='false'>"+lbl_false+"</option>" + "</select>"
													: "<select>"
																	+ "<option value='true'>"+lbl_true+"</option>"
																	+ "<option value='false' selected>"+lbl_false+"</option>"
																	+ "</select>";

									cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' value='' style='display:none;'>";
									break;

							default:
								
								if (values[1] == "equals") {
								
									cell_Operator.innerHTML = "<select class='function' name='function'>"
												+ "<option value='equals' selected>"+lbl_equals+"</option>"
												+ "<option value='not equals'>"+lbl_not_equals+"</option>"
												+ "<option value='like'>"+lbl_like+"</option>"
												+ "<option value='not like'>"+lbl_not_like+"</option>"
												+ "</select>";
								
								} else if (values[1] == "not equals") {
								
									cell_Operator.innerHTML = "<select class='function' name='function'>"
												+ "<option value='equals'>"+lbl_equals+"</option>"
												+ "<option value='not equals' selected>"+lbl_not_equals+"</option>"
												+ "<option value='like'>"+lbl_like+"</option>"
												+ "<option value='not like'>"+lbl_not_like+"</option>"
												+ "</select>";
								
								} else if (values[1] == "like") {
								
									cell_Operator.innerHTML = "<select class='function' name='function'>"
												+ "<option value='equals'>"+lbl_equals+"</option>"
												+ "<option value='not equals'>"+lbl_not_equals+"</option>"
												+ "<option value='like' selected>"+lbl_like+"</option>"
												+ "<option value='not like'>"+lbl_not_like+"</option>"
												+ "</select>";
								
								} else if (values[1] == "not like") {
								
									cell_Operator.innerHTML = "<select class='function' name='function'>"
												+ "<option value='equals'>"+lbl_equals+"</option>"
												+ "<option value='not equals'>"+lbl_not_equals+"</option>"
												+ "<option value='like'>"+lbl_like+"</option>"
												+ "<option value='not like' selected>"+lbl_not_like+"</option>"
												+ "</select>";
								
								} 
													
									cell_First_Parameter.innerHTML = '<input type="text" name="Param1" id="Param1" value="'
													+ values[2].replace(/\'/g, "\'") + '">';
									cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' value='' style='display:none;'>";
									
									break;

                        }

						var commaToken = (escapeTokensComma == "true") ? "${comma}" : ",";
						
						if (values[7].split("${comma}").length <= 1)
							commaToken = ",";
						
                        cell_Button.innerHTML = "<img class='asol_icon' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteFilterAlert+"\")) this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode)' name='del_button'>"
                                        + "<input type='hidden' name='value_type' value='"
                                        + values[4]
                                        + "'>"
                                        + "<input type='hidden' name='is_related' value='"
                                        + values[5]
                                        + "'>"
                                        + "<input type='hidden' name='index' value='"
                                        + values[6]
                                        + "'>"
                                        + "<input type='hidden' name='options' value='"
                                        + values[7].split(commaToken).join("${comma}")
                                        + "'>"
                                        + "<input type='hidden' name='options_db' value='"
                                        + values[8].split(commaToken).join("${comma}") + "'>";

                        cell_Order_Arrows.innerHTML = "&nbsp;<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_up.png' title=\""+ArrowUp+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFiltersUp'; document.create_form.rowIndex.value='"
                                        + (table.getElementsByTagName("tr").length -1)
                                        + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table');  document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">"
                                        + "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_down.png' title=\""+ArrowDown+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFiltersDown'; document.create_form.rowIndex.value='"
                                        + (table.getElementsByTagName("tr").length -1)
                                        + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">";

                        row.appendChild(cell_Field);
                        row.appendChild(cell_Alias);
                        row.appendChild(cell_Ref);
                        row.appendChild(cell_Behavior);
                        row.appendChild(cell_UserInputOptions);
                        row.appendChild(cell_Operator);
                        row.appendChild(cell_First_Parameter);
                        row.appendChild(cell_Second_Parameter);
                        row.appendChild(cell_Button);
                        row.appendChild(cell_Order_Arrows);

                        table.appendChild(row);

                }

                //Ejecutamos los scripts de inicializacion
                for ( var i = 0; i < param1.length; i++) {

                        Calendar.setup ({ inputField : "Param1_"+param1[i] , daFormat : calendar_dateformat, button : "trigger_"+param1[i] , singleClick : true, dateStr : '', step : 1, weekNumbers:false });

                }

                for ( var i = 0; i < param2.length; i++) {

                        Calendar.setup ({ inputField : "Param2_"+param2[i] , daFormat : calendar_dateformat, button : "trigger2_"+param2[i] , singleClick : true, dateStr : '', step : 1, weekNumbers:false });

                }


        }

}

function RememberTasks(idTable, task_Values, calendar_dateformat, DeleteTask, DeleteTaskAlert, AlphanumericAlert, lbl_monthly, lbl_weekly, lbl_daily, lbl_active, lbl_inactive, lbl_monday, lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday) {

        var table = document.getElementById(idTable);

        var range_End_Date = Array();

        var rows = task_Values.split("|");

        if (task_Values != "") {

                for ( var i = 0; i < rows.length; i++) {

                        var values = rows[i].split(":");
						
                        var row = document.createElement("tr");
                        row.setAttribute("class", "oddListRowS1");

                        var cell_Task = document.createElement("td");
                        var cell_Range = document.createElement("td");
                        var cell_Day_Parameter = document.createElement("td");
                        var cell_Time_Parameter = document.createElement("td");
                        var cell_End_Date = document.createElement("td");
                        var cell_State = document.createElement("td");
                        var cell_Button = document.createElement("td");
                        cell_Button.align = "right";


                        cell_Task.innerHTML = "<input type='text' name='task_name' class='task_name' size='30' maxlength='' value='"+values[0]+"' title='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

                        if (values[1] == "monthly"){

                                cell_Range.innerHTML = "<select class='execution_Range' name='execution_Range' " +
                                                "onChange='if (this.selectedIndex == 0){this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"inline\"} else if (this.selectedIndex == 1){ this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"inline\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\" } else {this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\"} '>" +
                                                "<option value='monthly' selected>"+lbl_monthly+"</option>" +
                                                "<option value='weekly'>"+lbl_weekly+"</option>" +
                                                "<option value='daily'>"+lbl_daily+"</option>" +
                                        "</select>";

                        } else if (values[1] == "weekly"){

                                cell_Range.innerHTML = "<select class='execution_Range' name='execution_Range' " +
                                                "onChange='if (this.selectedIndex == 0){this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"inline\"} else if (this.selectedIndex == 1){ this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"inline\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\" } else {this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\"} '>" +
                                                "<option value='monthly'>"+lbl_monthly+"</option>" +
                                                "<option value='weekly' selected>"+lbl_weekly+"</option>" +
                                                "<option value='daily'>"+lbl_daily+"</option>" +
                                        "</select>";

                        } else {

                                        cell_Range.innerHTML = "<select class='execution_Range' name='execution_Range' " +
                                        "onChange='if (this.selectedIndex == 0){this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"inline\"} else if (this.selectedIndex == 1){ this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"inline\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\" } else {this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\"} '>" +
                                        "<option value='monthly'>"+lbl_monthly+"</option>" +
                                        "<option value='weekly'>"+lbl_weekly+"</option>" +
                                        "<option value='daily' selected>"+lbl_daily+"</option>" +
                                "</select>";

                        }

                        //mostrar o ocultar en funcion de weekly, monthly o daily
                        if (values[1] == "monthly") {

                                cell_Day_Parameter.innerHTML = "<select class='range_Day_Value' name='range_Day_Value' style='display: inline;'>" +
                                                        "<option value='1'>01</option>" +
                                                        "<option value='2'>02</option>" +
                                                        "<option value='3'>03</option>" +
                                                        "<option value='4'>04</option>" +
                                                        "<option value='5'>05</option>" +
                                                        "<option value='6'>06</option>" +
                                                        "<option value='7'>07</option>" +
                                                        "<option value='8'>08</option>" +
                                                        "<option value='9'>09</option>" +
                                                        "<option value='10'>10</option>" +
                                                        "<option value='11'>11</option>" +
                                                        "<option value='12'>12</option>" +
                                                        "<option value='13'>13</option>" +
                                                        "<option value='14'>14</option>" +
                                                        "<option value='15'>15</option>" +
                                                        "<option value='16'>16</option>" +
                                                        "<option value='17'>17</option>" +
                                                        "<option value='18'>18</option>" +
                                                        "<option value='19'>19</option>" +
                                                        "<option value='20'>20</option>" +
                                                        "<option value='21'>21</option>" +
                                                        "<option value='22'>22</option>" +
                                                        "<option value='23'>23</option>" +
                                                        "<option value='24'>24</option>" +
                                                        "<option value='25'>25</option>" +
                                                        "<option value='26'>26</option>" +
                                                        "<option value='27'>27</option>" +
                                                        "<option value='28'>28</option>" +
                                                        "<option value='29'>29</option>" +
                                                        "<option value='30'>30</option>" +
                                                        "<option value='31'>31</option>" +
                                                "</select>" +

                                                "<select class='range_Week_Value' name='range_Week_Value' style='display: none;'>" +
                                                        "<option value='1' selected>"+lbl_monday+"</option>" +
                                                        "<option value='2'>"+lbl_tuesday+"</option>" +
                                                        "<option value='3'>"+lbl_wednesday+"</option>" +
                                                        "<option value='4'>"+lbl_thursday+"</option>" +
                                                        "<option value='5'>"+lbl_friday+"</option>" +
                                                        "<option value='6'>"+lbl_saturday+"</option>" +
                                                        "<option value='7'>"+lbl_sunday+"</option>" +
                                                "</select>";

                        } else if (values[1] == "weekly"){

                                        cell_Day_Parameter.innerHTML = "<select class='range_Day_Value' name='range_Day_Value' style='display: none;'>" +
                                        "<option value='1'>01</option>" +
                                        "<option value='2'>02</option>" +
                                        "<option value='3'>03</option>" +
                                        "<option value='4'>04</option>" +
                                        "<option value='5'>05</option>" +
                                        "<option value='6'>06</option>" +
                                        "<option value='7'>07</option>" +
                                        "<option value='8'>08</option>" +
                                        "<option value='9'>09</option>" +
                                        "<option value='10'>10</option>" +
                                        "<option value='11'>11</option>" +
                                        "<option value='12'>12</option>" +
                                        "<option value='13'>13</option>" +
                                        "<option value='14'>14</option>" +
                                        "<option value='15'>15</option>" +
                                        "<option value='16'>16</option>" +
                                        "<option value='17'>17</option>" +
                                        "<option value='18'>18</option>" +
                                        "<option value='19'>19</option>" +
                                        "<option value='20'>20</option>" +
                                        "<option value='21'>21</option>" +
                                        "<option value='22'>22</option>" +
                                        "<option value='23'>23</option>" +
                                        "<option value='24'>24</option>" +
                                        "<option value='25'>25</option>" +
                                        "<option value='26'>26</option>" +
                                        "<option value='27'>27</option>" +
                                        "<option value='28'>28</option>" +
                                        "<option value='29'>29</option>" +
                                        "<option value='30'>30</option>" +
                                        "<option value='31'>31</option>" +
                                "</select>" +

                                "<select class='range_Week_Value' name='range_Week_Value' style='display: inline;'>" +
                                        "<option value='1' selected>"+lbl_monday+"</option>" +
                                        "<option value='2'>"+lbl_tuesday+"</option>" +
                                        "<option value='3'>"+lbl_wednesday+"</option>" +
                                        "<option value='4'>"+lbl_thursday+"</option>" +
                                        "<option value='5'>"+lbl_friday+"</option>" +
                                        "<option value='6'>"+lbl_saturday+"</option>" +
                                        "<option value='7'>"+lbl_sunday+"</option>" +
                                "</select>";

                        } else {

                                cell_Day_Parameter.innerHTML = "<select class='range_Day_Value' name='range_Day_Value' style='display: none;'>" +
                                "<option value='1'>01</option>" +
                                "<option value='2'>02</option>" +
                                "<option value='3'>03</option>" +
                                "<option value='4'>04</option>" +
                                "<option value='5'>05</option>" +
                                "<option value='6'>06</option>" +
                                "<option value='7'>07</option>" +
                                "<option value='8'>08</option>" +
                                "<option value='9'>09</option>" +
                                "<option value='10'>10</option>" +
                                "<option value='11'>11</option>" +
                                "<option value='12'>12</option>" +
                                "<option value='13'>13</option>" +
                                "<option value='14'>14</option>" +
                                "<option value='15'>15</option>" +
                                "<option value='16'>16</option>" +
                                "<option value='17'>17</option>" +
                                "<option value='18'>18</option>" +
                                "<option value='19'>19</option>" +
                                "<option value='20'>20</option>" +
                                "<option value='21'>21</option>" +
                                "<option value='22'>22</option>" +
                                "<option value='23'>23</option>" +
                                "<option value='24'>24</option>" +
                                "<option value='25'>25</option>" +
                                "<option value='26'>26</option>" +
                                "<option value='27'>27</option>" +
                                "<option value='28'>28</option>" +
                                "<option value='29'>29</option>" +
                                "<option value='30'>30</option>" +
                                "<option value='31'>31</option>" +
                        "</select>" +

                        "<select class='range_Week_Value' name='range_Week_Value' style='display: none;'>" +
                                "<option value='1' selected>"+lbl_monday+"</option>" +
                                "<option value='2'>"+lbl_tuesday+"</option>" +
                                "<option value='3'>"+lbl_wednesday+"</option>" +
                                "<option value='4'>"+lbl_thursday+"</option>" +
                                "<option value='5'>"+lbl_friday+"</option>" +
                                "<option value='6'>"+lbl_saturday+"</option>" +
                                "<option value='7'>"+lbl_sunday+"</option>" +
                        "</select>";

                        }

                        if (values[1] == "monthly"){

                                cell_Day_Parameter.childNodes[0].selectedIndex=values[2]-1;

                        }else if (values[1] == "weekly"){

                                cell_Day_Parameter.childNodes[1].selectedIndex=values[2]-1;

                        }

                        cell_Time_Parameter.innerHTML = "<select class='range_Hour_Value' name='range_Hour_Value'>" +
                                                "<option value='00' selected>00</option>" +
                                                "<option value='01'>01</option>" +
                                                "<option value='02'>02</option>" +
                                                "<option value='03'>03</option>" +
                                                "<option value='04'>04</option>" +
                                                "<option value='05'>05</option>" +
                                                "<option value='06'>06</option>" +
                                                "<option value='07'>07</option>" +
                                                "<option value='08'>08</option>" +
                                                "<option value='09'>09</option>" +
                                                "<option value='10'>10</option>" +
                                                "<option value='11'>11</option>" +
                                                "<option value='12'>12</option>" +
                                                "<option value='13'>13</option>" +
                                                "<option value='14'>14</option>" +
                                                "<option value='15'>15</option>" +
                                                "<option value='16'>16</option>" +
                                                "<option value='17'>17</option>" +
                                                "<option value='18'>18</option>" +
                                                "<option value='19'>19</option>" +
                                                "<option value='20'>20</option>" +
                                                "<option value='21'>21</option>" +
                                                "<option value='22'>22</option>" +
                                                "<option value='23'>23</option>" +
                                        "</select> <b>:</b>" +
                                        "<select class='range_Minute_Value' name='range_Minute_Value'>" +
                                                "<option value='00' selected>00</option>" +
                                                "<option value='15'>15</option>" +
                                                "<option value='30'>30</option>" +
                                                "<option value='45'>45</option>" +
                                        "</select>";
										
                        cell_Time_Parameter.childNodes[0].selectedIndex=values[3].split(",")[0];
                        cell_Time_Parameter.childNodes[3].selectedIndex=values[3].split(",")[1]/15;


                        cell_End_Date.innerHTML = "<input type='text' id='range_End_Date_"+table.getElementsByTagName("tr").length+"' value='"+values[4]+"' disabled=true>" +
                                        "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='range_End_Date_Trigger_"+table.getElementsByTagName("tr").length+"'>";


                        range_End_Date[range_End_Date.length] = table.getElementsByTagName("tr").length;

                        if (values[5] == "active"){

                                cell_State.innerHTML = "<select class='task_State' name='task_State'>" +
                                                "<option value='active' selected>"+lbl_active+"</option>" +
                                                "<option value='inactive'>"+lbl_inactive+"</option>" +
                                                "</select>";

                        } else {

                                cell_State.innerHTML = "<select class='task_State' name='task_State'>" +
                                "<option value='active'>"+lbl_active+"</option>" +
                                "<option value='inactive' selected>"+lbl_inactive+"</option>" +
                                "</select>";

                        }

                        cell_Button.innerHTML = "<img class='asol_icon' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteTask+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteTaskAlert+"\")) this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode)' style='display: inline'>";



                        row.appendChild(cell_Task);
                        row.appendChild(cell_Range);
                        row.appendChild(cell_Day_Parameter);
                        row.appendChild(cell_Time_Parameter);
                        row.appendChild(cell_End_Date);
                        row.appendChild(cell_State);
                        row.appendChild(cell_Button);

                        table.appendChild(row);

                }

        }

        for (var i=0; i<range_End_Date.length; i++){

                Calendar.setup ({ inputField : "range_End_Date_"+range_End_Date[i] , daFormat : calendar_dateformat, button : "range_End_Date_Trigger_"+range_End_Date[i] , singleClick : true, dateStr : '', step : 1, weekNumbers:false });

        }

}

function RememberCharts(idTable, chart_Values, AlphanumericAlert, lbl_yes, lbl_no, lbl_pie, lbl_bar) {

    var table = document.getElementById(idTable);
    
    var rows = chart_Values.split("${pipe}");
    
	if (chart_Values != "") {
	
	    for ( var i = 0; i < rows.length; i++) {
	
	        var values = rows[i].split("${dp}");
			
	        var row = document.createElement("tr");
	        row.setAttribute("class", "oddListRowS1");
	
	        var cell_Field = document.createElement("td");
		    var cell_Name = document.createElement("td");
		    var cell_Function = document.createElement("td");
		    var cell_Display = document.createElement("td");
		    var cell_Type = document.createElement("td");
		    
		    
		    cell_Field.innerHTML = "<b>"+values[0]+"</b>";
		    cell_Name.innerHTML = "<input value='"+values[1]+"' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'/>";
		    cell_Function.innerHTML = "<span class='chart_function_"+values[6]+"_"+values[5]+"'>"+values[2]+"</span>";
		    cell_Display.innerHTML = (values[3] == 'yes') ? "<select><option value='yes' selected>"+lbl_yes+"</option><option value='no'>"+lbl_no+"</option></select>" : "<select><option value='yes'>"+lbl_yes+"</option><option value='no' selected>"+lbl_no+"</option></select>";
		    cell_Type.innerHTML = (values[4] == 'pie') ? "<select><option value='pie' selected>"+lbl_pie+"</option><option value='bar'>"+lbl_bar+"</option></select><input type='hidden' class='index' name='index' value='"+values[5]+"'><input type='hidden' class='is_related' name='is_related' value='"+values[6]+"'>" : "<select><option value='pie'>"+lbl_pie+"</option><option value='bar' selected>"+lbl_bar+"</option></select><input type='hidden' class='index' name='index' value='"+values[5]+"'><input type='hidden' class='is_related' name='is_related' value='"+values[6]+"'>";
		    
		    
		    row.appendChild(cell_Field);
		    row.appendChild(cell_Name);
		    row.appendChild(cell_Function);
		    row.appendChild(cell_Display);
		    row.appendChild(cell_Type);
		
		    table.appendChild(row);
	        
	    }
	    
	}
    
}

function InsertRows(idTable, idSelectFields, fieldLabels, typeFields, optionFields, optionFieldsDb,
                idSelectRelatedFields, key, typeRelatedFields, optionRelatedFields, optionRelatedFieldsDb,
                calendar_dateformat, AddButton, DeleteButton, ArrowUp, ArrowDown, DeleteFilter, FilterUp, 
				FilterDown, DeleteRowAlert, DeleteFilterAlert, AlphanumericAlert, lbl_yes, lbl_no, lbl_grouped, 
				lbl_detail, lbl_month_detail, lbl_fquarter_detail, lbl_nquarter_detail, lbl_asc, lbl_desc, 
				lbl_unavailable, lbl_equals, lbl_not_equals, lbl_less_than, lbl_more_than, lbl_like, lbl_not_like, 
				lbl_one_of, lbl_not_one_of, lbl_before_date, lbl_after_date, lbl_between, lbl_not_between, lbl_last, 
				lbl_not_last, lbl_this, lbl_not_this, lbl_theese, lbl_next, lbl_not_next, lbl_day, lbl_week, lbl_month, lbl_fquarter, 
				lbl_nquarter, lbl_fyear, lbl_nyear, lbl_true, lbl_false, lbl_pie, lbl_bar, lbl_monday, 
				lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday, lbl_january, 
				lbl_february, lbl_march, lbl_april, lbl_may, lbl_june, lbl_july, lbl_august, lbl_september, 
				lbl_october, lbl_november, lbl_december, lbl_auto, lbl_visible, lbl_user_input, escapeTokens) {

				
				
        var table = document.getElementById(idTable);

        var fields = document.getElementById(idSelectFields);
        var types = typeFields.split(",");
        var options = (escapeTokens == "true") ? optionFields.split("${comma}") : optionFields.split(",");
        var options_db = (escapeTokens == "true") ? optionFieldsDb.split("${comma}") : optionFields.split(",");
		
        
        
        var related_fields = document.getElementById(idSelectRelatedFields);
        var related_types = typeRelatedFields.split(",");
        var related_options = (escapeTokens == "true") ? optionRelatedFields.split("${comma}") : optionRelatedFields.split(",");
        var related_options_db = (escapeTokens == "true") ? optionRelatedFieldsDb.split("${comma}") : optionRelatedFieldsDb.split(",");

		var fieldsLabelsAlias = fieldLabels.split("${pipe}");
		
        if (fields != null) {

                for ( var i = 0; i < fields.options.length; i++) {
                	
                		
						if (fields.options[i].selected) {

                                var row = document.createElement("tr");
                                row.setAttribute("class", "oddListRowS1");

                                var cell_Field = document.createElement("td");
                                var cell_Alias = document.createElement("td");
                                var cell_Display = document.createElement("td");
                                var cell_Sort_Dir = document.createElement("td");
                                var cell_Sort_Seq = document.createElement("td");
                                var cell_Function = document.createElement("td");
                                var cell_Layout_Group = document.createElement("td");
                                var cell_Group_By_Seq = document.createElement("td");
                                var cell_Buttons = document.createElement("td");
                                cell_Buttons.align = "right";
                                var cell_Order_Arrows = document.createElement("td");

                                cell_Field.innerHTML = "<b>" + fields.options[i].value + "</b>";

                                cell_Alias.innerHTML = "<input type='text' name='alias' class='alias' size='15' maxlength='' value='"
                                                + fieldsLabelsAlias[i].replace(/_/g, " ") + "' title='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";
												
                                cell_Display.innerHTML = "<select class='display' name='display'>"
                                                + "<option value='Yes' selected>"+lbl_yes+"</option>"
                                                + "<option value='No'>"+lbl_no+"</option>" + "</select>";

                                cell_Sort_Dir.innerHTML = "<select class='sort_dir' name='sort_dir'>"
                                                + "<option value='0' selected></option>"
                                                + "<option value='ASC'>"+lbl_asc+"</option>"
                                                + "<option value='DESC'>"+lbl_desc+"</option>" + "</select>";

                                cell_Sort_Seq.innerHTML = "<input type='text' name='sort_seq' class='sort_seq' size='4' maxlength='' value='' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

								if (types[i].indexOf("int") === 0)
									types[i] = "int";
								
								
                                switch (types[i]) {

                                case "int":
                                case "double":
                                case "currency":  
								case "enum":
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"false\", \""+fields.options[i].value+"\", \""+fieldsLabelsAlias[i].replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='COUNT'>COUNT</option>"
                                                        + "<option value='MIN'>MIN</option>"
                                                        + "<option value='MAX'>MAX</option>"
                                                        + "<option value='SUM'>SUM</option>"
                                                        + "<option value='AVG'>AVG</option>" + "</select>";
                                        break;

                                case "datetime":
                                case "date":
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"false\", \""+fields.options[i].value+"\", \""+fieldsLabelsAlias[i].replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='MIN'>MIN</option>"
                                                        + "<option value='MAX'>MAX</option>" + "</select>";
                                        break;

                                case "bool":
                                case "tinyint(1)":
                                	cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"false\", \""+fields.options[i].value+"\", \""+fieldsLabelsAlias[i].replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
					                                    + "<option value='0' selected></option>"
					                                    + "<option value='COUNT'>COUNT</option>"
					                                    + "<option value='SUM'>SUM</option>"
                                        break;

                                default:
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"false\", \""+fields.options[i].value+"\", \""+fieldsLabelsAlias[i].replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='COUNT'>COUNT</option>"
                                                        + "</select>";
                                        break;

                                }

                                switch (types[i]) {

                                case "datetime":
                                case "date":
                                        cell_Layout_Group.innerHTML = "<select>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail' >"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail' >"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail' >"+lbl_nquarter_detail+"</option>"
                                                        + "</select>";
                                        break;

                                default:
                                        cell_Layout_Group.innerHTML = "<select>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail' >"+lbl_detail+"</option>"
                                                        + "</select>";
                                        break;

                                }

                                cell_Group_By_Seq.innerHTML = "<input type='text' name='group_seq' class='group_seq' size='4' maxlength='' value='' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

                                var commaToken = (escapeTokens == "true") ? "${comma}" : ",";
                                var dpToken = (escapeTokens == "true") ? "${dp}" : ":";
								
                                cell_Buttons.innerHTML = "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_addline.png' alt='"
                                                + fields.options[i].value
                                                + "${dp}"
                                                + types[i]
                                                + "${dp}"
                                                + options[i].split(commaToken).join("|")
                                                + "${dp}"
                                                + options_db[i].split(commaToken).join("|")
                                                + "' title=\""+AddButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='InsertFilters(\"filters_Table\", (this.alt.split(\""+dpToken+"\"))[0], (this.alt.split(\""+dpToken+"\"))[1], (this.alt.split(\""+dpToken+"\"))[2], (this.alt.split(\""+dpToken+"\"))[3], \"false\", "
                                                + i
                                                + ", \""
                                                + calendar_dateformat
                                                + "\", \""
                                                + DeleteFilter
                                                + "\", \""
                                                + FilterUp
                                                + "\", \""
                                                + FilterDown
                                                + "\", \""																																					
                                                + DeleteFilterAlert	
												+ "\", \"" + lbl_equals + "\", \"" + lbl_not_equals + "\", \"" + lbl_less_than + "\", \"" + lbl_more_than + "\", \"" + lbl_like + "\", \"" + lbl_not_like + "\", \"" + lbl_one_of + "\", \"" + lbl_not_one_of + "\", \"" + lbl_before_date + "\", \"" + lbl_after_date + "\", \"" + lbl_between + "\", \"" + lbl_not_between + "\", \"" + lbl_last + "\", \"" + lbl_not_last + "\", \"" + lbl_this + "\", \"" + lbl_not_this + "\", \"" + lbl_theese + "\", \"" + lbl_next + "\", \"" + lbl_not_next + "\", \"" + lbl_day + "\", \"" + lbl_week + "\", \"" + lbl_month + "\", \"" + lbl_fquarter + "\", \"" + lbl_nquarter + "\", \"" + lbl_fyear + "\", \"" + lbl_nyear + "\", \"" + lbl_true + "\", \"" + lbl_false + "\", \"" + lbl_monday + "\", \"" + lbl_tuesday + "\", \"" + lbl_wednesday + "\", \"" + lbl_thursday + "\", \"" + lbl_friday + "\", \"" + lbl_saturday + "\", \"" + lbl_sunday + "\", \"" + lbl_january + "\", \"" + lbl_february + "\", \"" + lbl_march + "\", \"" + lbl_april + "\", \"" + lbl_may + "\", \"" + lbl_june + "\", \"" + lbl_july + "\", \"" + lbl_august + "\", \"" + lbl_september + "\", \"" + lbl_october + "\", \"" + lbl_november + "\", \"" + lbl_december + "\", \"" + lbl_auto + "\", \"" + lbl_visible + "\", \"" + lbl_user_input
												+ "\", \""
												+ escapeTokens
                                                + "\")' name='add_button'>"
                                                + "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteRowAlert+"\")) { delete_field_filters(\"filters_Table\", \"\", \""+fields.options[i].value+"\"); this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode); insert_Chart(\"charts_Table\", \"false\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\");  } ' name='del_button'>"
                                                + "<input type='hidden' name='value_type' value='"
                                                + types[i]
                                                + "'>"
                                                + "<input type='hidden' name='key' value=''>"
                                                + "<input type='hidden' name='is_related' value='false'>"
                                                + "<input type='hidden' name='index' value='" + i
                                                + "'>" + "<input type='hidden' name='options' value='"
                                                + options[i] + "'>" +
                                                "<input type='hidden' name='options_db' value='"
                                                + options_db[i] + "'>";

                                cell_Order_Arrows.innerHTML = "&nbsp;<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_up.png' title=\""+ArrowUp+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFieldsUp'; document.create_form.rowIndex.value='"
                                                + (table.getElementsByTagName("tr").length - 1)
                                                + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">"
                                                + "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_down.png' title=\""+ArrowDown+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFieldsDown'; document.create_form.rowIndex.value='"
                                                + (table.getElementsByTagName("tr").length - 1)
                                                + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">";

                                row.appendChild(cell_Field);
                                row.appendChild(cell_Alias);
                                row.appendChild(cell_Display);
                                row.appendChild(cell_Sort_Dir);
                                row.appendChild(cell_Sort_Seq);
                                row.appendChild(cell_Function);
                                row.appendChild(cell_Layout_Group);
                                row.appendChild(cell_Group_By_Seq);
                                row.appendChild(cell_Buttons);
                                row.appendChild(cell_Order_Arrows);

                                table.appendChild(row);

                        }

                }

        }

        if (related_fields != null) {

                for ( var i = 0; i < related_fields.options.length; i++) {

                        if (related_fields.options[i].selected) {

                                var row = document.createElement("tr");
                                row.setAttribute("class", "oddListRowS1");

                                var cell_Field = document.createElement("td");
                                var cell_Alias = document.createElement("td");
                                var cell_Display = document.createElement("td");
                                var cell_Sort_Dir = document.createElement("td");
                                var cell_Sort_Seq = document.createElement("td");
                                var cell_Function = document.createElement("td");
                                var cell_Layout_Group = document.createElement("td");
                                var cell_Group_By_Seq = document.createElement("td");
                                var cell_Buttons = document.createElement("td");
                                cell_Buttons.align = "right";
                                var cell_Order_Arrows = document.createElement("td");

                                cell_Field.innerHTML = "<b>" + related_fields.options[i].value
                                                + "</b>";

                                cell_Alias.innerHTML = "<input type='text' name='alias' class='alias' size='15' maxlength='' value='"
                                                + key.replace(/_/g, " ")+" "+related_fields.options[i].value.replace(".", "_").replace(/_/g, " ")
                                                + "' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

                                cell_Display.innerHTML = "<select class='display' name='display'>"
                                                + "<option value='Yes' selected>"+lbl_yes+"</option>"
                                                + "<option value='No'>"+lbl_no+"</option>" + "</select>";

                                cell_Sort_Dir.innerHTML = "<select class='sort_dir' name='sort_dir'>"
                                                + "<option value='0' selected></option>"
                                                + "<option value='ASC'>"+lbl_asc+"</option>"
                                                + "<option value='DESC'>"+lbl_desc+"</option>" + "</select>";

                                cell_Sort_Seq.innerHTML = "<input min-width='min-width: 50px' type='text' name='sort_seq' class='sort_seq' size='4' maxlength='' value='' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

								
								if (related_types[i].indexOf("int") === 0)
									related_types[i] = "int";
								
                                switch (related_types[i]) {

                                case "int":
                                case "double":
                                case "currency":
                                case "enum":
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"false\", \""+related_fields.options[i].value+"\", \""+related_fields.options[i].value.replace(".", "_").replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='COUNT'>COUNT</option>"
                                                        + "<option value='MIN'>MIN</option>"
                                                        + "<option value='MAX'>MAX</option>"
                                                        + "<option value='SUM'>SUM</option>"
                                                        + "<option value='AVG'>AVG</option>" + "</select>";
                                        break;
                                        
                                case "datetime":
                                case "date":
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"false\", \""+related_fields.options[i].value+"\", \""+related_fields.options[i].value.replace(".", "_").replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='MIN'>MIN</option>"
                                                        + "<option value='MAX'>MAX</option>" + "</select>";
                                        break;

                                case "bool":
                                case "tinyint(1)":
                                	cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"false\", \""+related_fields.options[i].value+"\", \""+related_fields.options[i].value.replace(".", "_").replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
					                                    + "<option value='0' selected></option>"
					                                    + "<option value='COUNT'>COUNT</option>"
					                                    + "<option value='SUM'>SUM</option>" + "</select>";
                                        break;

                                default:
                                        cell_Function.innerHTML = "<select class='function' name='function' onChange='if (this.value != \"0\") { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"false\", \""+related_fields.options[i].value+"\", \""+related_fields.options[i].value.replace(".", "_").replace(/_/g, " ")+"\", this.value, \""+AlphanumericAlert+"\", \""+lbl_yes+"\", \""+lbl_no+"\", \""+lbl_pie+"\", \""+lbl_bar+"\"); } else { insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }'>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='COUNT'>COUNT</option>"
                                                        + "</select>";
                                        break;

                                }

                                switch (related_types[i]) {

                                case "datetime":
                                case "date":
                                        cell_Layout_Group.innerHTML = "<select>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail'>"+lbl_detail+"</option>"
                                                        + "<option value='Month Detail' >"+lbl_month_detail+"</option>"
                                                        + "<option value='Fiscal Quarter Detail' >"+lbl_fquarter_detail+"</option>"
                                                        + "<option value='Natural Quarter Detail' >"+lbl_nquarter_detail+"</option>"
                                                        + "</select>";
                                        break;

                                default:
                                        cell_Layout_Group.innerHTML = "<select>"
                                                        + "<option value='0' selected></option>"
                                                        + "<option value='Grouped'>"+lbl_grouped+"</option>"
                                                        + "<option value='Detail' >"+lbl_detail+"</option>"
                                                        + "</select>";
                                        break;

                                }

                                cell_Group_By_Seq.innerHTML = "<input type='text' name='group_seq' class='group_seq' size='4' maxlength='' value='' title='' tabindex='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

                                var commaToken = (escapeTokens == "true") ? "${comma}" : ",";
                                var dpToken = (escapeTokens == "true") ? "${dp}" : ":";

                                cell_Buttons.innerHTML = "<img class='asol_icon' src='modules/Reports/templates/images/asol_reports_addline.png' alt='"
                                                + related_fields.options[i].value
                                                + "${dp}"
                                                + related_types[i]
                                                + "${dp}"
                                                + related_options[i].split(commaToken).join("|")
                                                + "${dp}"
                                                + related_options_db[i].split(commaToken).join("|")
                                                + "' title=\""+AddButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='InsertFilters(\"filters_Table\", (this.alt.split(\""+dpToken+"\"))[0], (this.alt.split(\""+dpToken+"\"))[1], (this.alt.split(\""+dpToken+"\"))[2], (this.alt.split(\""+dpToken+"\"))[3], \""+key+"\", "
                                                + i
                                                + ",\""
                                                + calendar_dateformat
                                                + "\", \""
                                                + DeleteFilter
                                                + "\", \""
                                                + FilterUp
                                                + "\", \""
                                                + FilterDown
                                                + "\", \""
                                                + DeleteFilterAlert
                                                + "\", \"" + lbl_equals + "\", \"" + lbl_not_equals + "\", \"" + lbl_less_than + "\", \"" + lbl_more_than + "\", \"" + lbl_like + "\", \"" + lbl_not_like + "\", \"" + lbl_one_of + "\", \"" + lbl_not_one_of + "\", \"" + lbl_before_date + "\", \"" + lbl_after_date + "\", \"" + lbl_between + "\", \"" + lbl_not_between + "\", \"" + lbl_last + "\", \"" + lbl_not_last + "\", \"" + lbl_this + "\", \"" + lbl_not_this + "\", \"" + lbl_theese + "\", \"" + lbl_next + "\", \"" + lbl_not_next + "\", \"" + lbl_day + "\", \"" + lbl_week + "\", \"" + lbl_month + "\", \"" + lbl_fquarter + "\", \"" + lbl_nquarter + "\", \"" + lbl_fyear + "\", \"" + lbl_nyear + "\", \"" + lbl_true + "\", \"" + lbl_false + "\", \"" + lbl_monday + "\", \"" + lbl_tuesday + "\", \"" + lbl_wednesday + "\", \"" + lbl_thursday + "\", \"" + lbl_friday + "\", \"" + lbl_saturday + "\", \"" + lbl_sunday + "\", \"" + lbl_january + "\", \"" + lbl_february + "\", \"" + lbl_march + "\", \"" + lbl_april + "\", \"" + lbl_may + "\", \"" + lbl_june + "\", \"" + lbl_july + "\", \"" + lbl_august + "\", \"" + lbl_september + "\", \"" + lbl_october + "\", \"" + lbl_november + "\", \"" + lbl_december + "\", \"" + lbl_auto + "\", \"" + lbl_visible + "\", \"" + lbl_user_input
												+ "\", \""
												+ escapeTokens
                                                + "\")' name='add_button'>"
                                                + "<img class='asol_icon' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteRowAlert+"\")) { delete_field_filters(\"filters_Table\", \""+key+"\", \""+related_fields.options[i].value+"\"); this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode); insert_Chart(\"charts_Table\", \"true\", \""+i+"\", \"true\", \"\", \"\", \"\", \"\", \"\", \"\", \"\"); }' name='del_button'>"
                                                + "<input type='hidden' name='value_type' value='"
                                                + related_types[i]
                                                + "'>"
                                                + "<input type='hidden' name='key' value='"
                                                + key
                                                + "'>"
                                                + "<input type='hidden' name='is_related' value='true'>"
                                                + "<input type='hidden' name='index' value='" + i
                                                + "'>" + "<input type='hidden' name='options' value='"
                                                + related_options[i] + "'>"
                                                + "<input type='hidden' name='options_db' value='"+ related_options_db[i] + "'>";

                                cell_Order_Arrows.innerHTML = "&nbsp;<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_up.png' title=\""+ArrowUp+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFieldsUp'; document.create_form.rowIndex.value='"
                                                + (table.getElementsByTagName("tr").length - 1)
                                                + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">"
                                                + "<img class='asol_icon' border='0' src='modules/Reports/templates/images/asol_reports_down.png' title=\""+ArrowDown+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFieldsDown'; document.create_form.rowIndex.value='"
                                                + (table.getElementsByTagName("tr").length - 1)
                                                + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">";

                                row.appendChild(cell_Field);
                                row.appendChild(cell_Alias);
                                row.appendChild(cell_Display);
                                row.appendChild(cell_Sort_Dir);
                                row.appendChild(cell_Sort_Seq);
                                row.appendChild(cell_Function);
                                row.appendChild(cell_Layout_Group);
                                row.appendChild(cell_Group_By_Seq);
                                row.appendChild(cell_Buttons);
                                row.appendChild(cell_Order_Arrows);

                                table.appendChild(row);

                        }

                }

        }

}

function InsertFilters(idTable, idField, fieldType, fieldOption, fieldOptionDb, isRelated,
                index, calendar_dateformat, DeleteButton, ArrowUp, ArrowDown, DeleteFilterAlert, 
				lbl_equals, lbl_not_equals, lbl_less_than, lbl_more_than, lbl_like, lbl_not_like, 
				lbl_one_of, lbl_not_one_of, lbl_before_date, lbl_after_date, lbl_between, lbl_not_between, 
				lbl_last, lbl_not_last, lbl_this, lbl_not_this, lbl_theese, lbl_next, lbl_not_next, lbl_day, lbl_week, 
				lbl_month, lbl_fquarter, lbl_nquarter, lbl_fyear, lbl_nyear, lbl_true, lbl_false, lbl_monday, 
				lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday, lbl_january, 
				lbl_february, lbl_march, lbl_april, lbl_may, lbl_june, lbl_july, lbl_august, lbl_september, 
				lbl_october, lbl_november, lbl_december, lbl_auto, lbl_visible, lbl_user_input, escapeTokens) {


        var table = document.getElementById(idTable);

        var param1 = (table.getElementsByTagName("tr").length - 1);
        var param2 = (table.getElementsByTagName("tr").length - 1);
		
        //var options = (escapeTokens == "true") ? fieldOption.split("${pipe}") : fieldOption.split("|");
        //var options_db = (escapeTokens == "true") ? fieldOptionDb.split("${pipe}") : fieldOptionDb.split("|");
        var options = fieldOption.split("|");
        var options_db = fieldOptionDb.split("|");

        var row = document.createElement("tr");
        row.setAttribute("class", "oddListRowS1");

        var cell_Field = document.createElement("td");
        
        var cell_Ref = document.createElement("td");
        var cell_Alias = document.createElement("td");
        
        var cell_Behavior = document.createElement("td");
        var cell_UserInputOptions = document.createElement("td");
        
        var cell_Operator = document.createElement("td");
        var cell_First_Parameter = document.createElement("td");
        var cell_Second_Parameter = document.createElement("td");
        var cell_Button = document.createElement("td");
        cell_Button.align = "right";
        var cell_Order_Arrows = document.createElement("td");

        cell_Field.innerHTML = "<b>" + idField + "</b>";
		
        cell_Alias.innerHTML = "<input type='text' value='" + idField + "'>";
        
        cell_Ref.innerHTML = "<input type='text' value=''>";
        
        cell_Behavior.innerHTML = "<select class='behavior' name='behavior'>" +
        		"<option value='auto' selected>"+lbl_auto+"</option>" +
        		"<option value='visible'>"+lbl_visible+"</option>" +
        		"<option value='user_input'>"+lbl_user_input+"</option>" +
        		"</select>";
        
        cell_UserInputOptions.innerHTML = "<input type='text' value=''>";
		
		if (fieldType.indexOf("int") === 0)
			fieldType = "int";
		
        switch (fieldType) {

        case "enum":
                cell_Operator.innerHTML = "<select onChange='if (this.selectedIndex >= 2){this.parentNode.parentNode.cells[6].childNodes[0].multiple=true;this.parentNode.parentNode.cells[6].childNodes[0].size=3;} else {this.parentNode.parentNode.cells[6].childNodes[0].multiple=false;this.parentNode.parentNode.cells[6].childNodes[0].size=1;}'>"
                                + "<option value='equals' selected>"+lbl_equals+"</option>"
                                + "<option value='not equals'>"+lbl_not_equals+"</option>"
                                + "<option value='one of'>"+lbl_one_of+"</option>"
                                + "<option value='not one of'>"+lbl_not_one_of+"</option>" + "</select>";

                var optionsSelect = "";
                for ( var i = 0; i < options.length; i++) {
                        optionsSelect += "<option value='"+options_db[i]+"'>" + options[i].replace(/\${sq}/g, "\'" ) + "</option>";
                }

                cell_First_Parameter.innerHTML = "<select name='Param1[]' class='Param1'>"
                                + optionsSelect + "</select>";
                cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' value='' style='display:none;'>";
                break;

		
				
		case "int":
        case "double":
        case "currency":
                cell_Operator.innerHTML = "<select>"
                                + "<option value='equals' selected>"+lbl_equals+"</option>"
                                + "<option value='not equals'>"+lbl_not_equals+"</option>"
                                + "<option value='less than'>"+lbl_less_than+"</option>"
                                + "<option value='more than'>"+lbl_more_than+"</option>" + "</select>";

                cell_First_Parameter.innerHTML = "<input type='text' name='Param1' class='Param1' value=''>";
                cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' value='' style='display:none;'>";
                break;

        case "datetime":
        case "date":
                cell_Operator.innerHTML = "<select onChange='if ((this.selectedIndex == 4) || (this.selectedIndex == 5)) { this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].disabled=true; } else { this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"none\";this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"inline\";this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"inline\";this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[7].childNodes[1].style.display =\"none\"; if(this.selectedIndex >= 6) { this.parentNode.parentNode.cells[6].childNodes[0].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[1].style.display =\"none\"; this.parentNode.parentNode.cells[6].childNodes[3].style.display =\"inline\"; if ((this.selectedIndex == 6) || (this.selectedIndex == 7) || (this.selectedIndex == 10) || (this.selectedIndex == 11) || (this.selectedIndex == 12)) { this.parentNode.parentNode.cells[7].childNodes[0].style.display = \"inline\"; this.parentNode.parentNode.cells[7].childNodes[0].value = \"\"}; }; this.parentNode.parentNode.cells[7].childNodes[0].disabled=false; } if (this.selectedIndex >= 8) removeSelectElements(this.parentNode.parentNode.cells[6].childNodes[3], 7, 26); if ((this.selectedIndex == 6) || (this.selectedIndex == 7)) insertMonthDaysValues(this.parentNode.parentNode.cells[6].childNodes[3], \""+lbl_monday+"\", \""+lbl_tuesday+"\", \""+lbl_wednesday+"\", \""+lbl_thursday+"\", \""+lbl_friday+"\", \""+lbl_saturday+"\", \""+lbl_sunday+"\", \""+lbl_january+"\", \""+lbl_february+"\", \""+lbl_march+"\", \""+lbl_april+"\", \""+lbl_may+"\", \""+lbl_june+"\", \""+lbl_july+"\", \""+lbl_august+"\", \""+lbl_september+"\", \""+lbl_october+"\", \""+lbl_november+"\", \""+lbl_december+"\" ); '>"
                                + "<option value='equals' selected>"+lbl_equals+"</option>"
                                + "<option value='not equals'>"+lbl_not_equals+"</option>"
                                + "<option value='before date'>"+lbl_before_date+"</option>"
                                + "<option value='after date'>"+lbl_after_date+"</option>"
                                + "<option value='between'>"+lbl_between+"</option>"
                                + "<option value='not between'>"+lbl_not_between+"</option>"
                                + "<option value='last'>"+lbl_last+"</option>"
                                + "<option value='not last'>"+lbl_not_last+"</option>"
                                + "<option value='this'>"+lbl_this+"</option>"
                                + "<option value='not this'>"+lbl_not_this+"</option>"
                                + "<option value='theese'>"+lbl_theese+"</option>"
                                + "<option value='next'>"+lbl_next+"</option>"
                                + "<option value='not next'>"+lbl_not_next+"</option>"
                                + "</select>";

                cell_First_Parameter.innerHTML = "<input type='text' id='Param1_"
                                + (table.getElementsByTagName("tr").length - 1)
                                + "' value='' disabled=true>"
                                + "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger_"
                                + (table.getElementsByTagName("tr").length - 1) + "'>"
                                + "<span></span>"
                                + "<select style='display:none;' onChange='if (this.selectedIndex >= 7) { this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"none\"; } else if ((this.parentNode.parentNode.cells[5].childNodes[0].value != \"this\") && (this.parentNode.parentNode.cells[5].childNodes[0].value != \"not this\")) { this.parentNode.parentNode.cells[7].childNodes[0].style.display =\"inline\"; }'>"
                                + "<option value='day' selected>"+lbl_day+"</option>"
                                + "<option value='week'>"+lbl_week+"</option>"
                                + "<option value='month'>"+lbl_month+"</option>"
                                + "<option value='Nquarter'>"+lbl_nquarter+"</option>"
                                + "<option value='Fquarter'>"+lbl_fquarter+"</option>"
                                + "<option value='Nyear'>"+lbl_nyear+"</option>"
                                + "<option value='Fyear'>"+lbl_fyear+"</option>"
                                
                                + "<option value='monday'>"+lbl_monday+"</option>"
                                + "<option value='tuesday'>"+lbl_tuesday+"</option>"
                                + "<option value='wednesday'>"+lbl_wednesday+"</option>"
                                + "<option value='thursday'>"+lbl_thursday+"</option>"
                                + "<option value='friday'>"+lbl_friday+"</option>"
                                + "<option value='saturday'>"+lbl_saturday+"</option>"
                                + "<option value='sunday'>"+lbl_sunday+"</option>"
                                
                                + "<option value='january'>"+lbl_january+"</option>"
                                + "<option value='february'>"+lbl_february+"</option>"
                                + "<option value='march'>"+lbl_march+"</option>"
                                + "<option value='april'>"+lbl_april+"</option>"
                                + "<option value='may'>"+lbl_may+"</option>"
                                + "<option value='june'>"+lbl_june+"</option>"
                                + "<option value='july'>"+lbl_july+"</option>"
                                + "<option value='august'>"+lbl_august+"</option>"
                                + "<option value='september'>"+lbl_september+"</option>"
                                + "<option value='october'>"+lbl_october+"</option>"
                                + "<option value='november'>"+lbl_november+"</option>"
                                + "<option value='december'>"+lbl_december+"</option>"
                                
                                + "</select>";

                cell_Second_Parameter.innerHTML = "<input type='text' id='Param2_"
                                + (table.getElementsByTagName("tr").length - 1)
                                + "' value='' style='display:none;' disabled=true>"
                                + "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='trigger2_"
                                + (table.getElementsByTagName("tr").length - 1) + "' style='display:none;'>";

                break;

        case "bool":
        case "tinyint(1)":
                cell_Operator.innerHTML = "<select>"
                                + "<option value='equals' selected>"+lbl_equals+"</option>"
                                + "<option value='not equals'>"+lbl_not_equals+"</option>" + "</select>";

                cell_First_Parameter.innerHTML = "<select>"
                                + "<option value='true'>"+lbl_true+"</option>"
                                + "<option value='false'>"+lbl_false+"</option>" + "</select>";

                cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2'  value='' style='display:none;'>";
                break;

        default:
                cell_Operator.innerHTML = "<select class='function' name='function'>"
                                + "<option value='equals' selected>"+lbl_equals+"</option>"
								+ "<option value='not equals'>"+lbl_not_equals+"</option>"
								+ "<option value='like'>"+lbl_like+"</option>"
                                + "<option value='not like'>"+lbl_not_like+"</option>" + "</select>";

                cell_First_Parameter.innerHTML = "<input type='text' name='Param1' class='Param1' value=''>";
                cell_Second_Parameter.innerHTML = "<input type='text' name='Param2' class='Param2' value='' style='display:none;'>";
                break;

        }

        cell_Button.innerHTML = "<img class='asol_icon' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteFilterAlert+"\")){ this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode); }' name='del_button' value='Delete Filter'>"
                        + "<input type='hidden' name='value_type' value='"
                        + fieldType
                        + "'>"
                        + "<input type='hidden' name='is_related' value='"
                        + isRelated
                        + "'>"
                        + "<input type='hidden' name='index' value='"
                        + index
                        + "'>"
                        + "<input type='hidden' name='options' value='"
                        + options.join("${comma}") + "'>"
                        + "<input type='hidden' name='options_db' value='"
                        + options_db.join("${comma}") + "'>";

        cell_Order_Arrows.innerHTML = "&nbsp;<img class='asol_icon' border='0' title=\""+ArrowUp+"\" src='modules/Reports/templates/images/asol_reports_up.png' OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFiltersUp'; document.create_form.rowIndex.value='"
                        + (table.getElementsByTagName("tr").length - 1)
                        + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">"
                        + "<img class='asol_icon' border='0' title=\""+ArrowDown+"\" src='modules/Reports/templates/images/asol_reports_down.png' OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onclick=\"document.create_form.return_action.value='reOrderFiltersDown'; document.create_form.rowIndex.value='"
                        + (table.getElementsByTagName("tr").length - 1)
                        + "'; document.create_form.selected_fields.value=format_fields('fields_Table'); document.create_form.selected_filters.value=format_filters('filters_Table'); document.create_form.selected_tasks.value=format_tasks('tasks_Table'); document.create_form.row_index_display.value=document.getElementById('rowIndexDisplay').value; document.create_form.results_limit.value=format_results_limit(); document.create_form.submit();\">";

        row.appendChild(cell_Field);
        row.appendChild(cell_Alias);
        row.appendChild(cell_Ref);
        
        row.appendChild(cell_Behavior);
        row.appendChild(cell_UserInputOptions);
        
        row.appendChild(cell_Operator);
        row.appendChild(cell_First_Parameter);
        row.appendChild(cell_Second_Parameter);
        row.appendChild(cell_Button);
        row.appendChild(cell_Order_Arrows);

        table.appendChild(row);


        Calendar.setup ({ inputField : "Param1_"+param1 , daFormat : calendar_dateformat, button : "trigger_"+param1 , singleClick : true, dateStr : '', step : 1, weekNumbers:false });
        Calendar.setup ({ inputField : "Param2_"+param2 , daFormat : calendar_dateformat, button : "trigger2_"+param2 , singleClick : true, dateStr : '', step : 1, weekNumbers:false });

}

function removeSelectElements(selectObject, initIndex, endIndex) {
	
	for (var j=initIndex; j<endIndex; j++) 
		selectObject.remove(initIndex);
	
}

function insertMonthDaysValues(selectObject, lbl_monday, lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday, lbl_january, lbl_february, lbl_march, lbl_april, lbl_may, lbl_june, lbl_july, lbl_august, lbl_september, lbl_october, lbl_november, lbl_december) {
	
	var options = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]; 
	var optionsLabels = [lbl_monday, lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday, lbl_january, lbl_february, lbl_march, lbl_april, lbl_may, lbl_june, lbl_july, lbl_august, lbl_september, lbl_october, lbl_november, lbl_december];
	
	if (selectObject.length == 7) {
		
		for (var i=0; i<options.length; i++) {
		
			var optNew = document.createElement('option');
			optNew.text = optionsLabels[i];
			optNew.value = options[i];
	
			try {
				selectObject.add(optNew, null); // standards compliant; doesn't work in IE
			} catch(ex) {
				selectObject.add(optNew); // IE only
			}
		
		}

	}
	
}

function insert_Task(idTable, calendar_dateformat, DeleteButton, DeleteTaskAlert, AlphanumericAlert, lbl_monthly, lbl_weekly, lbl_daily, lbl_active, lbl_inactive, lbl_monday, lbl_tuesday, lbl_wednesday, lbl_thursday, lbl_friday, lbl_saturday, lbl_sunday) {

        var table = document.getElementById(idTable);
        var row = document.createElement("tr");
        row.setAttribute("class", "oddListRowS1");

        var range_End_Date = table.getElementsByTagName("tr").length;

        var cell_Task = document.createElement("td");
        var cell_Range = document.createElement("td");
        var cell_Day_Parameter = document.createElement("td");
        var cell_Time_Parameter = document.createElement("td");
        var cell_End_Date = document.createElement("td");
        var cell_State = document.createElement("td");
        var cell_Button = document.createElement("td");
        cell_Button.align = "right";

        cell_Task.innerHTML = "<input type='text' name='task_name' class='task_name' size='30' maxlength='' value='' title='' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'>";

        cell_Range.innerHTML = "<select class='execution_Range' name='execution_Range' " +
                                "onChange='if (this.selectedIndex == 0){this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"inline\"} else if (this.selectedIndex == 1){ this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"inline\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\" } else {this.parentNode.parentNode.childNodes[2].childNodes[1].style.display=\"none\"; this.parentNode.parentNode.childNodes[2].childNodes[0].style.display=\"none\"} '>" +
                                "<option value='monthly' selected>"+lbl_monthly+"</option>" +
                                "<option value='weekly'>"+lbl_weekly+"</option>" +
                                "<option value='daily'>"+lbl_daily+"</option>" +
                        "</select>";

        cell_Day_Parameter.innerHTML = "<select class='range_Day_Value' name='range_Day_Value' style='display: inline;'>" +
                                "<option value='1' selected>01</option>" +
                                "<option value='2'>02</option>" +
                                "<option value='3'>03</option>" +
                                "<option value='4'>04</option>" +
                                "<option value='5'>05</option>" +
                                "<option value='6'>06</option>" +
                                "<option value='7'>07</option>" +
                                "<option value='8'>08</option>" +
                                "<option value='9'>09</option>" +
                                "<option value='10'>10</option>" +
                                "<option value='11'>11</option>" +
                                "<option value='12'>12</option>" +
                                "<option value='13'>13</option>" +
                                "<option value='14'>14</option>" +
                                "<option value='15'>15</option>" +
                                "<option value='16'>16</option>" +
                                "<option value='17'>17</option>" +
                                "<option value='18'>18</option>" +
                                "<option value='19'>19</option>" +
                                "<option value='20'>20</option>" +
                                "<option value='21'>21</option>" +
                                "<option value='22'>22</option>" +
                                "<option value='23'>23</option>" +
                                "<option value='24'>24</option>" +
                                "<option value='25'>25</option>" +
                                "<option value='26'>26</option>" +
                                "<option value='27'>27</option>" +
                                "<option value='28'>28</option>" +
                                "<option value='29'>29</option>" +
                                "<option value='30'>30</option>" +
                                "<option value='31'>31</option>" +
                        "</select>" +

                        "<select class='range_Week_Value' name='range_Week_Value' style='display: none;'>" +
                                "<option value='1' selected>"+lbl_monday+"</option>" +
                                "<option value='2'>"+lbl_tuesday+"</option>" +
                                "<option value='3'>"+lbl_wednesday+"</option>" +
                                "<option value='4'>"+lbl_thursday+"</option>" +
                                "<option value='5'>"+lbl_friday+"</option>" +
                                "<option value='6'>"+lbl_saturday+"</option>" +
                                "<option value='7'>"+lbl_sunday+"</option>" +
                        "</select>";

        cell_Time_Parameter.innerHTML = "<select class='range_Hour_Value' name='range_Hour_Value'>" +
                                "<option value='00' selected>00</option>" +
                                "<option value='01'>01</option>" +
                                "<option value='02'>02</option>" +
                                "<option value='03'>03</option>" +
                                "<option value='04'>04</option>" +
                                "<option value='05'>05</option>" +
                                "<option value='06'>06</option>" +
                                "<option value='07'>07</option>" +
                                "<option value='08'>08</option>" +
                                "<option value='09'>09</option>" +
                                "<option value='10'>10</option>" +
                                "<option value='11'>11</option>" +
                                "<option value='12'>12</option>" +
                                "<option value='13'>13</option>" +
                                "<option value='14'>14</option>" +
                                "<option value='15'>15</option>" +
                                "<option value='16'>16</option>" +
                                "<option value='17'>17</option>" +
                                "<option value='18'>18</option>" +
                                "<option value='19'>19</option>" +
                                "<option value='20'>20</option>" +
                                "<option value='21'>21</option>" +
                                "<option value='22'>22</option>" +
                                "<option value='23'>23</option>" +
                        "</select> <b>:</b>" +
                        "<select class='range_Minute_Value' name='range_Minute_Value'>" +
                                "<option value='00' selected>00</option>" +
                                "<option value='15'>15</option>" +
                                "<option value='30'>30</option>" +
                                "<option value='45'>45</option>" +
                        "</select>";

        cell_End_Date.innerHTML = "<input type='text' id='range_End_Date_"+table.getElementsByTagName("tr").length+"' value='' disabled=true>" +
                        "<img border='0' align='absmiddle' src='themes/default/images/jscalendar.gif' alt='Enter Date' id='range_End_Date_Trigger_"+table.getElementsByTagName("tr").length+"'>"
                        + "<script type='text/javascript'>";

        cell_State.innerHTML = "<select class='task_State' name='task_State'>" +
                        "<option value='active' selected>"+lbl_active+"</option>" +
                        "<option value='inactive'>"+lbl_inactive+"</option>" +
                        "</select>";

        cell_Button.innerHTML = "<img class='asol_icon' src='modules/Reports/templates/images/asol_reports_delete.png' title=\""+DeleteButton+"\" OnMouseOver='this.style.cursor=\"pointer\"' OnMouseOut='this.style.cursor=\"default\"' onClick='if(confirm(\""+DeleteTaskAlert+"\")) this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode)'>";


        row.appendChild(cell_Task);
        row.appendChild(cell_Range);
        row.appendChild(cell_Day_Parameter);
        row.appendChild(cell_Time_Parameter);
        row.appendChild(cell_End_Date);
        row.appendChild(cell_State);
        row.appendChild(cell_Button);

        table.appendChild(row);


        Calendar.setup ({ inputField : "range_End_Date_"+range_End_Date , daFormat : calendar_dateformat, button : "range_End_Date_Trigger_"+range_End_Date , singleClick : true, dateStr : '', step : 1, weekNumbers:false });



}

function insert_Chart(idTable, isRelated, index, deleteChart, chartField, chartName, chartFunction, AlphanumericAlert, lbl_yes, lbl_no, lbl_pie, lbl_bar) {
	
	var chartExists = false;
	var table = document.getElementById(idTable);
	
	var tableRows = table.getElementsByTagName("tr");
	//Comprobar si ya existe ese chart
    for ( var i = 1; i < tableRows.length; i++) {

        var rowCells = tableRows[i].getElementsByTagName("td");
        
        if ((rowCells[4].childNodes[1].value == index) && (rowCells[4].childNodes[2].value == isRelated)) {
        
        	if (deleteChart == "true")
        		tableRows[i].parentNode.removeChild(tableRows[i]);
        		
        	//Editamos los valores del chart
        	document.getElementById("chart_function_"+isRelated+"_"+index).innerHTML = "<span class='chart_function_"+isRelated+"_"+index+"'><b>"+chartFunction+"</b></span>";
        	chartExists = true;
        
        }
        
    }
    
	
	if ((!chartExists) && (deleteChart == "false")) {
		
		var table = document.getElementById(idTable);
	    var row = document.createElement("tr");
	    row.setAttribute("class", "oddListRowS1");
	
	    var cell_Field = document.createElement("td");
	    var cell_Name = document.createElement("td");
	    var cell_Function = document.createElement("td");
	    var cell_Display = document.createElement("td");
	    var cell_Type = document.createElement("td");
	    
	    
	    cell_Field.innerHTML = "<b>"+chartField+"</b>";
	    cell_Name.innerHTML = "<input value='"+chartName+"' onblur='this.value = check_invalid_characters_field(this.value, \""+AlphanumericAlert+"\");'/>";
	    cell_Function.innerHTML = "<span class='chart_function_"+isRelated+"_"+index+"'><b>"+chartFunction+"</b></span>";
	    cell_Display.innerHTML = "<select><option value='yes' selected>"+lbl_yes+"</option><option value='no'>"+lbl_no+"</option></select>";
	    cell_Type.innerHTML = "<select><option value='pie' selected>"+lbl_pie+"</option><option value='bar'>"+lbl_bar+"</option></select><input type='hidden' class='index' name='index' value='"+index+"'><input type='hidden' class='is_related' name='is_related' value='"+isRelated+"'>";
	    
	    row.appendChild(cell_Field);
	    row.appendChild(cell_Name);
	    row.appendChild(cell_Function);
	    row.appendChild(cell_Display);
	    row.appendChild(cell_Type);
	
	    table.appendChild(row);
	    
	}
	
}

function format_fields(idFieldsTable) {

        var table = document.getElementById(idFieldsTable);
        var alias = new Array();
        var parsed_string = "";

        var tableRows = table.getElementsByTagName("tr");

        for ( var i = 2; i <  tableRows.length; i++) {

                var rowCells = tableRows[i].getElementsByTagName("td");

                for ( var j = 0; j < 9; j++) {

                        if (j == 0)
                                parsed_string += rowCells[j].childNodes[0].innerHTML;
                        else if (j == 8) {
						
								//rowcells 6 y 7 reformatear con token nuevo
						
                                parsed_string += rowCells[j].childNodes[2].value;
                                parsed_string += "${dp}"
                                                + rowCells[j].childNodes[3].value;
                                parsed_string += "${dp}"
                                                + rowCells[j].childNodes[4].value;
                                parsed_string += "${dp}"
                                                + rowCells[j].childNodes[5].value;
                                parsed_string += "${dp}"
                                                + rowCells[j].childNodes[6].value.split('|').join('${comma}');
                                parsed_string += "${dp}"
                                                + rowCells[j].childNodes[7].value.split('|').join('${comma}');

                        } else if (j == 1) {
                                // Comprobar que no hay dos alias iguales, y si los hay editar el
                                // nombre de todos menos el primero
                                if (getIndexOf(alias, rowCells[j].childNodes[0].value) == -1) {

                                        parsed_string += rowCells[j].childNodes[0].value.replace(".", "_");
                                        alias[i] = rowCells[j].childNodes[0].value.replace(".", "_");

                                } else {

                                        parsed_string += "Copy Of "
                                                        + rowCells[j].childNodes[0].value.replace(".", "_");
                                        alias[i] = "Copy Of "
                                                        + rowCells[j].childNodes[0].value.replace(".", "_");

                                }

                        } else
                                parsed_string += rowCells[j].childNodes[0].value;

                        parsed_string += "${dp}";

                }

                // substring quitando el ultimo 'dospuntos'
                //parsed_string = parsed_string.slice(0, -1);
                parsed_string = parsed_string.slice(0, -5);

                parsed_string += "${pipe}";

        }

        // substring quitando la ultima 'tuberia'
        //parsed_string = parsed_string.slice(0, -1);
        parsed_string = parsed_string.slice(0, -7);
        parsed_string += "${v2.2.2}";
		
        return parsed_string;

}

function format_filters(idFiltersTable) {

        //Escapar caracteres conflictivos

        var table = document.getElementById(idFiltersTable);
        var parsed_string = "";

        var tableRows = table.getElementsByTagName("tr");

        for ( var i = 2; i < tableRows.length; i++) {

                var rowCells = tableRows[i].getElementsByTagName("td");

                for ( var j = 0; j < 9; j++) {
                	                		
                	
                        if (j == 0) {

                                parsed_string += rowCells[j].childNodes[0].innerHTML;

                        } else if ((j == 6) && (rowCells[j].childNodes[0] == "[object HTMLSelectElement]")) {

                                var options = rowCells[j].childNodes[0].options;
                                var values = "";

                                for ( var k = 0; k < options.length; k++) {

                                        if (rowCells[j].childNodes[0].options[k].selected == true)
                                                values += rowCells[j].childNodes[0].options[k].value
                                                                + "${dollar}";
                                }

                                //values = values.slice(0, -1);
                                values = values.slice(0, -9);

                                parsed_string += values;

                        } else if (j == 8) {
						
								//rowcells 4 y 5 reformatear con token nuevo

                                parsed_string += rowCells[j].childNodes[1].value
                                                + "${dp}";
                                parsed_string += rowCells[j].childNodes[2].value
                                                + "${dp}";
                                parsed_string += rowCells[j].childNodes[3].value
                                                + "${dp}";
                                parsed_string += rowCells[j].childNodes[4].value
                                                + "${dp}";
                                parsed_string += rowCells[j].childNodes[5].value;

                        } else if ((j == 6) && ((rowCells[5].childNodes[0].value == "last") || (rowCells[5].childNodes[0].value == "this") || (rowCells[5].childNodes[0].value == "theese") || (rowCells[5].childNodes[0].value == "next" ) || (rowCells[5].childNodes[0].value == "not last") || (rowCells[5].childNodes[0].value == "not this") || (rowCells[5].childNodes[0].value == "not next" ))) {

                                parsed_string += rowCells[j].childNodes[3].value;

                        } else if ((j == 1) || (j == 2) || (j == 3) || (j == 4)){
                        	
                        	continue;
                        	
                        } else {

                                //parsed_string += rowCells[j].childNodes[0].value.replace(/[\\]/g , "\\\\").replace(/[:]/g, "\\:").replace(/[|]/g, "\\|").replace(/[$]/g , "\\$");
                                parsed_string += rowCells[j].childNodes[0].value.replace(/[\\]/g , "\\\\").replace(/[']/g , "\\\'").replace(/[%]/g , "\\\%").replace(/[_]/g , "\\\_");

                        }

                        parsed_string += "${dp}";

                }
                
                
                parsed_string += rowCells[2].childNodes[0].value+"${dp}";
                parsed_string += rowCells[1].childNodes[0].value+"${dp}";
                parsed_string += rowCells[3].childNodes[0].value+"${dp}";
                parsed_string += rowCells[4].childNodes[0].value+"${dp}";

                
                // substring quitando el ultimo char
                //parsed_string = parsed_string.slice(0, -1);
                parsed_string = parsed_string.slice(0, -5);

                parsed_string += "${pipe}";

        }

        // substring quitando la ultima tuberia
        //parsed_string = parsed_string.slice(0, -1);
        parsed_string = parsed_string.slice(0, -7);
        parsed_string += "${v2.2.2}";
        
        return parsed_string;

}

function format_tasks(idTasksTable) {

        var table = document.getElementById(idTasksTable);
        var parsed_string = "";

        var tableRows = table.getElementsByTagName("tr");

        for ( var i = 1; i < tableRows.length; i++) {

                var rowCells = tableRows[i].getElementsByTagName("td");

                for ( var j = 0; j < 6; j++) {

                        if ((j == 0) && (rowCells[j].childNodes[0].value == ""))
                                rowCells[0].childNodes[0].value = "Task "+i;

                        if (j == 3) {

                                parsed_string += rowCells[j].childNodes[0].value+","+rowCells[j].childNodes[3].value;

                        } else if ((j == 4) && (rowCells[j].childNodes[0].value == "")) {

                                var dat = new Date();
                                var month = ((dat.getMonth()+1) < 10) ? "0"+(dat.getMonth()+1) : (dat.getMonth()+1);

                                parsed_string += dat.getFullYear()+"-"+month+"-"+dat.getDate();

                        } else if (j == 2) {

                                if (rowCells[1].childNodes[0].value == "monthly"){

                                        parsed_string += rowCells[j].childNodes[0].value;

                                }else if (rowCells[1].childNodes[0].value == "weekly"){

                                        parsed_string += rowCells[j].childNodes[1].value;

                                }

                        } else {

                                parsed_string += rowCells[j].childNodes[0].value;

                        }

                        parsed_string += ":";

                }

                // substring quitando el ultimo char
                parsed_string = parsed_string.slice(0, -1);

                parsed_string += "|";

        }

        // substring quitando la ultima tuberia
        parsed_string = parsed_string.slice(0, -1)
		parsed_string += "${GMT}";
		
        return parsed_string;

}

function format_charts(idChartsTable){

    var table = document.getElementById(idChartsTable);
    var parsed_string = "";

    var tableRows = table.getElementsByTagName("tr");

    for ( var i = 1; i < tableRows.length; i++) {
    	
    	var rowCells = tableRows[i].getElementsByTagName("td");
    	
        parsed_string += rowCells[0].childNodes[0].innerHTML+"${dp}";
    	parsed_string += rowCells[1].childNodes[0].value+"${dp}";
    	parsed_string += rowCells[2].childNodes[0].innerHTML+"${dp}";
    	parsed_string += rowCells[3].childNodes[0].value+"${dp}";
    	parsed_string += rowCells[4].childNodes[0].value+"${dp}";
    	parsed_string += rowCells[4].childNodes[1].value+"${dp}";
    	parsed_string += rowCells[4].childNodes[2].value+"${pipe}";
    	
    }
    
    parsed_string = parsed_string.slice(0, -7)
    parsed_string += "${v2.2.2}";
    
    return parsed_string;
    
}

function format_results_limit() {

    var parsed_string = "";
	
	var operator = document.getElementById("results_limit_op").value;

	if (operator == "all")	
		parsed_string += "all";
	else
		parsed_string += "limit${dp}"+document.getElementById("results_limit_param").value+"${dp}"+document.getElementById("results_limit_amount").value;

	return parsed_string;
	
}

function format_external_filters() {
	
	var parsed_string = "";
	var userInputVal = document.getElementById("filters_hidden_inputs").value;
	var userInputs = userInputVal.split("${pipe}");
	
	for (var i=0; i<userInputs.length; i++) {
		
		var inputValues = userInputs[i].split("${dp}");
		parsed_string += inputValues[0] + "${dp}" + inputValues[1];
		
		if ((document.getElementById(inputValues[0]+"_1") == "[object HTMLSelectElement]") && (document.getElementById(inputValues[0]+"_1").multiple)) {
		
			var multiOptions = document.getElementById(inputValues[0]+"_1");
			parsed_string += "${dp}";
				
			for (var j=0; j<multiOptions.options.length; j++) {
				
				if (multiOptions.options[j].selected)
					parsed_string += multiOptions.options[j].value + "${dollar}";
			
			}
			
			parsed_string = parsed_string.slice(0, -9);
		
		} else {
		
			parsed_string += "${dp}" + document.getElementById(inputValues[0]+"_1").value;
		
		}
			
		parsed_string += (inputValues[2] == "2") ? "${dp}" + document.getElementById(inputValues[0]+"_2").value : "${dp}";
		
		parsed_string +=  "${pipe}";
		
	}
	
	parsed_string = parsed_string.slice(0, -7);
	
	return parsed_string;
	
} 

function delete_field_filters(tableId, field_key, field_name){

	var table = document.getElementById(tableId);
    var tableFilters = table.getElementsByTagName("tr");

	//Comprobar antes de eliminar que el field es el �nico que queda en la lista
	if (count_fields("fields_Table", field_key, field_name) == 1) {
	
		for ( var i = tableFilters.length-1; i >= 1 ; i--) {
		
			var rowCells = tableFilters[i].getElementsByTagName("td");
			
			if (field_key == ""){
			
				if (rowCells[0].childNodes[0].innerHTML == field_name)
					tableFilters[i].parentNode.removeChild(tableFilters[i]);
					
			} else {
			
				if ((rowCells[0].childNodes[0].innerHTML == field_name) && (rowCells[8].childNodes[2].value == field_key))
					tableFilters[i].parentNode.removeChild(tableFilters[i]);
			
			}
		
		}

	}
	
} 

function count_fields (tableId, field_key, field_name) {

	var table = document.getElementById(tableId);
    var tableFields = table.getElementsByTagName("tr");
	var counter = 0;
	
	for ( var i = 1; i < tableFields.length; i++) {
	
		var rowCells = tableFields[i].getElementsByTagName("td");
		
		if (field_key == ""){
		
			if (rowCells[0].childNodes[0].innerHTML == field_name)
				counter++;
		
		} else {
		
			if ((rowCells[0].childNodes[0].innerHTML == field_name) && (rowCells[8].childNodes[3].value == field_key))
				counter++;
		
		}
	
	}
	
	return counter;
	
}

function check_form(form_id, Email_Alert, Execution_Date_Alert) {

	var flag = true;
	var form = document.getElementById(form_id);
	
	if (form.report_name.value == "") {
        form.action.value = 'create';
        form.report_name.value = 'Report Name';
        flag = false;
	}
	
	if (form.report_module.value == "") {
        form.action.value = 'create';
        form.report_module.selectedIndex = 1;
        flag = false;
	}
	
	if (form.assigned_user_name.value == "") {
        form.action.value = 'create';
        form.assigned_user_name.value = 'admin';
        flag = false;
	}
	
	if (form.assigned_user_id.value == "") {
        form.assigned_user_id.value = 1;
        form.action.value = 'create';
        flag = false;
	}
	
    if (!check_emails_format(form.email_list.value, Email_Alert)){
        flag = false;
    }
	
	if (!check_emails_format(form.email_blind_copy.value, Email_Alert)){
        flag = false;
    }

    if (!check_execution_end_dates('tasks_Table', Execution_Date_Alert)){
        flag = false;
    }


    return flag;

}

function check_execution_end_dates(idTasksTable, Execution_Date_Alert){

    var table = document.getElementById(idTasksTable);
    var flag = true;

    var tableRows = table.getElementsByTagName("tr");

    for ( var i = 1; i < tableRows.length; i++) {

        var rowCells = tableRows[i].getElementsByTagName("td");

        if (rowCells[4].childNodes[0].value == ""){

            alert(Execution_Date_Alert);
            flag = false;

            break;

        }

    }

    return flag;

}

function check_invalid_characters_field(fieldValue, Alphanumeric_Alert){

    if(/[^a-zA-Z0-9_., ]/.test(fieldValue)) {

        alert(Alphanumeric_Alert);
        return fieldValue.replace(/[^a-zA-Z0-9_., ]/g, "_");

    }

    return fieldValue;

}

function escape_field(fieldValue){

    return fieldValue.replace(/[:]/g, "{$dp}").replace(/[|]/g, "{$pipe}");

}

function check_emails_format(email_list, Email_Alert){

    email_list = email_list.replace(/ /g,"");

    var emails = email_list.split(",");
    var flag = true;

    if (email_list != ""){

        for (var i=0; i<emails.length; i++){

            if ((!emails[i].match("[0-9a-zA-Z]@[0-9a-zA-Z].[a-zA-Z]")) && (emails[i] != "")){
                flag = false;
                alert("\""+emails[i]+"\" "+Email_Alert);
            }

        }

    }

        return flag;

}

function markCheckBoxes(idTable, value){

    var table = document.getElementById(idTable);

    for (var i=2; i<(table.rows.length-2); i++){

        if (value)
            table.rows[i].cells[0].childNodes[0].checked = true;
        else
            table.rows[i].cells[0].childNodes[0].checked = false;

    }

}

function getIndexOf(array, element){

    for (i = 0; i < array.length; i++){

        if (array[i] == element)
            return i;

    }

    return -1;

}

function countSelected(isSelect) {

    var fields = document.getElementById(isSelect);
    var count = 0;

    if (fields != null) {

        for ( var i = 0; i < fields.options.length; i++) {

            if (fields.options[i].selected)
                count++;

        }

    }

    return count;

}

