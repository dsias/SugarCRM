 <?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


error_reporting(E_ALL & ~E_NOTICE);  

function generateCsv($reportName, $headers, $resultset, $headersTotals, $totals, $subTotals, $hasDetail, $store, $rowIndex=0){
	
	global $sugar_config;
	
	$tmpFilesDir = "modules/Reports/tmpReportFiles/";
	$currentDir = getcwd()."/";
	
	$exportCsvDelimiter = (isset($sugar_config["asolReportsCsvDelimiter"])) ? $sugar_config["asolReportsCsvDelimiter"] : ",";
	
	$ExcelFile = "";
	//$idFile = strtolower(str_replace(" ", "_", $reportName))."_".date("Ymd")."T".date("His").".csv";
	$idFile = preg_replace('/[^a-zA-Z0-9]/', '', $reportName)."_".date("Ymd")."T".date("His").".csv";
		
	$ExcelFile .= strtoupper($reportName)."\n\n\n\n";
	
	$ExcelFile .= "REPORT FIELDS\n\n";
		
	$columns = "";
		
	if ($rowIndex == 1)
		$columns .= "N".$exportCsvDelimiter;
	
	foreach ($headers as $column)			
		$columns .= $column.$exportCsvDelimiter;

		
	$columns = substr($columns, 0, -1);
		
	$ExcelFile .= $columns;
	$ExcelFile .= "\n\n";
	
	
	if (!$hasDetail){
		
		$cont = 1;
		
		foreach ($resultset as $row){
			
			$rowSet = "";
			
			if ($rowIndex == 1)
				$rowSet .= "\"".$cont."\"".$exportCsvDelimiter;
			
			foreach ($row as $value)
				$rowSet .= "\"".$value."\"".$exportCsvDelimiter;
			
			$rowSet = substr($rowSet, 0, -1);
			
			$ExcelFile .= $rowSet."\n";
			
			$cont++;
			
		}
				
		$ExcelFile .= "\n\n\n";

	} else {
		
		
		foreach ($resultset as $key=>$subGroup){
			
			$ExcelFile .= strtoupper($key)."\n";
			
			$cont= 1;
			
			foreach ($subGroup as $row){
				
				$rowSet = "";
				
				if ($rowIndex == 1)
					$rowSet .= "\"".$cont."\"".$exportCsvDelimiter;
				
				foreach ($row as $value){
				
					$rowSet .= "\"".$value."\"".$exportCsvDelimiter;
				
				}
				
				$rowSet = substr($rowSet, 0, -1);
			
				$ExcelFile .= $rowSet."\n";
				
				$cont++;
				
			}
			
			$ExcelFile .= "\n".$key." SubTotals"."\n";
			
			$columnsTotals = "";
		
			foreach ($headersTotals as $columnTotal){
					
				$columnsTotals .= $columnTotal[1]."".$exportCsvDelimiter;
					
			}
				
			$columns = substr($columnsTotals, 0, -1);
				
			$ExcelFile .= $columnsTotals;
			$ExcelFile .= "\n";
					
			$rowTotals = "";
			
			foreach ($subTotals[$key] as $value){
				
				$rowTotals .= "\"".$value."\"".$exportCsvDelimiter;
				
			} 
			
			$ExcelFile .= $rowTotals."\n\n\n";
			
		}
		
		$ExcelFile .= "\n\n";
		
	}
	
		
	$ExcelFile .= "REPORT TOTALS\n\n";
		
	$columnsTotals = "";
		
	foreach ($headersTotals as $columnTotal){
			
		$columnsTotals .= $columnTotal[1].$exportCsvDelimiter;
			
	}
		
	$columnsTotals = substr($columnsTotals, 0, -1);
		
	$ExcelFile .= $columnsTotals;
	$ExcelFile .= "\n";
		
	$rowTotals = "";
		
	foreach ($totals as $total){
			
		foreach ($total as $value){
			
			$rowTotals .= "\"".$value."\"".$exportCsvDelimiter;
				
		}
			
	}
			
	$rowTotals = substr($rowTotals, 0, -1);
			
	$ExcelFile .= $rowTotals."\n";
	
	if (isset($sugar_config["asolReportsExportReplaceByEmptyString"])) {
	
		foreach ($sugar_config["asolReportsExportReplaceByEmptyString"] as $token)
			$ExcelFile = str_replace($token, "", $ExcelFile);
	
	}
	
	$ExcelFile = html_entity_decode($ExcelFile);
	
	 //formateamos el fichero a codificacion que pueda leer CSV

    $ExcelFile = iconv("UTF-8", "Windows-1252", $ExcelFile);

    if (!$store){
    
	    //The filename is stored in the $produitFilename variable in my script (the only thing you need)
	    header("Cache-Control: private");
	    header('Content-Type: application/csv; utf-8');
	    header("Content-Disposition: attachment; filename=\"$idFile\"");
	    header("Content-Description: File Transfer");
	    header("Content-Length: ".mb_strlen($ExcelFile, '8bit'));
	    header("Expires: 0");
	    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	    header("Pragma: public");
		
	    //$GLOBALS['log']->debug("ASOL---------------------------------------size ".mb_strlen($ExcelFile, '8bit'));
	    //$GLOBALS['log']->debug("ASOL-------------------------------------- ExcelFile ".$ExcelFile);
	    
		ob_clean();
	    flush();
	    
	    echo $ExcelFile;
	
	    exit;
	    
    } else {
    	
    	$descriptor = fopen($currentDir.$tmpFilesDir.$idFile, "w");
			
		fwrite($descriptor, $ExcelFile);
		fclose($descriptor);
		//Almacenar el csv y devolver la ruta y nombre del fichero
		return $idFile;
    	
    }
    
}


?>