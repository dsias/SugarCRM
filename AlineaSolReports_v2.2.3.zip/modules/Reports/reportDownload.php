<?php

global $sugar_config;

$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;

if ($asolLogLevelEnabled)
	$GLOBALS['log']->asol("ASOL------------------------------------------------------Getting File ".$_REQUEST['fileName']);
else
	$GLOBALS['log']->debug("ASOL------------------------------------------------------Getting File ".$_REQUEST['fileName']);

$tmpFilesDir = "modules/Reports/tmpReportFiles/";

$op = (isset($_REQUEST['op'])) ? $_REQUEST['op'] : "";

if ($op != "css"){

	header("Content-type: application/force-download");
	header("Content-Disposition: attachment; filename=\"".trim($_REQUEST['fileName'])."\"");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize($tmpFilesDir.trim($_REQUEST['fileName'])));
	
	readfile($tmpFilesDir.trim($_REQUEST['fileName'])); 

} else {
	
	header("Content-type: application/force-download");
	header("Content-Disposition: attachment; filename=\"".trim($_REQUEST['fileName'])."\"");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize("modules/Reports/templates/".trim($_REQUEST['fileName'])));
	
	readfile("modules/Reports/templates/".trim($_REQUEST['fileName'])); 
	
}

?>