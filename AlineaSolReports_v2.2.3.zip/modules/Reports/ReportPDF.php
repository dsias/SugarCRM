<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

include_once ('include/pclzip/pclzip.lib.php');
include_once ('dompdf/dompdf_config.inc.php');

error_reporting(E_ALL & ~E_NOTICE);  

function generatePDF($reportName, $module, $description, $headers, $resultset, $headersTotals, $totals, $subTotals, $hasDetail, $pdf_orientation, $urlChart, $isHTML, $store, $pdf_img_scaling_factor, $reportDate, $userTZ, $rowIndex=0, $domainId=""){

	//$pdf_img_scaling_factor solo usada para Exports & Emails
	global $sugar_config;
	
	$asolLogLevelEnabled = ((isset($sugar_config['asolLogLevelEnabled'])) && ($sugar_config['asolLogLevelEnabled'] == true)) ? true : false;

	
	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL--------------------------------------------------Entering at ReportPDF");
	else
		$GLOBALS['log']->debug("ASOL--------------------------------------------------Entering at ReportPDF");
		
		
	$tmpFilesDir = "modules/Reports/tmpReportFiles/";
	$currentDir = getcwd()."/";
	
	//$idFile = strtolower(str_replace(" ", "_", $reportName))."_".date("Ymd")."T".date("His");
	$idFile = preg_replace('/[^a-zA-Z0-9]/', '', $reportName)."_".date("Ymd")."T".date("His");
	
	if ($asolLogLevelEnabled)
		$GLOBALS['log']->asol("ASOL--------------------------------------------------Generating PDF: ".$idFile);
	else
		$GLOBALS['log']->debug("ASOL--------------------------------------------------Generating PDF: ".$idFile);
	
	//GENERAMOS EL HTML
	$html = "<br><br>";

	
	//Get the required css
	$cssURL = (is_file("modules/Reports/templates/".$domainId.".css")) ? "modules/Reports/templates/".$domainId.".css" : "modules/Reports/templates/reports.css";
	$cssFile = (is_file("modules/Reports/templates/".$domainId.".css")) ? $domainId.".css" : "reports.css";

	
	//Get the required company logo
	if (!empty($domainId)) {
		$logoURL = "modules/asol_Domains/logos/".$domainId.".png";
		$logoFile = $domainId.".png";
	} else {
		$logoURL = (is_file("custom/themes/default/images/company_logo.png")) ? "custom/themes/default/images/company_logo.png" : "themes/default/images/company_logo.png";
		$logoFile = "company_logo.png";
	}
		
	if (!$isHTML)
		$html .= "<table class='header-title'><tr><td rowspan=3><img src=\"".getcwd()."/".$logoURL."\"></td><td>".$reportName." - ".$module." Module </td></tr><tr><td>".$description."</td></tr><tr><td>".date("Y-m-d H:i:s", $reportDate)." - ".$userTZ."</td></tr></table>";
	else
		$html .= "<table class='header-title'><tr><td rowspan=3><img src='".$logoFile."'></td><td>".$reportName." - ".$module." Module </td></tr><tr><td>".$description."</td></tr><tr><td>".date("Y-m-d H:i:s", $reportDate)." - ".$userTZ."</td></tr></table>";
		
	$html .= "<br><br><table><tbody>";
	$html .= "<tr><td class='header'>Report Results</td></tr></tbody></table>";


	if (!$hasDetail){

		$html .= "<table><tbody>";
		
		$columns = "<tr>";
		
		if ($rowIndex == 1)		
			$columns .= "<td class='column'>N&deg;</td>";
		
		foreach ($headers as $column){	

				$columns .= "<td class='column'>".$column."</td>";

		}
			
		$columns .= "</tr>";
			
		$html .= $columns;
		
		$cont = 0;
		
		if (count($resultset) == 0)
			$resultset = Array();
		
		foreach ($resultset as $row){
			
			$rowSet = "<tr>";
			
			if ($rowIndex == 1) {
				if ($cont%2 != 0)
					$rowSet .= "<td class='row-uneven'>".($cont + 1)."</td>";
				else
					$rowSet .= "<td class='row-even'>".($cont + 1)."</td>";
			}
						
			foreach ($row as $key=>$value){

				if ($cont%2 != 0)
					$rowSet .= "<td class='row-uneven'>".$value."</td>";
				else
					$rowSet .= "<td class='row-even'>".$value."</td>";	
					
			}
			
			$html .= $rowSet."</tr>";
			
			$cont++;
			
		}
		
		$html .= "</tbody></table><br><br>";

	} else {
	
		foreach ($resultset as $key=>$subGroup){
			
			$html .= "<table><tbody>";
			
			$html .= "<tr><td class='header-group' colspan=".(count($headers) + $rowIndex).">".strtoupper($key)."</td></tr>";
				
			$columns = "<tr>";
		
			if ($rowIndex == 1)		
				$columns .= "<td class='column'>N&deg;</td>";
		
			foreach ($headers as $column){		

				$columns .= "<td class='column'>".$column."</td>";

			}
				
			$columns .= "</tr>";
				
			$html .= $columns;
			
			$cont=0;
			foreach ($subGroup as $row){
				
				$rowSet = "<tr>";
					
				if ($rowIndex == 1) {
					if ($cont%2 != 0)
						$rowSet .= "<td class='row-uneven'>".($cont + 1)."</td>";
					else
						$rowSet .= "<td class='row-even'>".($cont + 1)."</td>";
				}
					
				foreach ($row as $value){
	
					if ($cont%2 != 0)
						$rowSet .= "<td class='row-uneven'>".$value."</td>";
					else
						$rowSet .= "<td class='row-even'>".$value."</td>";	
						
				}
				$html .= $rowSet."</tr>";
				
				$cont++;
			}
		
			$html .= "</tbody></table><table><tbody>";
			
			$html .= "<tr><td class='header-subtotal' rowspan='2'>".strtoupper($key)." SubTotals</td>";
			
			$columnsTotals = "";
		
			foreach ($headersTotals as $columnTotal){
				$columnsTotals .= "<td class='column-subtotal'>".$columnTotal[1]."</td>";
			}

			$html .= $columnsTotals."</tr>";
			$rowTotals = "<tr>";
			
			foreach ($subTotals[$key] as $value){
				$rowTotals .= "<td class='row-subtotal'>".$value."</td>";
			} 
			
			$html .= $rowTotals."</tr>";
			
			$html .= "</tbody></table><br><br>";
		}
		
	}

	
	if (count($totals) > 0){
		
		$html .= "<table><tbody>"; 
		$html .= "<tr><td class='header'>Report Totals</td></tr></tbody></table>";
		
	}
		
	$html .= "<table><tbody>";
	$columnsTotals = "<tr>";
		
	foreach ($headersTotals as $columnTotal){
		
		$columnsTotals .= "<td class='column-total'>".$columnTotal[1]."</td>";

	}
		
	$columnsTotals .= "</tr>";
	
	if (count($totals) > 0)
		$html .= $columnsTotals;
	
	$rowTotals = "<tr>";
		
	foreach ($totals as $total){
				
		foreach ($total as $value){

			$rowTotals .= "<td class='row-total'>".$value."</td>";
		
		}
			
	}
			
	$rowTotals .= "</tr>";
			
	$html .= $rowTotals."\n";
	$html .= "</tbody></table>";
	
	
	$htmlChart = "";
	
	
	if (count($urlChart) > 0) {
		
	
		if (count($resultset) > 0)
			$htmlChart .= "<div style='page-break-after: always;'></div>";
		else
			$htmlChart .= "<br><br><br>";
								
		for ($i=0; $i<count($urlChart); $i++){
						
			if (!$isHTML){
				
				$htmlChart .= "<table><tr><td class='header'>Report Chart ".($i+1)."</td></tr></table>";
				
				$imgDimension = GetImageSize($tmpFilesDir.$urlChart[$i]);
				
				$widthDimension = ($imgDimension[0]*($pdf_img_scaling_factor/100));
				
				
				if ((($widthDimension > 1000) && ($pdf_orientation == "landscape"))) {
					
					$htmlChart .= "<table><tbody><tr><td><img class='chart-img' width='1000px' src='".$tmpFilesDir.$urlChart[$i]."'></td></tr></tbody></table>";
					
				} else if ($pdf_orientation == "landscape"){

					$htmlChart .= "<table><tbody><tr><td><img class='chart-img' width='".$widthDimension."px' src='".$tmpFilesDir.$urlChart[$i]."'></td></tr></tbody></table>";
					
				}
				
				
				if ((($widthDimension > 800) && ($pdf_orientation != "landscape"))) {
					
					$htmlChart .= "<table><tbody><tr><td><img class='chart-img' width='800px' src='".$tmpFilesDir.$urlChart[$i]."'></td></tr></tbody></table>";
					
				} else if ($pdf_orientation != "landscape"){

					$htmlChart .= "<table><tbody><tr><td><img class='chart-img' width='".$widthDimension."px'  src='".$tmpFilesDir.$urlChart[$i]."'></td></tr></tbody></table>";
					
				}
				
			
			} else {

				$htmlChart .= "<br><br><br><table><tr><td class='header'>Report Chart ".($i+1)."</td></tr></table>";
				$htmlChart .= "<table><tbody><tr><td><img class='chart-img' src='".$urlChart[$i]."'></td></tr></tbody></table>";
			
			}
				
			if ($i < (count($urlChart)-1))
				$htmlChart .= "<div style='page-break-after: always;'></div>";
				
		}
		
		$html .= $htmlChart;
		
	} 
	
	
	if (!$isHTML)
		$html = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><link href='".$cssURL."' type='text/css' rel='stylesheet'></head><body>".$html."</body></html>";
	else
		$html = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><link href='".$cssFile."' type='text/css' rel='stylesheet'></head><body>".$html."</body></html>";
		
		
	if (!$isHTML){
		
		$idFile .= ".pdf"; 
		
		if ($asolLogLevelEnabled)
			$GLOBALS['log']->asol("ASOL--------------------------------------------------Instantiating and configuring DOMPDF");
		else
			$GLOBALS['log']->debug("ASOL--------------------------------------------------Instantiating and configuring DOMPDF");
			
		$dompdf = new DOMPDF();
		
		if ($pdf_orientation == "landscape")
			$dompdf->set_paper('A4', 'landscape');
		else
			$dompdf->set_paper('A4', '');

		/*	
		$f = fopen("fileHTML.html", "w");
		fwrite($f, $html);
		fclose($f);
		*/

		if ($asolLogLevelEnabled)
			$GLOBALS['log']->asol("ASOL--------------------------------------------------Loading HTML with DOMPDF");
		else
			$GLOBALS['log']->debug("ASOL--------------------------------------------------Loading HTML with DOMPDF");
		
		if (isset($sugar_config["asolReportsExportReplaceByEmptyString"])) {
		
			foreach ($sugar_config["asolReportsExportReplaceByEmptyString"] as $token)
				$html = str_replace($token, "", $html);
		
		}
		
		
		$dompdf->load_html($html);

		
		if (!$store){
		
			$dompdf->render();	
			$dompdf->stream($idFile);

		} else {
		
			if ($asolLogLevelEnabled)
				$GLOBALS['log']->asol("ASOL--------------------------------------------------Generating PDF File");
			else
				$GLOBALS['log']->debug("ASOL--------------------------------------------------Generating PDF File");
			
			$descriptor = fopen($currentDir.$tmpFilesDir.$idFile, "w");
			
			$dompdf->render();
			$pdfoutput = $dompdf->output();
			
			if ($asolLogLevelEnabled)
				$GLOBALS['log']->asol("ASOL--------------------------------------------------Storing PDF File: ".$idFile);
			else
				$GLOBALS['log']->debug("ASOL--------------------------------------------------Storing PDF File: ".$idFile);
				
			fwrite($descriptor, $pdfoutput);
			fclose($descriptor);
			//Almacenar el html y devolver la ruta y nombre del fichero
			return $idFile;		
			
		}
		
		foreach ($urlChart as $key=>$chart){				
			unlink($tmpFilesDir.$chart);
		}
		
	} else {

		/*
		$zipname = explode(" ", $idFile);
		$idFile = implode("_", $zipname);
		*/
		
		$descriptor = fopen($currentDir.$tmpFilesDir.$idFile.".html", "w");
		fwrite($descriptor, $html);
		fclose($descriptor);
		
		$reportZip = new PclZip($tmpFilesDir.$idFile.".zip");
		
		$zipFiles = $tmpFilesDir.$idFile.".html";
		$zipFiles .= ",".$cssURL; 
		
		$zipFiles .= ",".$logoURL;
		
		foreach ($urlChart as $key=>$chart){
			$zipFiles .= ",".$tmpFilesDir.$chart;
		}
		
		$reportZip->create($zipFiles, PCLZIP_OPT_REMOVE_ALL_PATH, PCLZIP_OPT_ADD_PATH, $idFile);
		
		//Crear el fichero zip
		
		if (!$store){		
			
			header("Content-type: application/force-download");
	        header("Content-Disposition: attachment; filename=\"".$idFile.".zip\"");
	        header("Content-Transfer-Encoding: binary");
	        header("Content-Length: ".filesize($tmpFilesDir.$idFile.".zip"));

	        readfile($tmpFilesDir.$idFile.".zip"); 
		    
	        //Eliminamos ficheros tmp
	        unlink($tmpFilesDir.$idFile.".zip");
		    unlink($tmpFilesDir.$idFile.".html");
	        
			foreach ($urlChart as $key=>$chart){				
				unlink($tmpFilesDir.$chart);
			}
		    
		    
		} else {
			
			//Almacenar el html y devolver la ruta y nombre del fichero
			return $idFile.".zip";
			
		}
		
	}
	
}

?>