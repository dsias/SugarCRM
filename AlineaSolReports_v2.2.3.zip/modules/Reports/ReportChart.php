<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


function generateSwfPieChart($prefixChart, $chartTitle, $chartLegends, $chartValues, $numGroups, $overridedName = null){
	
	global $sugar_config;

	$tmpFilesDir = "modules/Reports/tmpReportFiles/";
	$currentDir = getcwd()."/";

	
	$prefixChart = str_replace(" ", "_", $prefixChart);
	$xmlName = $prefixChart."_".dechex(time()).dechex(rand(0,999999)).".xml";
	
	$xmlCompletePath = (empty($overridedName)) ? $tmpFilesDir.$xmlName : $overridedName;
	
	$descriptor = fopen($xmlCompletePath, "w");
	
	

	$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	$xml .= "<sugarcharts version=\"1.0\">\n";
	
	$xml .= "\t<properties>\n";
	$xml .= "\t\t<title>".$chartTitle."</title>\n";
	$xml .= "\t\t<subtitle>Value size in 1K</subtitle>\n";
	$xml .= "\t\t<type>pie chart</type>\n";
	$xml .= "\t\t<legend>on</legend>\n";
	$xml .= "\t\t<labels>value</labels>\n";
	$xml .= "\t</properties>\n";
	
	$xml .= "\t<data>\n";
	
	foreach ($chartLegends as $key=>$chartLegend){
		
		$xml .= "\t\t<group>\n";
		$xml .= "\t\t\t<title>".$chartLegend."</title>\n";
		
		if (max($chartValues) >= 1000){
			$xml .= "\t\t\t<value>".($chartValues[$key]/1000)."</value>\n";
			$xml .= "\t\t\t<label>".floor($chartValues[$key]/1000)."K</label>\n";
		} else {
			$xml .= "\t\t\t<value>".$chartValues[$key]."</value>\n";
			$xml .= "\t\t\t<label>".(floor($chartValues[$key] * 100) / 100)."</label>\n";
		}
		//fputs($descriptor, '<link>index.php?module=Opportunities&action=index&query=true&searchFormTab=advanced_search&lead_source=Cold+Call</link>')
		$xml .= "\t\t\t<subgroups>\n";
		$xml .= "\t\t\t</subgroups>\n";
		$xml .= "\t\t</group>\n";
		
	}
	
	$xml .= "\t</data>\n";
	
	$xml .= "\t<yAxis>\n";
	$xml .= "\t\t<yMin>0</yMin>\n";

	if (max($chartValues) >= 1000){
			$xml .= "\t\t<yMax>".(ceil((max($chartValues))/1000)+2)."</yMax>\n";
		} else {
			$xml .= "\t\t<yMax>".(max($chartValues)+1)."</yMax>\n";
		}
	
	$xml .= "\t\t<yStep>1</yStep>\n";
	$xml .= "\t\t<yLog>1</yLog>\n";
	$xml .= "\t</yAxis>\n";
	
	$xml .= "</sugarcharts>";
	
	$xml = chr(255).chr(254).mb_convert_encoding($xml, 'UTF-16LE', 'UTF-8'); 
	fputs($descriptor, $xml);
	fclose($descriptor);
	
	return $xmlCompletePath;
	
}

function generateSwfBarChart($prefixChart, $chartTitle, $chartLegends, $chartValues, $numGroups, $overridedName = null){
	
	global $sugar_config;

	$tmpFilesDir = "modules/Reports/tmpReportFiles/";
	$currentDir = getcwd()."/";
	
	
	$xmlName = $prefixChart."_".dechex(time()).dechex(rand(0,999999)).".xml";
	
	$xmlCompletePath = (empty($overridedName)) ? $tmpFilesDir.$xmlName : $overridedName;
	
	$descriptor = fopen($xmlCompletePath, "w");
	
	
	$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	$xml .= "<sugarcharts version=\"1.0\">";
	
	$xml .= "\t<properties>";
	$xml .= "\t\t<title>".$chartTitle."</title>";
	
	if (max($chartValues) >= 1000)
		$xml .= "\t\t<subtitle>Values size in 1K</subtitle>";
	else 
		$xml .= "\t\t<subtitle></subtitle>";
	
	$xml .= "\t\t<type>bar chart</type>";
	$xml .= "\t\t<legend>on</legend>";
	$xml .= "\t\t<labels>value</labels>";
	$xml .= "\t</properties>";
	
	$xml .= "\t<data>";
	
	foreach ($chartLegends as $key=>$chartLegend){
		
		$xml .= "\t\t<group>";
		$xml .= "\t\t\t<title>".$chartLegend."</title>";
	
		if (max($chartValues) >= 1000){
			$xml .= "\t\t\t<value>".($chartValues[$key]/1000)."</value>";
			$xml .= "\t\t\t<label>".floor($chartValues[$key]/1000)."K</label>";
		} else {
			$xml .= "\t\t\t<value>".$chartValues[$key]."</value>";
			$xml .= "\t\t\t<label>".(floor($chartValues[$key] * 100) / 100)."</label>";
		}
		
		//fputs($descriptor, '<link>index.php?module=Opportunities&action=index&query=true&searchFormTab=advanced_search&lead_source=Cold+Call</link>')
		$xml .= "\t\t\t<subgroups>";
		$xml .= "\t\t\t</subgroups>";
		$xml .= "\t\t</group>";
		
	}
	
	$xml .= "\t</data>";
	
	$xml .= "\t<yAxis>";
	$xml .= "\t\t<yMin>0</yMin>";
	
	if (max($chartValues) >= 1000){
		$xml .= "\t\t<yMax>".(ceil((max($chartValues))/1000)+2)."</yMax>";
		$xml .= "\t\t<yStep>".ceil((ceil((max($chartValues))/1000)+2)/5)."</yStep>";
	} else {
		$xml .= "\t\t<yMax>".(ceil(max($chartValues))+2)."</yMax>";
		$xml .= "\t\t<yStep>".(ceil((max($chartValues)+2)/5))."</yStep>";
	}
	
	$xml .= "\t\t<yLog>1</yLog>";
	$xml .= "\t</yAxis>";
	
	$xml .= "</sugarcharts>";
	
	$xml = chr(255).chr(254).mb_convert_encoding($xml, 'UTF-16LE', 'UTF-8'); 
	fputs($descriptor, $xml);
	fclose($descriptor);
	
	return $xmlCompletePath;
	
}

?>