<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $mod_strings,$app_strings;

if(ACLController::checkAccess('Reports', 'list', true)) $module_menu[]=Array("index.php?module=Reports&action=index", "Reports","Reports");
if(ACLController::checkAccess('Reports', 'edit', true)) $module_menu[]=Array("index.php?module=Reports&action=EditView", "Create","Reports");
$module_menu[]=Array("index.php?module=Administration&action=asolConfig&return_module=Reports&return_action=index", "Configuration", "Reports");

?>