<?php

$app_list_strings['moduleList']['Reports'] = 'Reports';

?>