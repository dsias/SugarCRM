<?php
$manifest = array(
    'acceptable_sugar_flavors' => array(),
    'acceptable_sugar_versions' => array(),
    'is_uninstallable'=>true,
	'remove_tables' => 'prompt',
    'name' => 'AlineaSol Reports',
    'description' => 'AlineaSol: This module adds customizable reports to SugarCRM. Also adds User module bugfix',
    'author' => 'AlineaSol',
    'published_date' => '2011/10/21',
    'version' => '2.2.3',
    'type' => 'module',
    'icon' => '',
);

$installdefs = array(
	'id' => 'AlineaSolReports',
	'beans' => array(
	     array(
	     	'module'          => 'Reports',
	     	'class'           => 'Report',
	     	'path'            => 'modules/Reports/Report.php',
	     	'tab'             => true, 
	     )
	),
	'language' => array(
	     array(
		     'from'           => '<basepath>/language/en_us.Reports.php',
		     'to_module'      => 'application',
		     'language'       => 'en_us' 
		     ),
		 array(
		     'from'           => '<basepath>/language/es_es.Reports.php',
		     'to_module'      => 'application',
		     'language'       => 'es_es' 
		     ),
		array(
		     'from'           => '<basepath>/language/sp_ve.Reports.php',
		     'to_module'      => 'application',
		     'language'       => 'sp_ve' 
		     ),
		array(
            'from' 			  => '<basepath>/language/en_us.administration.php' ,
            'to_module' 	  => 'Administration' ,
            'language' 	 	  => 'en_us'
        ) ,
		array(
            'from' 			  => '<basepath>/language/es_es.administration.php' ,
            'to_module' 	  => 'Administration' ,
            'language' 	 	  => 'es_es'
        ) ,
        array(
            'from' 			  => '<basepath>/language/sp_ve.administration.php' ,
            'to_module' 	  => 'Administration' ,
            'language' 	 	  => 'sp_ve'
        ) ,
   ),
	'copy' => array(
		array(
			'from' => '<basepath>/modules/',
			'to'   => 'modules/',
		),
		array(
			'from' => '<basepath>/include/SugarCharts/swf/',
			'to'   => 'include/SugarCharts/swf/',
		),
		array(
			'from' => '<basepath>/custom/',
			'to'   => 'custom/',
		),
		
	),
	
	'pre_execute'=>array(
		0 => '<basepath>/actions/pre_install.php',
	),
	
	'post_execute'=>array(
		0 => '<basepath>/actions/post_install.php',
	),
	
	'pre_uninstall'=>array(
		0 => '<basepath>/actions/pre_uninstall.php',
	),
	
	'post_uninstall'=>array(
		0 => '<basepath>/actions/post_uninstall.php',
	),

);
?>
