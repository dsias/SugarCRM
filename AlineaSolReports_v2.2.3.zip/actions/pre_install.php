<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('modules/Users/User.php');

global $sugar_config, $db, $timedate, $current_user;


//if database tables don`t use InnoDB engine, change the engine to InnoDB
$db_name = $sugar_config['dbconfig']['db_name'];

//Comprobamos si existe la tabla Reports y recorremos sus campos modificado las fechas a GMT
$queryResults = $db->query("SELECT * FROM reports");
	
while($queryRow = $db->fetchByAssoc($queryResults)){
	$retArray[] = $queryRow;
}


if (count($retArray) > 0){

	$GLOBALS['log']->debug("ASOL ------------------------------------------------------- Conversion a GMT");

	foreach ($retArray as $row){
	
		$theUser = new User();
		$theUser->retrieve($row["created_by"]);
		
		//$hourOffset = $timedate->get_hour_offset(true, $theUser->getPreference("timezone"))*3600;
		$userTZ = $theUser->getPreference("timezone");
		$phpDateTime = new DateTime(null, new DateTimeZone($userTZ));
		$hourOffset = $phpDateTime->getOffset()*-1;
	
		if (strpos($row["report_tasks"], "\${GMT}") === false){
			
			$GLOBALS['log']->debug("ASOL --------------------------------------------- Report sin GMT");
			
			//Adaptamos las fechas a formato GMT
			if (strlen($row["last_run"]) > 0){
			
				$lr = explode(" ", $row["last_run"]);
				$lr_date = explode("-", $lr[0]);
				$lr_time = explode(":", $lr[1]);
				$last_run = '"'.date("Y-m-d H:i:s", mktime($lr_time[0],$lr_time[1],$lr_time[2],$lr_date[1],$lr_date[2],$lr_date[0])+$hourOffset).'"';
			
			} else {
			
				$last_run = 'NULL';
			
			}
			
			//Fechas de los Tasks
			$tasks = explode("|", $row["report_tasks"]);
			
			foreach($tasks as $key=>$task){
			
				$values = explode(":", $task);
				$time1 = explode(",", $values[3]);
				$values[3] = date("H,i", mktime($time1[0],$time1[1],0,date("m"),date("d"),date("Y"))+$hourOffset);
				
				$tasks[$key] = implode(":", $values);
			
			}
			
			$db->query('UPDATE reports SET last_run='.$last_run.', report_tasks="'.implode("|", $tasks)."\${GMT}".'" WHERE id="'.$row["id"].'"');
			
		} else {
		
			$GLOBALS['log']->debug("ASOL --------------------------------------------- Report con GMT");
		
		}
	
	} 
	

} else {


	//Querys para generar las tablas nuevas: reports y reports_config

	$GLOBALS['log']->debug("ASOL ------------------------------------------------------- Creando tablas");

	$db->query("CREATE TABLE IF NOT EXISTS ".$db_name.".`reports` (
	  `id` char(36) NOT NULL,
	  `name` varchar(255) NULL,
	  `date_entered` datetime DEFAULT NULL,
	  `date_modified` datetime DEFAULT NULL,
	  `modified_user_id` char(36) DEFAULT NULL,
	  `created_by` char(36) DEFAULT NULL,
	  `description` varchar(255) DEFAULT NULL,
	  `deleted` tinyint(1) DEFAULT '0',
	  `assigned_user_id` char(36) DEFAULT NULL,
	  `last_run` datetime DEFAULT NULL,
	  `report_module` varchar(50) DEFAULT NULL,
	  `report_scope` text,
	  `report_fields` text,
	  `report_filters` text,
	  `report_charts_detail` text,
	  `report_type` varchar(12) DEFAULT NULL,
	  `report_charts` varchar(4) DEFAULT NULL,
	  `report_tasks` varchar(255) DEFAULT NULL,
	  `email_list` varchar(255) DEFAULT NULL,
	  `report_attachment_format` varchar(8) DEFAULT NULL,
	  `scheduled_images` tinyint(1) DEFAULT NULL,
	  `row_index_display` tinyint(1) DEFAULT '0',
	  `results_limit` varchar(255) DEFAULT 'all',
	  PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8;");

	/*
	$db->query("CREATE TABLE IF NOT EXISTS ".$db_name.".`reports_dispatcher` (
	  `id` char(36) NOT NULL,
	  `report_id` char(36) NULL,
	  `html_file_name` varchar(255) DEFAULT NULL,
	  `xml_files_name` varchar(255) DEFAULT NULL,
	  `status` varchar(45) DEFAULT NULL,
	  `request_init_date` datetime DEFAULT NULL,
	  `last_recall` datetime DEFAULT NULL,
	  `request_type` varchar(45) DEFAULT NULL,
	  `owner_user_id` char(36) DEFAULT NULL,
	  PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8;");
	*/
	 
 }
 
 
 $db->query("CREATE TABLE IF NOT EXISTS ".$db_name.".`asol_config` (
	  `id` CHAR(36) NOT NULL, 
	  `name` VARCHAR(255) NOT NULL, 
	  `date_entered` DATETIME NULL DEFAULT NULL, 
	  `date_modified` DATETIME NULL DEFAULT NULL, 
	  `modified_user_id` CHAR(36) NULL DEFAULT NULL, 
	  `created_by` CHAR(36) NULL DEFAULT NULL, 
	  `deleted` TINYINT(1) NULL DEFAULT '0', 
	  `config` VARCHAR(255) NOT NULL DEFAULT '1|15|landscape|1|120|7|localhost/sugarcrm', 
	  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

	  
	 $db->query("INSERT IGNORE INTO `asol_config` 
	  (`id`, `name`, `date_entered`, `date_modified`, `modified_user_id`, `created_by`, `deleted`, `config`) 
	 VALUES ('1', 'admin', '2010-01-01 00:00:00', '2010-01-01 00:00:00', '1', '1', 0, '1|15|landscape|1|120|7|');");
 
 
 $GLOBALS['log']->debug("ASOL ------------------------------------------------------- Tablas creadas");
 
 
 //Editamos el fichero entry_point_registry.php para a�adirle un nuevo entry point para la scheduled Tasks de los Reports
 
   $gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while ((!feof($gestor)) && (!strstr($buffer, '$entry_point_registry = array('))) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer;
		}
	
		$fileText .= "\t'viewReport' => array('file' => 'modules/Reports/DetailView.php', 'auth' => false),\n";
		echo "'viewReport' => array('file' => 'modules/Reports/DetailView.php', 'auth' => false),<br>";
		$fileText .= "\t'scheduledTask' => array('file' => 'modules/Reports/scheduledTask.php', 'auth' => false),\n";
		echo "'scheduledTask' => array('file' => 'modules/Reports/scheduledTask.php', 'auth' => false),<br>";
		$fileText .= "\t'vRender' => array('file' => 'modules/Reports/vRender.php', 'auth' => false),\n";
		echo "'vRender' => array('file' => 'modules/Reports/vRender.php', 'auth' => false),<br>";
		$fileText .= "\t'reportPopup' => array('file' => 'modules/Reports/reportPopup.php', 'auth' => false),\n";
		echo "'reportPopup' => array('file' => 'modules/Reports/reportPopup.php', 'auth' => false),<br>";
		$fileText .= "\t'reportDownload' => array('file' => 'modules/Reports/reportDownload.php', 'auth' => false),\n";
		echo "'reportDownload' => array('file' => 'modules/Reports/reportDownload.php', 'auth' => false),<br>";
		$fileText .= "\t'scheduledEmailReport' => array('file' => 'modules/Reports/scheduledEmailReport.php', 'auth' => false),\n";
		echo "'scheduledEmailReport' => array('file' => 'modules/Reports/scheduledEmailReport.php', 'auth' => false),<br>";
		$fileText .= "\t'asol_CheckHttpFileExists' => array('file' => 'modules/Reports/CheckHttpFileExists.php', 'auth' => false),\n";
		echo "'asol_CheckHttpFileExists' => array('file' => 'modules/Reports/CheckHttpFileExists.php', 'auth' => false),<br>";
		
		
		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer; 
		}
	
	fclose($gestor);
	
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }
  
  
  
  //Editamos el fichero User.php para arreglar el Bug que tiene a la hora de obtener el email del usuario activo
  $gestor = fopen("modules/Users/User.php", "r");
  
  if ($gestor){
  
	$fileText = "";
  
	while ((!feof($gestor)) && (!strstr($buffer, "\$fromddr = \$a['value'];"))) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer;
	}
	
	$fileText .= "\$fromaddr = \$a['value'];\n";
	echo "\$fromaddr = \$a['value'];<br>";
  
	while (!feof($gestor)) {
	
		$buffer = fgets($gestor);
		$fileText .= $buffer; 
	}
	
	fclose($gestor);
	
	$gestor = fopen("modules/Users/User.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }
  
 
//Mantenemos la ultma version del fichero repair de alineasol
if (file_exists("modules/Administration/asolRepair.php"))
	@copy("modules/Administration/asolRepair.php", "AlineaSol_restore/asolRepair.php");
 
?>
