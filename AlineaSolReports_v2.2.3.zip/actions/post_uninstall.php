<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $db;

$salesQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name IN ('AlineaSolSales', 'AlineaSolPublishHomePage', 'AlineaSolDomains') AND status='installed'");
$queryRow = $db->fetchByAssoc($salesQuery);

//Eliminar si es el �nico modulo de AlineaSol qe queda instalado en la instancia actual
if ($queryRow['count'] == 0) {

	//if remove tables option is set, remove roles_homepage table too
	if (isset($_REQUEST['remove_tables']) && $_REQUEST['remove_tables']=='true') {
		
		$GLOBALS['log']->debug("*********************** ASOL: Removing from asol_config");
		$db->query("DROP TABLE asol_config");
		/*$GLOBALS['log']->debug("*********************** ASOL: Removing from reports_dispatcher");
		$db->query("DROP TABLE reports_dispatcher");*/
		
	}
	
	@unlink("custom/Extension/modules/Administration/Ext/Administration/AlineaSolConfig.php");

} else {

	//Mantener los ficheros del modulo de administracion para la configuraci�n del resto de m�dulos AlineaSol que lo usen
	@copy("AlineaSol_restore/temp/asolConfig.php", "modules/Administration/asolConfig.php");
	@copy("AlineaSol_restore/temp/asolConfig.tpl", "modules/Administration/asolConfig.tpl");
	@copy("AlineaSol_restore/temp/asolConfigBean.php", "modules/Administration/asolConfigBean.php");
	@copy("AlineaSol_restore/temp/asolRepair.php", "modules/Administration/asolRepair.php");
	@copy("AlineaSol_restore/temp/AlineaSolConfig.php", "custom/Extension/modules/Administration/Ext/Administration/AlineaSolConfig.php");
	//Recuperamos el fichero de idioma EXT de Administracion
	@copy("AlineaSol_restore/temp/en_us.AlineaSol.php", "custom/Extension/modules/Administration/Ext/Language/en_us.AlineaSol.php");
	@copy("AlineaSol_restore/temp/es_es.AlineaSol.php", "custom/Extension/modules/Administration/Ext/Language/es_es.AlineaSol.php");
	
	@unlink("AlineaSol_restore/temp/asolConfig.php");
	@unlink("AlineaSol_restore/temp/asolConfig.tpl");
	@unlink("AlineaSol_restore/temp/asolConfigBean.php");
	@unlink("AlineaSol_restore/temp/AlineaSolConfig.php");
	@unlink("AlineaSol_restore/temp/en_us.AlineaSol.php");
	@unlink("AlineaSol_restore/temp/es_es.AlineaSol.php");
	
}

if ($queryRow['count'] == 0)
	@rmdir_recursive('AlineaSol_restore');


//Modificamos el fichero entry_point_registry.php para eliminarle la entrada de los scheduledTasks de los Reports
  $GLOBALS['log']->debug("*********************** ASOL: Restoring entry_point_registry.php File");
  
  $gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
								   
			if ( (!strstr($buffer, "'viewReport' => array('file' => 'modules/Reports/DetailView.php', 'auth' => false),")) && (!strstr($buffer, "'scheduledTask' => array('file' => 'modules/Reports/scheduledTask.php', 'auth' => false),")) && (!strstr($buffer, "'vRender' => array('file' => 'modules/Reports/vRender.php', 'auth' => false),")) && (!strstr($buffer, "'reportPopup' => array('file' => 'modules/Reports/reportPopup.php', 'auth' => false),")) && (!strstr($buffer, "'reportDownload' => array('file' => 'modules/Reports/reportDownload.php', 'auth' => false),")) && (!strstr($buffer, "'scheduledEmailReport' => array('file' => 'modules/Reports/scheduledEmailReport.php', 'auth' => false),")) && (!strstr($buffer, "'asol_CheckHttpFileExists' => array('file' => 'modules/Reports/CheckHttpFileExists.php', 'auth' => false),")) ){
				$fileText .= $buffer; 
				echo $buffer."<br>";
			}
    
		}
	
	fclose($gestor);
	
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }

  $GLOBALS['log']->debug("*********************** ASOL: entry_point_registry.php file has been restored");
  
  
  @rmdir_recursive('modules/Reports');
  
?>
