<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $db;

$salesQuery = $db->query("SELECT DISTINCT count(id_name) as count FROM upgrade_history WHERE id_name IN ('AlineaSolSales', 'AlineaSolPublishHomePage', 'AlineaSolDomains') AND status='installed'");
$queryRow = $db->fetchByAssoc($salesQuery);

//Mantener los ficheros del mdulo de administracion para la configuraci�n de m�dulos AlineaSol
if ($queryRow['count'] > 0) {
	
	$GLOBALS['log']->debug("********************************ASOL:  Saving files for AlineaSol Administration config Panel");
	
	@mkdir("AlineaSol_restore/temp", 0777, true);
	
	@copy("modules/Administration/asolConfig.php", "AlineaSol_restore/temp/asolConfig.php");
	@copy("modules/Administration/asolConfig.tpl", "AlineaSol_restore/temp/asolConfig.tpl");
	@copy("modules/Administration/asolConfigBean.php", "AlineaSol_restore/temp/asolConfigBean.php");
	@copy("modules/Administration/asolRepair.php", "AlineaSol_restore/temp/asolRepair.php");
	@copy("custom/Extension/modules/Administration/Ext/Administration/AlineaSolConfig.php", "AlineaSol_restore/temp/AlineaSolConfig.php");
	//Guardar e fichero de idioma EXT de Administracion
	@copy("custom/Extension/modules/Administration/Ext/Language/en_us.AlineaSol.php", "AlineaSol_restore/temp/en_us.AlineaSol.php");
	
}


//Buscamos todos los ficheros de la carpeta temporal de informes y los eliminamos
$dir = "modules/Reports/tmpReportFiles/";
$directorio=opendir($dir); 

while ($archivo = readdir($directorio))
	@unlink ($dir.$archivo); 

closedir($directorio); 

?>