<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//Renombramos el fichero de idioma de la zona de administracion
@rename("custom/Extension/modules/Administration/Ext/Language/en_us.AlineaSolReports.php", "custom/Extension/modules/Administration/Ext/Language/en_us.AlineaSol.php");

	
//Mantenemos la ultma version del fichero repair de alineasol
if (file_exists("modules/Administration/asolRepair.php"))
	@copy("AlineaSol_restore/asolRepair.php", "modules/Administration/asolRepair.php");
	

?>