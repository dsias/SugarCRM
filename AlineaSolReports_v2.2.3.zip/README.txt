//**************************************//
//****************Notes*****************//
//**************************************//

- Recommended php version: PHP Version 5.2.9

- The PHP memory limit in php.ini (memory_limit = 256M ) should be set to a minimum of 256MB to allow PDF rendering. 

- To test possible issues with memory limit or similar situations, exists some additional traces in the PDF report generation process (including PHP memory usage traces). 

- This module will modify the "User.php" file to fix a bug in Users module (this module does not obtain the email of the logged user to send emails).

- Also, "entry_point_registry.php" file will be modified to supporting report scheduled tasks and exported reports. 
To configure this functionality, you must configure the admin schedulers module of sugarCRM and create a new Scheduler that executes the url "http://localhost/sugarCRM_dir_in_htdocs/index.php?entryPoint=scheduledTask&module=Reports" every 15 minutes and every day.

- To add a custom logo to your exported PDF reports, the logo image you add to sugarCRM must be in "PNG" image format.

- If you don't want to share your exported report's email list, just find the following line: s:10:"email_list";s:36:"example1@mail.com, example2@mail.com";
Then, replace it by: s:10:"email_list";s:0:"";

- When programing scheduled reports with a link to the report with charts, you must configure the "host name" option of your AlineaSolReports module to generate that link correctly: 
e.g. 'www.your_domain_name.com/yourSugarCrmInstanceName'

- To import reports from Alineasol Reports module version 1.0, you must copy and save the emails list, the attachment format and the scheduled tasks before you delete the old module (while deleting the module, don't forget to remove database tables). 
When installing the new version and then importing the old reports, edit each report and update them with the emails, the attachment format and scheduled tasks saved previously.

- To upgrade from older versions than 1.2.2 to the current version, you must make a database repair and add the missing row, and then modify the Alineasol Reports Scheduler, appending the next string to the current: "&module=Reports".

- Also, for upgrade from older versions than 1.3.0 to the current version, you don't have to remove tables from reports module, but you should update the reports just modifying and saving them without any change. 
Anyway you can run any reports although you dont do this update.

- To upgrade from older versions than 2.0.0 to the current version, you must make a database repair and add the missing rows.

- To send external filters through url, you must add a "Filter Reference" value to filters when configuring a report. 
This is the structure for your external filters url query: "&external_filters=Filter1_ReferenceName${dp}Filter1_Operator${dp}Filter1_FirstParameter${dp}Filter1_SecondParameter${pipe}Filter2_ReferenceName${dp}Filter2_Operator${dp}Filter2_FirstParameter${dp}Filter2_SecondParameter{pipe}....".

- To configure an interactive Report, you can set the "Behaviour" value of a filter to "user input". Then this filter will appear at the execution of the report to perform a dynamic search (a filter reference must be defined for this filter to make it run).
If "visible" value is set, the filter configured value will be displayed but will not be modifiable when running report. Also when "user input" is selected, you can define user custom options (separated by commas) that will be displayed on a select input when running the report.


//**************************************//
//****************Notes*****************//
//**************************************//



//**************************************//
//******Config Override Features********//
//**************************************//

Activation of Features just configuring it at "config_override.php" file of your SugarCRM instance (just add the defined lines to this file):


	- External Database Connection:
		$sugar_config["asolReportsDbAddress"] = "192.168.0.X";
		$sugar_config["asolReportsDbUser"] = "root";
		$sugar_config["asolReportsDbPassword"] = "";
		$sugar_config["asolReportsDbName"] = "sugarcrm";
		$sugar_config["asolReportsDbPort"] = "3306";

		
	- Exporting Delimiter for CSV Reports:
		$sugar_config["asolReportsCsvDelimiter"] = ",";

		
	- Empty Exported Characters:
		$sugar_config["asolReportsExportReplaceByEmptyString"] = array ("€", "$");

	
	- Reports HTTP Request (the Url must be the same of your running sugarCRM instance):
		$sugar_config["asolReportsCurlRequestUrl"] = "http://127.0.0.1/sugarcrm/"; // normally will be the localhost ip
		$sugar_config["asolReportsExtHttpUrl"] = "http://192.168.0.X/sugarcrm/";
		$sugar_config["asolReportsCheckHttpFileTimeout"] = "10000"; // interval to asking for executed report (in miliseconds)


	- Enable/Disable reports pagination:
		$sugar_config["asolReportsAvoidReportsPagination"] = false; // true -> [disable] / false -> [enable]




//**************************************//
//******Config Override Features********//
//**************************************//


//**************************************//
//*************Know Issues**************//
//**************************************//

- In version 2.0.0 and up: when searching a report in report dashlets and then saving a selected one, does not refresh automatically the dashlet. You must refresh it manually.

//**************************************//
//*************Know Issues**************//
//**************************************//