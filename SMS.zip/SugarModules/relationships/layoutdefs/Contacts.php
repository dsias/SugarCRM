<?php
// created: 2015-03-25 22:27:57
$layout_defs["Contacts"]["subpanel_setup"]["np_56_sms_messages_contacts"] = array (
  'order' => 100,
  'module' => 'np_56_SMS_Messages',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NP_56_SMS_MESSAGES_CONTACTS_FROM_NP_56_SMS_MESSAGES_TITLE',
  'get_subpanel_data' => 'np_56_sms_messages_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
