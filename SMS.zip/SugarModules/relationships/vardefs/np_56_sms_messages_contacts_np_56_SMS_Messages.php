<?php
// created: 2015-03-25 22:27:57
$dictionary["np_56_SMS_Messages"]["fields"]["np_56_sms_messages_contacts"] = array (
  'name' => 'np_56_sms_messages_contacts',
  'type' => 'link',
  'relationship' => 'np_56_sms_messages_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_NP_56_SMS_MESSAGES_CONTACTS_FROM_CONTACTS_TITLE',
);
$dictionary["np_56_SMS_Messages"]["fields"]["np_56_sms_messages_contacts_name"] = array (
  'name' => 'np_56_sms_messages_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_NP_56_SMS_MESSAGES_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'np_56_sms_25fbontacts_ida',
  'link' => 'np_56_sms_messages_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["np_56_SMS_Messages"]["fields"]["np_56_sms_25fbontacts_ida"] = array (
  'name' => 'np_56_sms_25fbontacts_ida',
  'type' => 'link',
  'relationship' => 'np_56_sms_messages_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_NP_56_SMS_MESSAGES_CONTACTS_FROM_NP_56_SMS_MESSAGES_TITLE',
);
