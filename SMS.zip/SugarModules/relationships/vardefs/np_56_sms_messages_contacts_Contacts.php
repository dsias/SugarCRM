<?php
// created: 2015-03-25 22:27:57
$dictionary["Contact"]["fields"]["np_56_sms_messages_contacts"] = array (
  'name' => 'np_56_sms_messages_contacts',
  'type' => 'link',
  'relationship' => 'np_56_sms_messages_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_NP_56_SMS_MESSAGES_CONTACTS_FROM_NP_56_SMS_MESSAGES_TITLE',
);
