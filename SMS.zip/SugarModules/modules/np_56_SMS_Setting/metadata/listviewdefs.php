<?php
$module_name = 'np_56_SMS_Setting';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'USER_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_USER_ID',
    'width' => '10%',
    'default' => true,
  ),
  'PASSWORD' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PASSWORD',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
?>
