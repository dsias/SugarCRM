<?php
$module_name = 'np_56_SMS_Messages';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      0 => 'name',
      1 => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'message' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_MESSAGE',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'message',
      ),
      'np_56_sms_messages_contacts_name' => 
      array (
        'type' => 'relate',
        'link' => 'np_56_sms_messages_contacts',
        'label' => 'LBL_NP_56_SMS_MESSAGES_CONTACTS_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'name' => 'np_56_sms_messages_contacts_name',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
