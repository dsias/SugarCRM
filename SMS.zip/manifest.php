    <?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

    $manifest = array (
         'acceptable_sugar_versions' => 
          array (
            
          ),
          'acceptable_sugar_flavors' =>
          array(
            'CE', 'PRO','ENT'
          ),
          'readme'=>'',
          'key'=>'np_56',
          'author' => '',
          'description' => 'LittoChacko',
          'icon' => '',
          'is_uninstallable' => true,
          'name' => 'New_Package56',
          'published_date' => '2015-03-26 05:27:56',
          'type' => 'module',
          'version' => '1427347676',
          'remove_tables' => 'prompt',
          );
$installdefs = array (
  'id' => 'New_Package56',
  'beans' => 
  array (
    0 => 
    array (
      'module' => 'np_56_SMS_Messages',
      'class' => 'np_56_SMS_Messages',
      'path' => 'modules/np_56_SMS_Messages/np_56_SMS_Messages.php',
      'tab' => true,
    ),
    1 => 
    array (
      'module' => 'np_56_SMS_Setting',
      'class' => 'np_56_SMS_Setting',
      'path' => 'modules/np_56_SMS_Setting/np_56_SMS_Setting.php',
      'tab' => true,
    ),
  ),
  'layoutdefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
      'to_module' => 'Contacts',
    ),
  ),
  'relationships' => 
  array (
    0 => 
    array (
      'meta_data' => '<basepath>/SugarModules/relationships/relationships/np_56_sms_messages_contactsMetaData.php',
    ),
  ),
  'image_dir' => '<basepath>/icons',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/modules/np_56_SMS_Messages',
      'to' => 'modules/np_56_SMS_Messages',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/modules/np_56_SMS_Setting',
      'to' => 'modules/np_56_SMS_Setting',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/np_56_SMS_Messages.php',
      'to_module' => 'np_56_SMS_Messages',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    2 => 
    array (
      'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
  ),
  'vardefs' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/np_56_sms_messages_contacts_np_56_SMS_Messages.php',
      'to_module' => 'np_56_SMS_Messages',
    ),
    1 => 
    array (
      'from' => '<basepath>/SugarModules/relationships/vardefs/np_56_sms_messages_contacts_Contacts.php',
      'to_module' => 'Contacts',
    ),
  ),
  'layoutfields' => 
  array (
    0 => 
    array (
      'additional_fields' => 
      array (
      ),
    ),
  ),
);