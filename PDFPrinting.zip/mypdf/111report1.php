<?php

	require_once '../config.php';
	session_start();  
	if($_SESSION['authenticated_user_id'])
	{

	}
	else
	{
		die("Invalid Access");
	}
	$conn2=mysql_connect($sugar_config['dbconfig']['db_host_name'],$sugar_config['dbconfig']['db_user_name'],$sugar_config['dbconfig']['db_password']);
	if (!$conn2)
	{
		die('Could not connect to database');
		
	}
	$db1 = mysql_select_db($sugar_config['dbconfig']['db_name'],$conn2);
		


require('mc_table1.php');

$pdf=new PDF_MC_Table();
$pdf->AddPage('L');
$pdf->SetSubject("sarfaraz",true);
$pdf->SetAuthor("sarfaraz",true);
$pdf->SetTitle("sarfaraz",true);
$pdf->SetCreator("sarfaraz",true);
$pdf->SetKeywords("sarfaraz",true);
$pdf->SetFont('Arial','B',22);
$pdf->SetTextColor(23,14,204);
$pdf->Image('../custom/themes/default/images/company_logo.png',10,02,-1300);
$pdf->Cell(0,0,'Retention Report',0,0,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','B',10);

$header = array('# of pages sold','Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov','Dec' );

$pdf->Ln(4);
// Column widths
$head=0;
$k = 0;
while($r < 12)
{

	$r++;
	if ($head==0)
	{
		$head++;
		$pdf->SetWidths(array(40,20,20,20,20,20,20,20,20,20,20,20,20));
		$pdf->Head_Row(array('# of pages sold','Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov','Dec'));

	}

//	echo(strlen($row['name'])."<br>");
	
	$pdf->SetTextColor(0,0,0);
//     $x=$pdf->GetX();
//     $y=$pdf->GetY();

	$r1 = date('M',mktime(0, 0, 0, $r, 1, 2000));
	
	$pdf->SetFont('Arial','',9);
		$pdf->SetWidths(array(40,20,20,20,20,20,20,20,20,20,20,20,20));
	
	$pdf->Row(array($r1.' Retained','',$row['date_added'],$row['cmonpay'],$row['active'],$row['base_line'],$row['pause_date'],$row['rpt_update'],$row['lx_update'],$row['ww_update'],$row['bb_update'],$row['which_bb'],''));

}

$pdf->Ln(2);
$pdf->SetFont('Arial','I',8);
$pdf->Write(4,'This is a computer generated report from rankpop-CRM @ '.date('m/d/Y h:i a'));

$pdf->Output();
?>