<?php

$db = DBManagerFactory::getInstance();

// Report Parameters
$accountid=$_GET['record'];

$p1 = "";
$p2 = "";
$p3 = "";
$p4 = "";
$p5 = "";




// $sql = "
// SELECT * 
// FROM pa_attendance a
// WHERE a.deleted=0 $p1 $p2 $p3 $p4 $p5
// ORDER BY attendance_date_time
// ";
// //echo $sql;
// $results = $db->query($sql);


$sql1 = "SELECT * FROM `accounts` c, `accounts_cstm` cc WHERE c.`id`=cc.`id_c` AND  c.`id` = '$accountid'";

$results1 = $db->query($sql1);
$row1 = $db->fetchByAssoc($results1);



require('mypdf/mc_table_1.php');

$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage('L');
$pdf->SetSubject("Litto",true);
$pdf->SetAuthor("Litto",true);
$pdf->SetTitle("Client Reports",true);
$pdf->SetCreator("Litto",true);
$pdf->SetKeywords("Litto",true);
//$pdf->Image('img/header.png',10,10,-240);
//$pdf->Image('img/globe-sindh.png',10,3,0);
//$pdf->Image('img/mec_logo.png',268,6,-220);


$pdf->Image('modules/Accounts/default.png',8,9,26,30);


$pdf->Ln(6);
$pdf->SetFont('Arial','B',18);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(50);
$pdf->Cell(0,0,'Client Report',0,0,'C');
$pdf->Ln(8);
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);


if($row1['name']!="")
{
$pdf->Cell(0,0,'Name: '.$row1['name'],0,0,'R');
$pdf->Ln(4);
}
if($row1['phone_office']!="")
{
$pdf->Cell(0,0,'Phone: '.$row1['phone_office'],0,0,'R');
$pdf->Ln(4);
}

if($row1['billing_address_city']!="" || $row1['billing_address_state']!="" )
{
$pdf->Cell(0,0,$row1['billing_address_city'].'-'.$row1['billing_address_state'],0,0,'R');
$pdf->Ln(4);
}


if($row1['billing_address_street']!="")
{
$pdf->Cell(0,0,'Address: '.$row1['billing_address_street'],0,0,'R');
$pdf->Ln(4);
}
if($row1['billing_address_country']!="")
{
$pdf->Cell(0,0,'Country: '.$row1['billing_address_country'],0,0,'R');
$pdf->Ln(4);
}



if($row1['passport_no_c']!="")
{
$pdf->Cell(0,0,'Passport No.: '.$row1['passport_no_c'],0,0,'R');
$pdf->Ln(4);
}
if($row1['cnic_no_c']!="")
{
$pdf->Cell(0,0,'CNIC No.: '.$row1['cnic_no_c'],0,0,'R');
$pdf->Ln(4);
}

if($row1['accountid_c']!="")
{
$pdf->Cell(0,0,'Ref No.: '.$row1['accountid_c'],0,0,'L');
$pdf->Ln(4);
}


//Investment Transactions

$sql3 ="SELECT * from `proxy_invester` c, `proxy_invester_cstm` cc WHERE c.`id`=cc.`id_c` AND cc.`account_id_c`='$accountid' AND c.`deleted`=0";
		$row3 =$db->query($sql3);
		$investerdet =$db->fetchByAssoc($row3);
		$investerid=$investerdet['id'];

		


$sql3 ="select * from `proxy_invester_proxy_investment_1_c` where `proxy_invester_proxy_investment_1proxy_invester_ida`='". $investerid ."' and `deleted`=0";
		$row3 =$db->query($sql3);	
  $results88 =$db->query($sql3);
		$rt00=$db->fetchByAssoc($results88);

		if($rt00['id']!=''){


$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Investment Transactions',0,0,'C');
$pdf->Ln(4);

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('#','Name(Trans No)','Unit No','Agreement Date.', 'From date','To Date','Amount');


$pdf->Ln(2);
$pdf->Ln(2);
$head=0;
$sno=0;

while($row_other = $db->fetchByAssoc($row3)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

$invid=$row_other['proxy_invester_proxy_investment_1proxy_investment_idb'];

 $sql4 ="select * from `proxy_investment` c, `proxy_investment_cstm` cc where c.`id`=cc.`id_c`  AND c.`id`='$invid' AND c.`deleted`='0'";
$row4 =$db->query($sql4);
$invdet =$db->fetchByAssoc($row4);

$sql5 ="select * from `proxy_propertyunits_proxy_investment_1_c` where `proxy_propertyunits_proxy_investment_1proxy_investment_idb`='".$invid."' and `deleted`=0";
$row5 =$db->query($sql5);
$unittrandet =$db->fetchByAssoc($row5);
$unitid1=$unittrandet['proxy_propertyunits_proxy_investment_1proxy_propertyunits_ida'];

 $sql5 ="select * from `proxy_propertyunits` where `id`='$unitid1'";
		$row5 =$db->query($sql5);
		$unitdet1 =$db->fetchByAssoc($row5);
	
$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$invdet['name'].'('.$invdet['refid_c'].')',$unitdet1['name'],date('d-m-Y',strtotime($invdet['agreementdate_c'])),date('d-m-Y',strtotime($invdet['fromdate_c'])),date('d-m-Y',strtotime($invdet['todate_c'])),$invdet['amountpaid_c']));

}
}
//rental Transactions

$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$sql3 ="SELECT * from `proxy_tenant` c, `proxy_tenant_cstm` cc WHERE c.`id`=cc.`id_c` AND cc.`account_id_c`='$accountid' AND c.`deleted`=0";
		$row3 =$db->query($sql3);
		$investerdet =$db->fetchByAssoc($row3);
		$tenantid=$investerdet['id'];

$sql3 ="select * from `proxy_tenant_proxy_rental_1_c` where `proxy_tenant_proxy_rental_1proxy_tenant_ida`='". $tenantid ."' and `deleted`=0";
$row7 =$db->query($sql3);
	$i=0;

  $results88 =$db->query($sql3);
		$rt00=$db->fetchByAssoc($results88);

		if($rt00['id']!=''){


$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Rental Transactions',0,0,'C');
$pdf->Ln(4);

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('#','Name(Trans No)','Unit No','Agreement Date.', 'From date','To Date','Amount');



$pdf->Ln(2);
$head=0;
$sno=0;

while($row_other = $db->fetchByAssoc($row7)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

$invid=$row_other['proxy_tenant_proxy_rental_1proxy_rental_idb'];

  $sql4 ="select * from `proxy_rental` c, `proxy_rental_cstm` cc where c.`id`=cc.`id_c`  AND c.`id`='$invid' AND c.`deleted`='0'";
$row4 =$db->query($sql4);
$invdet =$db->fetchByAssoc($row4);

$sql5 ="select * from `proxy_rentalunits_proxy_rental_1_c` where `proxy_rentalunits_proxy_rental_1proxy_rental_idb`='".$invid."' and `deleted`=0";
$row5 =$db->query($sql5);
$unittrandet =$db->fetchByAssoc($row5);
$unitid1=$unittrandet['proxy_rentalunits_proxy_rental_1proxy_rentalunits_ida'];

 $sql5 ="select * from `proxy_rentalunits` where `id`='$unitid1'";
		$row5 =$db->query($sql5);
		$unitdet1 =$db->fetchByAssoc($row5);
	
$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$invdet['name'].'('.$invdet['refid_c'].')',$unitdet1['name'],date('d-m-Y',strtotime($invdet['agreementdate_c'])),date('d-m-Y',strtotime($invdet['fromdate_c'])),date('d-m-Y',strtotime($invdet['todate_c'])),$invdet['amounttopay_c']));


}
}
//Investment Agreements

$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$sql3 ="select * from `proxy_invester_proxy_agreement_1_c` where `proxy_invester_proxy_agreement_1proxy_invester_ida`='". $investerid ."' and `deleted`=0";
		$row3 =$db->query($sql3);	

		  $results88 =$db->query($sql3);
		$rt00=$db->fetchByAssoc($results88);

		if($rt00['id']!=''){

$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Investment Agreements',0,0,'C');
$pdf->Ln(4);

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('#','Name','Unit No','Agreement Ref.', 'Agreement Type','Agreement Status.','Agreement Date');



$pdf->Ln(2);
$head=0;
$sno=0;

while($row_other = $db->fetchByAssoc($row3)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

$invid=$row_other['proxy_invester_proxy_agreement_1proxy_agreement_idb'];

 $sql4 ="select * from `proxy_agreement` c, `proxy_agreement_cstm` cc where c.`id`=cc.`id_c`  AND c.`id`='$invid' AND c.`deleted`='0'";
$row4 =$db->query($sql4);
$invdet =$db->fetchByAssoc($row4);

$sql5 ="select * from `proxy_propertyunits_proxy_agreement_1_c` where `proxy_propertyunits_proxy_agreement_1proxy_agreement_idb`='".$invid."' and `deleted`=0";
$row5 =$db->query($sql5);
$unittrandet =$db->fetchByAssoc($row5);
$unitid1=$unittrandet['proxy_propertyunits_proxy_agreement_1proxy_propertyunits_ida'];

 $sql5 ="select * from `proxy_propertyunits` where `id`='$unitid1'";
		$row5 =$db->query($sql5);
		$unitdet1 =$db->fetchByAssoc($row5);
	
$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$invdet['name'],$unitdet1['name'],$invdet['agreement_ref_c'],$invdet['agreementtype_c'],$invdet['agreementstatus_c'],date('d-m-Y',strtotime($invdet['agreementdate_c']))));

}
}

//Rental Agreements

$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);

$sql3 ="select * from `proxy_tenant_proxy_agreement_1_c` where `proxy_tenant_proxy_agreement_1proxy_tenant_ida`='". $tenantid ."' and `deleted`=0";
		$row3 =$db->query($sql3);	

		  $results88 =$db->query($sql3);
		$rt00=$db->fetchByAssoc($results88);

		if($rt00['id']!=''){

$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Rental Agreements',0,0,'C');
$pdf->Ln(4);

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('#','Name','Unit No','Agreement Ref.', 'Agreement Type','Agreement Status.','Agreement Date');



$pdf->Ln(2);
$head=0;
$sno=0;

while($row_other = $db->fetchByAssoc($row3)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

$invid=$row_other['proxy_tenant_proxy_agreement_1proxy_agreement_idb'];

  $sql4 ="select * from `proxy_agreement` c, `proxy_agreement_cstm` cc where c.`id`=cc.`id_c`  AND c.`id`='$invid' AND c.`deleted`='0'";
$row4 =$db->query($sql4);
$invdet =$db->fetchByAssoc($row4);

$sql5 ="select * from `proxy_rentalunits_proxy_agreement_1_c` where `proxy_rentalunits_proxy_agreement_1proxy_agreement_idb`='".$invid."' and `deleted`=0";
$row5 =$db->query($sql5);
$unittrandet =$db->fetchByAssoc($row5);
$unitid1=$unittrandet['proxy_rentalunits_proxy_agreement_1proxy_rentalunits_ida'];

$sql5 ="select * from `proxy_rentalunits` where `id`='$unitid1'";
		$row5 =$db->query($sql5);
		$unitdet1 =$db->fetchByAssoc($row5);
	
$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$invdet['name'],$unitdet1['name'],$invdet['agreement_ref_c'],$invdet['agreementtype_c'],$invdet['agreementstatus_c'],date('d-m-Y',strtotime($invdet['agreementdate_c']))));

}

}

//Investment Cheques

$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$sql3 ="select * from `proxy_invester_proxy_cheque_1_c` where `proxy_invester_proxy_cheque_1proxy_invester_ida`='". $investerid ."' and `deleted`=0";
		$row3 =$db->query($sql3);	


  $results88 =$db->query($sql3);
		$rt00=$db->fetchByAssoc($results88);

		if($rt00['id']!=''){		

$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Investment Cheque History',0,0,'C');
$pdf->Ln(4);

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('#','Name','Unit No','Trans No.', 'Cheque No.','Amount.','Cheque Date');



$pdf->Ln(2);
$head=0;
$sno=0;

while($row_other = $db->fetchByAssoc($row3)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

$invid=$row_other['proxy_invester_proxy_cheque_1proxy_cheque_idb'];

 $sql4 ="select * from `proxy_cheque` c, `proxy_cheque_cstm` cc where c.`id`=cc.`id_c`  AND c.`id`='$invid' AND c.`deleted`='0'";
$row4 =$db->query($sql4);
$invdet =$db->fetchByAssoc($row4);

$sql5 ="select * from `proxy_propertyunits_proxy_cheque_1_c` where `proxy_propertyunits_proxy_cheque_1proxy_cheque_idb`='".$invid."' and `deleted`=0";
$row5 =$db->query($sql5);
$unittrandet =$db->fetchByAssoc($row5);
$unitid1=$unittrandet['proxy_propertyunits_proxy_cheque_1proxy_propertyunits_ida'];

 $sql5 ="select * from `proxy_propertyunits` where `id`='$unitid1'";
		$row5 =$db->query($sql5);
		$unitdet1 =$db->fetchByAssoc($row5);
	
$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$invdet['name'],$unitdet1['name'],$invdet['cheque_ref_c'],$invdet['cheque_no_c'],$invdet['amount_c'],date('d-m-Y',strtotime($invdet['cheque_date_c']))));

}

}

//Rental Cheques

$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);
$pdf->Ln(2);

$sql3 ="select * from `proxy_tenant_proxy_cheque_1_c` where `proxy_tenant_proxy_cheque_1proxy_tenant_ida`='". $tenantid ."' and `deleted`=0";
		$row3 =$db->query($sql3);

		  $results88 =$db->query($sql3);
		$rt00=$db->fetchByAssoc($results88);

		if($rt00['id']!=''){	

$pdf->SetFont('Arial','B',15);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,0,'Rental Cheque History',0,0,'C');
$pdf->Ln(4);

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0,0,0);
$header = array('#','Name','Unit No','Trans No.', 'Cheque No.','Amount.','Cheque Date');



$pdf->Ln(2);
$head=0;
$sno=0;

while($row_other = $db->fetchByAssoc($row3)) 
{
	
	if ($head==0)
	{
		$head++;
		$w = array(10,65,36,36,36,36,59);
		$pdf->SetWidths($w);
		$pdf->Head_Row($header);
	}

$invid=$row_other['proxy_tenant_proxy_cheque_1proxy_cheque_idb'];

 $sql4 ="select * from `proxy_cheque` c, `proxy_cheque_cstm` cc where c.`id`=cc.`id_c`  AND c.`id`='$invid' AND c.`deleted`='0'";
$row4 =$db->query($sql4);
$invdet =$db->fetchByAssoc($row4);

$sql5 ="select * from `proxy_rentalunits_proxy_cheque_1_c` where `proxy_rentalunits_proxy_cheque_1proxy_cheque_idb`='".$invid."' and `deleted`=0";
$row5 =$db->query($sql5);
$unittrandet =$db->fetchByAssoc($row5);
$unitid1=$unittrandet['proxy_rentalunits_proxy_cheque_1proxy_rentalunits_ida'];

 $sql5 ="select * from `proxy_rentalunits` where `id`='$unitid1'";
		$row5 =$db->query($sql5);
		$unitdet1 =$db->fetchByAssoc($row5);
	
$pdf->SetFont('Arial','',9);
	$pdf->SetTextColor(0,0,0);
	$pdf->SetWidths($w);

	$sno++;

	$pdf->Row(array($sno.".",$invdet['name'],$unitdet1['name'],$invdet['cheque_ref_c'],$invdet['cheque_no_c'],$invdet['amount_c'],date('d-m-Y',strtotime($invdet['cheque_date_c']))));

}
}


$pdf->SetLeftMargin(8);

$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);

$pdf->Ln(6);

$pdf->Ln(6);
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(0,0,0);

//$pdf->Ln(4);
//$pdf->Cell(0,0,'Total Remaining Leave Day(s): '.($total_available_leave-$total_leave),0,0);
$pdf->Ln(4);
$pdf->Cell(0,0,'Authorized Signature: ',0,0,'L');


$pdf->Ln(4);
$pdf->Cell(0,0,'Date: '.date('d-m-Y'),0,0,'R');


$pdf->Output();


?>