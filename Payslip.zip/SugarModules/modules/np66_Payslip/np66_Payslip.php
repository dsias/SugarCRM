<?PHP
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/np66_Payslip/np66_Payslip_sugar.php');
class np66_Payslip extends np66_Payslip_sugar {
	
	function np66_Payslip(){	
		parent::np66_Payslip_sugar();
	}
	

	function save($check_notify = FALSE){
		$n = $_POST['name'];

		if($_POST['duplicateSave']=='true')
			$k[1] = "";
		else
			$k = explode("-",$n);

		if($k[1]=="")
		{
			global $db;
			$d = date('dmy')."-".date('gis')."-".date('Y');

			$_POST['name']="PS-".$d;
			$this->name = $_POST['name'];
		}
		
		parent::save($check_notify);

//		if(isset($_POST['acase_id_c'])){
			$this->saveListItems();
//		}
	}



	function saveListItems(){
		
		
		require_once('modules/np66_PayslipDetail/np66_PayslipDetail.php');
		$productQuote = new np66_PayslipDetail();

		$product = array('id' => $_POST['payslip_detail_id'],
						 'employee_name' => $_POST['employee_name'],
						 'employee_id' => $_POST['employee_id'],						 
						 'crm_user_name' => $_POST['crm_user_name'],						 
						 'other_detail' => $_POST['other_detail'],
						 'fines' => $_POST['fines'],
						 'deduction' => $_POST['deduction'],						 
						 'line_deleted' => $_POST['line_deleted']);
							 
		$productLineCount = count($product['employee_name']);
		
		$j = 0;
		
		for ($i = 0; $i < $productLineCount; $i++) {
			if($_POST['duplicateSave']=='true')
				$productQuote->id = "";
			else	
				$productQuote->id = $product['id'][$i];
				
			$productQuote->np66_payslip_id_c = $this->id;
			$productQuote->name = $this->payslip_month."-".$this->payslip_year;
			$productQuote->employee_id = $product['employee_id'][$i];
			$productQuote->employee_name = $product['employee_name'][$i];
			$productQuote->crm_user_name = $product['crm_user_name'][$i];
			$productQuote->other_detail = $product['other_detail'][$i];			
			$productQuote->fines = $product['fines'][$i];			
			$productQuote->deduction = $product['deduction'][$i];									

			$productQuote->deleted = $product['line_deleted'][$i];
			$productQuote->assigned_user_id=$this->assigned_user_id;
				
			if ($productQuote->deleted == 1) {
				$productQuote->mark_deleted($productQuote->id);
			} else {
				if( trim($productQuote->employee_name) != ''){
					$productQuote->save();
				}
			}
		}
	}


	
	
}
?>