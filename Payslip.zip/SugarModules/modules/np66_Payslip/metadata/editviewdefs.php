<?php
$module_name = 'np66_Payslip';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
            'customCode' => '{$fields.name.value}<input type="hidden" id="name" name="name" value="{$fields.name.value}"/>',
          ),
          1 => 
          array (
            'name' => 'payslip_status',
            'studio' => 'visible',
            'label' => 'LBL_PAYSLIP_STATUS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'payslip_month',
            'studio' => 'visible',
            'label' => 'LBL_PAYSLIP_MONTH',
			'customLabel' => 'Payslip Month - Year:',
			'customCode' => '{html_options name="payslip_month" id="payslip_month" options=$fields.payslip_month.options selected=$fields.payslip_month.value} &nbsp; - &nbsp; {html_options name="payslip_year" id="payslip_year" options=$fields.payslip_year.options selected=$fields.payslip_year.value}',
			
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'payslip_employees',
            'label' => 'LBL_PAYSLIP_EMPLOYEES',
			'customCode' => '{$EMPLOYEE_DETAIL}',
          ),
        ),
      ),
    ),
  ),
);
?>
