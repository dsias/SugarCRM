<?php
$module_name = 'np66_Payslip';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      0 => 'name',
      1 => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
      ),
    ),
    'advanced_search' => 
    array (
      'date_modified' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_MODIFIED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_modified',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'payslip_month' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_PAYSLIP_MONTH',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'payslip_month',
      ),
      'payslip_year' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_PAYSLIP_YEAR',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'payslip_year',
      ),
      'payslip_status' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_PAYSLIP_STATUS',
        'sortable' => false,
        'width' => '10%',
        'name' => 'payslip_status',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'label' => 'LBL_ASSIGNED_TO',
        'type' => 'enum',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
