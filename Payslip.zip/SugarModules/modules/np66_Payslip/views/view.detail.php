<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class np66_PayslipViewDetail extends ViewDetail {
	var $currSymbol;
	function np66_PayslipViewDetail(){
 		parent::ViewDetail();
 	}
	
	function display(){
		$this->populateLineItems();
		parent::display();
	}
	
	function populateLineItems(){
		global $app_strings, $mod_strings, $app_list_strings;
		
  		$sql = "SELECT * FROM np66_payslipdetail WHERE np66_payslip_id_c = '".$this->bean->id."' AND deleted = 0";
		$result = $this->bean->db->query($sql);
		$countLine = $this->bean->db->getRowCount($result);
		$sep = get_number_seperators();
		
		$html = "";
		$html .= "<table border='0' width='100%' cellpadding='0' cellspacing='0'>";
		
		if($countLine != 0)
		{
			$html .= "<tr>";
			$html .= "<td width='5%' class='tabDetailViewDL' style='text-align: left;padding:2px;'>&nbsp;</td>";
			$html .= "<td width='5%' class='tabDetailViewDL' style='text-align: left;padding:2px;' scope='row'>Employee ID</td>";			
			$html .= "<td width='5%' class='tabDetailViewDL' style='text-align: left;padding:2px;' scope='row'>Employee Name</td>";			
			$html .= "<td width='5%' class='tabDetailViewDL' style='text-align: left;padding:2px;' scope='row'>CRM User Name</td>";			

			$html .= "<td width='15%' class='tabDetailViewDL' style='text-align: left;padding:2px;' scope='row'>Other Detail</td>";
			$html .= "<td width='5%' class='tabDetailViewDL' style='text-align: left;padding:2px;' scope='row'>Fines</td>";			
			$html .= "<td width='5%' class='tabDetailViewDL' style='text-align: left;padding:2px;' scope='row'>Deduction</td>";						
			$html .= "</tr>";
		}
		$i = 1;
		$strk = "";
		while ($row = $this->bean->db->fetchByAssoc($result)) {

			$pd = new np66_PayslipDetail;
			$pd->retrieve($row['id']);
							
			$html .= "<tr $strk>";

			$html .= "<td class='tabDetailViewDF' style='text-align: left; padding:2px;'>".$i++."</td>";
			$html .= "<td class='tabDetailViewDF' style='padding:2px;'>".$pd->employee_id."</td>";			
		  	$html .= "<td class='tabDetailViewDF' style='padding:2px;'> ".$pd->employee_name."</td>";
			$html .= "<td class='tabDetailViewDF' style='padding:2px;'>".$pd->crm_user_name."</td>";			

			$html .= "<td class='tabDetailViewDF' style='padding:2px;'>".$pd->other_detail."</td>";			
			$html .= "<td class='tabDetailViewDF' style='padding:2px;'>".number_format($pd->fines,2,'.',',')."</td>";			
			$html .= "<td class='tabDetailViewDF' style='padding:2px;'>".number_format($pd->deduction,2,'.',',')."</td>";			

			$html .= "</tr>";
		}
		$html .= "</table>";
		
		$this->ss->assign('EMPLOYEE_DETAIL',$html);
	}
	
}
?>
