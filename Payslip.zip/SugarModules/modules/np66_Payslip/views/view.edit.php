<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.edit.php');

class np66_PayslipViewEdit extends ViewEdit {
	function np66_PayslipViewEdit(){
 		parent::ViewEdit();
 	}
	
	function display(){
		$this->populateLineItems();
		parent::display();
		$this->displayJS();
	}
	
	function populateLineItems(){
	
		global $locale, $app_list_strings, $app_strings, $mod_strings, $popup_request_data, $sugar_config;
		
		if (empty($this->bean->fetched_row['id']))  // New Record
		{ 
			$html = "";
			
			$sql = "SELECT * FROM pa_EmployeeDetail WHERE deleted=0 and employee_status='Active'";
	  		$result = $this->bean->db->query($sql);
			$header=0;
			while ($row = $this->bean->db->fetchByAssoc($result)) 
			{
				$ed = new pa_EmployeeDetail;
				$ed->retrieve($row['id']);
				$header++;
		
				$html .= "<table border='0' cellspacing='4'width='37.5%' id='productLine'>";
				if($header==1)
				{			
					$html .= "<tr id='productHeader'>";
					$html .= "<td width='25%' class='dataLabel' style='text-align: left;'>Employee ID</td>";
					$html .= "<td width='25%' class='dataLabel' style='text-align: left;'>Employee Name</td>";
					$html .= "<td width='25%' class='dataLabel' style='text-align: left;'>CRM User Name</td>";
					$html .= "<td width='10%' class='dataLabel' style='text-align: left;'>Other Detail</td>";
					$html .= "<td width='25%' class='dataLabel' style='text-align: left;'>Fines</td>";
					$html .= "<td width='15%' class='dataLabel' style='text-align: left;'>Deduction</td>";

					$html .= "</tr>";
				}

				$html .= "<tr id='tr$i'>";

			  	$html .= "<td class='dataField'><input  autocomplete='off' tabindex='116' type='text' name='employee_id[$i]' id='employee_id$i' size='10' value='".$ed->employee_id."' style='background-color:#CCC; font-weight:bold' readonly='readonly' title=''><input type='hidden' id='payslip_detail_id$i' name='payslip_detail_id[$i]' value='' /></td>";

			  	$html .= "<td class='dataField'><input  autocomplete='off' tabindex='116' type='text' name='employee_name[$i]' id='employee_name$i' size='30' value='".$ed->first_name." ".$ed->last_name."' style='background-color:#CCC; font-weight:bold' readonly='readonly' title=''></td>";

			  	$html .= "<td class='dataField'><input  autocomplete='off' tabindex='116' type='text' name='crm_user_name[$i]' id='crm_user_name$i' size='25' value='".$ed->crm_user."' style='background-color:#CCC; font-weight:bold' readonly='readonly' title=''></td>";

			  	$html .= "<td class='dataField'><textarea name='other_detail[$i]' id='other_detail$i' style='background-color:#CCC; font-weight:bold' readonly='readonly'>paki</textarea></td>";


			  	$html .= "<td class='dataField'><input  autocomplete='off' tabindex='116' type='text' name='fines[$i]' id='fines$i' size='10' value='' style='text-alignment: right'  title=''></td>";

			  	$html .= "<td class='dataField'><input  autocomplete='off' tabindex='116' type='text' name='deduction[$i]' id='deduction$i' size='10' value='' style='text-alignment: right'  title=''><input type='hidden' id='line_delete$i' name='line_delete[$i]' value='0' /></td>";

			
				$html .= "</tr>";		
				$html .= "</table>";




				
			}
			

			
			$this->ss->assign('EMPLOYEE_DETAIL',$html);
		}  
		else // Edit existing Record
		{
			$this->ss->assign('EMPLOYEE_DETAIL',"Edit Record");			
		}

		
	}
	
	function displayJS(){
		global $app_strings, $mod_strings;
		echo "
			<script type=\"text/javascript\">
				var selectButtonTitle = '". $app_strings['LBL_SELECT_BUTTON_TITLE'] . "';
				var selectButtonKey	  = '". $app_strings['LBL_SELECT_BUTTON_KEY'] . "';
				var selectButtonValue = '". $app_strings['LBL_SELECT_BUTTON_LABEL'] . "';
				var deleteButtonValue = '". $mod_strings['LBL_REMOVE_PRODUCT_LINE'] . "';";
		
		$js=<<<JS
			if(typeof sqs_objects == 'undefined'){var sqs_objects = new Array;}
	sqs_objects['EditView_billing_account']={"form":"EditView","method":"query","modules":["Accounts"],"group":"or","field_list":["name","id","billing_address_street","billing_address_city","billing_address_state","billing_address_postalcode","billing_address_country","shipping_address_street","shipping_address_city","shipping_address_state","shipping_address_postalcode","shipping_address_country"],"populate_list":["EditView_billing_account","billing_account_id","billing_address_street","billing_address_city","billing_address_state","billing_address_postalcode","billing_address_country","shipping_address_street","shipping_address_city","shipping_address_state","shipping_address_postalcode","shipping_address_country"],"conditions":[{"name":"name","op":"like_custom","end":"%","value":""}],"required_list":["billing_account_id"],"order":"name","limit":"30","no_match_text":"No Match"};			
	document.getElementById('btn_billing_account').onclick = function() {
	open_popup('Accounts', 800, 851, '', true, false, {'call_back_function':'set_return','form_name':'EditView','field_to_name_array':{'id':'billing_account_id','name':'billing_account','billing_address_street':'billing_address_street','billing_address_city':'billing_address_city','billing_address_state':'billing_address_state','billing_address_postalcode':'billing_address_postalcode','billing_address_country':'billing_address_country','shipping_address_street':'shipping_address_street','shipping_address_city':'shipping_address_city','shipping_address_state':'shipping_address_state','shipping_address_postalcode':'shipping_address_postalcode','shipping_address_country':'shipping_address_country'}}, 'single', true);
	}
	document.getElementById('btn_billing_contact').onclick = function() {
	open_popup('Contacts', 800, 851, '&account_name='+ document.getElementById('billing_account').value , true, false, {'call_back_function':'set_return','form_name':'EditView','field_to_name_array':{'id':'billing_contact_id','name':'billing_contact'}},'single', true);
	}

JS;
		echo $js;				
		echo "</script>
			";
	}
}
?>
