<?php
$module_name = 'np66_PayslipDetail';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'EMPLOYEE_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_ID',
    'width' => '10%',
    'default' => true,
  ),
  'EMPLOYEE_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'CRM_USER_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CRM_USER_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'FINES' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_FINES',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'DEDUCTION' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_DEDUCTION',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PAYSLIP' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PAYSLIP',
    'width' => '10%',
    'default' => true,
  ),
  'OTHER_DETAIL' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_OTHER_DETAIL',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'created_by_link',
    'label' => 'LBL_CREATED',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'modified_user_link',
    'label' => 'LBL_MODIFIED_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
);
?>
