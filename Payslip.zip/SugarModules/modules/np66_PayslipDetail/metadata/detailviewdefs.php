<?php
$module_name = 'np66_PayslipDetail';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
          1 => 
          array (
            'name' => 'payslip',
            'studio' => 'visible',
            'label' => 'LBL_PAYSLIP',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'employee_id',
            'label' => 'LBL_EMPLOYEE_ID',
          ),
          1 => '',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'employee_name',
            'label' => 'LBL_EMPLOYEE_NAME',
          ),
          1 => 
          array (
            'name' => 'crm_user_name',
            'label' => 'LBL_CRM_USER_NAME',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'fines',
            'label' => 'LBL_FINES',
          ),
          1 => 
          array (
            'name' => 'deduction',
            'label' => 'LBL_DEDUCTION',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'other_detail',
            'studio' => 'visible',
            'label' => 'LBL_OTHER_DETAIL',
          ),
        ),
      ),
    ),
  ),
);
?>
