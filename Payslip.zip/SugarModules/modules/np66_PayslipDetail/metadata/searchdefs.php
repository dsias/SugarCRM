<?php
$module_name = 'np66_PayslipDetail';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'employee_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_EMPLOYEE_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'employee_name',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'employee_id' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_EMPLOYEE_ID',
        'width' => '10%',
        'default' => true,
        'name' => 'employee_id',
      ),
      'employee_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_EMPLOYEE_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'employee_name',
      ),
      'crm_user_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CRM_USER_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'crm_user_name',
      ),
      'fines' => 
      array (
        'type' => 'currency',
        'label' => 'LBL_FINES',
        'currency_format' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'fines',
      ),
      'deduction' => 
      array (
        'type' => 'currency',
        'label' => 'LBL_DEDUCTION',
        'currency_format' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'deduction',
      ),
      'payslip' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PAYSLIP',
        'width' => '10%',
        'default' => true,
        'name' => 'payslip',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
